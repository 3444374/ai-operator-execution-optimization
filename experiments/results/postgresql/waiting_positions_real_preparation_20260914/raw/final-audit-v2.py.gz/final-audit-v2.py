from pathlib import Path
import json,hashlib,subprocess,os,sys
import psutil
from src.experiments.postgresql.query_workloads import read_prepared
from src.baselines.common.private_artifacts import write_private_json
from src.baselines.common.redact import redact_text
base=Path('<artifact-root>');source=base/'source'
snapshot=json.loads((base/'source-snapshot-v2.json').read_text())
for name,digest in snapshot['files'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
sets={}
for key in ('tuning','evaluation'):
 rows=list(read_prepared(base/'inputs'/key/'manifest.json','raw.jsonl'))
 sets[key]=dict(movies={r[2] for r in rows},ids={r[4] for r in rows},texts={hashlib.sha256(r[3].encode()).hexdigest() for r in rows})
for key in sets['tuning']:assert not sets['tuning'][key]&sets['evaluation'][key]
fixture=json.loads((base/'controlled/m1/fixture-summary.json').read_text());assert fixture['fixture_posts']==128 and fixture['actual_model_posts']==0
assert fixture['active_http']==0 and fixture['server_stopped']
run=json.loads((base/'controlled.json').read_text());assert run['status']=='passed'
c=json.loads((base/'campaign-config-v2.json').read_text());assert c['authorization']['approved'] is False
inspect=subprocess.run([sys.executable,str(base/'run-model.py'),str(base/'campaign-config-v2.json'),'--inspect'],capture_output=True,text=True)
assert inspect.returncode==0
(base/'inspect-v2.log').write_text(redact_text(inspect.stdout+inspect.stderr))
excluded={os.getpid(),*(p.pid for p in psutil.Process().parents())};remaining=[]
for p in psutil.process_iter(['cmdline','status']):
 try:
  if p.pid not in excluded and p.info['status']!=psutil.STATUS_ZOMBIE and any(str(base) in a for a in p.info['cmdline'] or []):remaining.append(p.pid)
 except (psutil.NoSuchProcess,psutil.AccessDenied):pass
assert not remaining
report=dict(status='prepared_not_executed',actual_model_posts=0,controlled_posts=128,controlled_queries=8,
 source_commit=snapshot['commit'],source_files_verified=len(snapshot['files']),tests=22,
 source_partitions_disjoint=['movie ID','review ID','exact review text'],
 campaign=dict(max_posts=44544,max_seconds=1800,approval_pending=True,real_run_directory_exists=(base/'real-run').exists()),
 cleanup=run['cleanup'],remaining_task_processes=remaining,
 gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.used,utilization.gpu','--format=csv,noheader'],text=True),
 controller_sha256=hashlib.sha256((base/'run-model.py').read_bytes()).hexdigest())
assert not report['campaign']['real_run_directory_exists']
write_private_json(base/'final-audit-v2.json',report);print(json.dumps(report))
