from pathlib import Path
import os,subprocess,json,hashlib
root=Path('<artifact-root>');source=root/'source'
python='<driver-venv>/bin/python'
from src.baselines.common.redact import redact_text
envfile=root/'runtime.env'
envfile.write_text(Path('<artifact-root>/runtime.env').read_text().replace('<artifact-root>',str(root)));envfile.chmod(0o600)
env=dict(os.environ,AI_OPERATOR_ENV_FILE=str(envfile),PYTHONPATH=str(source/'code'))
for key in ('http_proxy','https_proxy','HTTP_PROXY','HTTPS_PROXY','RAY_ADDRESS'):env.pop(key,None)
r=subprocess.run([python,'code/scripts/environment/manage_environment.py','check','--groups','core,text,semantic-benchmarks','--json-out',str(root/'preflight.json')],cwd=source,env=env,capture_output=True,text=True)
(root/'preflight.log').write_text(redact_text(r.stdout+r.stderr))
assert r.returncode==0
assert json.loads((root/'preflight.json').read_text())['status']=='ok'
old=Path('<source-root>/code/postgres/semloom_pg')
current=source/'code/postgres/semloom_pg'
files={str(p.relative_to(old)):hashlib.sha256(p.read_bytes()).hexdigest() for p in old.rglob('*') if p.is_file() and p.suffix in ('.c','.h')}
assert all(hashlib.sha256((current/p).read_bytes()).hexdigest()==digest for p,digest in files.items())
build=json.loads(Path('<artifact-root>/build.json').read_text())
prefix=Path('/opt/semloom-pg18.3-m1-probe');lib=prefix/'lib/semloom_pg.so'
if not lib.exists():lib=prefix/'lib/postgresql/semloom_pg.so'
assert hashlib.sha256(lib.read_bytes()).hexdigest()==build['library_sha256']
(root/'build-reuse.json').write_text(json.dumps(dict(prior_build=build,c_source_hashes=files,verified_same_library=True),indent=2)+'\n')
print('preflight passed; matching diagnostic PG library reused')
