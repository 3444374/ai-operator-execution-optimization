from pathlib import Path
from statistics import median,stdev,mean
from collections import Counter
import json,hashlib,subprocess
from src.experiments.postgresql.waiting_positions import analyze_waiting_positions
from src.experiments.postgresql.query_evaluation import _evaluate_rows
from src.experiments.postgresql.query_config import QueryConfig
from src.experiments.postgresql.query_inputs import QueryInputs
from src.execution_provider.semantic_map import SemanticMapPlan
from src.baselines.text.sembench_movie import MOVIE_MAP_INSTRUCTION
base=Path('<artifact-root>');root=base/'warm/m1'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=base/'source',text=True)
comparison=json.loads((root/'persistent-comparison.json').read_text());rows=[];groups={}
manifest=json.loads((root/'persistent-input/manifest.json').read_text())
http=json.loads((root/'fixture-http-timing.json').read_text())['rows']
for r in comparison:
 path=root/r['group']/r['unit'];summary=json.loads((path/'summary.json').read_text());assert summary['status']=='passed'
 timing=analyze_waiting_positions(path,expected_rows=32,window=8);assert timing==r['timing']
 cfg=QueryConfig(**summary['config']);inputs=QueryInputs(manifest['kind'],cfg.table,32,manifest['max_source_bytes'],manifest['max_input_bytes'])
 execution=json.loads((path/'q0/execution.json').read_text());raw=(path/'q0/results.jsonl').read_bytes()
 assert len(raw)==execution['recorded_bytes'] and hashlib.sha256(raw).hexdigest()==execution['results_sha256']
 recorded=[json.loads(line)['row'] for line in raw.splitlines()]
 assert len(recorded)==execution['recorded_rows']==32 and execution['query_status']=='completed'
 evaluation=_evaluate_rows(cfg,inputs,SemanticMapPlan(MOVIE_MAP_INSTRUCTION,'fixture-model',128),root/'persistent-input/manifest.json',path,None,recorded)
 assert evaluation==summary['evaluation'];assert evaluation['quality']['invalid']==evaluation['quality']['false_negative']==0
 projection=json.loads((path/'event-projection.json').read_text())
 for name in ('events.jsonl','sessions.jsonl'):
  raw=(path.parent/name).read_bytes()[projection['start_bytes'][name]:projection['end_bytes'][name]]
  original=[json.loads(line) for line in raw.splitlines()]
  expected=original
  if name=='events.jsonl' and projection['added_reference_events']:
   expected=[e for e in map(json.loads,(path.parent/name).read_text().splitlines()) if e['event']=='core_map_organization_config']+original
  assert expected==[json.loads(line) for line in (path/name).read_text().splitlines()]
 execution=json.loads((path/'q0/execution.json').read_text());events=list(map(json.loads,(path/'events.jsonl').read_text().splitlines()))
 arrivals=[h for h in http if execution['t_release_ns']<=h['handler_received_ns']<=execution['t_query_terminal_ns']]
 assert len(arrivals)==32
 assert Counter(h['request_values_sha256'] for h in arrivals)==Counter(e['request_values_sha256'] for e in events if e['event']=='request')
 rss=[json.loads(l) for l in (path/'query-rss.jsonl').read_text().splitlines()]
 rows.append(dict(group=r['group'],repeat=r['repeat'],warmup=r['warmup'],full_s=timing['preparation_to_eof_seconds'],
  preparation_s=timing['preparation_seconds'],sql_s=timing['sql_to_eof_seconds'],http_p99_s=timing['http_p99_seconds'],
  means=timing['mean_seconds'],handler_queue_mean_s=mean((h['service_started_ns']-h['handler_received_ns'])/1e9 for h in arrivals),
  handler_service_mean_s=mean((h['handler_finished_ns']-h['service_started_ns'])/1e9 for h in arrivals),
  peak_summed_rss_bytes=max(s['summed_rss_bytes'] for s in rss),gateway_session=evaluation['association']['gateway_session']))
for group in sorted({r['group'] for r in rows}):
 g=root/group;summary=json.loads((g/'summary.json').read_text());assert summary['status']=='passed'
 assert summary['gateway_exit']==0 and summary['socket_removed']
 assert len(summary['transport_close'])==1 and summary['transport_close'][0]['closed'] and not any(summary['transport_close'][0]['usage'].values())
 samples=[r for r in rows if r['group']==group and not r['warmup']]
 assert len(samples)==5 and sorted(r['gateway_session'] for r in rows if r['group']==group)==list(range(1,7))
 groups[group]=dict(startup_s=(summary['startup_ready_ns']-summary['startup_started_ns'])/1e9,
  full_s=[r['full_s'] for r in samples],median_full_s=median(r['full_s'] for r in samples),
  cv_full=stdev(r['full_s'] for r in samples)/mean(r['full_s'] for r in samples),
  median_sql_s=median(r['sql_s'] for r in samples),median_preparation_s=median(r['preparation_s'] for r in samples),
  median_http_p99_s=median(r['http_p99_s'] for r in samples),
  mean_waits={k:mean(r['means'][k] for r in samples) for k in samples[0]['means']})
fixture=json.loads((root/'fixture-summary.json').read_text());assert fixture['fixture_posts']==768 and fixture['actual_model_posts']==0
assert fixture['active_http']==0 and fixture['server_stopped']
run=json.loads((base/'warm.json').read_text());assert run['status']=='passed'
report=dict(status='passed',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=base/'source',text=True).strip(),
 rows=rows,groups=groups,queries=24,fixture_posts=768,actual_model_posts=0,cleanup=run['cleanup'],fixture=fixture,
 c4_faster_repeats=sum(a<b for a,b in zip(groups['request-c4']['full_s'],groups['request-c8']['full_s'])))
(base/'readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('rows','fixture')},indent=2))
