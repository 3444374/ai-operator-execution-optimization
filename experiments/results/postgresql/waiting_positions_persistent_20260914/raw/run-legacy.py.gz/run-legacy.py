"""Own normal PG qualification and the finite instrumented flow comparison."""
from pathlib import Path
import json,os,pwd,signal,subprocess,time
import psutil
from src.baselines.common.redact import redact_text
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster
root=Path('<artifact-root>');source=root/'source';user=pwd.getpwnam('postgres')
python='<driver-venv>/bin/python'
normal=Path('/opt/semloom-pg18.3-m1-probe')
assert json.loads((root/'preflight.json').read_text())['status']=='ok'
acl_before={str(p):subprocess.check_output(['getfacl','-p',str(p)],text=True) for p in (Path('/root'),root)}
(root/'legacy-acl-before.json').write_text(json.dumps(acl_before,indent=2)+'\n')
started=time.monotonic();report=dict(status='failed',actual_model_posts=0,stages=[])

def run(name,command,env,cwd=source,timeout=300):
    process=subprocess.Popen(['runuser','-u','postgres','--',*command],cwd=cwd,env=env,
                             stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
    try:output,_=process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid,signal.SIGTERM)
        try:output,_=process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);output,_=process.communicate()
        (root/(name+'.log')).write_text(redact_text(output));raise TimeoutError(name+' exceeded deadline')
    (root/(name+'.log')).write_text(redact_text(output))
    report['stages'].append(dict(name=name,exit_code=process.returncode,command=command))
    (root/'legacy.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,'exit',process.returncode,flush=True)
    if process.returncode:raise RuntimeError(name+' failed')

try:
    for p in acl_before:subprocess.run(['setfacl','-m','u:postgres:--x',p],check=True)
    for name in ('pg-legacy','legacy','tmp-legacy'):
        p=root/name;p.mkdir(mode=0o700);os.chown(p,user.pw_uid,user.pw_gid)
    env=dict(os.environ,PYTHONPATH=str(source/'code'),TMPDIR=str(root/'tmp-legacy'),
        PATH=str(Path(python).parent)+':'+str(normal/'bin')+':'+os.environ['PATH'],
        OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PGUSER='postgres',
        SEMLOOM_TEST_SEMBENCH_ROOT='<data-root>/sq-b/sembench-checkout',
        SEMLOOM_TEST_RAY_TMPDIR=str(root/'legacy/ray-unused'))
    run('legacy-contracts',[python,'-m','unittest','-v','tests.experiments.test_persistent_gateway','tests.experiments.test_waiting_positions','tests.experiments.test_flow_timing','tests.experiments.test_query_validation'],env)
    with isolated_pg18_cluster(normal,root/'pg-legacy',user,port=57694) as connection:
        assert connection.execute("SELECT count(*) FROM pg_settings WHERE name LIKE 'semloom_pg.test_flow_%'").fetchone()[0]==4
        env.update(PGHOST=str(root/'pg-legacy/socket'),PGPORT='57694',
            SEMLOOM_TEST_PG_DSN='host='+str(root/'pg-legacy/socket')+' port=57694 user=postgres dbname=postgres',
            SEMLOOM_TEST_PG_LOG=str(root/'pg-legacy/postgres.log'))
        env.update(SEMLOOM_TEST_FLOW_DIAGNOSTIC='1',SEMLOOM_TEST_HTTP_BACKLOG='32',SEMLOOM_TEST_ARTIFACT_ROOT=str(root/'legacy/m1'))
        run('waiting-legacy-pilot',[python,'-m','unittest','-v','tests.experiments.test_database_query_runner_integration.DatabaseQueryRunnerTests.test_total_budget_query_reports_independent_pg_memory'],env,timeout=500)
    report['status']='passed'
except Exception as error:
    report.update(error=redact_text(str(error)),error_type=type(error).__name__)
finally:
    # Stop any owned TAP cluster left by an abnormal test-process exit before restoring ACLs.
    for pid in root.rglob('postmaster.pid'):
        subprocess.run(['runuser','-u','postgres','--',str(normal/'bin/pg_ctl'),'-D',str(pid.parent),'-m','fast','-w','stop'],
                       stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=20)
    for p,acl in acl_before.items():subprocess.run(['setfacl','--restore=-'],input=acl,text=True,check=True)
    after={p:subprocess.check_output(['getfacl','-p',p],text=True) for p in acl_before}
    excluded={os.getpid(),*(p.pid for p in psutil.Process().parents())};remaining=[]
    for p in psutil.process_iter(['cmdline','status']):
        try:
            if p.pid not in excluded and p.info['status']!=psutil.STATUS_ZOMBIE and any(str(root) in a for a in (p.info['cmdline'] or [])):remaining.append(p.pid)
        except (psutil.NoSuchProcess,psutil.AccessDenied):pass
    report['cleanup']=dict(acl_restored=acl_before==after,pg_pid_files=[str(p.relative_to(root)) for p in root.rglob('postmaster.pid')],
        remaining_task_processes=remaining,elapsed_s=time.monotonic()-started)
    if not report['cleanup']['acl_restored'] or report['cleanup']['pg_pid_files'] or remaining:report['status']='failed_cleanup'
    (root/'legacy.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],cleanup=report['cleanup'])),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
