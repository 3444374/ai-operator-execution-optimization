"""Recompute the finite main-source fixture and every observed return interval."""
from collections import Counter
import gzip,hashlib,json,math,sqlite3,statistics,sys
from pathlib import Path
root=Path(sys.argv[1]);output=Path(sys.argv[2])
summary=json.loads((root/'summary.json').read_text());runs=[]
def stats(values):
    if not values or any(v<0 for v in values):raise ValueError('missing or negative intervals')
    x=sorted(values);n=len(x)
    return dict(samples=n,mean_ms=statistics.mean(x)/1e6,p50_ms=x[math.ceil(n*.5)-1]/1e6,p99_ms=x[math.ceil(n*.99)-1]/1e6,empirical_p9999_ms=x[math.ceil(n*.9999)-1]/1e6,sum_s=sum(x)/1e9)
for run in summary['runs']:
    directory=root/run['run_id']
    with gzip.open(directory/'events.jsonl.gz','rt') as stream:events=[json.loads(line) for line in stream]
    n=run['rows'];kinds={name:{} for name in ('ray_http_completed','remote_request_guard','[DEBUG-semreturn]reserve','[DEBUG-semreturn]consumer_receipt','[DEBUG-semreturn]ordered_output')}
    for event in events:
        kind=event['event']
        if kind not in kinds:continue
        seq=event.get('sequence',event.get('key',{}).get('sequence'))
        assert seq not in kinds[kind];kinds[kind][seq]=event
    assert all(set(v)==set(range(n)) for v in kinds.values())
    received,guards,detail,consumer,ordered=(kinds[k] for k in kinds)
    ready={v['sequence']:v['future_ready_ns'] for v in run['future_ready']}
    calls={v['sequence']:v for v in run['actor_calls']};assert set(calls)==set(ready)==set(range(n))
    metrics={name:[] for name in ('reserve_wall','reserve_thread_cpu','worker_end_to_callback','callback_to_map','map_to_core_receipt','core_receipt_to_ordered_output','callback_to_ordered_output','guard_total','reserve_queue','reserve_resume','request_observe')}
    switches=Counter();durable=[]
    for seq in range(n):
        e=received[seq];d=detail[seq];g=guards[seq];c=consumer[seq];o=ordered[seq]
        stamps=(calls[seq]['ended_ns'],ready[seq],e['received_ns'],c['received_ns'],o['delivered_ns'])
        assert list(stamps)==sorted(stamps) and e['shared_clock'] and e['worker_ended_ns']==stamps[0]
        assert d['wall_ns']==d['ended_ns']-d['started_ns'] and d['attempt'] is not None
        digest=hashlib.sha256(f'fixture-input:{seq}:'.encode()+b'x'*128).hexdigest();durable.append((d['attempt'],digest))
        metrics['reserve_wall'].append(d['wall_ns']);metrics['reserve_thread_cpu'].append(d['thread_cpu_ns']);metrics['guard_total'].append(g['elapsed_ns'])
        for name,a,b in (('worker_end_to_callback',stamps[0],stamps[1]),('callback_to_map',stamps[1],stamps[2]),('map_to_core_receipt',stamps[2],stamps[3]),('core_receipt_to_ordered_output',stamps[3],stamps[4]),('callback_to_ordered_output',stamps[1],stamps[4])):metrics[name].append(b-a)
        for dest,field in (('reserve_queue','reserve_queue_ns'),('reserve_resume','reserve_resume_ns'),('request_observe','request_observe_ns')):
            if g.get(field) is not None:metrics[dest].append(g[field])
        switches.update({k:d[k] for k in ('voluntary_switches','involuntary_switches')})
    assert sum(metrics['callback_to_map'])+sum(metrics['map_to_core_receipt'])+sum(metrics['core_receipt_to_ordered_output'])==sum(metrics['callback_to_ordered_output'])
    connection=sqlite3.connect('file:'+str(directory/'ledger.sqlite')+'?mode=ro',uri=True)
    assert connection.execute('SELECT sequence,request_sha256 FROM shared_requests ORDER BY sequence').fetchall()==sorted(durable);connection.close()
    assert run['status']=='passed' and run['exactly_once'] and run['actor_disposed'] and run['transport_drained']
    assert run['issued_calls']==run['accounted_calls']==n and not run['cleanup_errors']
    batch_sizes=Counter(e.get('rows',e.get('count','unavailable')) for e in events if e['event']=='ray_block_put')
    runs.append(dict(run_id=run['run_id'],phase=run['phase'],repeat=run['repeat'],path=run['path'],guard_kind=run['guard_kind'],rows=n,query_seconds=run['query_seconds'],first_result_seconds=run['first_result_seconds'],startup_seconds=run['startup_seconds'],object_batches=run['object_batches'],batch_size_histogram=dict(batch_sizes),prepared_blocks=run['prepared_blocks'],thread_context_switches=dict(switches),intervals={k:stats(v) for k,v in metrics.items() if v}))
rows=[]
for path,guard in (('immediate','sync'),('immediate','threaded'),('coalesced','sync'),('coalesced','threaded')):
    measured=sorted((r for r in runs if r['phase']=='measurement' and r['path']==path and r['guard_kind']==guard),key=lambda r:r['repeat'])
    assert len(measured)==3
    rows.append(dict(path=path,guard_kind=guard,query_median_s=statistics.median(r['query_seconds'] for r in measured),all_query_s=[r['query_seconds'] for r in measured],object_batches=[r['object_batches'] for r in measured],interval_mean_medians_ms={k:statistics.median(r['intervals'][k]['mean_ms'] for r in measured) for k in measured[0]['intervals']},units=[r['run_id'] for r in measured]))
assert summary['status']=='passed' and len(runs)==20 and sum(r['rows'] for r in runs)==16448
value=dict(status='passed',source_commit=summary['reference_commit'],actual_actor_calls=16448,model_requests=0,http_requests=0,pg_queries=0,gpu_requested=0,rows=rows,runs=runs,interpretation='real Core/Daft/Ray with deterministic sleep actor; thread CPU versus wall time cannot identify storage or GIL cause; callback is a Python observation; per-row intervals overlap and are not query wall time; no production default changed')
output.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(status='passed',actor_calls=16448,model_requests=0,rows=rows)))
