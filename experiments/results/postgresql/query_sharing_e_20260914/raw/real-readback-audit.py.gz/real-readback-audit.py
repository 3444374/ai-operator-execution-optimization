from pathlib import Path
from collections import Counter
import hashlib,json,os,socket,sqlite3,subprocess
import psutil
from src.execution_provider.wire import v3
from src.execution_provider.semantic_map import SemanticMapPlan,canonical_messages
from src.experiments.postgresql.map_bindings import parse_pg_bindings,verify_bound_map_results
from src.experiments.postgresql.filter_bindings import verify_filter_decisions
from src.experiments.postgresql.window_memory import verify_window_memory
from src.baselines.common.private_artifacts import write_private_json
base=Path('<artifact-root>');root=base/'real-run-v2';outputs=root/'queries'
c=json.loads((base/'real-config-v2.json').read_text());values=[tuple(x) for x in c['inputs']]
runs=json.loads((outputs/'queries.json').read_text());events=[json.loads(s) for s in (outputs/'events.jsonl').read_text().splitlines()]
sessions=[json.loads(s) for s in (outputs/'sessions.jsonl').read_text().splitlines()];lines=(root/'pg/postgres.log').read_text().splitlines();bindings=parse_pg_bindings(lines)
expected_requests=Counter();returned=[];verified=[]
def expect(text,filter=False):
 instruction=c['filter_instruction'] if filter else c['map_instruction']
 messages=json.loads(v3.canonical_messages(instruction,text) if filter else canonical_messages(instruction,text))
 generation=v3.GENERATION_CONSTRAINTS if filter else SemanticMapPlan(instruction,c['model_id'],c['map_tokens']).generation_constraints()
 expected_requests[json.dumps(dict(model=c['model_id'],messages=messages,**generation),sort_keys=True)]+=1
for r in runs:
 p=outputs/r['label'];raw=(p/'results.jsonl').read_bytes();execution=json.loads((p/'execution.json').read_text())
 assert execution['status']=='completed' and execution['query_status']=='completed'
 assert execution['results_sha256']==hashlib.sha256(raw).hexdigest() and execution['recorded_bytes']==len(raw)
 predictions=[tuple(json.loads(s)['row']) for s in raw.splitlines()];assert execution['recorded_rows']==len(predictions)
 returned.extend(text for _,text in predictions)
 expected=values if r['limit'] is None else values[:r['limit']]
 if r['dependent']:
  trace=[line for line in lines if 'SEMLOOM_FILTER_BINDING ' in line and json.loads(line.split('SEMLOOM_FILTER_BINDING ',1)[1])['backend_pid']==r['backend_pid']]
  decisions=verify_filter_decisions(trace,dict(values),c['model_id'],complete=True,instruction=c['filter_instruction'])
  assert all(decisions.values())
  expected=[v for v in values if decisions[v[0]]]
  for _,text in values:expect(text,True)
 for _,text in expected:expect(text)
 peer_sessions={s['session_id'] for s in sessions if s.get('event')=='session_start' and s.get('peer_pid')==r['backend_pid']}
 selected=[e for e in events if e.get('session_id') in peer_sessions and e['event'] in ('core_map_task','core_map_completion')]
 verified.append(verify_bound_map_results(expected,predictions,[b for b in bindings if b.backend_pid==r['backend_pid']],selected,sessions,plan=SemanticMapPlan(c['map_instruction'],c['model_id'],c['map_tokens'])))
 memory=verify_window_memory(lines,backend_pid=r['backend_pid'],retained_limit=c['pg_bytes'],staging_limit=c['staging_bytes'],window=c['window'])
 assert memory==r['memory']
actual=Counter(json.dumps(e['body'],sort_keys=True) for e in events if e['event']=='request');assert actual==expected_requests and sum(actual.values())==63
requests=[e for e in events if e['event']=='request']
with sqlite3.connect(root/'budget.sqlite') as db:
 hashes=Counter(row[0] for row in db.execute('SELECT request_sha256 FROM shared_requests'))
 assert hashes==Counter(e['request_bytes_sha256'] for e in requests)
 assert db.execute('SELECT count(*) FROM closed_shared_units').fetchone()[0]==1
assert (root/'model.log').read_text().count('POST /v1/chat/completions ')==63
flow_jobs={e['engine_session_id']:e['job_id'] for e in events if e['event']=='core_query_flow_joined'}
active=set();peaks=Counter()
for e in events:
 if e['event'] not in ('core_submitted','core_terminal'):continue
 key=(e['key']['session_id'],e['key']['sequence'])
 if e['event']=='core_submitted':assert key not in active;active.add(key)
 else:assert key in active;active.remove(key)
 assert len(active)==e['usage']['active_requests']<=c['requests']
 for job,n in Counter(flow_jobs[k[0]] for k in active).items():peaks[job]=max(peaks[job],n)
assert not active
counts=Counter(e['event'] for e in events);assert counts['core_job_opened']==counts['core_job_drained']==len(runs)==19
assert counts['core_submitted']==counts['core_terminal']==63
close=[e for e in events if e['event']=='core_transport_closed'];assert len(close)==1 and close[0]['closed'] and not any(close[0]['usage'].values())
snapshot=json.loads((base/'local-source.json').read_text())
for name,digest in snapshot['files'].items():assert hashlib.sha256((base/'source'/name).read_bytes()).hexdigest()==digest
assert not subprocess.check_output(['git','status','--porcelain'],cwd=base/'source',text=True)
report=json.loads((root/'campaign-result.json').read_text());assert report['status']=='passed' and report['cleanup']['acl_restored']
assert not list(base.rglob('postmaster.pid'))
for port in (57680,57681,57682):
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',port))!=0
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
result=dict(status='passed',actual_posts=63,queries=19,matched_map_rows=sum(v['matched_rows'] for v in verified),
 exact_echo=sum(text=='TRUE' for text in returned),map_output_count=len(returned),
 output_hash_counts=dict(Counter(hashlib.sha256(text.encode()).hexdigest() for text in returned)),
 per_job_peak_distribution=dict(Counter(peaks.values())),source_files=len(snapshot['files']),cleanup_verified=True,
 quality_interpretation='All Map rows were associated correctly; exact echo quality is zero and has not been repaired or rerun')
write_private_json(root/'readback-audit.json',result);print(json.dumps(result))
