"""Own normal PG qualification and the finite instrumented flow comparison."""
from pathlib import Path
import json,os,pwd,signal,subprocess,time
import psutil
from src.baselines.common.redact import redact_text
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster
root=Path('<artifact-root>');source=root/'source';user=pwd.getpwnam('postgres')
python='<driver-venv>/bin/python'
normal=Path('/opt/semloom-pg18.3-query-sharing-e')
assert json.loads((root/'preflight.json').read_text())['status']=='ok'
acl_before={str(p):subprocess.check_output(['getfacl','-p',str(p)],text=True) for p in (Path('/root'),root)}
(root/'dry-real-acl-before.json').write_text(json.dumps(acl_before,indent=2)+'\n')
started=time.monotonic();report=dict(status='failed',actual_model_posts=0,stages=[])

def run(name,command,env,cwd=source,timeout=300):
    process=subprocess.Popen(['runuser','-u','postgres','--',*command],cwd=cwd,env=env,
                             stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
    try:output,_=process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid,signal.SIGTERM)
        try:output,_=process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);output,_=process.communicate()
        (root/(name+'.log')).write_text(redact_text(output));raise TimeoutError(name+' exceeded deadline')
    (root/(name+'.log')).write_text(redact_text(output))
    report['stages'].append(dict(name=name,exit_code=process.returncode,command=command))
    (root/'dry-real.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,'exit',process.returncode,flush=True)
    if process.returncode:raise RuntimeError(name+' failed')

try:
    for p in acl_before:subprocess.run(['setfacl','-m','u:postgres:--x',p],check=True)
    for name in ('pg-dry-real','dry-real','tmp-dry-real'):
        p=root/name;p.mkdir(mode=0o700);os.chown(p,user.pw_uid,user.pw_gid)
    build=root/'check/code/postgres/semloom_pg'
    for p in (build,*build.rglob('*')):os.chown(p,user.pw_uid,user.pw_gid,follow_symlinks=False)
    env=dict(os.environ,PYTHONPATH=str(source/'code'),TMPDIR=str(root/'tmp-dry-real'),
        PATH=str(Path(python).parent)+':'+str(normal/'bin')+':'+os.environ['PATH'],
        OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PGUSER='postgres',
        SEMLOOM_TEST_SEMBENCH_ROOT='<data-root>/sq-b/sembench-checkout',
        SEMLOOM_TEST_RAY_TMPDIR=str(root/'dry-real/ray-unused'))
    with isolated_pg18_cluster(normal,root/'pg-dry-real',user,port=57680) as connection:
        assert connection.execute("SELECT count(*) FROM pg_settings WHERE name LIKE 'semloom_pg.test_flow_%'").fetchone()[0]==0
        env.update(PGHOST=str(root/'pg-dry-real/socket'),PGPORT='57680',
            SEMLOOM_TEST_PG_DSN='host='+str(root/'pg-dry-real/socket')+' port=57680 user=postgres dbname=postgres',
            SEMLOOM_TEST_PG_LOG=str(root/'pg-dry-real/postgres.log'))
        import threading
        from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
        from src.experiments.attempt_ledger import AttemptBudget
        from src.experiments.cell_budget import CellBudgetLedger
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                self.rfile.read(int(self.headers['Content-Length']))
                body=json.dumps(dict(model='fixture-model',choices=[dict(message=dict(content='TRUE'),finish_reason='stop')],usage=dict(prompt_tokens=10,completion_tokens=1))).encode()
                self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
            def log_message(self,*_):pass
        http=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=http.serve_forever);thread.start()
        try:
            cfg=json.loads((root/'real-config.json').read_text())
            cfg.update(output_root=str(root/'dry-real/queries'),model_id='fixture-model',model_config=str(root/'dry-real/model.json'),budget_path=str(root/'dry-real/budget.sqlite'),budget_id='fixture.shared.real.worker')
            for name,value in [('config.json',cfg),('model.json',dict(endpoint_url='http://127.0.0.1:'+str(http.server_port)+'/v1/chat/completions',model_id='fixture-model',timeout_ms=5000))]:
                p=root/'dry-real'/name;p.write_text(json.dumps(value));os.chown(p,user.pw_uid,user.pw_gid)
            ledger=CellBudgetLedger.create(Path(cfg['budget_path']),AttemptBudget(cfg['budget_id'],63),deadline_utc=time.time()+150)
            ledger.reserve_unit(cfg['unit_id'],63);os.chown(ledger.path,user.pw_uid,user.pw_gid)
            env.update(SEMLOOM_QUERY_DSN=env['SEMLOOM_TEST_PG_DSN'],SEMLOOM_PG_LOG=env['SEMLOOM_TEST_PG_LOG'])
            run('dry-real-worker',[python,str(root/'real-worker.py'),str(root/'dry-real/config.json')],env,timeout=150)
            ledger.close_shared_unit(cfg['unit_id'])
        finally:
            http.shutdown();http.server_close();thread.join(3)
    report['status']='passed'
except Exception as error:
    report.update(error=redact_text(str(error)),error_type=type(error).__name__)
finally:
    # Stop any owned TAP cluster left by an abnormal test-process exit before restoring ACLs.
    for pid in root.rglob('postmaster.pid'):
        subprocess.run(['runuser','-u','postgres','--',str(normal/'bin/pg_ctl'),'-D',str(pid.parent),'-m','fast','-w','stop'],
                       stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=20)
    for p,acl in acl_before.items():subprocess.run(['setfacl','--restore=-'],input=acl,text=True,check=True)
    after={p:subprocess.check_output(['getfacl','-p',p],text=True) for p in acl_before}
    excluded={os.getpid(),*(p.pid for p in psutil.Process().parents())};remaining=[]
    for p in psutil.process_iter(['cmdline','status']):
        try:
            if p.pid not in excluded and p.info['status']!=psutil.STATUS_ZOMBIE and any(str(root) in a for a in (p.info['cmdline'] or [])):remaining.append(p.pid)
        except (psutil.NoSuchProcess,psutil.AccessDenied):pass
    report['cleanup']=dict(acl_restored=acl_before==after,pg_pid_files=[str(p.relative_to(root)) for p in root.rglob('postmaster.pid')],
        remaining_task_processes=remaining,elapsed_s=time.monotonic()-started)
    if not report['cleanup']['acl_restored'] or report['cleanup']['pg_pid_files'] or remaining:report['status']='failed_cleanup'
    (root/'dry-real.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],cleanup=report['cleanup'])),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
