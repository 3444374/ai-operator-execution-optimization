from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,socket,os
import psutil
base=Path('<artifact-root>');root=base/'shared-v2/shared'
snapshot=json.loads((base/'local-source.json').read_text())
for n,d in snapshot['files'].items():assert hashlib.sha256((base/'source'/n).read_bytes()).hexdigest()==d,n
assert subprocess.check_output(['git','status','--porcelain'],cwd=base/'source',text=True)==''
posts=json.loads((root/'http.json').read_text());queries=json.loads((root/'queries.json').read_text())
values=[('[KEEP]' if i%2==0 else '[DROP]')+' row '+str(i) for i in range(8)]
expected=Counter()
def add(rows,tokens,instruction,repeats):
 for text in rows:expected[(instruction,text,tokens)]+=repeats
add(values,128,'Echo.',8) # 2 + 4 simultaneous and 2 staggered
add(values,8,'Keep inputs containing [KEEP].',4)
add(values[::2],128,'Echo.',4)
add(values,128,'Echo.',4) # three paused queries plus active neighbour
add(values[:4],128,'Echo.',1) # cancelled after four confirmed starts
add(values,128,'Echo.',1) # surviving query
add(values[:1],128,'Echo.',7) # lifetime Job count exceeds concurrency
actual=Counter()
for row in posts:
 r=row['request'];assert r['model']=='fixture-model'
 assert {k:r[k] for k in ('temperature','top_p','n','stream','stop')}==dict(temperature=0,top_p=1,n=1,stream=False,stop=None)
 assert [m['role'] for m in r['messages']]==['system','user']
 actual[(r['messages'][0]['content'],r['messages'][1]['content'],r['max_tokens'])]+=1
assert actual==expected and sum(expected.values())==163
active=0;peak=0
for _,change in sorted([(r['start'],1) for r in posts]+[(r['end'],-1) for r in posts]):
 active+=change;assert 0<=active<=4;peak=max(peak,active)
assert active==0 and peak==4
assert Counter(q['status'] for q in queries)==Counter(completed=14,cancelled=1)
events=[json.loads(x) for x in (root/'events.jsonl').read_text().splitlines()]
counts=Counter(e['event'] for e in events)
assert counts['core_job_opened']==counts['core_job_drained']==25
assert counts['core_submitted']==counts['core_terminal']==163
assert counts['core_filter_completion']==32 and counts['core_map_completion']==127
closed=[e for e in events if e['event']=='core_transport_closed']
assert len(closed)==1 and closed[0]['closed'] and not any(closed[0]['usage'].values())
peaks={k:max(e['usage'][k] for e in events if 'usage' in e) for k in closed[0]['usage']}
limits=dict(held_tasks=32,input_bytes=32*1048576,result_bytes=32*1048576,active_requests=4,active_work=4)
assert all(peaks[k]<=limits[k] for k in peaks)
report=json.loads((base/'shared-v2.json').read_text());assert report['status']=='passed' and report['cleanup']['acl_restored']
assert not list(base.rglob('postmaster.pid'))
with socket.socket() as s:assert s.connect_ex(('127.0.0.1',57680))!=0
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
excluded={os.getpid(),*(p.pid for p in psutil.Process().parents())}
remaining=[]
for p in psutil.process_iter(['cmdline','status']):
 try:
  if p.pid not in excluded and p.info['status']!=psutil.STATUS_ZOMBIE and any(str(base) in a for a in p.info['cmdline'] or []):remaining.append(p.pid)
 except (psutil.NoSuchProcess,psutil.AccessDenied):pass
assert not remaining
result=dict(status='passed',source_files=len(snapshot['files']),source_commit=snapshot['commit'],
 expected_http_posts=163,actual_http_posts=len(posts),peak_http=peak,peak_usage=peaks,
 global_limits=limits,jobs_opened=25,jobs_drained=25,filter_completions=32,map_completions=127,
 actual_model_posts=0,cleanup_verified=True)
(base/'independent-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
