"""Build separate normal and explicitly instrumented PG extension installations."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
from src.baselines.common.redact import redact_text
root=Path('<artifact-root>');source=root/'source'
assert json.loads((root/'preflight.json').read_text())['status']=='ok'
records=[]
for name,flag in (('normal',0),('probe',1)):
    prefix=Path('/opt/semloom-pg18.3-flow-'+name)
    if prefix.exists():raise FileExistsError('new profile prefix already exists')
    shutil.copytree('/opt/semloom-pg18.3-total-budget',prefix,symlinks=True)
    pgconfig=prefix/'bin/pg_config'
    actual=Path(subprocess.check_output([str(pgconfig),'--pkglibdir'],text=True).strip())
    assert str(actual).startswith(str(prefix)), 'PG installation did not relocate'
    build=root/('build-'+name);shutil.copytree(source/'code/postgres/semloom_pg',build)
    command=['make','-j8','PG_CONFIG='+str(pgconfig),'PG_CFLAGS=-O2 -Werror','SEMLOOM_FLOW_DIAGNOSTIC='+str(flag)]
    started=time.monotonic()
    result=subprocess.run(command,cwd=build,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
    (root/('build-'+name+'.log')).write_text(redact_text(result.stdout))
    if result.returncode:raise RuntimeError(name+' compilation failed')
    result=subprocess.run(['make','install',*command[2:]],cwd=build,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
    (root/('install-'+name+'.log')).write_text(redact_text(result.stdout))
    if result.returncode:raise RuntimeError(name+' installation failed')
    library=actual/'semloom_pg.so'
    present='SEMLOOM_FLOW_TRACE' in subprocess.check_output(['strings',str(library)],text=True)
    assert present==bool(flag)
    records.append(dict(profile=name,diagnostic_flag=flag,prefix=str(prefix),build=str(build),
        extension_sha256=hashlib.sha256(library.read_bytes()).hexdigest(),trace_string_present=present,
        elapsed_s=time.monotonic()-started,command=command))
    print(name,'compiled and installed',flush=True)
(root/'build-profiles.json').write_text(json.dumps(records,indent=2)+'\n')
