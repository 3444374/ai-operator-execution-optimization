from pathlib import Path
from dataclasses import asdict
import hashlib,json,os,pwd
from src.experiments.postgresql.query_workloads import prepare,read_prepared,load_manifest
from src.experiments.postgresql.query_config import QueryConfig
from src.baselines.common.private_artifacts import new_private_directory,write_private_json
base=Path('<artifact-root>');source=base/'source';p=base/'real-proposal';new_private_directory(p)
old=Path('<data-root>/sq-cda/real-proposal/warm/manifest.json')
raw=list(read_prepared(old,'raw.jsonl'));refs={r['row_id']:r['reference'] for r in read_prepared(old,'references.jsonl')}
for n in (8,1):
 prepare(p/('input'+str(n)),'movie',[(r[1],r[2],r[3],refs[r[1]],r[4]) for r in raw[:n]],
         dict(source_manifest=load_manifest(old)['sha256'],selection='first '+str(n)+' original input occurrences; no label filtering'),max_rows=n)
org=json.loads(Path('<data-root>/sq-cda/real-proposal/rows-loose.json').read_text())
org.update(window_rows=4,batch_rows=4,batch_work=2048,active_work=2048)
write_private_json(p/'organization.json',org);osh=hashlib.sha256((p/'organization.json').read_bytes()).hexdigest()
units=[]
for name,arm,profile,ready in [('warm','pg','normal',None),('pg','pg','normal',None),('direct','pg-source-direct','normal',None),
 ('flow0-current','pg','probe',False),('flow0-ready','pg','probe',True),('flow1-ready','pg','probe',True),('flow1-current','pg','probe',False),
 ('deadline','pg-source-direct','normal',None)]:
 n=1 if name=='deadline' else 8
 c=QueryConfig(name,arm,'map','flow_input'+str(n),concurrency=4,window=4,pg_window_bytes=8388608,
 pg_staging_bytes=4194304,pg_total_budget=arm=='pg',query_timeout_s=5 if n==1 else 60,max_posts=n,
 organization_config=str(p/'organization.json') if profile=='probe' else None,organization_sha256=osh if profile=='probe' else None)
 write_private_json(p/(name+'.json'),asdict(c));units.append(dict(name=name,config_file=name+'.json',manifest='input'+str(n)+'/manifest.json',profile=profile,ready_first=ready))
write_private_json(p/'schedule.json',dict(units=units,max_model_posts=64,planned_model_posts=57,admin_prefix_resets=8,unit_deadline_s=180))
write_private_json(p/'authorization.json',dict(approved=True,user_message_id='2039368',max_model_posts=64,max_seconds=1200,
 planned_posts=57,stop_on_unexpected_failure=True,no_retry_or_refund=True,one_gpu=True))
files={str(f.relative_to(source)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (source/'code').rglob('*') if f.is_file() and f.suffix in ('.py','.c','.h','.toml','.sql')}
libs={profile:hashlib.sha256(Path('/opt/semloom-pg18.3-flow-'+profile+'/lib/postgresql/semloom_pg.so').read_bytes()).hexdigest() for profile in ('normal','probe')}
write_private_json(p/'source-snapshot.json',dict(files=files,pg_libraries=libs,git_commit='0274b1218faacec0ea24c4cb033b36c8ad55dff5'))
u=pwd.getpwnam('postgres')
for f in (p,*p.rglob('*')):os.chown(f,u.pw_uid,u.pw_gid)
print(json.dumps(dict(units=len(units),planned_posts=57,cap=64,code_files=len(files),model_started=False)))
