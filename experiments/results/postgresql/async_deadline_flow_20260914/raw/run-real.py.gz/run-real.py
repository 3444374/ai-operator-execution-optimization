"""Finite authorized model campaign; immutable inputs, durable accounting, no retry."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,os,pwd,signal,socket,sqlite3,subprocess,sys,time,urllib.request
import psutil
from src.infrastructure.environment import load_env_file
from src.baselines.common.private_artifacts import new_private_directory,write_private_json
from src.baselines.common.redact import redact_text
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.postgresql.query_config import QueryConfig
from src.experiments.postgresql.query_inputs import QueryInputs
from src.experiments.postgresql.query_workloads import read_prepared
from src.experiments.postgresql.query_tables import install_input_table
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster
base=Path('<artifact-root>');source=base/'source';proposal=base/'real-proposal';root=base/'real-run'
user=pwd.getpwnam('postgres');python='<driver-venv>/bin/python';port=57672
schedule=json.loads((proposal/'schedule.json').read_text());approval=json.loads((proposal/'authorization.json').read_text())
configs=[QueryConfig(**json.loads((proposal/u['config_file']).read_text())) for u in schedule['units']]
assert sum(c.max_posts for c in configs)==57 and len(configs)==8 and approval['max_model_posts']==64 and approval['max_seconds']==1200
assert [c.max_posts for c in configs]==[8]*7+[1] and all(c.concurrency==c.window==4 for c in configs)
assert all(c.pg_window_bytes==8388608 and c.pg_staging_bytes==4194304 for c in configs)
assert json.loads((base/'controlled-v2.json').read_text())['status']=='passed'
if sys.argv[1:]==['--inspect']:
 print(json.dumps(dict(units=8,planned_posts=57,cap=64,model_started=False)));raise SystemExit(0)
assert sys.argv[1:]==['--execute'] and approval['approved'] and approval['user_message_id']
new_private_directory(root);os.chown(root,user.pw_uid,user.pw_gid)
started=time.time();deadline=started+1200;work_until=deadline-90
write_private_json(root/'campaign-time.json',dict(started_utc=started,deadline_utc=deadline,work_until=work_until))
write_private_json(root/'authorization.json',approval)
budget=AttemptBudget('semloom.deadline.flow.20260914',64);ledger=CellBudgetLedger.create(root/'budget.sqlite',budget,deadline_utc=work_until)
os.chown(root/'budget.sqlite',user.pw_uid,user.pw_gid)
acl_before={str(p):subprocess.check_output(['getfacl','-p',str(p)],text=True) for p in (Path('/root'),base)}
write_private_json(root/'acl-before.json',acl_before)
model_process=None;forced=False;report=dict(status='failed',completed_units=[],errors=[]);unit_process=None

def verify(path,expected):
 d=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(16*1048576),b''):
   if time.time()>=work_until:raise TimeoutError('identity verification exceeded campaign time')
   d.update(block)
 if d.hexdigest()!=expected:raise ValueError('declared file identity differs: '+path.name)

def stop_model():
 global forced
 if model_process is None:return
 if model_process.poll() is None:os.killpg(model_process.pid,signal.SIGTERM)
 try:model_process.wait(timeout=30)
 except subprocess.TimeoutExpired:
  forced=True;os.killpg(model_process.pid,signal.SIGKILL);model_process.wait(timeout=10)
 write_private_json(root/'service-stop.json',dict(returncode=model_process.returncode,forced=forced,stopped_utc=time.time()))

def stop_unit(process):
 try:children=psutil.Process(process.pid).children(recursive=True)
 except psutil.NoSuchProcess:children=[]
 for child in children:
  try:child.terminate()
  except psutil.NoSuchProcess:pass
 _,alive=psutil.wait_procs(children,timeout=10)
 for child in alive:
  try:child.kill()
  except psutil.NoSuchProcess:pass
 psutil.wait_procs(alive,timeout=10)
 if process.poll() is None:process.terminate()
 process.wait(timeout=10)

try:
 snapshot=json.loads((proposal/'source-snapshot.json').read_text())
 for name,digest in snapshot['files'].items():verify(source/name,digest)
 for profile,digest in snapshot['pg_libraries'].items():verify(Path('/opt/semloom-pg18.3-flow-'+profile+'/lib/postgresql/semloom_pg.so'),digest)
 model=Path('<model-root>');reference=json.loads(Path('<data-root>/sq-ar2/service-reference.json').read_text())
 for name,digest in reference['model']['files'].items():verify(model/name,digest)
 write_private_json(root/'identity-verified.json',dict(code_files=len(snapshot['files']),source_commit=snapshot['git_commit'],libraries=snapshot['pg_libraries'],model=reference['model']))
 busy=subprocess.check_output(['nvidia-smi','-i','0','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
 if busy:raise RuntimeError('GPU 0 has an existing compute process')
 with socket.socket() as s:s.bind(('127.0.0.1',port))
 for p in acl_before:subprocess.run(['setfacl','-m','u:postgres:--x',p],check=True)
 with ExitStack() as stack:
  for profile,pgport in [('normal',57673),('probe',57674)]:
   pgroot=root/('pg-'+profile);pgroot.mkdir(mode=0o700);os.chown(pgroot,user.pw_uid,user.pw_gid)
   conn=stack.enter_context(isolated_pg18_cluster(Path('/opt/semloom-pg18.3-flow-'+profile),pgroot,user,port=pgport))
   assert conn.execute("SELECT count(*) FROM pg_settings WHERE name LIKE 'semloom_pg.test_flow_%'").fetchone()[0]==(0 if profile=='normal' else 4)
   for n in (8,1):
    installed=install_input_table(conn,QueryInputs('movie','flow_input'+str(n),n),read_prepared(proposal/('input'+str(n)+'/manifest.json'),'raw.jsonl'))
    write_private_json(root/(profile+'-input'+str(n)+'-installed.json'),installed)
  runtime=load_env_file(base/'runtime.env');cache=root/'cache';cache.mkdir(mode=0o700)
  env=dict(os.environ,CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',VLLM_SERVER_DEV_MODE='1',CUDA_HOME=runtime['CUDA_HOME'],
   PATH='<model-venv>/bin:'+runtime['CUDA_NVCC_BIN']+':'+os.environ['PATH'],HF_HOME=str(cache/'hf'),
   XDG_CACHE_HOME=str(cache/'xdg'),VLLM_CACHE_ROOT=str(cache/'vllm'),TORCHINDUCTOR_CACHE_DIR=str(cache/'torch'),
   FLASHINFER_WORKSPACE_BASE=str(cache/'flashinfer'),TRITON_CACHE_DIR=str(cache/'triton'),TMPDIR=str(cache),TOKENIZERS_PARALLELISM='false')
  args=['--model',str(model),'--tokenizer',str(model),'--served-model-name','Qwen2.5-7B-Instruct','--dtype','bfloat16',
   '--max-model-len','4096','--gpu-memory-utilization','0.8','--scheduling-policy','fcfs','--max-num-seqs','128',
   '--max-num-batched-tokens','8192','--tensor-parallel-size','1','--host','127.0.0.1','--port',str(port),
   '--generation-config','vllm','--enable-prefix-caching','--enable-chunked-prefill']
  command=['<model-venv>/bin/python',str(source/'code/scripts/services/launch_vllm_with_identity.py'),
   '--identity-output',str(root/'vllm-identity.json'),'--port',str(port),'--',*args]
  write_private_json(root/'service-command.json',dict(command=command))
  fixed=root/'fixed-model.json';write_private_json(fixed,dict(endpoint_url=f'http://127.0.0.1:{port}/v1/chat/completions',model_id='Qwen2.5-7B-Instruct',timeout_ms=30000));os.chown(fixed,user.pw_uid,user.pw_gid)
  log=stack.enter_context((root/'model.log').open('x'));model_process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  stack.callback(stop_model)
  until=min(time.time()+420,work_until)
  while time.time()<until:
   if model_process.poll() is not None:raise RuntimeError('model startup failed')
   try:
    with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=1) as response:
     if response.status==200:break
   except OSError:time.sleep(.5)
  else:raise TimeoutError('model readiness deadline')
  identity=json.loads((root/'vllm-identity.json').read_text());assert identity['package_version']==reference['vllm_version']=='0.25.1'
  with urllib.request.urlopen(f'http://127.0.0.1:{port}/v1/models',timeout=2) as response:models=json.load(response)
  assert [m['id'] for m in models['data']]==['Qwen2.5-7B-Instruct']
  actual=Path(f'/proc/{model_process.pid}/cmdline').read_bytes().decode().split('\0')[:-1];assert actual[-len(args):]==args
  write_private_json(root/'service-ready.json',dict(ready_utc=time.time(),model_id_verified=True,actual_argv_matches=True))
  print('model ready; starting bounded 57 POST sequence',flush=True)
  for u,c in zip(schedule['units'],configs):
   if time.time()+180>=work_until:raise TimeoutError('insufficient time for supervised query and cleanup')
   offset=(root/'model.log').stat().st_size
   with urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}/reset_prefix_cache',method='POST'),timeout=10) as response:assert response.status==200
   reset_until=time.monotonic()+5
   while True:
    with (root/'model.log').open('rb') as f:f.seek(offset);tail=f.read().decode()
    if 'Successfully reset prefix cache' in tail:break
    if time.monotonic()>=reset_until:raise RuntimeError('prefix reset unconfirmed')
    time.sleep(.05)
   assert tail.count('Successfully reset prefix cache')==1 and 'Failed to reset prefix cache' not in tail
   write_private_json(root/(c.unit_id+'-cache-reset.json'),dict(confirmed=True,offset=offset))
   profile=u['profile'];pgport=57673 if profile=='normal' else 57674;pgroot=root/('pg-'+profile)
   child=['runuser','-u','postgres','--','env','PYTHONDONTWRITEBYTECODE=1','PYTHONPATH='+str(source/'code'),
    'OMP_NUM_THREADS=1','OPENBLAS_NUM_THREADS=1','TOKENIZERS_PARALLELISM=false',
    'SEMLOOM_QUERY_DSN=host='+str(pgroot/'socket')+' port='+str(pgport)+' user=postgres dbname=postgres',
    'SEMLOOM_PG_LOG='+str(pgroot/'postgres.log'),python,str(base/'real-worker.py'),u['name']]
   unit_process=subprocess.Popen(child,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
   try:out,_=unit_process.communicate(timeout=min(180,work_until-time.time()))
   except BaseException:
    ledger.close_shared_unit(c.unit_id);stop_unit(unit_process);out=unit_process.stdout.read();(root/(c.unit_id+'.log')).write_text(redact_text(out));raise
   (root/(c.unit_id+'.log')).write_text(redact_text(out))
   if unit_process.returncode:raise RuntimeError(c.unit_id+' failed; no retry')
   unit_process=None
   value=json.loads((root/c.unit_id/('expected-timeout.json' if c.unit_id=='deadline' else 'summary.json')).read_text())
   if c.unit_id!='deadline':
    value=dict(status=value['status'],actual_posts=value['evaluation']['actual_posts'],quality=value['evaluation']['quality'],
     query_jct_seconds=value['execution']['query_jct_seconds'])
   report['completed_units'].append(dict(unit_id=c.unit_id,**value));print(json.dumps(report['completed_units'][-1]),flush=True)
  report['status']='passed'
except BaseException as error:
 report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
finally:
 if unit_process is not None and unit_process.poll() is None:
  try:stop_unit(unit_process)
  except BaseException as e:report['errors'].append(dict(phase='unit_cleanup',message=redact_text(str(e))))
 if model_process is not None and model_process.poll() is None:
  try:stop_model()
  except BaseException as e:report['errors'].append(dict(phase='model_cleanup',message=redact_text(str(e))))
 for pid in root.rglob('postmaster.pid'):
  subprocess.run(['runuser','-u','postgres','--','/opt/semloom-pg18.3-flow-normal/bin/pg_ctl','-D',str(pid.parent),'-m','fast','-w','stop'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=20)
 for path,acl in acl_before.items():subprocess.run(['setfacl','--restore=-'],input=acl,text=True,check=True)
 after={p:subprocess.check_output(['getfacl','-p',p],text=True) for p in acl_before}
 excluded={os.getpid(),*(p.pid for p in psutil.Process().parents())};remaining=[]
 for p in psutil.process_iter(['cmdline','status']):
  try:
   if p.pid not in excluded and p.info['status']!=psutil.STATUS_ZOMBIE and any(str(root) in a for a in (p.info['cmdline'] or [])):remaining.append(p.pid)
  except (psutil.NoSuchProcess,psutil.AccessDenied):pass
 with sqlite3.connect(root/'budget.sqlite') as db:
  tables={r[0] for r in db.execute('SELECT name FROM sqlite_master WHERE type="table"')}
  spent=db.execute('SELECT count(*) FROM shared_requests').fetchone()[0] if 'shared_requests' in tables else 0
  closed=db.execute('SELECT count(*) FROM closed_shared_units').fetchone()[0] if 'closed_shared_units' in tables else 0
 logtext=(root/'model.log').read_text() if (root/'model.log').exists() else ''
 model_posts=logtext.count('POST /v1/chat/completions ');admin=logtext.count('POST /reset_prefix_cache ')
 with socket.socket() as s:port_closed=s.connect_ex(('127.0.0.1',port))!=0
 gpu=subprocess.check_output(['nvidia-smi','-i','0','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
 report.update(started_utc=started,ended_utc=time.time(),elapsed_s=time.time()-started,deadline_utc=deadline,ledger=ledger.snapshot(),
  actual_posts=spent,server_model_posts=model_posts,admin_reset_posts=admin,closed_units=closed,
  cleanup=dict(acl_restored=acl_before==after,remaining_task_processes=remaining,pg_pid_files=[str(p.relative_to(root)) for p in root.rglob('postmaster.pid')],
   model_port_closed=port_closed,gpu_processes=gpu,forced=forced))
 if report['status']=='passed' and (spent!=57 or model_posts!=57 or admin!=8 or closed!=8):report['errors'].append(dict(message='final request reconciliation failed'))
 if remaining or report['cleanup']['pg_pid_files'] or gpu or not port_closed or acl_before!=after or time.time()>deadline:report['errors'].append(dict(message='cleanup or wall clock bound failed'))
 if report['errors']:report['status']='failed'
 write_private_json(root/'campaign-result.json',report)
 print(json.dumps(dict(status=report['status'],actual_posts=spent,server_model_posts=model_posts,elapsed_s=report['elapsed_s'],errors=report['errors'],cleanup=report['cleanup'])),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
