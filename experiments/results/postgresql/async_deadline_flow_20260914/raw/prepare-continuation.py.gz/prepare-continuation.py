from pathlib import Path
import hashlib,json,os,pwd,shutil
from dataclasses import asdict
from transformers import AutoTokenizer
from src.baselines.common.private_artifacts import new_private_directory,write_private_json
from src.execution_provider.adapters.map_organization import MapOrganizationConfig,tokenizer_fingerprint
from src.baselines.text.sembench_movie import MOVIE_MAP_INSTRUCTION
from src.execution_provider.semantic_map import canonical_messages
from src.modalities.text.tokenization import chat_token_count
from src.experiments.postgresql.query_workloads import read_prepared
from src.experiments.postgresql.query_config import QueryConfig
base=Path('<artifact-root>');old=base/'real-proposal';p=base/'continuation-proposal';new_private_directory(p)
previous=json.loads((base/'real-run/campaign-result.json').read_text());assert previous['actual_posts']==24 and previous['ledger']['allocated_requests']==32
for name in ('input8','input1'):shutil.copytree(old/name,p/name)
organization=json.loads((old/'organization.json').read_text());organization['active_work']=4096
config=MapOrganizationConfig(**organization);assert tokenizer_fingerprint(config.tokenizer_path)==config.tokenizer_sha256
write_private_json(p/'organization.json',asdict(config));digest=hashlib.sha256((p/'organization.json').read_bytes()).hexdigest()
tokenizer=AutoTokenizer.from_pretrained(config.tokenizer_path,local_files_only=True,trust_remote_code=False,use_fast=True)
work=[chat_token_count(tokenizer,json.loads(canonical_messages(MOVIE_MAP_INSTRUCTION,row[3])),max_tokens=4096-128)+128 for row in read_prepared(p/'input8/manifest.json','raw.jsonl')]
assert max(work)<=4096 and sum(sorted(work,reverse=True)[:4])<4096
units=json.loads((old/'schedule.json').read_text())['units'][3:]
for u in units:
 c=json.loads((old/u['config_file']).read_text())
 if u['profile']=='probe':c.update(organization_config=str(p/'organization.json'),organization_sha256=digest)
 QueryConfig(**c);write_private_json(p/u['config_file'],c)
write_private_json(p/'schedule.json',dict(units=units,max_model_posts=33,planned_model_posts=33,admin_prefix_resets=5,unit_deadline_s=180,
 previous_actual_posts=24,combined_model_posts=57,original_ledger_preserved=True))
shutil.copyfile(old/'source-snapshot.json',p/'source-snapshot.json')
write_private_json(p/'authorization.json',dict(approved=False,max_model_posts=33,max_seconds=1200,planned_posts=33,previous_actual_posts=24,
 combined_model_posts=57,user_message_id=None,stop_on_unexpected_failure=True,no_retry_or_refund=True,one_gpu=True))
write_private_json(p/'pre-model-validation.json',dict(status='passed',active_work=4096,context_tokens=4096,estimated_work=work,
 maximum_four_request_work=sum(sorted(work,reverse=True)[:4]),active_work_nonbinding_for_inputs=True,tokenizer_identity_verified=True,
 original_campaign_unchanged=True,original_actual_posts=24,original_allocated_requests=32,model_started=False))
u=pwd.getpwnam('postgres')
for f in (p,*p.rglob('*')):os.chown(f,u.pw_uid,u.pw_gid)
print((p/'pre-model-validation.json').read_text())
