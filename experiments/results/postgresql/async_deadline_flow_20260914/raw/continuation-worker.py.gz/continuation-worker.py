from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
import asyncio,hashlib,json,os,sys,time
from src.baselines.common.private_artifacts import write_private_json
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.postgresql.query_config import QueryConfig
from src.experiments.postgresql import query_runner,map_query_recording
from src.experiments.postgresql.flow_timing import analyze_flow
base=Path('<artifact-root>');p=base/'continuation-proposal';r=base/'real-continuation';name=sys.argv[1]
u=next(u for u in json.loads((p/'schedule.json').read_text())['units'] if u['name']==name)
c=QueryConfig(**json.loads((p/u['config_file']).read_text()));output=r/name
original_pg=query_runner.run_pg;original_open=map_query_recording._Recording.open_results

def traced(*args):
 connection=args[3];target=args[7]
 settings=dict(pause_input=4,pause_ms=80,ready_first=u['ready_first'],clock_source=time.get_clock_info('monotonic').implementation)
 for key,value in [('test_flow_trace','on'),('test_flow_ready_first','on' if u['ready_first'] else 'off'),('test_flow_pause_input','4'),('test_flow_pause_ms','80')]:
  connection.execute('SELECT set_config(%s,%s,false)',('semloom_pg.'+key,value))
 write_private_json(target/'flow-settings.json',settings)
 return original_pg(*args)

def slow_open(recording):
 original_open(recording);stream=recording.stream
 class SlowLastWrite:
  def write(self,value):
   before=asyncio.get_running_loop().time();deadline=recording.async_deadline['deadline_s']
   assert before<deadline,'real response did not arrive before deadline'
   result=stream.write(value)
   time.sleep(max(0,deadline+.05-asyncio.get_running_loop().time()))
   write_private_json(output/'write-injection.json',dict(before_s=before,deadline_s=deadline,after_s=asyncio.get_running_loop().time()))
   return result
  def flush(self):return stream.flush()
 recording.stream=SlowLastWrite()

with ExitStack() as stack:
 if u['profile']=='probe':stack.enter_context(patch.object(query_runner,'run_pg',traced))
 if name=='deadline':stack.enter_context(patch.object(map_query_recording._Recording,'open_results',slow_open))
 try:
  result=query_runner.run_query(c,manifest_path=p/u['manifest'],model_path=r/'fixed-model.json',budget_path=r/'budget.sqlite',
      budget=AttemptBudget('semloom.deadline.flow.continuation.20260914',33),root=output,dsn=os.environ['SEMLOOM_QUERY_DSN'],pg_log=os.environ['SEMLOOM_PG_LOG'])
 except TimeoutError:
  if name!='deadline':raise
  e=json.loads((output/'q0/execution.json').read_text());content=(output/'q0/results.jsonl').read_bytes()
  assert e['status']=='failed' and e['query_status']=='failed' and e['recorded_rows']==e['received_rows']==1
  assert e['results_sha256']==hashlib.sha256(content).hexdigest() and e['recorded_bytes']==len(content)
  d=e['async_deadline'];assert d['detection']=='absolute_check' and d['observed_s']>=d['deadline_s']+.04
  assert e['t_cancel_triggered_ns']==d['observed_ns']<=e['t_query_terminal_ns']<=e['t_stream_cleanup_ns']
  events=[json.loads(x) for x in (output/'events.jsonl').read_text().splitlines()]
  assert sum(e['event']=='request' for e in events)==1 and sum(e['event']=='direct_completion' for e in events)==1
  called=[]
  try:map_query_recording.evaluate_recording(output/'q0',lambda rows:called.append(True))
  except ValueError:pass
  else:raise AssertionError('failed results unexpectedly evaluated')
  assert not called and json.loads((output/'summary.json').read_text())['status']=='failed'
  write_private_json(output/'expected-timeout.json',dict(status='passed',actual_posts=1,provisional_rows=1,
   detection=d['detection'],deadline_overshoot_s=d['observed_s']-d['deadline_s'],evaluation_rejected=True))
 else:
  if name=='deadline':raise AssertionError('expired query reported success')
  assert result['status']=='passed' and result['evaluation']['actual_posts']==8 and result['evaluation']['quality']['invalid']==0
  if u['profile']=='probe':
   flow=analyze_flow(output,expected_rows=8,window=4);assert flow['startup_candidate_rows']==[4]
   write_private_json(output/'flow-timing.json',flow)
print(name,'passed',flush=True)
