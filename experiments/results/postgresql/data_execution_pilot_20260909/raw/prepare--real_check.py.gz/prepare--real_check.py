"""Bounded 68-request real-data qualification using the existing PG/runtime.

Small materialized client results are intentional; these are not steady-state
performance or RSS-bound measurements. No HTTP retry or semantic truncation.
"""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import pwd
import sys
import threading
import time

import psutil
from psycopg import sql

from src.baselines.common.redact import redact_text
from src.baselines.text.squad_map import content_digest, validate_manifest
from src.observability.metrics.squad import squad_example_scores, squad_quality_metrics
from src.experiments.attempt_ledger import AttemptBudget, AttemptLedger
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster, owned_child_process, wait_for_path


def save(path, value):
    path.write_text(redact_text(json.dumps(value, ensure_ascii=False, indent=2))+'\n')


def events(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def wait_drained(path):
    deadline = time.monotonic()+30
    while time.monotonic() < deadline:
        rows = events(path)
        if sum(r['event']=='core_job_opened' for r in rows) == sum(r['event']=='core_job_drained' for r in rows) > 0:
            return
        time.sleep(.01)
    raise AssertionError('job_not_drained')


def sample_rss(stop, pids, samples):
    while not stop.is_set():
        sample = {'monotonic_ns':time.monotonic_ns()}
        for role,pid in pids.items():
            try:sample[role+'_rss_bytes']=psutil.Process(pid).memory_info().rss
            except psutil.Error:sample[role+'_rss_bytes']=None
        samples.append(sample)
        stop.wait(.02)


def verify_requests(rows, instruction, tokens, requests, completions, output, config):
    expected = Counter(content_digest([
        {'role':'system','content':instruction},{'role':'user','content':r['input_text']}
    ]) for r in rows)
    assert Counter(content_digest(r['body']['messages']) for r in requests) == expected, 'actual_messages'
    for request in requests:
        body=request['body']
        assert body['model']==config['model_id'] and body['temperature']==0 and body['max_tokens']==tokens, 'generation_identity'
    assert len(completions)==len(rows), 'completion_count'
    assert [row[0] for row in output]==[r['source_example_id'] for r in rows], 'observed_input_order'
    assert [r['raw_output'] for r in completions]==[r[1] for r in output], 'result_association'
    for completion in completions:
        assert completion['response_model_id']==config['model_id'], 'model_identity'
        assert completion['finish_reason']=='stop', 'output_truncated'
        assert completion['prompt_tokens']>0 and completion['output_tokens']>0, 'usage_missing'
    assert all(isinstance(text,str) and text.strip() and '\x00' not in text for _,text in output), 'invalid_output'


def run_query(conn, settings, dataset, rows, name, trace, proc, profile):
    root=Path(settings['root']);config=json.loads(Path(settings['config']).read_text())
    conn.execute('DROP TABLE IF EXISTS pilot_inputs')
    conn.execute('CREATE TEMP TABLE pilot_inputs(source_example_id text PRIMARY KEY,input_text text NOT NULL)')
    with conn.cursor().copy('COPY pilot_inputs(source_example_id,input_text) FROM STDIN') as copy:
        for row in rows:copy.write_row((row['source_example_id'],row['input_text']))
    conn.execute('ANALYZE pilot_inputs')
    statement=sql.SQL('SELECT source_example_id,ai_semantic.map(input_text,{},{}::jsonb) FROM ONLY pilot_inputs').format(
        sql.Literal(dataset['instruction']),sql.Literal(json.dumps({'model':config['model_id'],'max_tokens':dataset['max_tokens'],'temperature':0})))
    before=len(events(trace));calls=AttemptLedger(Path(settings['ledger']),AttemptBudget(settings['budget_id'],68)).attempts
    plan=conn.execute(sql.SQL('EXPLAIN (FORMAT JSON) ')+statement).fetchone()[0]
    save(root/(name+'-plan.json'),plan)
    def nodes(value):
        if isinstance(value,dict):
            yield value
            for child in value.values():yield from nodes(child)
        elif isinstance(value,list):
            for child in value:yield from nodes(child)
    assert any(n.get('Custom Plan Provider')=='SemLoom SemMap' for n in nodes(plan)), 'missing_semmap'
    if profile=='incremental-map':
        assert any(n.get('Semantic Input Window')==2 for n in nodes(plan)), 'effective_window_not_two'
    stop=threading.Event();samples=[]
    sampler=threading.Thread(target=sample_rss,args=(stop,{'pg':conn.info.backend_pid,'gateway':proc.pid,'client':os.getpid()},samples))
    sampler.start()
    started=time.monotonic_ns()
    try:output=conn.execute(statement).fetchall()
    finally:
        finished=time.monotonic_ns();stop.set();sampler.join()
        save(root/(name+'-rss.json'),samples)
    predictions=[{'source_example_id':identity,'prediction':text} for identity,text in output]
    save(root/(name+'-predictions.json'),predictions)
    if profile=='incremental-map':wait_drained(trace)
    recent=events(trace)[before:]
    requests=[r for r in recent if r['event']=='request']
    completions=[r for r in recent if r['event'] in ('completion','core_map_completion')]
    verify_requests(rows,dataset['instruction'],dataset['max_tokens'],requests,completions,output,config)
    after=AttemptLedger(Path(settings['ledger']),AttemptBudget(settings['budget_id'],68)).attempts
    assert after-calls==len(rows), 'physical_attempts'
    report={'name':name,'profile':profile,'rows':len(rows),'requests':after-calls,'query_start_ns':started,
        'query_end_ns':finished,'query_seconds':(finished-started)/1e9,'association_verified':True,
        'actual_messages_verified':True,'completion_metadata':[{k:v for k,v in r.items() if k in ('prompt_tokens','output_tokens','finish_reason','response_model_id')} for r in completions],
        'row_ids':[r['source_example_id'] for r in rows],
        'row_input_hashes':[hashlib.sha256(r['input_text'].encode()).hexdigest() for r in rows],
        'request_bodies_sha256':[content_digest(r['body']) for r in requests],
        'provider_resource_peaks':{},'metrics_unavailable':['PG retained payload time series','service queue time series','per-row consumer latency']}
    usage=[r['usage'] for r in recent if isinstance(r.get('usage'),dict)]
    for key in {k for r in usage for k in r}:
        values=[r[key] for r in usage if isinstance(r.get(key),(int,float))]
        if values:report['provider_resource_peaks'][key]=max(values)
    active=peak=0
    for event in recent:
        if event['event']=='core_http_started':active+=1;peak=max(peak,active)
        elif event['event']=='core_http_finished':active-=1
    if profile=='incremental-map':
        assert active==0 and peak<=2,'HTTP_capacity'
        drained=[r['usage'] for r in recent if r['event']=='core_job_drained']
        assert drained and all(all(value==0 for value in r.values()) for r in drained),'resource_not_zero'
        assert report['provider_resource_peaks'].get('held_tasks',0)<=2,'held_capacity'
        assert report['provider_resource_peaks'].get('input_bytes',0)<=2*1048576,'input_capacity'
        assert report['provider_resource_peaks'].get('result_bytes',0)<=2*1048576,'result_capacity'
        report['http_peak']=peak;report['final_job_usage']=drained[-1]
    else:report['http_peak']='unavailable: synchronous transport has no HTTP overlap events'
    if dataset['name']=='squad':
        references={r['source_example_id']:r['reference_answers'] for r in rows}
        report['quality']=squad_quality_metrics(dict(output),references)
        report['per_row_scores']=[{'source_example_id':identity,'em':squad_example_scores(text,references[identity])[0],
            'f1':squad_example_scores(text,references[identity])[1]} for identity,text in output]
    else:report['quality']='pending per-row intent and hallucination review'
    save(root/(name+'-report.json'),report)
    return report


def run(settings):
    root=Path(settings['root']);root.mkdir();source=Path(settings['source'])
    for name,digest in settings['source_delta'].items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,'source_identity'
    assert hashlib.sha256((Path(settings['prefix'])/'lib/postgresql/semloom_pg.so').read_bytes()).hexdigest()==settings['extension_sha256'],'extension_identity'
    ledger=AttemptLedger(Path(settings['ledger']),AttemptBudget(settings['budget_id'],68))
    assert ledger.attempts==0
    squad=json.loads(Path(settings['squad_manifest']).read_text());validate_manifest(squad)
    share=json.loads(Path(settings['sharegpt_manifest']).read_text())
    datasets=[{'name':'squad','instruction':squad['instruction'],'max_tokens':64,'rows':squad['splits']['tuning'][:16]},share]
    summary={'status':'incomplete','reports':[],'performance_qualified':False}
    user=pwd.getpwuid(os.getuid())
    try:
        with isolated_pg18_cluster(Path(settings['prefix']),root,user,port=settings['pg_port']) as conn:
            summary['postgres_version']=conn.execute('SHOW server_version').fetchone()[0]
            for dataset in datasets:
                for profile in ('openai-compatible-fixed','incremental-map'):
                    name=dataset['name']+('-sync' if profile=='openai-compatible-fixed' else '-incremental')
                    sock=root/'socket'/(name+'.sock');trace=root/(name+'-events.jsonl')
                    command=[sys.executable,'-m','src.experiments.choice_gateway_observer','--events',str(trace),
                        '--ledger',settings['ledger'],'--budget-id',settings['budget_id'],'--max-attempts','68',
                        '--','--socket',str(sock),'--fixed-model-config',settings['config'],'--max-active-requests','2']
                    if profile=='incremental-map':command+=['--incremental-map','--max-active-jobs','1','--max-held-tasks','2','--input-buffer-bytes','2097152','--result-buffer-bytes','2097152']
                    with owned_child_process(command,root,name,dict(os.environ,PYTHONPATH=str(source/'code')),user) as proc:
                        wait_for_path(sock,proc)
                        conn.execute("SELECT set_config('semloom_pg.gateway_socket',%s,false)",(str(sock),))
                        conn.execute("SELECT set_config('semloom_pg.provider_execution_profile',%s,false)",(profile,))
                        conn.execute("SET semloom_pg.provider_window_tasks=2; SET semloom_pg.provider_window_bytes='8MB'; SET statement_timeout='120s'")
                        if profile=='openai-compatible-fixed':
                            summary['reports'].append(run_query(conn,settings,dataset,dataset['rows'][:2],name+'-precheck',trace,proc,profile))
                        summary['reports'].append(run_query(conn,settings,dataset,dataset['rows'],name,trace,proc,profile))
                        save(root/'progress.json',summary)
                    assert proc.returncode==0 and not sock.exists(),'gateway_cleanup'
            assert ledger.attempts==68,'request_total'
        summary['status']='passed'
    finally:
        summary['actual_requests']=ledger.attempts
        save(root/'summary.json',summary)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--settings',required=True)
    run(json.loads(Path(parser.parse_args().settings).read_text()))
