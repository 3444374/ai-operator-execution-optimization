"""Prepare private run inputs and verify existing model/source assets without inference."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import pwd
import shutil
import subprocess
import sys

ROOT=Path('/root/autodl-tmp/dex1')
SOURCE=ROOT/'source'
sys.path.insert(0,str(SOURCE/'code'))
from src.baselines.common.redact import redact_text
from transformers import AutoTokenizer


def save(path,value):path.write_text(redact_text(json.dumps(value,ensure_ascii=False,indent=2))+'\n')
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(8*1024*1024),b''):h.update(data)
    return h.hexdigest()


prep=ROOT/'prepare';prep.mkdir()
settings=json.loads(Path('/root/autodl-tmp/ql-real1/prepare/settings.json').read_text())
verified=json.loads(Path('/root/autodl-tmp/ql-real1/prepare/model-verification.json').read_text())
model=Path(settings['model_root'])
actual={name:digest(model/name) for name in verified['files']}
assert actual==verified['files'],'model_artifact_changed'
save(prep/'model-verification.json',verified)
manifest=json.loads((ROOT/'source-manifest.json').read_text())
for name in ['code/src/experiments/choice_gateway_observer.py','code/tests/experiments/test_choice_http_observer.py']:
    manifest[name]=digest(SOURCE/name)
assert all(digest(SOURCE/name)==sha for name,sha in manifest.items()),'source_identity'
save(ROOT/'source-final-manifest.json',manifest)
old_source=Path(settings['source'])
pg_code=[name for name in manifest if name.startswith('code/postgres/') and not name.endswith('.md')]
assert all(digest(old_source/name)==manifest[name] for name in pg_code),'PG_source_changed'
assert digest(Path(settings['prefix'])/'lib/postgresql/semloom_pg.so')==settings['extension_sha256'],'extension_changed'
save(prep/'pg-source-binding.json',{'code_files':len(pg_code),'match':True,'extension_sha256':settings['extension_sha256']})

raw_path=Path('/root/autodl-tmp/ai-operator/data/raw/sharegpt_vicuna/ShareGPT_V3_unfiltered_cleaned_split.json')
raw=json.loads(raw_path.read_text());chosen=[];reasons=Counter();ids=set()
for index,record in enumerate(raw):
    if len(chosen)==16:break
    humans=[item for item in record.get('conversations',[]) if item.get('from')=='human']
    if not humans or not isinstance(humans[0].get('value'),str) or not humans[0]['value'].strip():
        reasons['missing_nonempty_first_human']+=1;continue
    text=humans[0]['value'];size=len(text.encode())
    if not 256<=size<=2048:reasons['outside_256_2048_bytes']+=1;continue
    identity=record['id'];assert identity and identity not in ids,'sharegpt_id'
    ids.add(identity);chosen.append({'source_example_id':identity,'source_position':index,'input_text':text,'input_bytes':size})
assert len(chosen)==16
share={'name':'sharegpt','instruction':'Summarize the user request in one sentence. Preserve the language of the request.',
    'max_tokens':128,'rows':chosen,'source_sha256':digest(raw_path),'source_bytes':raw_path.stat().st_size,
    'source_rows':len(raw),'skipped_before_selection_complete':dict(reasons),'uninspected_after_selection':len(raw)-index}
save(ROOT/'sharegpt-manifest.json',share)
tokenizer=AutoTokenizer.from_pretrained(model,local_files_only=True)
squad=json.loads((ROOT/'squad/manifest.json').read_text())
token_counts={}
for name,rows,instruction,cap in [('squad-tuning',squad['splits']['tuning'],squad['instruction'],64),
    ('squad-evaluation',squad['splits']['evaluation'],squad['instruction'],64),('sharegpt',chosen,share['instruction'],128)]:
    counts=[len(tokenizer.apply_chat_template([{'role':'system','content':instruction},{'role':'user','content':r['input_text']}],
        tokenize=True,add_generation_prompt=True)) for r in rows]
    assert max(counts)+cap<=4096,'context_limit'
    token_counts[name]={'rows':len(rows),'input_tokens':counts,'max_with_output_budget':max(counts)+cap}
save(prep/'token-check.json',token_counts)

settings.update(source=str(SOURCE),source_commit='0ba12bfad0e4e95fdc0928358e7ea12470173fe9+data-execution-working-tree',
    source_delta=manifest,root=str(ROOT/'run'),config=str(prep/'model.json'),ledger=str(prep/'ledger.jsonl'),
    budget_id='pg-map-real-data-20260909',budget_limit=68,model_port=56619,pg_port=60543,
    temporary_root=str(prep/'temp'),squad_manifest=str(ROOT/'squad/manifest.json'),sharegpt_manifest=str(ROOT/'sharegpt-manifest.json'))
settings.pop('service_verification',None)
argv=settings['service_args'];argv[argv.index('--port')+1]='56619'
settings['service_args']=argv
config={'endpoint_url':'http://127.0.0.1:56619/v1/chat/completions','model_id':'Qwen2.5-7B-Instruct','timeout_ms':120000}
save(prep/'model.json',config);save(prep/'settings.json',settings)
shutil.copyfile(ROOT/'preflight-driver.json',prep/'preflight.json')
shutil.copyfile(ROOT/'real_check.py',prep/'real_check.py')
shutil.copyfile('/root/autodl-tmp/ql-real1/prepare/launch.py',prep/'launch.py')
(prep/'temp').mkdir()
user=pwd.getpwnam('postgres');os.chown(ROOT,user.pw_uid,user.pw_gid)
save(prep/'preparation-summary.json',{'status':'prepared','source_files':len(manifest),
    'source_manifest_sha256':digest(ROOT/'source-final-manifest.json'),'model_files':len(actual),
    'squad_rows_per_split':64,'sharegpt_rows':16,'model_requests':0,'request_budget':68,
    'model_revision':settings['model_revision'],'service_config_purpose':'correctness_only_not_tuned',
    'deadline_seconds':600,'max_active_requests':2,'pg_window':2})
print(json.dumps({'prepared':True,'source_files':len(manifest),'request_budget':68,'model_requests':0}))
