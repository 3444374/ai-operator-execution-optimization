"""Run existing adapter checks against the recovered integration source."""
from contextlib import redirect_stdout, redirect_stderr
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "GPU"
LABEL = sys.argv[1] if len(sys.argv) > 1 else "local-adapter-tests"
sys.path.insert(0, str(REPO / "code"))
TESTS = [
    "tests.baselines.test_native_dataset_configuration",
    "tests.baselines.test_native_ray_configuration",
    "tests.baselines.test_native_call_cleanup",
    "tests.baselines.test_native_http_lifecycle",
    "tests.baselines.test_native_daft_activity.DaftGraphLoopClientTests",
    "tests.baselines.test_native_calls.NativeHttpTests",
    "tests.baselines.test_native_calls.NativeRaySessionTests",
    "tests.experiments.test_native_adapter_runtime_evidence",
    "tests.experiments.test_native_http_observer",
    "tests.experiments.test_native_adapter_query",
    "tests.experiments.test_persistent_native_adapter_query.PersistentAdapterTests",
    "tests.experiments.test_persistent_native_adapter_query.PersistentNativeOptionsTests",
    "tests.experiments.test_native_adapter_metrics",
    "tests.experiments.test_native_query_entry",
]
SOURCE_PATHS = [
    "code/src/baselines/text/frameworks/native_calls.py",
    "code/src/baselines/text/frameworks/prepared_map.py",
    "code/src/semantic_methods/lotus/batch.py",
    "code/src/semantic_methods/lotus/sdk.py",
    "code/src/experiments/postgresql/native_adapter_query.py",
    "code/src/experiments/postgresql/persistent_native_adapter_query.py",
    "code/src/experiments/postgresql/sema_native_query.py",
    "code/src/experiments/postgresql/query_config.py",
]

def main():
    start = time.monotonic()
    log_path = ROOT / "verification" / (LABEL + ".log")
    source_hashes = {
        path: hashlib.sha256((REPO / path).read_bytes()).hexdigest()
        for path in SOURCE_PATHS
    }
    loader = unittest.TestLoader()
    with log_path.open("w") as log, redirect_stdout(log), redirect_stderr(log):
        suite = loader.loadTestsFromNames(TESTS)
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    value = {
        "source_commit": subprocess.check_output(
            ["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True
        ).strip(),
        "working_diff_sha256": hashlib.sha256(subprocess.check_output(
            ["git", "-C", str(REPO), "diff", "--", "code/src", "code/tests"]
        )).hexdigest(),
        "python_version": sys.version.split()[0],
        "test_targets": TESTS,
        "tests_run": result.testsRun,
        "passed": result.testsRun - len(result.skipped) - len(result.failures) - len(result.errors),
        "skipped": [{"test": test.id(), "reason": reason} for test, reason in result.skipped],
        "failures": [test.id() for test, _ in result.failures],
        "errors": [test.id() for test, _ in result.errors],
        "successful": result.wasSuccessful(),
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "source_sha256": source_hashes,
        "source_unchanged": all(
            hashlib.sha256((REPO / path).read_bytes()).hexdigest() == expected
            for path, expected in source_hashes.items()
        ),
        "scope": "existing local adapter, graph stand-in and localhost HTTP checks; no vendor graphs, server, model or GPU",
        "log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
    }
    (ROOT / "verification" / (LABEL + ".json")).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    )
    print(json.dumps(value, ensure_ascii=False, indent=2))
    return 0 if result.wasSuccessful() and value["source_unchanged"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
