"""No-HTTP reproduction of normal-EOF native graph cleanup failure."""
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'GPU' / 'code'))
from src.baselines.text.frameworks import native_calls as native


class CloseFailure(RuntimeError):
    pass


def probe(backend, graph_name):
    closing = CloseFailure('fixture graph finally close')
    calls = (native.NativeCall('eof-close:0', 0, b'{}', 'http://localhost/fixture', (), 1),)
    executor = native.NativeCallExecutor(backend)

    def graph(values, options, control):
        try:
            for call in values:
                yield native.NativeCallOutcome(call.call_id, call.row_id,
                    native.FullModelResponse(200, (), b'{}'))
        finally:
            raise closing

    caught = None
    with patch.object(native, graph_name, graph):
        try:
            list(executor.iter_batch(calls, timeout_s=2))
        except CloseFailure as error:
            caught = error
    report = executor.last_close_report
    entered = []

    def later_graph(values, options, control):
        entered.append(True)
        for call in values:
            yield native.NativeCallOutcome(call.call_id, call.row_id,
                native.FullModelResponse(200, (), b'{}'))

    refused = False
    with patch.object(native, graph_name, later_graph):
        try:
            list(executor.iter_batch(calls, timeout_s=2))
        except RuntimeError as error:
            refused = 'unconfirmed work' in str(error)
    return dict(backend=backend, primary_preserved=caught is closing,
        close_report=report, next_batch_refused=refused, next_graph_entries=len(entered),
        passed=(caught is closing and report['unconfirmed_work'] is True
            and report['reuse_allowed'] is False and refused and not entered))


source = ROOT / 'GPU' / 'code' / 'src' / 'baselines' / 'text' / 'frameworks' / 'native_calls.py'
results = [probe(backend, graph_name) for backend, graph_name in
           (('daft', '_daft_rows'), ('ray-data', '_ray_rows'))]
evidence = dict(schema='native-eof-close-before-v1', source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    graph_stand_in=True, model_posts=0, http_requests=0, vendor_libraries_used=False,
    passed=all(result['passed'] for result in results), results=results)
output = Path(__file__).with_suffix('.json')
output.write_text(json.dumps(evidence, indent=2) + '\n')
print(json.dumps(evidence, indent=2))
assert evidence['passed'], 'normal EOF cleanup failure must forbid executor reuse'
