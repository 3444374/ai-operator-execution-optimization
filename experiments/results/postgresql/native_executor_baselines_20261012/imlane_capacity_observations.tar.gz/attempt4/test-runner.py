"""Actual author CPython/Ray with only one owned localhost response fixture."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib
import importlib.util
import json
import os
import signal
import socket
import subprocess
import sys
import threading
import time
import uuid

root=Path(__file__).resolve().parent;source=root/'source';code=source/'code'
sys.path.insert(0,str(code))
from src.baselines.text.frameworks.imlane_calls import IMLaneCallConfig,IMLaneCallExecutor,process_start_ticks
from src.baselines.text.frameworks.imlane_limits import IMLaneBatchLimits
from src.baselines.text.frameworks.native_calls import NativeCall,_call_wire
from src.baselines.text.frameworks.prepared_map import NativeGraphOptions
from src.baselines.common.redact import redact_text
import psutil

author=Path('<checked-author-build>')
spec=importlib.util.spec_from_file_location('existing_author_helper',author/'harness/code/integrations/imlane/verify.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
sys.path.insert(0,str(code))
start=time.monotonic();lock=threading.Lock();sessions=[];receipts=[];peak=active=0
prior_posts=int(os.environ.get('IMLANE_CAPACITY_PRIOR_POSTS','0'))
completed_cpython=os.environ.get('IMLANE_CAPACITY_COMPLETED_CPYTHON_CLIENT')
completed_window=os.environ.get('IMLANE_CAPACITY_COMPLETED_CPYTHON_WINDOW')
combined_evidence=json.loads(Path(os.environ['IMLANE_CAPACITY_PREVIOUS_COMPLETE']).read_text())
prior_modes={m['runtime']:m for m in combined_evidence['modes']}
report=dict(models=0,gpu=0,cpu_affinity=sorted(os.sched_getaffinity(0)),localhost_post_limit=5000,
            planned_posts=12,prior_posts=prior_posts,modes=[],cleanup=[],started_monotonic=start)
def status():
    with lock:
        (root/'post-budget.json').write_text(json.dumps(dict(actual_posts=len(receipts)+prior_posts,attempt_posts=len(receipts),maximum=5000,active=active,peak=peak,models=0,gpu=0)))
class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*_args):pass
    def do_POST(self):
        global active,peak
        raw=self.rfile.read(int(self.headers.get('Content-Length','0')))
        with lock:
            entry=dict(index=len(receipts),path=self.path,payload_sha256=hashlib.sha256(raw).hexdigest(),
                       occurrence=self.headers.get('X-Fixture-Occurrence'),case=self.headers.get('X-Fixture-Case'),
                       received_monotonic=time.monotonic(),completed_monotonic=None)
            receipts.append(entry);active+=1;peak=max(peak,active)
            with (root/'fixture-receipts.jsonl').open('a') as log:log.write(json.dumps(entry)+'\n')
            if len(receipts)+prior_posts>=4980:
                os.kill(os.getppid(),signal.SIGTERM)
        status()
        try:
            if self.path=='/slow':
                cancel_started.set();time.sleep(.8)
            time.sleep(float(self.headers.get('X-Fixture-Delay','0')))
            body=json.dumps(dict(id='owned-fixture-response',object='chat.completion',created=0,
                model='Qwen2.5-1.5B-Instruct',fixture_occurrence=int(entry['occurrence']) if entry['occurrence'] is not None else None,
                choices=[dict(index=0,message=dict(role='assistant',content='True'),finish_reason='stop')],
                usage=dict(prompt_tokens=2,completion_tokens=1,total_tokens=3))).encode()
            self.send_response(200);self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(body)));self.end_headers()
            try:self.wfile.write(body);self.wfile.flush()
            except (BrokenPipeError,ConnectionResetError):pass
        finally:
            with lock:active-=1;entry['completed_monotonic']=time.monotonic()
            status()
cancel_started=threading.Event()
fixture=ThreadingHTTPServer(('127.0.0.1',0),Handler);fixture.daemon_threads=True
fixture_thread=threading.Thread(target=fixture.serve_forever,daemon=True);fixture_thread.start()
base='http://127.0.0.1:'+str(fixture.server_port)
report['fixture_port']=fixture.server_port

class AuthorSession:
    def __init__(self,mode,label):
        self.mode=mode;self.label=label;self.tag=uuid.uuid4().hex[:10]
        self.namespace='ic10-'+mode+'-'+self.tag
        self.out=root/(mode+'-'+label+'-'+self.tag);self.out.mkdir()
        self.service=self.owner=None;self.writer=self.owner_writer=None
        self.known={};self.peak_rss=0;self.peak_shm=0;self.sampler_stop=threading.Event();self.short=None
        sessions.append(self)
    def sample(self):
        while not self.sampler_stop.wait(.05):
            rss=0
            for p in (self.service,self.owner):
                if p is None:continue
                try:family=[psutil.Process(p.pid),*psutil.Process(p.pid).children(recursive=True)]
                except psutil.Error:continue
                for child in family:
                    try:
                        self.known[child.pid]=process_start_ticks(child.pid);rss+=child.memory_info().rss
                    except (psutil.Error,OSError):pass
            self.peak_rss=max(self.peak_rss,rss)
            self.peak_shm=max(self.peak_shm,sum(helper.resources(self.namespace).values()))
    def __enter__(self):
        python=author/'venv/bin/python';prefix=author/'prefix-patched'
        info=json.loads(subprocess.check_output([str(python),'-B','-c',
            "import sys,sysconfig,pyarrow,json;print(json.dumps(dict(site=sysconfig.get_path('purelib'),lib=pyarrow.get_library_dirs()[0],base=sys.base_prefix)))"],text=True))
        cpp=Path(subprocess.check_output(['g++','-print-file-name=libstdc++.so.6'],text=True).strip()).resolve()
        tmp=self.out/'tmp';tmp.mkdir()
        self.env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
            PATH=str(python.parent)+os.pathsep+os.environ['PATH'],
            PYTHONPATH=os.pathsep.join([info['site'],str(code),str(code/'integrations/sema')]),
            LD_LIBRARY_PATH=os.pathsep.join([str(cpp.parent),str(prefix/'lib'),info['lib'],
                str(author/'source/third_party/fmt/dist/lib'),str(author/'source/third_party/boost/dist/lib'),info['base']+'/lib']),
            TMPDIR=str(tmp),IMLANE_NAMESPACE=self.namespace,IMLANE_GATEWAY_HOST='127.0.0.1',
            IMLANE_HTTP_TRACE_DIR=str(self.out/'worker-traces'),RAY_USAGE_STATS_ENABLED='0',RAY_DEDUP_LOGS='0')
        self.env.pop('PYTHONHOME',None);self.env.pop('RAY_ADDRESS',None)
        self.sampler=threading.Thread(target=self.sample,daemon=True);self.sampler.start()
        port=helper.free_port();command=[str(prefix/'bin/imlane'),'--working_dir',str(self.out/'state'),
            '--n_executors','2','--runtime',self.mode,'--gateway_port',str(port)]
        try:
            if self.mode=='ray':
                ray=self.out/'ray';ray.mkdir();self.short=Path('/root/autodl-tmp')/('it10-'+self.tag)
                self.short.symlink_to(ray,target_is_directory=True);address=self.out/'ray-address.json'
                program="import sys,ray,json;ctx=ray.init(address='local',num_cpus=2,num_gpus=0,include_dashboard=False,object_store_memory=134217728,_node_ip_address='127.0.0.1',_temp_dir=sys.argv[1]);open(sys.argv[2],'w').write(json.dumps(dict(address=ctx.address_info['gcs_address'])));sys.stdin.readline();ray.shutdown()"
                self.owner,self.owner_writer=helper.spawn([str(python),'-B','-c',program,str(self.short),str(address)],self.env,self.out/'ray-owner.log',stdin=True)
                until=time.monotonic()+60
                while not address.is_file():
                    if self.owner.poll() is not None or time.monotonic()>=until:raise TimeoutError('owned Ray startup failed')
                    time.sleep(.05)
                command+=['--ray_address',json.loads(address.read_text())['address']]
            self.service,self.writer=helper.spawn(command,self.env,self.out/'coordinator.log')
            self.known[self.service.pid]=process_start_ticks(self.service.pid)
            until=time.monotonic()+60
            while True:
                if self.service.poll() is not None:raise RuntimeError('Coordinator exited before readiness')
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=.1):break
                except OSError:
                    if time.monotonic()>=until:raise TimeoutError('Coordinator startup failed')
                    time.sleep(.05)
            kernel=code/'integrations/sema/imlane_complete_call.py'
            probe=subprocess.run([str(root/'bridge/imlane_http'),str(port),str(kernel),'0'],
                env=self.env,input='',text=True,capture_output=True,timeout=30)
            (self.out/'probe.log').write_text(redact_text(probe.stdout+probe.stderr))
            assert probe.returncode==0,probe.stderr
            meta=json.loads(next(line.partition(' ')[2] for line in probe.stdout.splitlines() if line.startswith('SEMA_IMLANE_META ')))
            assert meta['native_task_threads']<=8
            bridge=dict(author_commit='072f8257db80569e42c9f5727d839587df529652',bridge_binary=str(root/'bridge/imlane_http'),
                bridge_sha256=hashlib.sha256((root/'bridge/imlane_http').read_bytes()).hexdigest(),gateway_port=port,
                udf_path=str(kernel),udf_sha256=hashlib.sha256(kernel.read_bytes()).hexdigest(),work_root=str(self.out/'batches'),
                namespace=self.namespace,native_task_threads=meta['native_task_threads'],
                env={k:self.env[k] for k in ('LD_LIBRARY_PATH','PATH','PYTHONPATH','TMPDIR','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS')})
            bridge_path=self.out/'bridge-config.json';bridge_path.write_text(json.dumps(bridge))
            self.cfg=IMLaneCallConfig(self.mode,str(bridge_path),self.service.pid,process_start_ticks(self.service.pid),
                str(author/'artifacts/build-patched/build-identity.json'),2)
            self.config_file=self.out/'call-config.json';self.config_file.write_text(json.dumps(self.cfg.__dict__))
            self.meta=meta
            return self
        except BaseException:
            self.__exit__(*sys.exc_info());raise
    def executor(self,*,limits=None):
        value=IMLaneCallExecutor(self.cfg,NativeGraphOptions(concurrency=8),max_batch_rows=2000)
        if limits is not None:
            value.limits=limits;value.delegate.limits=limits
            value.max_batch_rows=limits.max_batch_rows;value.max_batch_bytes=limits.max_input_payload_bytes
        return value
    def __exit__(self,*_error):
        if getattr(self,'closed',False):return
        self.closed=True
        cleanup=dict(runtime=self.mode,label=self.label,namespace=self.namespace)
        if self.service is not None:cleanup['coordinator']=helper.stop(self.service,self.writer)
        if self.owner is not None:cleanup['ray_owner']=helper.stop(self.owner,self.owner_writer,owner=True)
        self.sampler_stop.set()
        if hasattr(self,'sampler'):self.sampler.join(2)
        cleanup['owned_survivors']=[]
        for pid,ticks in self.known.items():
            try:
                p=psutil.Process(pid)
                if process_start_ticks(pid)==ticks and p.status()!=psutil.STATUS_ZOMBIE:cleanup['owned_survivors'].append(pid)
            except (psutil.Error,OSError):pass
        cleanup.update(remaining_shm=helper.resources(self.namespace),owned_process_identities=[dict(pid=p,start_ticks=t) for p,t in sorted(self.known.items())],
            author_rss_peak_bytes_observed=self.peak_rss,author_shm_peak_bytes_observed=self.peak_shm)
        if self.short is not None and self.short.is_symlink():self.short.unlink()
        cleanup['passed']=not cleanup['owned_survivors'] and not cleanup['remaining_shm'] and all(
            not cleanup[k]['forced'] and cleanup[k]['returncode']==0 for k in ('coordinator','ray_owner') if k in cleanup)
        traces=[]
        for p in (self.out/'worker-traces').glob('*.jsonl'):
            traces.extend(json.loads(line) for line in p.read_text().splitlines())
        cleanup['actual_worker_pids']=sorted({r['worker_pid'] for r in traces})
        cleanup['ray_actor_ids']=sorted({r['ray_actor_id'] for r in traces if r.get('ray_actor_id')})
        report['cleanup'].append(cleanup);(self.out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

def normal(session,label):
    executor=session.executor()
    try:
        values=list(executor.iter_batch(tuple(NativeCall(label+':'+str(i),i,b'{}',base+'/normal',(),5) for i in range(2))))
        assert len(values)==2 and executor.last_close_report['clean']
        return executor.last_close_report
    finally:executor.close()

try:
    for mode in ('cpython','ray'):
        mode_report=dict(runtime=mode,cases={});report['modes'].append(mode_report)
        before=len(receipts)
        with AuthorSession(mode,'complete-and-error') as session:
            mode_report['settings']=session.meta
            mode_report['cases']['pre_dispatch_cancel']=dict(posts=0)
            adapter=session.executor()
            try:
                list(adapter.iter_batch((NativeCall('cancel-before',0,b'{}',base+'/unused',(),5),),cancelled=lambda:True))
                raise AssertionError('pre-dispatch cancel was ignored')
            except InterruptedError:pass
            assert len(receipts)==before
            one=NativeCall('over-bytes',0,b'{}',base+'/unused',(),5)
            rejected=[]
            for limits in (IMLaneBatchLimits(max_batch_rows=2000,max_item_payload_bytes=1),
                           IMLaneBatchLimits(max_batch_rows=2000,max_input_payload_bytes=1),
                           IMLaneBatchLimits(max_batch_rows=2000,max_input_wire_bytes=1)):
                target=session.executor(limits=limits)
                try:
                    list(target.iter_batch((one,)));raise AssertionError('oversize accepted')
                except ValueError as error:rejected.append(getattr(error,'details',{}))
                finally:target.close()
            assert all(item['author_submission_started'] is False for item in rejected)
            assert len(receipts)==before
            mode_report['cases']['byte_rejections']=rejected
            # Direct binary rejection needs no Coordinator connection and sends no POST.
            rejected_cpp=[]
            for profile,wires in ((IMLaneBatchLimits(max_batch_rows=2000),[_call_wire(replace(one,call_id='over:'+str(i))) for i in range(2001)]),
                                  (IMLaneBatchLimits(max_batch_rows=2000,max_item_payload_bytes=1),[_call_wire(one)]),
                                  (IMLaneBatchLimits(max_batch_rows=2000,max_input_payload_bytes=1),[_call_wire(one)]),
                                  (IMLaneBatchLimits(max_batch_rows=2000,max_input_wire_bytes=1),[_call_wire(one)])):
                check=subprocess.run([str(root/'bridge/imlane_http'),'1',str(code/'integrations/sema/imlane_complete_call.py'),'6',*profile.cpp_arguments()],
                    env=session.env,input='\n'.join(wires)+'\n',text=True,capture_output=True,timeout=15)
                assert check.returncode==1 and 'author submission has not started' in check.stdout
                assert 'SEMA_IMLANE_META ' not in check.stdout
                rejected_cpp.append(dict(returncode=check.returncode,output=redact_text(check.stdout)))
            mode_report['cases']['cpp_rejections']=rejected_cpp
            client_result=session.out/'client-result.json'
            if mode in prior_modes:
                completed=prior_modes[mode]['cases']['full_client']
                assert completed['passed'] and completed['q1']['completed']
                mode_report['cases']['full_client']=completed
                mode_report['cases']['completed_client_reused_from_prior_attempt']=os.environ['IMLANE_CAPACITY_PREVIOUS_COMPLETE']
                expected_client_posts=0
            else:
                with (session.out/'client.log').open('x') as log:
                    result=subprocess.run(['/root/autodl-tmp/venvs/sembench-query-0910/bin/python','-B',str(root/'capacity-client.py'),
                        str(root),str(session.config_file),base,str(client_result)],env=session.env,stdout=log,stderr=subprocess.STDOUT,timeout=360)
                if client_result.is_file():mode_report['cases']['full_client']=json.loads(client_result.read_text())
                assert result.returncode==0,('capacity client failed',result.returncode)
                expected_client_posts=2259
            assert len(receipts)-before==expected_client_posts
            if mode in prior_modes:
                saved=prior_modes[mode]['cases']['continued_supply']
                assert saved['third_started_before_first_completed'] and saved['close']['clean']
                mode_report['cases']['continued_supply']=saved
                mode_report['cases']['completed_window_reused_from_prior_attempt']=os.environ['IMLANE_CAPACITY_PREVIOUS_COMPLETE']
            else:
                # Observe replenishment with a small holding allowance so the
                # author's existing task queue cannot hide it behind 128 entries.
                window=IMLaneCallExecutor(session.cfg,NativeGraphOptions(concurrency=8),max_batch_rows=2000,max_pending_calls=2)
                barrier_before=len(receipts)
                calls=tuple(NativeCall('continuous:'+str(i),i,b'{}',base+'/diagnostic',
                    (('X-Fixture-Occurrence',str(i)),('X-Fixture-Case','window-two'),
                     ('X-Fixture-Delay','2' if i==0 else '0')),5) for i in range(8))
                try:
                    values=list(window.iter_batch(calls))
                    assert len(values)==8 and window.last_close_report['clean']
                    assert window.last_close_report['bridge_stats']['pending_peak']==2
                    observed=receipts[barrier_before:]
                    first=next(r for r in observed if r['occurrence']=='0')
                    third=next(r for r in observed if r['occurrence']=='2')
                    assert third['received_monotonic']<first['completed_monotonic']
                    mode_report['cases']['continued_supply']=dict(rows=8,max_pending_calls=2,
                        third_started_before_first_completed=True,close=window.last_close_report)
                finally:window.close()
            errored=session.executor()
            try:
                list(errored.iter_batch((NativeCall('response-size-error',0,b'{}',base+'/error',(),5,max_response_bytes=256),)))
                raise AssertionError('response capacity error disappeared')
            except ValueError as error:
                assert 'ValueError:' in getattr(error,'native_execution_error','')
                mode_report['cases']['execution_error']=dict(type=type(error).__name__,diagnostic=str(error),close=errored.last_close_report)
            assert errored.last_close_report['external_coordinator_requires_cleanup']
            another=session.executor()
            try:
                list(another.iter_batch((NativeCall('blocked',0,b'{}',base+'/unused',(),5),)))
                raise AssertionError('uncertain author accepted another query')
            except RuntimeError as error:assert 'unsettled' in str(error)
            finally:another.close();errored.close();adapter.close()
        assert report['cleanup'][-1]['passed']
        with AuthorSession(mode,'after-error-and-cancel') as session:
            mode_report['cases']['normal_after_error_cleanup']=normal(session,'after-error')
            cancelled=threading.Event();cancel_started.clear();target=session.executor()
            with ThreadPoolExecutor(max_workers=1) as pool:
                future=pool.submit(lambda:list(target.iter_batch((NativeCall('cancel-sent',0,b'{}',base+'/slow',(),5),),cancelled=cancelled.is_set,timeout_s=15)))
                assert cancel_started.wait(10);cancelled.set()
                try:future.result(timeout=10);raise AssertionError('sent cancellation ignored')
                except InterruptedError:pass
            mode_report['cases']['cancel_after_send']=target.last_close_report
            assert target.last_close_report['external_coordinator_requires_cleanup']
            target.close();time.sleep(.85)
        assert report['cleanup'][-1]['passed']
        with AuthorSession(mode,'after-cancel') as session:
            mode_report['cases']['normal_after_cancel_cleanup']=normal(session,'after-cancel')
        assert report['cleanup'][-1]['passed']
        mode_report.update(passed=True,actual_posts=len(receipts)-before)
        assert mode_report['actual_posts']==6
        (root/(mode+'-result.json')).write_text(json.dumps(mode_report,indent=2)+'\n')
    report['passed']=len(report['modes'])==2 and all(m.get('passed') for m in report['modes'])
except BaseException as error:
    report.update(passed=False,error_type=type(error).__name__,error=redact_text(str(error)))
    raise
finally:
    for session in reversed(sessions):session.__exit__(None,None,None)
    fixture.shutdown();fixture.server_close();fixture_thread.join(2)
    report.update(actual_posts=len(receipts)+prior_posts,attempt_posts=len(receipts),fixture_active_after_cleanup=active,fixture_peak_active=peak,
                  fixture_server_closed=fixture.fileno()==-1,elapsed_seconds=time.monotonic()-start)
    report['passed']=report.get('passed',False) and all(c['passed'] for c in report['cleanup']) and len(receipts)+prior_posts<=5000 and active==0
    (root/'test-result.json').write_text(json.dumps(report,indent=2)+'\n')
    (root/'completed-receipts.json').write_text(json.dumps(receipts)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('modes','cleanup')}),flush=True)
raise SystemExit(not report['passed'])
