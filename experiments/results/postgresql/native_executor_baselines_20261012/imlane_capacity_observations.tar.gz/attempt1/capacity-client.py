"""One LOTUS driver: finite diagnostic batches and the unchanged original Movie Q1."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time
from dataclasses import replace

root=Path(sys.argv[1]);config_file=Path(sys.argv[2]);endpoint=sys.argv[3];output=Path(sys.argv[4])
sys.path.insert(0,str(root/'source/code'))
from src.baselines.text.frameworks.imlane_calls import IMLaneCallConfig,IMLaneCallExecutor
from src.baselines.text.frameworks.native_calls import NativeCall,_call_wire
from src.baselines.text.frameworks.prepared_map import NativeGraphOptions
from src.baselines.common.redact import redact_text
from src.execution_provider.adapters.model_config import FixedModelConfig
from src.semantic_methods.lotus.batch import lotus_executor
from src.semantic_methods.lotus.native import LotusNativeBatchExecutor

config=IMLaneCallConfig(**json.loads(config_file.read_text()))
adapter=IMLaneCallExecutor(config,NativeGraphOptions(concurrency=8),max_batch_rows=2000)
facts=dict(runtime=config.runtime,models=0,gpu=0,tests=[],q1=None)
def save():output.write_text(json.dumps(facts,indent=2)+'\n')
def diagnostic(count,name,*,slow=False):
    payload=b'{"text":"duplicate complete request"}'
    calls=tuple(NativeCall(name+':'+str(i),i//3,payload,endpoint+'/diagnostic',
        (('Content-Type','application/json'),('X-Fixture-Occurrence',str(i)),
         ('X-Fixture-Case',name),('X-Fixture-Delay','2' if i==0 and slow else '.08' if i==0 else '0')),5)
        for i in range(count))
    iterator=adapter.iter_batch(calls,timeout_s=120)
    first=next(iterator);time.sleep(.2)
    values=[first,*iterator]
    expected={c.call_id:c for c in calls}
    assert len(values)==count and len({v.call_id for v in values})==count
    for value in values:
        call=expected[value.call_id]
        assert value.row_id==call.row_id and value.response.status_code==200
        assert json.loads(value.response.body)['fixture_occurrence']==int(value.call_id.rsplit(':',1)[1])
    assert [v.call_id for v in values]!=[c.call_id for c in calls]
    close=adapter.last_close_report
    assert close['clean'] and close['bridge_stats']['submitted']==count
    assert close['bridge_stats']['pending_peak']<=128
    facts['tests'].append(dict(case=name,rows=count,first_call_id=first.call_id,
        duplicate_payload_sha256=hashlib.sha256(payload).hexdigest(),slow_consumer_seconds=.2,close=close))
    save()

try:
    diagnostic(128,'capacity-128')
    diagnostic(129,'capacity-129',slow=True)
    import lotus
    import pandas as pd
    from lotus.models import LM
    from tokenizers import Tokenizer
    raw=Path('/root/autodl-tmp/sq-b/movie-sf2000/prepared2/raw.jsonl')
    csv=Path('/root/autodl-tmp/sq-b/movie-sf2000/Reviews.csv')
    expected=json.loads((root/'q1-size.json').read_text())
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==expected['raw_sha256']
    assert hashlib.sha256(csv.read_bytes()).hexdigest()==expected['csv_sha256']
    rows=[json.loads(line) for line in raw.read_text().splitlines()]
    assert len(rows)==2000 and len({row[1] for row in rows})==2000
    frame=pd.DataFrame([(r[4],r[2],r[3],r[1]) for r in rows],columns=['reviewId','id','reviewText','_execution_row_id'])
    model=FixedModelConfig(endpoint+'/v1/chat/completions','Qwen2.5-1.5B-Instruct',5000,'local-fixture')
    lm=LM('openai/'+model.model_id,api_base=endpoint+'/v1',api_key='***',
        temperature=0,top_p=1,max_tokens=8,max_batch_size=8,stop=['\n'],num_retries=0,max_retries=0,
        timeout=5,tokenizer=Tokenizer.from_file('/root/autodl-tmp/models/Qwen2.5-1.5B-Instruct/tokenizer.json'))
    prepared={};delivered=[]
    class CapturedBridge:
        max_batch_rows=2000
        max_batch_bytes=32*1024**2
        last_close_report=None
        last_cleanup_errors=()
        def iter_batch(self,calls,**options):
            assert len(calls)==2000
            original_wires=[_call_wire(replace(call,endpoint='http://127.0.0.1:9/v1/chat/completions')).encode() for call in calls]
            prepared.update(input_rows=len(calls),payload_total_bytes=sum(len(c.payload) for c in calls),
                actual_stdin_bytes=sum(len(_call_wire(c).encode())+1 for c in calls),
                max_payload_bytes=max(len(c.payload) for c in calls),
                payload_sequence_sha256=hashlib.sha256(b''.join(c.payload for c in calls)).hexdigest(),
                original_wire_sequence_sha256=hashlib.sha256(b'\n'.join(original_wires)+b'\n').hexdigest(),
                max_response_bytes=calls[0].max_response_bytes)
            assert prepared['payload_sequence_sha256']==expected['payload_sequence_sha256'],prepared
            assert prepared['original_wire_sequence_sha256']==expected['wire_sequence_sha256'],prepared
            assert prepared['payload_total_bytes']==expected['payload_total_bytes']
            facts['q1']=dict(prepared=prepared,started=True,completed=False);save()
            try:yield from adapter.iter_batch(calls,**options)
            finally:self.last_close_report=adapter.last_close_report
    bridge=CapturedBridge()
    def response(index,full):
        if not delivered:time.sleep(.2)
        assert full.status_code==200
        delivered.append(index)
    selected=LotusNativeBatchExecutor(bridge,model,query_id='q1-offline',operator_id='filter',
                                      max_batch_rows=2000,on_response=response)
    q1_module=Path('/tmp/sb4.a741/source/code/src/baselines/text/sembench_movie.py')
    assert hashlib.sha256(q1_module.read_bytes()).hexdigest()==json.loads((root/'existing-source-hashes.json').read_text())['q1_module']
    spec=importlib.util.spec_from_file_location('original_sembench_adapter',q1_module)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    with lotus.settings.context(lm=lm,enable_cache=False),lotus_executor(lm,selected):
        result=module.run_original_lotus_query('/root/autodl-tmp/sq-b/sembench-checkout',1,lambda:frame)
    assert len(delivered)==2000 and set(delivered)==set(range(2000))
    assert adapter.last_close_report['clean']
    assert adapter.last_close_report['bridge_stats']['submitted']==2000
    assert adapter.last_close_report['bridge_stats']['delivered']==2000
    assert len(result)==5,result
    facts['q1'].update(completed=True,original_query_result_rows=len(result),
        complete_responses=len(delivered),distinct_occurrences=len(set(delivered)),
        output_columns=list(result.columns),slow_consumer_seconds=.2,
        close=adapter.last_close_report,original_parser='LOTUS 1.2.4 sem_filter')
    save()
    calls=tuple(NativeCall('follow:'+str(i),i,b'{}',endpoint+'/normal',(),5) for i in range(2))
    values=list(adapter.iter_batch(calls));assert len(values)==2 and adapter.last_close_report['clean']
    facts['tests'].append(dict(case='next-normal-after-Q1',rows=2,close=adapter.last_close_report))
    before=adapter._facts
    try:
        list(adapter.iter_batch(tuple(NativeCall('over:'+str(i),i,b'{}',endpoint+'/unused',(),5) for i in range(2001))))
        raise AssertionError('2001 rows accepted')
    except ValueError as error:
        assert getattr(error,'details',{}).get('author_submission_started') is False
        facts['tests'].append(dict(case='2001-rejection',details=error.details))
    assert adapter._facts==before
    facts['passed']=True;save()
except BaseException as error:
    facts.update(passed=False,error_type=type(error).__name__,error=redact_text(str(error)))
    save();raise
finally:adapter.close()
