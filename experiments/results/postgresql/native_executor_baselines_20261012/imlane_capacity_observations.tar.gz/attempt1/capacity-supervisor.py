"""Finite CPU-only process owner. Every cleanup target is identified by PID/start ticks."""
from pathlib import Path
import json
import os
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
phase=sys.argv[1];started=float(sys.argv[2]);limit=int(sys.argv[3]);deadline=started+limit
token=os.environ['IMLANE_CAPACITY_RUN_TOKEN']
known={};child=None;ancestors={os.getpid()}
report=dict(phase=phase,actual_launch_monotonic=started,hard_deadline_monotonic=deadline,
            wall_limit_seconds=limit,cpu_affinity=sorted(os.sched_getaffinity(0)),models=0,gpu=0)
def identities():
    values={}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            cells=(p/'stat').read_text().rsplit(')',1)[1].split()
            values[int(p.name)]=(int(cells[1]),int(cells[19]),cells[0])
        except (OSError,ValueError):pass
    return values
parent=os.getppid()
initial=identities()
while parent>1 and parent not in ancestors:
    ancestors.add(parent)
    parent=initial.get(parent,(1,0,''))[0]
def scan():
    values=identities()
    for pid,value in values.items():
        if pid in ancestors:continue
        try:
            if ('IMLANE_CAPACITY_RUN_TOKEN='+token).encode() in Path(f'/proc/{pid}/environ').read_bytes().split(b'\0'):
                known[pid]=value[1]
        except OSError:pass
    return values
def live(pid,ticks,values=None):
    value=(values if values is not None else identities()).get(pid)
    return value is not None and value[1]==ticks and value[2]!='Z'
def stopped(_signal,_frame):raise TimeoutError('supervisor received a stop signal')
signal.signal(signal.SIGTERM,stopped)
signal.signal(signal.SIGINT,stopped)
try:
    with (root/(phase+'-child.log')).open('x') as log:
        python=('/root/autodl-tmp/venvs/sembench-query-0910/bin/python' if phase=='build'
                else '<checked-author-build>/venv/bin/python')
        child=subprocess.Popen([python,'-B',str(root/(phase+'-runner.py'))],cwd=root,
             stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        known[child.pid]=identities()[child.pid][1]
        while child.poll() is None:
            scan()
            if time.monotonic()>=deadline-(12 if phase=='build' else 65):
                raise TimeoutError('finite software time allowance reached; cleanup starts')
            time.sleep(.15)
        report['child_exit']=child.returncode
except BaseException as error:
    report.update(timed_out=isinstance(error,TimeoutError),error_type=type(error).__name__,error=str(error))
finally:
    signal.signal(signal.SIGTERM,signal.SIG_IGN)
    values=scan();remaining=[(p,t) for p,t in known.items() if live(p,t,values)]
    report['cleanup_requested']=[p for p,_ in remaining]
    for pid,ticks in remaining:
        if live(pid,ticks):
            try:os.kill(pid,signal.SIGTERM)
            except ProcessLookupError:pass
    until=min(deadline-3,time.monotonic()+8)
    while time.monotonic()<until:
        values=scan()
        if not any(live(p,t,values) for p,t in known.items()):break
        time.sleep(.1)
    report['forced_cleanup']=[]
    for pid,ticks in list(known.items()):
        if live(pid,ticks):
            try:os.kill(pid,signal.SIGKILL);report['forced_cleanup'].append(pid)
            except ProcessLookupError:pass
    if child is not None:
        try:child.wait(timeout=max(.1,min(2,deadline-time.monotonic())))
        except subprocess.TimeoutExpired:pass
    values=scan()
    report['owned_process_identities']=[dict(pid=p,start_ticks=t) for p,t in sorted(known.items())]
    report['owned_survivors']=[p for p,t in known.items() if live(p,t,values)]
    report['elapsed_seconds']=time.monotonic()-started
    report['passed']=report.get('child_exit')==0 and not report['owned_survivors'] and not report.get('timed_out',False) and report['elapsed_seconds']<=limit
    (root/(phase+'-supervisor-result.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)
raise SystemExit(not report['passed'])
