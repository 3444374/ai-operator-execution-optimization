"""One CPU-only, localhost-library window using the existing common host lease."""
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import signal
import sys
import threading
import time
import traceback

import psutil

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT / 'plan.json').read_text())
sys.path.insert(0, str(ROOT / 'source/code'))
from src.infrastructure.runner_lease import acquire_runner_lease, HOST_SCOPE_DIR_NAME, HOST_SCOPE_FINGERPRINT
from src.baselines.common.redact import redact_json_values, redact_text



def main():
    def interrupted(number, _frame):
        raise RuntimeError('software window interrupted by signal ' + str(number))
    for number in (signal.SIGINT, signal.SIGTERM):
        signal.signal(number, interrupted)
    def save(name, value):
        path = ROOT / name
        with path.open('x') as stream:
            json.dump(redact_json_values(value), stream, indent=2)
            stream.write('\n')


    def verify_files():
        manifest = json.loads((ROOT / 'bundle-manifest.json').read_text())
        for name, identity in manifest['files'].items():
            content = (ROOT / name).read_bytes()
            if len(content) != identity['bytes'] or hashlib.sha256(content).hexdigest() != identity['sha256']:
                raise RuntimeError('package digest mismatch: ' + name)


    verify_files()
    if (ROOT / 'window-started.json').exists():
        raise RuntimeError('window already attempted; no implicit repeat or budget reset')
    if str(ROOT) != PLAN['remote_root'] or os.sys.executable != PLAN['driver_python']:
        raise RuntimeError('unexpected target or driver')
    if not set(PLAN['cpu_affinity']).issubset(os.sched_getaffinity(0)):
        raise RuntimeError('requested CPU mask unavailable')
    os.sched_setaffinity(0, set(PLAN['cpu_affinity']))
    for package, version in PLAN['pinned_versions'].items():
        if importlib.metadata.version(package) != version:
            raise RuntimeError('fixed dependency mismatch: ' + package)
    if (Path(PLAN['host_scope']) / '.host-runner-scope/.runner-lease.json').exists():
        raise RuntimeError('common lease exists; leave it intact and report software window required')
    gpu_pids = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
        '--format=csv,noheader'], text=True, timeout=10).strip()
    if gpu_pids:
        raise RuntimeError('existing GPU work; stop before library checks')
    for process in psutil.process_iter(['pid', 'cmdline']):
        if process.pid == os.getpid():
            continue
        words = process.info['cmdline'] or []
        executables = [Path(word).name for word in words]
        if any(name in ('raylet', 'gcs_server') for name in executables) or any(
                word.endswith(('.py', '.sh')) and any(label in Path(word).name for label in
                    ('run_ai_operator_scenarios', 'run_shared_vllm_experiment',
                     'run_official_baseline_gate', 'pilot_supervisor', 'single_gpu'))
                for word in words):
            raise RuntimeError('existing experiment process; report software window required')

    started, epoch = time.monotonic(), time.time()
    save('window-started.json', dict(started_epoch=epoch,
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        deadline_epoch=epoch + PLAN['max_seconds'], source_sha=PLAN['source_sha']))
    owned, samples, violations, forced, outcomes = {}, [], [], [], []
    lease, child, error = None, None, None


    def observe():
        root = psutil.Process(os.getpid())
        processes = [root, *root.children(recursive=True)]
        for pid, birth in tuple(owned):
            try:
                process = psutil.Process(pid)
                if process.create_time() == birth and process not in processes:
                    processes.append(process)
            except psutil.NoSuchProcess:
                pass
        rss = 0
        for process in processes:
            try:
                birth = process.create_time()
                if process.status() == psutil.STATUS_ZOMBIE:
                    continue
                affinity = process.cpu_affinity()
                owned[(process.pid, birth)] = dict(pid=process.pid, birth=birth, name=process.name())
                if not set(affinity).issubset(PLAN['cpu_affinity']):
                    violations.append(dict(pid=process.pid, affinity=affinity))
                rss += process.memory_info().rss
            except psutil.NoSuchProcess:
                pass
        samples.append(dict(monotonic_ns=time.monotonic_ns(), summed_rss_bytes=rss))
        return rss


    def live_owned():
        current = []
        for pid, birth in tuple(owned):
            if pid == os.getpid():
                continue
            try:
                process = psutil.Process(pid)
                if process.create_time() == birth and process.status() != psutil.STATUS_ZOMBIE:
                    current.append(process)
            except psutil.NoSuchProcess:
                pass
        return current


    def stop_owned():
        matches = live_owned()
        for process in matches:
            try:
                process.terminate()
                forced.append(dict(pid=process.pid, action='terminate'))
            except psutil.NoSuchProcess:
                pass
        _, alive = psutil.wait_procs(matches, timeout=3)
        for process in alive:
            try:
                process.kill()
                forced.append(dict(pid=process.pid, action='kill'))
            except psutil.NoSuchProcess:
                pass
        psutil.wait_procs(alive, timeout=3)


    def rows(pattern):
        result = []
        for path in (ROOT / 'fixtures').rglob(pattern):
            # The watcher may read during a flush. The next sample sees the
            # final line; all logs must end in a newline at postflight.
            content = path.read_text()
            lines = content.splitlines()
            if content and not content.endswith('\n'):
                lines = lines[:-1]
            result.extend(json.loads(line) for line in lines if line.strip())
        return result


    def http_counts():
        fixture = sum(row['event'] == 'fixture_received' for row in rows('fixture-receipts.jsonl'))
        arrivals = len(rows('proxy-arrivals.jsonl'))
        proxy = len(rows('proxy-trace.jsonl'))
        return dict(fixture_posts=fixture, proxy_arrivals=arrivals,
            proxy_posts=proxy, observed_physical_posts=arrivals + fixture,
            completed_trace_physical_posts=proxy + fixture)


    def fixture_posts():
        return http_counts()['fixture_posts']


    def check_limits(*, reserve=45):
        observe()
        quota = Path('/sys/fs/cgroup/cpu.max').read_text().split()
        if quota[0] == 'max' or int(quota[0]) / int(quota[1]) != PLAN['cpu_quota']:
            raise RuntimeError('host CPU quota changed during software window')
        if lease is not None:
            identity = json.loads(lease.path.read_text())
            if identity['owner_token'] != lease.owner.owner_token or identity['config_fingerprint'] != HOST_SCOPE_FINGERPRINT:
                raise RuntimeError('common lease ownership changed')
        reasons = []
        if time.monotonic() - started >= PLAN['max_seconds'] - reserve:
            reasons.append('time')
        if max(item['summed_rss_bytes'] for item in samples) > PLAN['max_sampled_rss_bytes']:
            reasons.append('sampled summed RSS')
        if violations:
            reasons.append('affinity')
        counts = http_counts()
        if counts['fixture_posts'] > PLAN['max_logical_calls']:
            reasons.append('completed fixture POST count')
        if counts['observed_physical_posts'] > PLAN['max_physical_posts']:
            reasons.append('physical POST count')
        if reasons:
            raise RuntimeError('resource stop condition: ' + ', '.join(reasons))


    def copy_log(stream, log, failures):
        try:
            for raw in iter(stream.readline, b''):
                log.write(redact_text(raw.decode('utf-8', errors='replace')))
                log.flush()
        except BaseException as failure:
            failures.append(dict(type=type(failure).__name__, message=str(failure)))


    env = dict(os.environ, PYTHONPATH=str(ROOT / 'source/code'), PYTHONDONTWRITEBYTECODE='1',
        SEMLOOM_NATIVE_ADAPTER_COMPLETION_TEST='1',
        SEMLOOM_NATIVE_ADAPTER_COMPLETION_ROOT=str(ROOT / 'fixtures'),
        SEMLOOM_NATIVE_ADAPTER_COMPLETION_BUDGET=str(ROOT / 'budget.sqlite'),
        SEMLOOM_NATIVE_ADAPTER_COMPLETION_BUDGET_ID=PLAN['run_id'],
        RAY_DATA_DEFAULT_ASYNC_BATCH_UDF_MAX_CONCURRENCY='2', CUDA_VISIBLE_DEVICES='',
        HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', RAY_USAGE_STATS_ENABLED='0',
        OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
        TOKENIZERS_PARALLELISM='false', NO_PROXY='localhost,127.0.0.1,::1',
        TMPDIR=str(ROOT / 'tmp'), XDG_CACHE_HOME=str(ROOT / 'cache'))
    for key in ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy',
                'all_proxy', 'RAY_ADDRESS', 'RAY_NAMESPACE'):
        env.pop(key, None)
    try:
        lease = acquire_runner_lease(Path(PLAN['host_scope']) / HOST_SCOPE_DIR_NAME,
            config_fingerprint=HOST_SCOPE_FINGERPRINT, repository_commit=PLAN['source_sha'], recover_stale=False)
        save('lease-acquired.json', dict(pid=os.getpid(), source_sha=PLAN['source_sha'],
            owner_token_sha256=hashlib.sha256(lease.owner.owner_token.encode()).hexdigest(),
            recovered_stale=lease.recovered_owner is not None))
        for name in ('tmp', 'cache', 'fixtures'):
            (ROOT / name).mkdir()
        from src.experiments.attempt_ledger import AttemptBudget
        from src.experiments.cell_budget import CellBudgetLedger
        CellBudgetLedger.create(ROOT / 'budget.sqlite', AttemptBudget(PLAN['run_id'], PLAN['max_logical_calls']),
            deadline_utc=epoch + PLAN['max_seconds'] - 45)
        preflight = subprocess.run([sys.executable, str(ROOT / 'source/code/scripts/environment/manage_environment.py'),
            '--env-file', PLAN['env_file'], 'check', '--groups', 'core,text',
            '--json-out', str(ROOT / 'runtime-preflight.json')], cwd=ROOT / 'source', env=env,
            capture_output=True, text=True, timeout=30)
        (ROOT / 'runtime-preflight.log').write_text(redact_text(preflight.stdout + preflight.stderr))
        if preflight.returncode:
            raise RuntimeError('read-only core,text runtime preflight failed')
        for group in PLAN['groups']:
            if time.monotonic() - started >= PLAN['max_seconds'] - 45:
                raise TimeoutError('cleanup reserve reached')
            at = time.monotonic()
            env['SEMLOOM_NATIVE_ADAPTER_COMPLETION_ROOT'] = str(ROOT / 'fixtures' / group['name'])
            env['SEMLOOM_NATIVE_ADAPTER_COMPLETION_RAY_TMP'] = str(ROOT / group['ray_dir'])
            env['RAY_DATA_DEFAULT_ASYNC_BATCH_UDF_MAX_CONCURRENCY'] = str(group['async_batches'])
            log_failures = []
            with (ROOT / (group['name'] + '.log')).open('x') as log:
                child = subprocess.Popen([sys.executable, str(ROOT / 'qualify_native.py'), group['name']],
                    cwd=ROOT / 'source', env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    start_new_session=True)
                child_process = psutil.Process(child.pid)
                child_birth = child_process.create_time()
                owned[(child.pid, child_birth)] = dict(pid=child.pid, birth=child_birth, name=child_process.name())
                reader = threading.Thread(target=copy_log, args=(child.stdout, log, log_failures), daemon=True)
                reader.start()
                try:
                    while child.poll() is None:
                        if time.monotonic() - at >= group['max_seconds']:
                            raise TimeoutError('selected actual-library group timed out')
                        check_limits()
                        if log_failures:
                            raise RuntimeError('redacted log copy failed')
                        time.sleep(.1)
                    code = child.wait(timeout=5)
                except BaseException:
                    observe()
                    stop_owned()
                    raise
                finally:
                    reader.join(5)
                    if reader.is_alive():
                        observe()
                        stop_owned()
                        reader.join(5)
                    if reader.is_alive() or log_failures:
                        raise RuntimeError('redacted log close unconfirmed')
                    child.stdout.close()
            outcomes.append(dict(group=group['name'], returncode=code, seconds=time.monotonic() - at,
                cumulative_http=http_counts()))
            check_limits()
            if code:
                raise RuntimeError(group['name'] + ' failed; no automatic additional run')
        verify_files()
    except BaseException as failure:
        error = dict(type=type(failure).__name__, message=str(failure))
    finally:
        cleanup_errors = []
        remaining = None
        try:
            observe()
        except BaseException as failure:
            cleanup_errors.append(dict(action='observe', type=type(failure).__name__, message=str(failure)))
        try:
            deadline = min(time.monotonic() + 5, started + PLAN['max_seconds'] - 10)
            while live_owned() and time.monotonic() < deadline:
                time.sleep(.1)
            stop_owned()
            remaining = [process.pid for process in live_owned()]
        except BaseException as failure:
            cleanup_errors.append(dict(action='stop_owned', type=type(failure).__name__, message=str(failure)))
        try:
            if child is not None and child.poll() is None:
                child.wait(timeout=5)
        except BaseException as failure:
            cleanup_errors.append(dict(action='wait_child', type=type(failure).__name__, message=str(failure)))
        final_versions, final_gpu_pids, final_ray_pids = None, None, None
        try:
            check_limits(reserve=0)
            verify_files()
            final_versions = {name: importlib.metadata.version(name) for name in PLAN['pinned_versions']}
            if final_versions != PLAN['pinned_versions']:
                raise RuntimeError('fixed dependency versions changed during software window')
            final_gpu_pids = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
                '--format=csv,noheader'], text=True, timeout=10).strip().splitlines()
            if final_gpu_pids:
                raise RuntimeError('GPU process observed during zero-model software postflight')
            markers = []
            final_ray_pids = []
            for process in psutil.process_iter(['pid', 'cmdline']):
                if process.pid in {os.getpid(), *(parent.pid for parent in psutil.Process(os.getpid()).parents())}:
                    continue
                words = process.info['cmdline'] or []
                if any(str(ROOT) in word for word in words):
                    markers.append(process.pid)
                if any(Path(word).name in ('raylet', 'gcs_server') for word in words) or any(
                        word.startswith('ray::') for word in words):
                    final_ray_pids.append(process.pid)
            if markers:
                raise RuntimeError('window-marked process remains after cleanup: ' + repr(markers))
            if final_ray_pids:
                raise RuntimeError('Ray process remains after the exclusively owned window: ' + repr(final_ray_pids))
            for pattern in ('fixture-receipts.jsonl', 'proxy-arrivals.jsonl', 'proxy-trace.jsonl', 'pre-send.jsonl'):
                for path in (ROOT / 'fixtures').rglob(pattern):
                    content = path.read_text()
                    if content and not content.endswith('\n'):
                        raise RuntimeError('HTTP evidence has an incomplete final line: ' + str(path.relative_to(ROOT)))
        except BaseException as failure:
            cleanup_errors.append(dict(action='final_limits_and_identity', type=type(failure).__name__, message=str(failure)))
        counts, budget_report, validation_errors = None, None, []
        try:
            counts = http_counts()
            if (ROOT / 'budget.sqlite').exists():
                import sqlite3
                with sqlite3.connect('file:' + str(ROOT / 'budget.sqlite') + '?mode=ro', uri=True) as database:
                    tables = [row[0] for row in database.execute("SELECT name FROM sqlite_master WHERE type='table'")]
                    budget_report = dict(tables=tables,
                        allocated=database.execute('SELECT allocated FROM budget').fetchone()[0],
                        charged_logical=database.execute('SELECT count(*) FROM shared_requests').fetchone()[0] if 'shared_requests' in tables else 0)
            save('budget-postflight.json', budget_report)
            if budget_report is None or not (
                    budget_report['charged_logical'] == counts['fixture_posts'] == PLAN['expected_logical_calls']
                    and counts['proxy_arrivals'] == counts['proxy_posts'] == PLAN['expected_proxy_posts']
                    and counts['observed_physical_posts'] == PLAN['expected_physical_posts']):
                validation_errors.append(dict(action='exact_http_and_budget', message='planned counts were not all reached'))
        except BaseException as failure:
            validation_errors.append(dict(action='exact_http_and_budget', type=type(failure).__name__, message=str(failure)))
        # Count mismatches make the qualification fail. The lease can still
        # be released after all owned execution and HTTP resources have gone.
        lease_released = False
        try:
            if lease is not None and remaining == [] and not cleanup_errors:
                lease.release()
                lease_released = True
        except BaseException as failure:
            cleanup_errors.append(dict(action='release_lease', type=type(failure).__name__, message=str(failure)))
        save('window-resources.json', dict(identities=list(owned.values()), samples=samples,
            affinity_violations=violations, forced_cleanup=forced, remaining_owned_pids=remaining,
            cleanup_errors=cleanup_errors))
        counted_posts = None if counts is None else counts['fixture_posts']
        success = (error is None and budget_report is not None
            and budget_report['charged_logical'] == counted_posts == PLAN['expected_logical_calls']
            and len(outcomes) == len(PLAN['groups']) and remaining == []
            and not forced and not cleanup_errors and not validation_errors and lease_released
            and counts['proxy_arrivals'] == counts['proxy_posts'] == PLAN['expected_proxy_posts']
            and counts['observed_physical_posts'] == PLAN['expected_physical_posts'])
        report = dict(source_sha=PLAN['source_sha'], budget=budget_report, success=success, outcomes=outcomes, error=error,
            elapsed_seconds=time.monotonic() - started, fixture_posts=counted_posts,
            http_counts=counts, postflight_versions=final_versions, postflight_gpu_pids=final_gpu_pids,
            postflight_ray_pids=final_ray_pids,
            expected_fixture_posts=PLAN['expected_fixture_posts'], max_logical_calls=PLAN['max_logical_calls'],
            expected_physical_posts=PLAN['expected_physical_posts'], max_physical_posts=PLAN['max_physical_posts'],
            max_sampled_summed_rss_bytes=max((item['summed_rss_bytes'] for item in samples), default=0),
            common_lease_released=lease_released, cleanup_errors=cleanup_errors, validation_errors=validation_errors,
            remaining_owned_pids=remaining, forced_cleanup=forced, real_model_calls=0, gpu_starts=0)
        save('window-result.json', report)
        print(json.dumps(redact_json_values(report)), flush=True)
    raise SystemExit(0 if success else 1)


if __name__ == "__main__":
    try:
        main()
    except Exception as failure:
        print(json.dumps(redact_json_values(dict(type=type(failure).__name__,
            message=str(failure), traceback=traceback.format_exc()))), flush=True)
        raise SystemExit(1)
