"""Recompute each retained software window without turning failed attempts green.

Run with PYTHONPATH=<repository>/code and explicit window directories. This
reads complete response wires, gateway hashes, budget totals and postflight
records. It neither starts a runtime nor changes the retained inputs.
"""
import argparse
import base64
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3

from src.execution_provider.adapters.full_response import decode_full_response


def load(path):
    return json.loads(path.read_text())


def lines(path):
    text = path.read_text()
    if text and not text.endswith('\n'):
        raise ValueError('incomplete retained JSONL: '+path.name)
    return [json.loads(line) for line in text.splitlines() if line]


def ledger_records(root):
    database = root/'budget.sqlite'
    if not database.exists():
        retained = load(root/'budget-records.json')
        return retained['tables'], retained['source_sqlite_sha256']
    records = {}
    with sqlite3.connect(database.resolve().as_uri()+'?mode=ro', uri=True) as connection:
        connection.row_factory = sqlite3.Row
        for table in ('budget', 'units', 'shared_units', 'closed_shared_units', 'shared_requests'):
            records[table] = [dict(row) for row in connection.execute('SELECT * FROM '+table+' ORDER BY 1')]
    return records, hashlib.sha256(database.read_bytes()).hexdigest()


def audit(root):
    plan = load(root/'plan.json')
    window = load(root/'window-result.json')
    postflight = load(root/'independent-postflight.json')
    resources = load(root/'window-resources.json')
    ledger, ledger_sha = ledger_records(root)
    budget = ledger['budget'][0]
    charged = len(ledger['shared_requests'])
    allocated = sum(row['requests'] for row in ledger['units'])
    errors, units = [], []
    if (len(ledger['budget']) != 1 or budget['budget_id'] != plan['run_id']
            or budget['limit_count'] != plan['max_logical_calls']
            or allocated != budget['allocated'] or allocated > budget['limit_count']
            or charged > allocated):
        errors.append('read-only SQLite allocation/declaration mismatch')
    claimed = {row['unit_id'] for row in ledger['units'] if row['claimed']}
    shared = {row['unit_id'] for row in ledger['shared_units']}
    closed = {row['unit_id'] for row in ledger['closed_shared_units']}
    if not claimed == shared == closed or any(not row['claimed'] for row in ledger['units']):
        errors.append('reserved shared units are not all claimed and closed')
    for group in plan['groups']:
        case = group['tests'][0].rsplit('.', 1)[1]
        directory = root/'fixtures'/group['name']/case
        finals = list(directory.glob('*-final.json'))
        result_path = root/(group['name']+'-result.json')
        if not finals and not result_path.exists():
            units.append(dict(group=group['name'], case=case, status='not_run',
                              associated_outcomes=0, fixture_posts=0, proxy_posts=0))
            continue
        if len(finals) != 1 or not result_path.exists():
            errors.append('missing unique case record: '+group['name'])
            continue
        final, result = load(finals[0]), load(result_path)
        receipts = lines(directory/'fixture-receipts.jsonl')
        requests = [row for row in receipts if row['event'] == 'fixture_complete_body']
        trace = lines(directory/'proxy-trace.jsonl')
        arrivals = lines(directory/'proxy-arrivals.jsonl')
        charges = lines(directory/'pre-send.jsonl')
        ledger_charges = [row for row in ledger['shared_requests'] if row['unit_id'] == case]
        if (Counter(row['request_sha256'] for row in ledger_charges)
                != Counter(row['request_sha256'] for row in charges)):
            errors.append('SQLite charged identities differ from pre-send log: '+group['name'])
        declared = [row for row in ledger['units'] if row['unit_id'] == case]
        if len(declared) != 1 or declared[0]['requests'] != group['expected_fixture_posts']:
            errors.append('reserved case request count differs from planned unit: '+group['name'])
        by_call = {row['call_id']: row for row in requests}
        if len(by_call) != len(requests):
            errors.append('duplicate complete fixture identity: '+group['name'])
        sent_hashes = Counter(hashlib.sha256(base64.b64decode(row['body_base64'])).hexdigest()
                              for row in requests)
        if any(sent_hashes != Counter(row[field] for row in rows)
               for rows, field in ((charges, 'request_sha256'), (trace, 'request_body_sha256'),
                                   (arrivals, 'request_sha256'))):
            errors.append('pre-send/gateway/fixture request hashes disagree: '+group['name'])
        if not len(arrivals) == len(trace) == len(requests):
            errors.append('two-hop POST counts disagree: '+group['name'])
        if any(row['error_type'] or row['response_write_status'] != 'completed'
               or not row['request_terminal_monotonic_ns']
               or row['request_body_sha256'] != row['forwarded_body_sha256'] for row in trace):
            errors.append('gateway request did not complete unchanged: '+group['name'])
        observed, statuses = [], Counter()
        for row in final.get('complete_outcomes', []):
            identifier = row['call_id']
            if identifier not in by_call:
                errors.append('result without complete original request: '+group['name'])
                continue
            request = by_call[identifier]
            payload = base64.b64decode(request['body_base64'])
            content = json.loads(payload)
            full = decode_full_response(base64.b64decode(row['response_wire']))
            expected_body = b'public-fixture-response:'+payload+b'\n\x00\xff'
            expected_headers = (('Server', 'public-fixture'), ('Date', 'Thu, 01 Jan 1970 00:00:00 GMT'),
                ('Content-Type', 'application/octet-stream'), ('X-Repeated', 'one'), ('X-Repeated', 'two'),
                ('X-Call-Id', identifier), ('Content-Length', str(len(expected_body))))
            correct = (row['row_id'] == request['row_id'] == content['row_id']
                and identifier == content['call_id'] and full.body == expected_body
                and full.status_code == (429 if row['row_id'] % 2 == 0 else 500)
                and full.http_version == 'HTTP/1.1'
                and Counter((k.lower(), v) for k, v in full.headers)
                    == Counter((k.lower(), v) for k, v in expected_headers)
                and [v for k, v in full.headers if k.lower() == 'x-repeated'] == ['one', 'two'])
            if not correct:
                errors.append('complete response/request association changed: '+group['name']+'/'+identifier)
            statuses[full.status_code] += 1
            observed.append(identifier)
        if Counter(observed) != Counter(by_call.keys()):
            errors.append('complete fixture responses not all associated exactly once: '+group['name'])
        if final['status'] == 'passed' and len(requests) != group['expected_fixture_posts']:
            errors.append('passing case did not reach its planned count: '+group['name'])
        passed_result = (result['success'] and result['tests_run'] == 1 and not result['failures']
                         and not result['errors'] and not result['skipped'])
        if (final['status'] == 'passed') != bool(passed_result):
            errors.append('case final status and unittest result disagree: '+group['name'])
        cleanup = final.get('fixture_cleanup') or {}
        if (cleanup.get('active') != 0 or cleanup.get('serving_thread_alive')
                or cleanup.get('live_handler_threads') or not final.get('gateway_thread_stopped')):
            errors.append('HTTP fixture/gateway cleanup not confirmed: '+group['name'])
        units.append(dict(group=group['name'], case=case, status=final['status'],
            test_source_sha256=final.get('test_source_sha256'), tests_run=result['tests_run'],
            failures=len(result['failures']), errors=len(result['errors']), skipped=len(result['skipped']),
            associated_outcomes=len(observed), fixture_posts=len(requests), proxy_posts=len(trace),
            proxy_arrivals=len(arrivals),
            full_response_status_counts=dict(statuses), options=final.get('options'),
            cpu1_rejection=final.get('cpu1_rejection'), fault_close_report=final.get('fault_close_report'),
            close_reports=final.get('close_reports'), primary_error=final.get('primary_error'),
            actual_iterator_type=final.get('actual_iterator_type'), fault_location=final.get('fault_location'),
            rejected_batch_added_fixture_posts=final.get('rejected_batch_added_fixture_posts'),
            rejected_batch_added_proxy_posts=final.get('rejected_batch_added_proxy_posts'),
            fixture_cleanup=cleanup, gateway_thread_stopped=final.get('gateway_thread_stopped'),
            runtime_driver_disconnected=final.get('runtime', {}).get('driver_disconnected')))
    fixture_count = sum(unit['fixture_posts'] for unit in units)
    proxy_count = sum(unit['proxy_posts'] for unit in units)
    arrival_count = sum(unit.get('proxy_arrivals', 0) for unit in units)
    actual = dict(logical=charged, fixture=fixture_count, proxy=proxy_count,
                  physical=arrival_count+fixture_count)
    if (window['budget']['allocated'] != allocated or window['budget']['charged_logical'] != charged
            or window['http_counts']['fixture_posts'] != fixture_count
            or window['http_counts']['proxy_posts'] != proxy_count
            or window['http_counts']['proxy_arrivals'] != arrival_count
            or window['http_counts']['completed_trace_physical_posts'] != proxy_count+fixture_count
            or window['http_counts']['observed_physical_posts'] != actual['physical']
            or postflight['fixture_posts'] != fixture_count or postflight['proxy_posts'] != proxy_count
            or postflight['physical_posts'] != actual['physical']):
        errors.append('derived log/SQLite counts differ from controller or independent postflight')
    if actual['logical'] != actual['fixture'] or actual['proxy'] != actual['fixture']:
        errors.append('charged logical and actual two-hop requests differ')
    if sum(unit['associated_outcomes'] for unit in units) != actual['fixture']:
        errors.append('complete outcome total differs from fixture total')
    if resources['affinity_violations'] or resources['forced_cleanup'] or resources['remaining_owned_pids']:
        errors.append('owned resources did not exit within declared settings')
    if (postflight['postflight_errors'] or postflight['live_owned_identities']
            or postflight['own_lease_remaining'] or not window['common_lease_released']):
        errors.append('independent exit/source/lease check failed')
    return dict(run_id=plan['run_id'], source_sha=plan['source_sha'],
        window_success=window['success'], actual_counts=actual, association_errors=errors,
        units=units, allocated_requests=allocated, charged_requests=charged,
        unused_closed_reservation_requests=allocated-charged,
        ledger_records=ledger, ledger_source_sqlite_sha256=ledger_sha,
        elapsed_seconds=window['elapsed_seconds'],
        peak_sampled_summed_rss_bytes=window['max_sampled_summed_rss_bytes'],
        owned_identities_checked=postflight['owned_identities_checked'],
        live_owned_identities=postflight['live_owned_identities'], forced_cleanup=resources['forced_cleanup'],
        own_lease_remaining=postflight['own_lease_remaining'], common_lease_released=window['common_lease_released'],
        real_model_calls=window['real_model_calls'], gpu_starts=window['gpu_starts'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('windows', nargs='+', type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    windows = [audit(root) for root in args.windows]
    aggregate = dict(schema='semloom.native_adapter_completion_sdk_audit.v1', windows=windows,
        actual_counts={key: sum(w['actual_counts'][key] for w in windows)
                       for key in ('logical', 'fixture', 'proxy', 'physical')},
        attempted_cases=sum(u.get('tests_run', 0) for w in windows for u in w['units']),
        passed_case_attempts=sum(u['status'] == 'passed' for w in windows for u in w['units']),
        failed_assertion_attempts=sum(u.get('failures', 0) for w in windows for u in w['units']),
        error_attempts=sum(u.get('errors', 0) for w in windows for u in w['units']),
        skipped_attempts=sum(u.get('skipped', 0) for w in windows for u in w['units']),
        association_errors=[e for w in windows for e in w['association_errors']],
        allocated_requests=sum(w['allocated_requests'] for w in windows),
        charged_requests=sum(w['charged_requests'] for w in windows),
        unused_closed_reservation_requests=sum(w['unused_closed_reservation_requests'] for w in windows),
        real_model_calls=sum(w['real_model_calls'] for w in windows), gpu_starts=sum(w['gpu_starts'] for w in windows))
    args.out.write_text(json.dumps(aggregate, indent=2)+'\n')
    print(json.dumps({key: value for key, value in aggregate.items() if key != 'windows'}))


if __name__ == '__main__':
    main()
