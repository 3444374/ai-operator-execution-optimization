"""One CPU-only, localhost-library window using the existing common host lease."""
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import traceback

import psutil

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT / 'plan.json').read_text())
sys.path.insert(0, str(ROOT / 'source/code'))
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.baselines.common.redact import redact_json_values, redact_text



def main():
    def save(name, value):
        path = ROOT / name
        with path.open('x') as stream:
            json.dump(redact_json_values(value), stream, indent=2)
            stream.write('\n')


    def verify_files():
        manifest = json.loads((ROOT / 'bundle-manifest.json').read_text())
        for name, identity in manifest['files'].items():
            content = (ROOT / name).read_bytes()
            if len(content) != identity['bytes'] or hashlib.sha256(content).hexdigest() != identity['sha256']:
                raise RuntimeError('package digest mismatch: ' + name)


    verify_files()
    if (ROOT / 'window-started.json').exists():
        raise RuntimeError('window already attempted; no implicit repeat or budget reset')
    if str(ROOT) != PLAN['remote_root'] or os.sys.executable != PLAN['driver_python']:
        raise RuntimeError('unexpected target or driver')
    if not set(PLAN['cpu_affinity']).issubset(os.sched_getaffinity(0)):
        raise RuntimeError('requested CPU mask unavailable')
    os.sched_setaffinity(0, set(PLAN['cpu_affinity']))
    for package, version in PLAN['pinned_versions'].items():
        if importlib.metadata.version(package) != version:
            raise RuntimeError('fixed dependency mismatch: ' + package)
    if (Path(PLAN['host_scope']) / '.host-runner-scope/.runner-lease.json').exists():
        raise RuntimeError('common lease exists; leave it intact and report software window required')
    gpu_pids = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
        '--format=csv,noheader'], text=True, timeout=10).strip()
    if gpu_pids:
        raise RuntimeError('existing GPU work; stop before library checks')
    for process in psutil.process_iter(['pid', 'cmdline']):
        if process.pid == os.getpid():
            continue
        words = process.info['cmdline'] or []
        executables = [Path(word).name for word in words]
        if any(name in ('raylet', 'gcs_server') for name in executables) or any(
                word.endswith(('.py', '.sh')) and any(label in Path(word).name for label in
                    ('run_ai_operator_scenarios', 'run_shared_vllm_experiment',
                     'run_official_baseline_gate', 'pilot_supervisor', 'single_gpu'))
                for word in words):
            raise RuntimeError('existing experiment process; report software window required')

    started, epoch = time.monotonic(), time.time()
    save('window-started.json', dict(started_epoch=epoch,
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        deadline_epoch=epoch + PLAN['max_seconds'], source_sha=PLAN['source_sha']))
    owned, samples, violations, forced, outcomes = {}, [], [], [], []
    lease, child, error = None, None, None


    def observe():
        root = psutil.Process(os.getpid())
        processes = [root, *root.children(recursive=True)]
        for pid, birth in tuple(owned):
            try:
                process = psutil.Process(pid)
                if process.create_time() == birth and process not in processes:
                    processes.append(process)
            except psutil.NoSuchProcess:
                pass
        rss = 0
        for process in processes:
            try:
                birth = process.create_time()
                if process.status() == psutil.STATUS_ZOMBIE:
                    continue
                affinity = process.cpu_affinity()
                owned[(process.pid, birth)] = dict(pid=process.pid, birth=birth, name=process.name())
                if not set(affinity).issubset(PLAN['cpu_affinity']):
                    violations.append(dict(pid=process.pid, affinity=affinity))
                rss += process.memory_info().rss
            except psutil.NoSuchProcess:
                pass
        samples.append(dict(monotonic_ns=time.monotonic_ns(), summed_rss_bytes=rss))
        return rss


    def live_owned():
        current = []
        for pid, birth in tuple(owned):
            if pid == os.getpid():
                continue
            try:
                process = psutil.Process(pid)
                if process.create_time() == birth and process.status() != psutil.STATUS_ZOMBIE:
                    current.append(process)
            except psutil.NoSuchProcess:
                pass
        return current


    def stop_owned():
        matches = live_owned()
        for process in matches:
            try:
                process.terminate()
                forced.append(dict(pid=process.pid, action='terminate'))
            except psutil.NoSuchProcess:
                pass
        _, alive = psutil.wait_procs(matches, timeout=3)
        for process in alive:
            try:
                process.kill()
                forced.append(dict(pid=process.pid, action='kill'))
            except psutil.NoSuchProcess:
                pass
        psutil.wait_procs(alive, timeout=3)


    def fixture_posts():
        total = 0
        for path in (ROOT / 'fixtures').rglob('*.json'):
            if 'complete-http' not in path.name and 'daft-http-service' not in path.name:
                continue
            try:
                total += json.loads(path.read_text())['actual_posts'] if 'complete-http' in path.name else len(
                    json.loads(path.read_text())['requests'])
            except json.JSONDecodeError:
                continue  # A fixture may still be writing its final observation.
        return total


    def check_limits(*, reserve=30):
        observe()
        reasons = []
        if time.monotonic() - started >= PLAN['max_seconds'] - reserve:
            reasons.append('time')
        if max(item['summed_rss_bytes'] for item in samples) > PLAN['max_sampled_rss_bytes']:
            reasons.append('sampled summed RSS')
        if violations:
            reasons.append('affinity')
        if fixture_posts() > PLAN['max_fixture_posts']:
            reasons.append('completed fixture POST count')
        if reasons:
            raise RuntimeError('resource stop condition: ' + ', '.join(reasons))


    def copy_log(stream, log, failures):
        try:
            for raw in iter(stream.readline, b''):
                log.write(redact_text(raw.decode('utf-8', errors='replace')))
                log.flush()
        except BaseException as failure:
            failures.append(dict(type=type(failure).__name__, message=str(failure)))


    env = dict(os.environ, PYTHONPATH=str(ROOT / 'source/code'), PYTHONDONTWRITEBYTECODE='1',
        SEMLOOM_NATIVE_CALL_TEST='1', SEMLOOM_NATIVE_CALL_RAY_TMP=str(ROOT / 'ray'),
        RAY_DATA_DEFAULT_ASYNC_BATCH_UDF_MAX_CONCURRENCY='2', CUDA_VISIBLE_DEVICES='',
        HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', RAY_USAGE_STATS_ENABLED='0',
        OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
        TOKENIZERS_PARALLELISM='false', NO_PROXY='localhost,127.0.0.1,::1',
        TMPDIR=str(ROOT / 'tmp'), XDG_CACHE_HOME=str(ROOT / 'cache'))
    for key in ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy',
                'all_proxy', 'RAY_ADDRESS', 'RAY_NAMESPACE'):
        env.pop(key, None)
    try:
        lease = acquire_host_runner_lease(Path(PLAN['host_scope']), repository_commit=PLAN['source_sha'])
        save('lease-acquired.json', dict(pid=os.getpid(), source_sha=PLAN['source_sha'],
            recovered_stale=lease.recovered_owner is not None))
        for name in ('tmp', 'cache', 'fixtures'):
            (ROOT / name).mkdir()
        for group in PLAN['groups']:
            if time.monotonic() - started >= PLAN['max_seconds'] - 30:
                raise TimeoutError('cleanup reserve reached')
            at = time.monotonic()
            env['SEMLOOM_NATIVE_CALL_ARTIFACT'] = str(ROOT / 'fixtures' / group['name'])
            log_failures = []
            with (ROOT / (group['name'] + '.log')).open('x') as log:
                child = subprocess.Popen([sys.executable, str(ROOT / 'qualify_native.py'), group['name']],
                    cwd=ROOT / 'source', env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    start_new_session=True)
                reader = threading.Thread(target=copy_log, args=(child.stdout, log, log_failures), daemon=True)
                reader.start()
                try:
                    while child.poll() is None:
                        check_limits()
                        if log_failures:
                            raise RuntimeError('redacted log copy failed')
                        time.sleep(.1)
                    code = child.wait(timeout=5)
                except BaseException:
                    observe()
                    stop_owned()
                    raise
                finally:
                    reader.join(5)
                    if reader.is_alive():
                        observe()
                        stop_owned()
                        reader.join(5)
                    if reader.is_alive() or log_failures:
                        raise RuntimeError('redacted log close unconfirmed')
                    child.stdout.close()
            outcomes.append(dict(group=group['name'], returncode=code, seconds=time.monotonic() - at,
                cumulative_fixture_posts=fixture_posts()))
            check_limits()
            if code:
                raise RuntimeError(group['name'] + ' failed; no automatic additional run')
        verify_files()
    except BaseException as failure:
        error = dict(type=type(failure).__name__, message=str(failure))
    finally:
        cleanup_errors = []
        remaining = None
        try:
            observe()
        except BaseException as failure:
            cleanup_errors.append(dict(action='observe', type=type(failure).__name__, message=str(failure)))
        try:
            deadline = min(time.monotonic() + 5, started + PLAN['max_seconds'] - 10)
            while live_owned() and time.monotonic() < deadline:
                time.sleep(.1)
            stop_owned()
            remaining = [process.pid for process in live_owned()]
        except BaseException as failure:
            cleanup_errors.append(dict(action='stop_owned', type=type(failure).__name__, message=str(failure)))
        try:
            if child is not None and child.poll() is None:
                child.wait(timeout=5)
        except BaseException as failure:
            cleanup_errors.append(dict(action='wait_child', type=type(failure).__name__, message=str(failure)))
        try:
            if lease is not None and remaining == [] and not cleanup_errors:
                lease.release()
        except BaseException as failure:
            cleanup_errors.append(dict(action='release_lease', type=type(failure).__name__, message=str(failure)))
        try:
            check_limits(reserve=0)
        except BaseException as failure:
            cleanup_errors.append(dict(action='final_limits', type=type(failure).__name__, message=str(failure)))
        save('window-resources.json', dict(identities=list(owned.values()), samples=samples,
            affinity_violations=violations, forced_cleanup=forced, remaining_owned_pids=remaining,
            cleanup_errors=cleanup_errors))
        counted_posts = fixture_posts()
        success = error is None and len(outcomes) == len(PLAN['groups']) and remaining == [] and not forced and not cleanup_errors and counted_posts == PLAN['max_fixture_posts']
        report = dict(source_sha=PLAN['source_sha'], success=success, outcomes=outcomes, error=error,
            elapsed_seconds=time.monotonic() - started, fixture_posts=counted_posts,
            expected_fixture_posts=PLAN['max_fixture_posts'],
            max_sampled_summed_rss_bytes=max((item['summed_rss_bytes'] for item in samples), default=0),
            common_lease_released=lease is not None and not lease.path.exists(), cleanup_errors=cleanup_errors,
            remaining_owned_pids=remaining, forced_cleanup=forced, real_model_calls=0, gpu_starts=0)
        save('window-result.json', report)
        print(json.dumps(redact_json_values(report)), flush=True)
    raise SystemExit(0 if success else 1)


if __name__ == "__main__":
    try:
        main()
    except Exception as failure:
        print(json.dumps(redact_json_values(dict(type=type(failure).__name__,
            message=str(failure), traceback=traceback.format_exc()))), flush=True)
        raise SystemExit(1)
