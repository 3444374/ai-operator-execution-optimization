"""Run one selected actual-library group and retain unittest outcomes."""
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source/code'))
from src.baselines.common.redact import redact_json_values


def main():
    plan = json.loads((ROOT / 'plan.json').read_text())
    group = next(item for item in plan['groups'] if item['name'] == sys.argv[1])
    suite = unittest.defaultTestLoader.loadTestsFromNames(group['tests'])
    if unittest.defaultTestLoader.errors or suite.countTestCases() != group['expected_cases']:
        raise RuntimeError('selected unittest group did not load exactly')
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = dict(group=group['name'], tests_run=result.testsRun,
        skipped=result.skipped, failures=[(test.id(), error) for test, error in result.failures],
        errors=[(test.id(), error) for test, error in result.errors],
        expected_cases=group['expected_cases'], success=result.wasSuccessful() and not result.skipped
        and result.testsRun == group['expected_cases'])
    with (ROOT / (group['name'] + '-result.json')).open('x') as stream:
        json.dump(redact_json_values(report), stream, indent=2)
        stream.write('\n')
    return 0 if report['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
