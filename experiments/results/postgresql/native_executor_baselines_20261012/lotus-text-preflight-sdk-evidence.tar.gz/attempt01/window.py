"""One bounded qualification, holding the existing common host lease."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT / 'plan.json').read_text())
os.sched_setaffinity(0, set(PLAN['cpu_affinity']))
sys.path.insert(0, str(ROOT / 'source/code'))
import psutil
from src.infrastructure.runner_lease import acquire_host_runner_lease

started = time.monotonic()
start_epoch = time.time()
assert not (ROOT / 'window-started.json').exists(), 'this window was already started'
(ROOT / 'window-started.json').write_text(json.dumps(dict(
    started_epoch=start_epoch, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    deadline_epoch=start_epoch + PLAN['max_seconds'], source_sha=PLAN['source_sha']), indent=2) + '\n')
owned, samples, violations, outcomes = {}, [], [], []
child = None

def posts():
    path = ROOT / 'post-budget.sqlite'
    if not path.exists(): return 0
    try:
        with sqlite3.connect('file:' + str(path) + '?mode=ro', uri=True) as db:
            return db.execute('SELECT count(*) FROM sends').fetchone()[0]
    except sqlite3.OperationalError:
        return 0

def observe():
    root = psutil.Process(os.getpid())
    rss = 0
    for process in [root, *root.children(recursive=True)]:
        try:
            identity = process.create_time()
            mask = process.cpu_affinity()
            owned[(process.pid, identity)] = dict(pid=process.pid, birth=identity, affinity=mask)
            if not set(mask).issubset(PLAN['cpu_affinity']): violations.append('affinity')
            rss += process.memory_info().rss
        except psutil.Error:
            pass
    samples.append(dict(monotonic_ns=time.monotonic_ns(), summed_rss_bytes=rss))
    return rss

def stop_child():
    matches = []
    for (pid, birth) in owned:
        if pid == os.getpid(): continue
        try:
            process = psutil.Process(pid)
            if process.create_time() == birth and process.status() != psutil.STATUS_ZOMBIE:
                process.terminate(); matches.append(process)
        except psutil.Error:
            pass
    _, alive = psutil.wait_procs(matches, timeout=3)
    for process in alive:
        try: process.kill()
        except psutil.Error: pass
    psutil.wait_procs(alive, timeout=3)

env = dict(os.environ, PYTHONPATH=str(ROOT/'source/code'), PYTHONDONTWRITEBYTECODE='1',
    QUALIFICATION_ROOT=str(ROOT), CUDA_VISIBLE_DEVICES='',
    AI_OPERATOR_ENV_FILE=PLAN['runtime_env_file'], HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
    LITELLM_LOCAL_MODEL_COST_MAP='True', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
    MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false', RAY_USAGE_STATS_ENABLED='0')
for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','RAY_ADDRESS'):
    env.pop(key, None)
env['NO_PROXY'] = 'localhost,127.0.0.1,::1'
lease = None
try:
    manifest = json.loads((ROOT / 'source-manifest.json').read_text())
    for name, digest in manifest['files'].items():
        assert hashlib.sha256((ROOT/'source'/name).read_bytes()).hexdigest() == digest, name
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
    lease = acquire_host_runner_lease(Path(PLAN['host_scope']), repository_commit=PLAN['source_sha'])
    (ROOT/'lease-acquired.json').write_text(json.dumps(dict(pid=os.getpid(), source_sha=PLAN['source_sha'],
        recovered_stale=lease.recovered_owner is not None), indent=2)+'\n')
    commands = [
        ('preflight', [sys.executable, 'code/scripts/environment/manage_environment.py', 'check',
            '--groups','core,text,semantic-benchmarks','--json-out',str(ROOT/'preflight.json')]),
        ('sdk', [sys.executable, str(ROOT/'qualify_sdk.py')])]
    for label, command in commands:
        if time.monotonic()-started >= PLAN['max_seconds']-30: raise TimeoutError('cleanup reserve reached')
        at = time.monotonic()
        with (ROOT/(label+'.log')).open('wb') as log:
            child = subprocess.Popen(command, cwd=ROOT/'source', env=env,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            while child.poll() is None:
                rss = observe()
                if (time.monotonic()-started >= PLAN['max_seconds']-30
                        or rss > PLAN['max_sampled_rss_bytes'] or violations
                        or posts() > PLAN['max_fixture_posts']):
                    stop_child(); raise RuntimeError('time/RSS/affinity/POST stop condition')
                time.sleep(.1)
            code = child.wait(timeout=5)
        outcomes.append(dict(group=label, returncode=code, seconds=time.monotonic()-at, cumulative_posts=posts()))
        if code != 0: raise RuntimeError(label+' failed; stop before further qualification')
except BaseException as error:
    outcomes.append(dict(group='window', error_type=type(error).__name__, error=str(error)))
finally:
    stop_child()
    if child is not None and child.poll() is None: child.wait(timeout=5)
    if lease is not None: lease.release()
    (ROOT/'window-resources.json').write_text(json.dumps(dict(identities=list(owned.values()),
        samples=samples, affinity_violations=violations), indent=2)+'\n')
    success = len(outcomes)==2 and all(item.get('returncode')==0 for item in outcomes)
    report = dict(source_sha=PLAN['source_sha'], success=success, outcomes=outcomes,
        elapsed_seconds=time.monotonic()-started, reserved_posts=posts(), max_seconds=PLAN['max_seconds'],
        max_fixture_posts=PLAN['max_fixture_posts'], max_sampled_summed_rss_bytes=max(
            (sample['summed_rss_bytes'] for sample in samples), default=0),
        common_lease_released=lease is not None and not lease.path.exists(), real_model_calls=0, gpu_starts=0)
    (ROOT/'window-result.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report), flush=True)
raise SystemExit(0 if success else 1)
