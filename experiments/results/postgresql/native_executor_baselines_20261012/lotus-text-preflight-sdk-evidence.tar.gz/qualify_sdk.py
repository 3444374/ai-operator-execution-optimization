"""Affected real-SDK qualification; only deterministic loopback HTTP."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import socket
import sqlite3
import threading
import time
import unittest
from unittest.mock import Mock, patch

ROOT = Path(os.environ['QUALIFICATION_ROOT'])
PLAN = json.loads((ROOT / 'plan.json').read_text())
CURRENT = ['imports']
LOCK = threading.Lock()
DB = sqlite3.connect(ROOT / 'post-budget.sqlite', check_same_thread=False)
DB.execute('CREATE TABLE sends (sequence INTEGER PRIMARY KEY, test TEXT, monotonic_ns INTEGER, header_sha256 TEXT)')
DB.execute('CREATE TABLE receipts (sequence INTEGER PRIMARY KEY, test TEXT, monotonic_ns INTEGER)')
DB.commit()
BLOCKED = []
original_connect, original_addr = socket.socket.connect, socket.getaddrinfo
original_send, original_sendall = socket.socket.send, socket.socket.sendall

def local_host(value):
    return value in ('127.0.0.1', 'localhost', '::1')

def connect(sock, address):
    if isinstance(address, tuple) and not local_host(address[0]):
        BLOCKED.append('non-loopback socket connection')
        raise PermissionError('SDK qualification allows loopback only')
    return original_connect(sock, address)

def addr(host, *args, **kwargs):
    if host is not None and not local_host(host):
        BLOCKED.append('non-loopback address lookup')
        raise PermissionError('SDK qualification allows loopback lookup only')
    return original_addr(host, *args, **kwargs)

def reserve(data):
    if bytes(data).startswith(b'POST '):
        with LOCK:
            count = DB.execute('SELECT count(*) FROM sends').fetchone()[0]
            if count >= PLAN['max_fixture_posts']:
                raise RuntimeError('cumulative localhost POST limit reached before send')
            DB.execute('INSERT INTO sends VALUES (?, ?, ?, ?)',
                (count + 1, CURRENT[0], time.monotonic_ns(), hashlib.sha256(data).hexdigest()))
            DB.commit()

def send(sock, data, *args, **kwargs):
    reserve(data)
    return original_send(sock, data, *args, **kwargs)

def sendall(sock, data, *args, **kwargs):
    reserve(data)
    return original_sendall(sock, data, *args, **kwargs)

socket.socket.connect, socket.getaddrinfo = connect, addr
socket.socket.send, socket.socket.sendall = send, sendall

from http.server import ThreadingHTTPServer
server_init = ThreadingHTTPServer.__init__
def counted_server(server, address, handler, *args, **kwargs):
    if not local_host(address[0]):
        raise PermissionError('fixture binding must be loopback')
    original_post = handler.do_POST
    def post(self):
        with LOCK:
            DB.execute('INSERT INTO receipts(test,monotonic_ns) VALUES (?,?)',
                (CURRENT[0], time.monotonic_ns()))
            DB.commit()
        return original_post(self)
    handler.do_POST = post
    return server_init(server, address, handler, *args, **kwargs)
ThreadingHTTPServer.__init__ = counted_server

from tests.semantic_methods.test_lotus_adapter import (
    LotusSdkTests, fixture_server, local_execution, model, config)
from src.execution_provider.adapters.native_tasks import NativeTaskSession
from src.scheduling.core.session_contract import Usage
from src.semantic_methods.lotus.batch import LotusBatchExecutor
from src.semantic_methods.lotus.limits import LotusCallLimits
from src.semantic_methods.lotus.sdk import prepare_call

CHECKS = []
class ActualGuardQualification(unittest.TestCase):
    def rejection(self, fault, error):
        for remote in (False, True):
            with self.subTest(remote=remote), fixture_server() as (base, calls), local_execution(base) as execution:
                lm = model(base, 'foreign' if fault == 'model' else 'lotus-fixture')
                texts = ['prefix-' + str(i) for i in range(5)]
                if fault == 'request':
                    texts[-1] = 'large-' + 'x' * 2048
                data = [([dict(role='user', content=text)], None) for text in texts]
                prepared = [prepare_call(lm, item[0], lm.kwargs) for item in data]
                sizes = [len(call.payload) for call in prepared]
                limits = LotusCallLimits(5., max_request_bytes=(max(sizes[:4]) + 16
                    if fault == 'request' else max(sizes) + 16),
                    max_batch_input_bytes=sum(sizes[:4]) if fault == 'batch' else 1048576)
                opening = Mock(side_effect=lambda q, o: NativeTaskSession(execution, q, o))
                selected = LotusBatchExecutor(None if remote else execution, config(base),
                    query_id='reject-' + fault, operator_id='map', call_limits=limits,
                    prevalidate_batch=True, session_factory=opening if remote else None,
                    session_limits=execution.engine.capacity.limits if remote else None)
                with patch('src.semantic_methods.lotus.batch.NativeTaskSession', opening):
                    with self.assertRaisesRegex(ValueError, error):
                        selected(lm, data, lm.kwargs, False, 'fixture')
                opening.assert_not_called()
                self.assertEqual(calls, [])
                self.assertEqual(execution.engine.jobs.jobs, {})
                self.assertEqual(execution.engine.capacity.usage(), Usage())
                CHECKS.append(dict(case=fault, remote=remote, prepared_payload_bytes=sizes,
                    limits=limits.describe(), flow_opened=0, received_posts=0, capacity_released=True))

    def test_fifth_request_limit_before_any_flow_or_send(self):
        self.rejection('request', 'request exceeds')

    def test_fifth_cumulative_input_limit_before_any_flow_or_send(self):
        self.rejection('batch', 'batch input exceeds')

    def test_actual_sdk_model_mismatch_before_any_flow_or_send(self):
        self.rejection('model', 'model configuration')

    def test_native_sdk_and_default_guarded_remote_text_match(self):
        import lotus
        messages = [[dict(role='user', content=text)] for text in ('same', '你好😀', 'same')]
        data = [(item, None) for item in messages]
        with fixture_server() as (base, calls), local_execution(base) as execution:
            lm = model(base)
            expected = [json.loads(prepare_call(lm, item, lm.kwargs).payload) for item in messages]
            with lotus.settings.context(enable_cache=False):
                native = lm(messages, show_progress_bar=False)
            self.assertEqual(len(calls), 3)
            self.assertCountEqual(calls, expected)
            for guarded, remote in ((False, False), (True, False), (True, True)):
                before = len(calls)
                opening = Mock(side_effect=lambda q, o: NativeTaskSession(execution, q, o))
                selected = LotusBatchExecutor(None if remote else execution, config(base),
                    query_id='valid-' + str(guarded) + '-' + str(remote), operator_id='map',
                    prevalidate_batch=guarded, session_factory=opening if remote else None,
                    session_limits=execution.engine.capacity.limits if remote else None)
                parsed = selected(lm, data, lm.kwargs, False, 'fixture')
                self.assertEqual([lm._get_top_choice(item) for item in parsed], native.outputs)
                self.assertEqual([item.usage.total_tokens for item in parsed], [10] * 3)
                self.assertEqual(len(calls) - before, 3)
                self.assertCountEqual(calls[before:], expected)
                if remote:
                    self.assertEqual(opening.call_count, 1)
                self.assertEqual(execution.engine.jobs.jobs, {})
                self.assertEqual(execution.engine.capacity.usage(), Usage())
                CHECKS.append(dict(case='valid', guarded=guarded, remote=remote,
                    received_posts=3, outputs_match_original_sdk=True, capacity_released=True))

RESULTS = []
class RecordingResult(unittest.TextTestResult):
    def startTest(self, test):
        CURRENT[0] = test.id()
        self.at = time.monotonic()
        super().startTest(test)
    def stopTest(self, test):
        status = 'failed' if any(item[0] == test for item in self.failures + self.errors) else 'passed'
        if any(item[0] == test for item in self.skipped):
            status = 'skipped'
        RESULTS.append(dict(test=test.id(), status=status, seconds=time.monotonic() - self.at))
        super().stopTest(test)

suite = unittest.defaultTestLoader.loadTestsFromTestCase(ActualGuardQualification)
suite.addTest(LotusSdkTests('test_sdk_body_matches_native_http_and_complete_response'))
suite.addTest(LotusSdkTests('test_native_surrogate_input_is_rejected_before_transport_or_flow'))
result = unittest.TextTestRunner(verbosity=2, resultclass=RecordingResult, failfast=True).run(suite)
with LOCK:
    sends = DB.execute('SELECT sequence,test,monotonic_ns,header_sha256 FROM sends').fetchall()
    receipts = DB.execute('SELECT sequence,test,monotonic_ns FROM receipts').fetchall()
summary = dict(source_sha=PLAN['source_sha'], tests=result.testsRun, failures=len(result.failures),
    errors=len(result.errors), skips=len(result.skipped), test_results=RESULTS, checks=CHECKS,
    reserved_posts=len(sends), received_posts=len(receipts), sends=sends, receipts=receipts,
    non_loopback_attempts=BLOCKED, real_model_calls=0, gpu_starts=0,
    versions={name:importlib.metadata.version(name) for name in ('lotus-ai','litellm','openai','pandas')},
    success=result.wasSuccessful() and result.testsRun == 6 and not result.skipped and
        len(sends) == len(receipts) == 13 and not BLOCKED)
(ROOT / 'sdk-result.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
DB.close()
raise SystemExit(0 if summary['success'] else 1)
