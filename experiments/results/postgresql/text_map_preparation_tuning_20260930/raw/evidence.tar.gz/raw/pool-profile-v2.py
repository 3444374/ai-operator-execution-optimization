"""Bounded synthetic HTTP diagnosis of existing per-query PG transports."""
from contextlib import suppress, ExitStack
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import pwd
import signal
import sys
import threading
import time
import traceback
import psutil

from src.baselines.common.private_artifacts import new_private_directory,write_private_json
from src.baselines.common.redact import redact_text
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.postgresql.query_config import QueryConfig
from src.experiments.postgresql.query_inputs import QueryInputs
from src.experiments.postgresql.query_tables import install_input_table
from src.experiments.postgresql.query_workloads import prepare,read_prepared
from src.experiments.postgresql.query_supervisor import supervise
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster
from src.experiments.postgresql.text_map_comparison import read_run

root,source,prefix=map(Path,sys.argv[1:4])
new_private_directory(root)
started=time.monotonic();deadline=started+900
report=dict(status='failed',real_model_requests=0,fixture_limit=8352,completed=[],errors=[],cleanup={})
services=ExitStack()
def identity(path):return dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def expired(*args):raise TimeoutError('profile overall duration exceeded')
signal.signal(signal.SIGALRM,expired);signal.alarm(900)
lock=threading.Lock();posts=active=peak=0;current='startup';thread_stop=threading.Event()
http=ray=None;ledger=None;sample_thread=None;server_thread=None
sample_errors=[]

class FixtureServer(ThreadingHTTPServer):
    request_queue_size=512
    def handle_error(self,*args):
        server_errors.append('fixture handler error')
        super().handle_error(*args)

def tcp_counters():
    lines=Path('/proc/net/netstat').read_text().splitlines()
    for index,line in enumerate(lines[:-1]):
        if line.startswith('TcpExt:'):
            values=dict(zip(line.split()[1:],map(int,lines[index+1].split()[1:])))
            return {key:values[key] for key in ('ListenOverflows','ListenDrops','TCPBacklogDrop','TCPAbortOnClose','TCPAbortOnData')}
    raise RuntimeError('TCP counters unavailable')

server_errors=[]
class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def do_POST(self):
        global posts,active,peak
        body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        with lock:
            posts+=1;active+=1;peak=max(peak,active);permitted=posts<=8352
        try:
            if not permitted:self.send_error(429,'fixture limit reached');return
            if body['model']!='fixture-model':self.send_error(400,'fixture model identity differs');return
            label='POSITIVE' if '[GOOD]' in body['messages'][-1]['content'] else 'NEGATIVE'
            payload=json.dumps(dict(model='fixture-model',choices=[dict(message=dict(content=label),finish_reason='stop')],
                               usage=dict(prompt_tokens=10,completion_tokens=1))).encode()
            self.send_response(200);self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
        finally:
            with lock:active-=1
    def log_message(self,*args):pass

def samples():
    try:
        with (root/'threads.jsonl').open('x') as stream:
            count=0
            while not thread_stop.wait(.2):
                values=[]
                for process in psutil.Process().children(recursive=True):
                    with suppress(psutil.NoSuchProcess,psutil.AccessDenied):
                        times=process.cpu_times()
                        values.append(dict(pid=process.pid,created_at=process.create_time(),threads=process.num_threads(),
                            cpu_seconds=times.user+times.system,rss_bytes=process.memory_info().rss))
                stream.write(json.dumps(dict(unit=current,monotonic_ns=time.monotonic_ns(),processes=values))+'\n')
                count+=1
                if count>4500:raise RuntimeError('thread sample limit exceeded')
    except BaseException as error:
        sample_errors.append(type(error).__name__)

try:
    report['fixture_request_queue_size']=512
    report['tcp_start']=tcp_counters()
    report['versions']={name:importlib.metadata.version(name) for name in ('ray','daft','pyarrow','psycopg','httpx')}
    if report['versions']['ray']!='2.56.1' or report['versions']['daft']!='0.7.21':raise ValueError('pinned runtime differs')
    report['source_sha256']={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in source.rglob('*.py')}
    http=FixtureServer(('127.0.0.1',0),Handler);server_thread=threading.Thread(target=http.serve_forever)
    server_thread.start()
    model=root/'model.json';write_private_json(model,dict(endpoint_url=f'http://127.0.0.1:{http.server_port}/v1/chat/completions',
                                                      model_id='fixture-model',timeout_ms=30000))
    os.environ['RAY_USAGE_STATS_ENABLED']='0'
    ray_started=time.monotonic()
    import ray
    ray.init(address='local',num_cpus=8,num_gpus=0,include_dashboard=False,_node_ip_address='127.0.0.1',
             object_store_memory=268435456,_temp_dir=str(root/'r'))
    from ray._private.state import actors
    report['ray_service_startup_seconds']=time.monotonic()-ray_started
    transport=root/'transport.json'
    write_private_json(transport,dict(address=ray.get_runtime_context().gcs_address,workers=1,batch_rows=16,
                                    window_bytes=2097152,object_bytes=4194304))
    from src.execution_provider.adapters.model_config import load_fixed_model_config
    from src.execution_provider.adapters.ray_map_transport import RayMapConfig,RayMapTransport,owned_map_worker_pool,_Block,_Row
    from tests.execution_provider.test_ray_map_transport import task
    from dataclasses import replace
    import asyncio
    import pyarrow as pa
    fixed=load_fixed_model_config(model)
    physical=RayMapConfig(**json.loads(transport.read_text()),worker_pool='tuning')
    pool_started=time.monotonic()
    services.enter_context(owned_map_worker_pool(ray,fixed,64,physical))
    report['worker_service_startup_seconds']=time.monotonic()-pool_started
    pooled=root/'pooled-transport.json';write_private_json(pooled,asdict(physical))
    first=RayMapTransport(fixed,64,physical=physical)
    checked=[]
    try:
        for test_config,capacity,name in ((replace(fixed,model_id='other-model'),64,'wrong-model'),
                (fixed,128,'wrong-capacity'),(fixed,64,'busy-worker')):
            try:
                unexpected=RayMapTransport(test_config,capacity,physical=physical)
            except Exception:
                checked.append(name)
            else:
                unexpected.abort_startup();raise AssertionError('worker accepted incompatible query')
    finally:first.abort_startup()
    async def unconfirmed_test():
        borrowed=RayMapTransport(fixed,64,physical=replace(physical,worker_pool='fault'))
        request=task(0)
        table=pa.table({'session_id':[0],'sequence':[999],'payload':[b'wrong row']})
        row=_Row(request,asyncio.get_running_loop().create_future())
        borrowed.blocks[0]=_Block(ray.put(table),table.get_total_buffer_size(),{request.key})
        borrowed.used_bytes=table.get_total_buffer_size()
        await borrowed._run_row(row,0,0)
        try:await row.future
        except RuntimeError:pass
        else:raise AssertionError('wrong payload was accepted')
        try:await borrowed.close()
        except RuntimeError:pass
        else:raise AssertionError('uncertain lease was released')
        if not borrowed.unknown or borrowed.used_bytes!=table.get_total_buffer_size():raise AssertionError('uncertain charge differs')
        try:RayMapTransport(fixed,64,physical=replace(physical,worker_pool='fault'))
        except Exception:pass
        else:raise AssertionError('uncertain worker was reused')
    try:
        with owned_map_worker_pool(ray,fixed,64,replace(physical,worker_pool='fault')):
            asyncio.run(unconfirmed_test());checked.append('unknown-outcome-quarantined')
    except RuntimeError as error:
        if 'unknown-outcome-quarantined' not in checked or 'cleanup could not be confirmed' not in str(error):raise
        checked.append('uncertain-service-terminated')
    if posts:raise AssertionError('ownership checks spent HTTP')
    report['actual_ray_checks']=checked
    baseline_actors=set(actors())
    budget=AttemptBudget('worker-pool.synthetic.v1',8352)
    ledger=CellBudgetLedger.create(root/'budget.sqlite',budget,deadline_utc=time.time()+780)
    pg=root/'pg';pg.mkdir()
    sample_thread=threading.Thread(target=samples);sample_thread.start()
    with isolated_pg18_cluster(prefix,pg,pwd.getpwuid(os.getuid()),port=55497) as connection:
        report['pg_version']=connection.info.server_version
        os.environ['STARTUP_PROFILE_DSN']=connection.info.dsn
        manifests={}
        for rows in (16,1024):
            path=root/f'inputs-{rows}'
            prepare(path,'movie',((str(i),'fixture-movie','[GOOD] 很好 review' if i%2==0 else '[BAD] poor review',
                'POSITIVE' if i%2==0 else 'NEGATIVE','original-'+str(i//2)) for i in range(rows)),
                dict(source='bounded synthetic startup diagnosis'),max_rows=rows)
            manifests[rows]=path/'manifest.json'
            installed=install_input_table(connection,QueryInputs('movie',f'startup_{rows}',rows),read_prepared(manifests[rows],'raw.jsonl'))
            write_private_json(root/f'installation-{rows}.json',installed)
        schedule=[(16,'query',-20),(16,'service',-19)]+[(16,'query',i-8) for i in range(8)]+[
            (1024,mode,repeat) for repeat in range(4) for mode in
            (('query','service') if repeat%2==0 else ('service','query'))]
        write_private_json(root/'schedule.json',dict(queries=18,max_fixture_posts=8352,real_model_requests=0,schedule=schedule,
            per_query_lifecycle='fresh driver and gateway; query-owned or caller-owned worker'))
        for index,(rows,mode,repeat) in enumerate(schedule):
            role='pg-daft-ray'
            selected=transport if mode=='query' else pooled
            remaining=deadline-time.monotonic()-90
            if remaining<120:raise TimeoutError('profile has insufficient query and cleanup time')
            unit=f'q{index:02}';current=unit
            options=dict(concurrency=64,window=256,input_bytes=134217728,result_bytes=134217728,
                         query_timeout_s=120,max_posts=rows)
            if role=='pg-daft-ray':options.update(map_transport_config=str(selected),map_transport_sha256=identity(selected)['sha256'],
                pg_total_budget=True,pg_window_bytes=268435456,pg_staging_bytes=4194304)
            cfg=QueryConfig(unit,'pg' if role=='pg-daft-ray' else role,'map',f'startup_{rows}',**options)
            config=root/(unit+'.json');write_private_json(config,asdict(cfg))
            output=root/unit;new_private_directory(output)
            with lock:before=posts;peak=0
            command=[sys.executable,'-m','src.experiments.postgresql.query_cli','run','--worker','--config',str(config),
                     '--manifest',str(manifests[rows]),'--model',str(model),'--budget',str(ledger.path),
                     '--budget-id',budget.budget_id,'--max-attempts',str(budget.limit),'--output',str(output),
                     '--dsn-env','STARTUP_PROFILE_DSN','--pg-log',str(pg/'postgres.log')]
            supervise(command,output,lambda:ledger.close_shared_unit(unit),query_timeout_s=120,max_duration_s=120,grace_s=5)
            ref=identity(output/'unit/summary.json');record=read_run(ref,role)
            if record['rows']!=rows or record['quality']['false_positive'] or record['quality']['false_negative']:
                raise ValueError('synthetic query association or labels differ')
            with lock:
                if posts-before!=rows or active or peak>64:raise ValueError('fixture request count or cleanup differs')
                unit_peak=peak
            until=time.monotonic()+30
            while True:
                live=[a for key,a in actors().items() if key not in baseline_actors and a['State']!='DEAD']
                if not live and ray.available_resources().get('CPU',0)>=7:break
                if time.monotonic()>until:raise RuntimeError('query Ray actors or CPU slots remain held')
                time.sleep(.1)
            saved=json.loads((output/'unit/summary.json').read_text());timing=saved['execution']
            item=dict(unit=unit,role=role,worker_ownership=mode,rows=rows,repeat=repeat,summary=ref,fixture_posts=rows,peak_http=unit_peak,
                jct_seconds=(timing['t_query_terminal_ns']-saved['query_preparation_started_ns'])/1e9,
                preparation_seconds=(timing['t_release_ns']-saved['query_preparation_started_ns'])/1e9,
                release_to_first_row_seconds=(timing['t_first_row_ns']-timing['t_release_ns'])/1e9,
                stream_seconds=(timing['t_query_terminal_ns']-timing['t_release_ns'])/1e9)
            if role=='pg-daft-ray':
                item['pg_preparation']=saved['resources']['pg_preparation']
                item['gateway_startup']=json.loads((output/'unit/observer.json').read_text())['startup']
                events=[json.loads(s) for s in (output/'unit/public-events.jsonl').read_text().splitlines()]
                item['ray_startup']=[e for e in events if e['event'] in ('core_ray_startup','core_ray_first_submit')]
            report['completed'].append(item);write_private_json(root/f'completed-{index:02}.json',item)
            if server_errors:raise RuntimeError('fixture HTTP handlers failed')
            if sample_errors:raise RuntimeError('thread sampling failed')
            print(json.dumps({k:v for k,v in item.items() if k in ('unit','role','rows','repeat','jct_seconds','preparation_seconds','release_to_first_row_seconds')}),flush=True)
    if posts!=8352 or ledger.snapshot()['allocated_requests']!=8352:raise ValueError('complete fixture accounting differs')
    report['status']='passed'
except BaseException as error:
    report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
    print(redact_text(traceback.format_exc()),file=sys.stderr,flush=True)
finally:
    signal.alarm(0);current='cleanup';thread_stop.set()
    if sample_thread:sample_thread.join(5)
    if ray and ray.is_initialized():
        try:
            services.close()
            until=time.monotonic()+30
            while any(a['State']!='DEAD' for a in actors().values()) or ray.available_resources().get('CPU',0)<8:
                if time.monotonic()>until:raise RuntimeError('service actors remain after owner cleanup')
                time.sleep(.1)
            report['cleanup']['worker_services_released']=True
        except Exception as error:
            report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
            report['cleanup']['worker_services_released']=False
        ray.shutdown()
    if http:http.shutdown();http.server_close()
    if server_thread:server_thread.join(5)
    report.update(fixture_posts=posts,elapsed_seconds=time.monotonic()-started,
                  budget=ledger.snapshot() if ledger else None)
    report['cleanup'].update(pg_stopped=not (root/'pg/data/postmaster.pid').exists(),
        ray_driver_disconnected=not ray or not ray.is_initialized(),http_active=active,
        server_thread_stopped=not server_thread or not server_thread.is_alive(),sample_thread_stopped=not sample_thread or not sample_thread.is_alive())
    report['sample_errors']=sample_errors
    report['server_errors']=server_errors
    report['tcp_end']=tcp_counters()
    checks=[v for k,v in report['cleanup'].items() if k!='http_active']
    if not all(checks) or active or sample_errors:report['status']='failed'
    write_private_json(root/'controller-summary.json',report)
raise SystemExit(0 if report['status']=='passed' else 1)
