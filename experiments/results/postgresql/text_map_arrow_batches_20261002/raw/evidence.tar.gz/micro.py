"""Finite payload-conversion microprobe; no database, HTTP or inference."""
import json
import os
from pathlib import Path
import signal
import statistics
import sys
import time
from src.data.materializers.payloads import PayloadBatchLimits, iter_payload_batches

output=Path(sys.argv[1])
def expired(*args):raise TimeoutError('finite conversion probe exceeded 120 seconds')
signal.signal(signal.SIGALRM,expired)
signal.alarm(120)
started=time.monotonic_ns()
imports={}
for name in ('pyarrow','daft'):
    before=time.monotonic_ns()
    __import__(name)
    imports[name]=(time.monotonic_ns()-before)/1e9
report=dict(status='failed',http_posts=0,real_model_posts=0,imports_seconds=imports,
            windows=[],batch_rows=16,repeats=3,calls_per_repeat=20,
            environment={k:os.environ.get(k) for k in ('DO_NOT_TRACK','DAFT_NUM_THREADS','RAY_USAGE_STATS_ENABLED')})
for count in (1,2,16,64):
    rows=tuple((1+i//16,i%16,b'\x00\xff'+b'x'*510) for i in range(count))
    limits=PayloadBatchLimits(64,2*1048576)
    for repeat in range(4):
        for backend in (('daft','arrow') if repeat%2==0 else ('arrow','daft')):
            calls=1 if repeat==0 else 20
            before=time.monotonic_ns()
            cpu=time.process_time_ns()
            batch_count=0
            largest=0
            for _ in range(calls):
                expected=iter(rows)
                stream=iter_payload_batches(rows,limits,batch_rows=16,backend=backend)
                try:
                    for table in stream:
                        largest=max(largest,table.get_total_buffer_size())
                        batch_count+=1
                        for row in table.to_pylist():
                            assert next(expected)==tuple(row[name] for name in ('session_id','sequence','payload'))
                    assert next(expected,None) is None
                finally:stream.close()
            elapsed=time.monotonic_ns()-before
            report['windows'].append(dict(rows=count,backend=backend,repeat=repeat,calls=calls,
                batches=batch_count,wall_seconds=elapsed/1e9,cpu_seconds=(time.process_time_ns()-cpu)/1e9,
                mean_ms=elapsed/calls/1e6,max_backing_bytes=largest))
report['summary']=[dict(rows=count,backend=backend,median_mean_ms=statistics.median(
    v['mean_ms'] for v in report['windows'] if v['rows']==count and v['backend']==backend and v['repeat']>0))
    for count in (1,2,16,64) for backend in ('daft','arrow')]
report.update(status='passed',elapsed_seconds=(time.monotonic_ns()-started)/1e9,
              window_calls=sum(v['calls'] for v in report['windows']))
output.write_text(json.dumps(report,indent=2)+'\n')
signal.alarm(0)
print(json.dumps(dict(status=report['status'],window_calls=report['window_calls'],summary=report['summary'])))
