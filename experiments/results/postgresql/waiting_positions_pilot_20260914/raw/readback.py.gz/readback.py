from pathlib import Path
from statistics import median
from collections import Counter
import json,hashlib,subprocess,socket,os
import psutil
from src.experiments.postgresql.waiting_positions import analyze_waiting_positions
from src.baselines.common.private_artifacts import write_private_json
base=Path('<artifact-root>');snapshot=json.loads((base/'local-source.json').read_text())
for name,digest in snapshot['files'].items():assert hashlib.sha256((base/'source'/name).read_bytes()).hexdigest()==digest
assert not subprocess.check_output(['git','status','--porcelain'],cwd=base/'source',text=True)
all_rows=[];transport=[]
for name,expected in [('controlled',384),('transport',288)]:
 root=base/name/'m1';comparison=json.loads((root/'waiting-comparison.json').read_text())
 total=0
 for row in comparison:
  path=root/row['unit'];count=16 if row['role']=='tuning' else 32
  timing=analyze_waiting_positions(path,expected_rows=count,window=8)
  assert timing==row['timing']
  summary=json.loads((path/'summary.json').read_text());assert summary['status']=='passed'
  assert summary['evaluation']['actual_posts']==count
  assert summary['evaluation']['http']['final_http_active']==0
  assert summary['evaluation']['quality']['false_negative']==0
  assert summary['evaluation']['quality']['invalid']==0
  total+=count
  all_rows.append(dict(round=name,unit=row['unit'],role=row['role'],arm=row['arm'],repeat=row['repeat'],
   full_s=timing['preparation_to_eof_seconds'],preparation_s=timing['preparation_seconds'],sql_s=timing['sql_to_eof_seconds'],
   http_p99_s=timing['http_p99_seconds'],upstream_after_sql_release_s=timing['mean_seconds']['eligible_to_submit']-timing['preparation_seconds'],
   means=timing['mean_seconds']))
 assert total==expected
 fixture=json.loads((root/'fixture-summary.json').read_text());assert fixture['fixture_posts']==total and fixture['actual_model_posts']==0
 assert fixture['active_http']==0 and fixture['server_stopped']
 if name=='transport':
  observation=json.loads((root/'fixture-http-timing.json').read_text());assert observation['listen_backlog']==32
  http_rows=observation['rows'];assert len(http_rows)==288
  for row in comparison:
   path=root/row['unit'];execution=json.loads((path/'q0/execution.json').read_text())
   events=[json.loads(x) for x in (path/'events.jsonl').read_text().splitlines()]
   requests=[e for e in events if e['event']=='request']
   arrivals=[h for h in http_rows if execution['t_release_ns']<=h['handler_received_ns']<=execution['t_query_terminal_ns']]
   assert Counter(h['request_values_sha256'] for h in arrivals)==Counter(e['request_values_sha256'] for e in requests)
   assert len(arrivals)==32
   assert all(h['handler_received_ns']<=h['service_started_ns']<=h['handler_finished_ns'] for h in arrivals)
   active=0;peak=0
   for _,change in sorted([(h['service_started_ns'],1) for h in arrivals]+[(h['handler_finished_ns'],-1) for h in arrivals]):
    active+=change;assert 0<=active<=4;peak=max(peak,active)
   assert active==0
   transport.append(dict(unit=row['unit'],service_peak=peak,
    mean_service_queue_s=sum(h['service_started_ns']-h['handler_received_ns'] for h in arrivals)/32/1e9,
    max_service_queue_s=max(h['service_started_ns']-h['handler_received_ns'] for h in arrivals)/1e9))
 medians={}
 for arm in ('request','token-wide','token-tight'):
  selected=[r for r in all_rows if r['round']==name and r['role']=='evaluation' and r['arm']==arm]
  medians[arm]={key:median(r[key] for r in selected) for key in ('full_s','preparation_s','sql_s','http_p99_s','upstream_after_sql_release_s')}
 write_private_json(base/(name+'-medians.json'),medians)
assert not list(base.rglob('postmaster.pid'))
with socket.socket() as s:assert s.connect_ex(('127.0.0.1',57690))!=0
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
result=dict(status='passed',source_files=len(snapshot['files']),queries=len(all_rows),fixture_posts=672,actual_model_posts=0,
 rows=all_rows,transport=transport,cleanup_verified=True)
write_private_json(base/'readback.json',result);print(json.dumps(dict(status='passed',source_files=len(snapshot['files']),queries=len(all_rows),fixture_posts=672,actual_model_posts=0,medians=medians)))
