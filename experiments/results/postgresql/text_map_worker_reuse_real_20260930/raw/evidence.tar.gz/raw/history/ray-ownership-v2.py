"""No HTTP or model: distinguish query workers from native cluster services."""
from pathlib import Path
import json,os,time
os.environ['RAY_USAGE_STATS_ENABLED']='0'
import ray
from ray._private.state import actors
from ray_services import query_actors
root=Path('<experiment>/ownership-v2');root.mkdir(mode=0o700)
ray.init(address='local',num_cpus=8,num_gpus=0,include_dashboard=False,_node_ip_address='127.0.0.1',object_store_memory=268435456,_temp_dir='<experiment>/o2')
class Echo:
 def __call__(self,batch):return batch
report=dict(real_model_requests=0,http_posts=0,version=ray.__version__,snapshots=[])
try:
 initial=actors()
 from ray.llm._internal.batch.observability.usage_telemetry.usage import get_or_create_telemetry_agent
 telemetry=get_or_create_telemetry_agent()
 values=ray.data.range(16).map_batches(Echo,batch_size=1,concurrency=4,num_cpus=1).take_all()
 assert len(values)==16
 for number in range(3):
  time.sleep(1)
  state=actors()
  report['snapshots'].append(dict(cpu_available=ray.available_resources().get('CPU'),actors=[{k:v for k,v in item.items() if k in ('ActorID','ActorClassName','Name','IsDetached','State','RequiredResources','JobID')} for item in state.values()]))
 assert not query_actors(state,set()),state
 assert ray.available_resources().get('CPU')==8
 report['old_all_actors_check']=all(item['State']=='DEAD' for item in state.values())
 report['correct_query_actors_check']=not query_actors(state,set())
 report['status']='passed'
finally:
 ray.shutdown();report['driver_disconnected']=not ray.is_initialized()
 (root/'probe.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
