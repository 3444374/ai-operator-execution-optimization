"""Fixed five-path real-model remeasurement, with one durable request allowance."""
from contextlib import ExitStack
from dataclasses import asdict,replace
from pathlib import Path
import hashlib,json,os,sys,time,uuid
from urllib.request import urlopen
from src.baselines.common.private_artifacts import write_private_json,new_private_directory
from src.baselines.common.redact import redact_text
from src.execution_provider.adapters.model_config import load_fixed_model_config
from src.execution_provider.adapters.ray_map_transport import RayMapConfig,RayMapTransport,owned_map_worker_pool
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.postgresql.query_config import QueryConfig
from src.experiments.postgresql.query_inputs import QueryInputs
from src.experiments.postgresql.query_tables import install_input_table
from src.experiments.postgresql.query_workloads import load_manifest,read_prepared,file_identity
from src.experiments.postgresql.text_map_candidates import main_candidates
from src.experiments.postgresql.text_map_comparison import read_run,configuration_identity
from src.experiments.postgresql.query_supervisor import supervise
from src.observability.metrics.vllm import scrape_prometheus_metrics

LIMIT=20640
from ray_services import native_cluster_service,query_actors
config=json.loads(Path(sys.argv[1]).read_text());root=Path(config['output_root']);new_private_directory(root)
if config['max_posts']!=LIMIT:raise ValueError('exact authorized request allowance required')
started=time.monotonic();deadline=min(started+900,started+config['deadline_utc']-time.time())
report=dict(status='failed',completed=[],errors=[],max_posts=LIMIT,actual_posts=0,ray_driver_disconnected=False)
ray=None;ledger=None
try:
 import psycopg,ray
 os.environ['RAY_USAGE_STATS_ENABLED']='0'
 os.environ['RAY_DATA_DEFAULT_ASYNC_BATCH_UDF_MAX_CONCURRENCY']='1'
 model=Path(config['model_config']);fixed=load_fixed_model_config(model)
 manifests={}
 with psycopg.connect(os.environ[config['dsn_env']],autocommit=True) as pg:
  if pg.info.server_version!=180003:raise ValueError('PG version differs')
  for split in ('qualification','evaluation'):
   data=config['inputs'][split];path=Path(data['path']);manifest=load_manifest(path)
   if manifest['sha256']!=data['manifest_sha256']:raise ValueError('input manifest differs')
   table='recheck_'+split
   installation=install_input_table(pg,QueryInputs('movie',table,manifest['rows'],manifest['max_source_bytes'],manifest['max_input_bytes']),read_prepared(path,'raw.jsonl'))
   write_private_json(root/(split+'-installation.json'),dict(installation,manifest_sha256=manifest['sha256']))
   manifests[split]=(path,table,manifest['rows'],manifest['sha256'])
 ray_started=time.monotonic()
 ray.init(address='local',num_cpus=8,num_gpus=0,include_dashboard=False,_node_ip_address='127.0.0.1',object_store_memory=268435456,_temp_dir=config['ray_root'])
 report['ray_startup_seconds']=time.monotonic()-ray_started
 report['ray_source_commit']=ray.__commit__
 from ray._private.state import actors
 address=ray.get_runtime_context().gcs_address
 physical=RayMapConfig(address,1,16,2097152,4194304,'realmap')
 pooled=root/'pooled-transport.json';write_private_json(pooled,asdict(physical))
 legacy=root/'legacy-transport.json';write_private_json(legacy,asdict(replace(physical,worker_pool=None)))
 pool=owned_map_worker_pool(ray,fixed,64,physical);pool_started=time.monotonic();pool.__enter__()
 report['worker_service_startup_seconds']=time.monotonic()-pool_started
 baseline=set(actors());report['initial_ray_available']=ray.available_resources()
 if ray.available_resources().get('CPU',0)!=7:raise ValueError('declared worker-service CPU reservation differs')
 def metrics():return scrape_prometheus_metrics(config['model_url']+'/metrics',timeout_s=3)
 def healthy():
  with urlopen(config['model_url']+'/health',timeout=2) as response:
   if response.status!=200:raise ValueError('model health differs')
 ledger=CellBudgetLedger.create(root/'budget.sqlite',AttemptBudget(config['budget_id'],LIMIT),deadline_utc=min(time.time()+900,config['deadline_utc']))
 modes=['pg-source-direct','daft-native','ray-data','semloom-query','semloom-service']
 schedule=[('qualification',mode,-20) for mode in ('semloom-query','semloom-service')]+[('qualification','semloom-query',i-8) for i in range(8)]
 for repeat in range(4):
  order=modes[repeat:]+modes[:repeat]
  schedule.extend(('evaluation',mode,repeat) for mode in order)
 write_private_json(root/'schedule.json',dict(queries=30,max_posts=LIMIT,orders=schedule,selected_capacities=dict(zip(modes,[64,64,128,64,64])),selection='previous completed run; no new selection'))
 try:
  for index,(split,mode,repeat) in enumerate(schedule):
   remaining=deadline-time.monotonic()-30
   if remaining<=0:raise TimeoutError('query list has no remaining time')
   healthy();before=metrics()
   if any(before.get(k)!=0 for k in ('vllm:num_requests_running','vllm:num_requests_waiting')):raise ValueError('model occupied before query')
   manifest,table,rows,manifest_sha=manifests[split]
   transport=pooled if mode=='semloom-service' else legacy
   role='pg-daft-ray' if mode.startswith('semloom-') else mode
   capacity=128 if mode=='ray-data' else 64
   candidates=main_candidates(table,rows,ray_address=address,transport_path=str(transport),transport_sha256=file_identity(transport)['sha256'])
   selected=[v for v in candidates if v['role']==role and v['config']['concurrency']==capacity]
   if len(selected)!=1:raise ValueError('fixed selected configuration is absent')
   unit=f'q{index:02}';cfg=replace(QueryConfig(**selected[0]['config']),unit_id=unit)
   path=root/(unit+'.json');write_private_json(path,asdict(cfg));output=root/unit;new_private_directory(output)
   command=[sys.executable,'-m','src.experiments.postgresql.query_cli','run','--worker','--config',str(path),'--manifest',str(manifest),'--model',str(model),
      '--budget',str(ledger.path),'--budget-id',config['budget_id'],'--max-attempts',str(LIMIT),'--output',str(output),'--dsn-env',config['dsn_env'],'--pg-log',config['pg_log']]
   supervise(command,output,lambda:ledger.close_shared_unit(unit),query_timeout_s=120,max_duration_s=min(120,remaining),grace_s=5)
   ref=dict(path=str(output/'unit/summary.json'),sha256=file_identity(output/'unit/summary.json')['sha256']);record=read_run(ref,role)
   if record['unit_id']!=unit or record['config_sha256']!=configuration_identity(asdict(cfg)) or record['rows']!=rows or record['identities'][0]!=manifest_sha:raise ValueError('executed query differs from declared input/configuration')
   after=metrics();delta=after.get('vllm:request_success_total',0)-before.get('vllm:request_success_total',0)
   if delta!=rows or any(after.get(k)!=0 for k in ('vllm:num_requests_running','vllm:num_requests_waiting')):raise ValueError('model counts or occupancy differ after query')
   until=time.monotonic()+30
   while True:
    state=actors();live=query_actors(state,baseline)
    if not live and ray.available_resources().get('CPU',0)>=7:break
    if time.monotonic()>until:
     write_private_json(output/'ray-cleanup-failure.json',dict(actors=state,query_actors=live,available=ray.available_resources()))
     raise RuntimeError('query actors remain or CPU slots were not returned')
    time.sleep(.1)
   write_private_json(output/'ray-cleanup.json',dict(actors=state,query_actors=live,available=ray.available_resources()))
   check=RayMapTransport(fixed,64,physical=physical,ray_api=ray);check.abort_startup()
   saved=json.loads((output/'unit/summary.json').read_text());timing=saved['execution']
   quality=record['quality'];item=dict(unit=unit,mode=mode,role=role,split=split,repeat=repeat,rows=rows,summary=ref,
      config_sha256=record['config_sha256'],input_sha256=manifest_sha,actual_posts=record['actual_posts'],model_success_delta=delta,
      jct_seconds=record['jct_seconds'],preparation_seconds=(timing['t_release_ns']-saved['query_preparation_started_ns'])/1e9,
      stream_seconds=(timing['t_query_terminal_ns']-timing['t_release_ns'])/1e9,
      release_to_first_row_seconds=(timing['t_first_row_ns']-timing['t_release_ns'])/1e9,
      cleanup_seconds=(saved['t_execution_cleanup_ns']-timing['t_query_terminal_ns'])/1e9,
      accuracy=(quality['true_positive']+quality['true_negative'])/rows,quality=quality,model_usage=record['model_usage'],http=record['http'],
      service_before=before,service_after=after,ray_available_after=ray.available_resources(),worker_service_recovery_claim='passed')
   if mode.startswith('semloom-'):
    item['pg_preparation']=saved['resources']['pg_preparation'];item['gateway_startup']=json.loads((output/'unit/observer.json').read_text())['startup']
    events=[json.loads(line) for line in (output/'unit/public-events.jsonl').read_text().splitlines()]
    item['ray_startup']=[event for event in events if event['event'] in ('core_ray_startup','core_ray_first_submit')]
   report['completed'].append(item);report['actual_posts']+=record['actual_posts'];write_private_json(root/f'completed-{index:02}.json',item)
   print(json.dumps({k:item[k] for k in ('unit','mode','repeat','rows','jct_seconds','preparation_seconds','accuracy')}),flush=True)
  if report['actual_posts']!=LIMIT or ledger.snapshot()['allocated_requests']!=LIMIT:raise ValueError('final request allowance/accounting differs')
  report['status']='passed'
 finally:
  close_started=time.monotonic()
  pool.__exit__(*sys.exc_info());report['worker_service_cleanup_seconds']=time.monotonic()-close_started
  until=time.monotonic()+30
  while query_actors(actors(),set()) or ray.available_resources().get('CPU',0)<8:
   if time.monotonic()>until:raise RuntimeError('service actors or CPU slots remain after cleanup')
   time.sleep(.1)
except BaseException as error:
 report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
 raise
finally:
 if ray is not None and ray.is_initialized():ray.shutdown()
 report['ray_driver_disconnected']=ray is None or not ray.is_initialized();report['elapsed_seconds']=time.monotonic()-started
 if ledger:report['budget']=ledger.snapshot()
 write_private_json(root/'summary.json',report)
