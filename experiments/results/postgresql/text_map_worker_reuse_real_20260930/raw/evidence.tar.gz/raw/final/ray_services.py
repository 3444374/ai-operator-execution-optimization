"""Pinned native Ray services may outlive a query; query workers may not."""
SERVICES = {
    ('_StatsActor', 'datasets_stats_actor'),
    ('ActorLocationTracker', 'ActorLocationTracker'),
    ('_AutoscalingCoordinatorActor', 'AutoscalingCoordinator'),
    ('_TelemetryAgent', 'llm_batch_telemetry'),
}


def native_cluster_service(actor):
    return (actor.get('IsDetached') is True
            and (actor.get('ActorClassName'), actor.get('Name')) in SERVICES
            and actor.get('RequiredResources', {}).get('CPU', 0) == 0)


def query_actors(state, initial):
    return [actor for key, actor in state.items()
            if key not in initial and actor['State'] != 'DEAD'
            and not native_cluster_service(actor)]


def public_actor_state(state):
    fields = ('ActorID', 'ActorClassName', 'Name', 'IsDetached', 'State', 'JobID', 'NumRestarts')
    return {key: {field: actor[field] for field in fields if field in actor}
            for key, actor in state.items()}
