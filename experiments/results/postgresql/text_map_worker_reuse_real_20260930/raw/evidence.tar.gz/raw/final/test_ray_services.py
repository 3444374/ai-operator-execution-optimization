import unittest
from ray_services import native_cluster_service,query_actors,SERVICES,public_actor_state

class NativeServiceTests(unittest.TestCase):
    def test_known_detached_services_do_not_hide_query_actors(self):
        for cls,name in SERVICES:
            service=dict(ActorClassName=cls,Name=name,IsDetached=True,State='ALIVE')
            self.assertTrue(native_cluster_service(service))
            for changed in (dict(IsDetached=False),dict(Name='other'),dict(RequiredResources={'CPU':1})):
                self.assertFalse(native_cluster_service(dict(service,**changed)))
        worker=dict(ActorClassName='MapWorker',Name='',IsDetached=False,State='ALIVE')
        service=dict(ActorClassName='_StatsActor',Name='datasets_stats_actor',IsDetached=True,State='ALIVE')
        unknown=dict(ActorClassName='Unknown',Name='',IsDetached=True,State='ALIVE')
        self.assertEqual(query_actors({'known':service,'worker':worker,'unknown':unknown},set()),[worker,unknown])
        self.assertEqual(query_actors({'worker':dict(worker,State='DEAD')},set()),[])

    def test_protobuf_death_cause_is_excluded_from_public_state(self):
        import json
        actor=dict(ActorID='fixture',ActorClassName='MapWorker',Name='',IsDetached=False,State='DEAD',DeathCause=object())
        saved=public_actor_state({'fixture':actor})
        self.assertEqual(json.loads(json.dumps(saved))['fixture']['State'],'DEAD')
        self.assertNotIn('DeathCause',saved['fixture'])

if __name__=='__main__':unittest.main(verbosity=2)
