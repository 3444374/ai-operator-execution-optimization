import json
from pathlib import Path
PRIVATE = Path(__file__).parent

def read(relative):
    return json.loads((PRIVATE / relative).read_text())

def timeline(relative):
    base = PRIVATE / relative
    native = [json.loads(line) for line in (base / 'sema-service.jsonl').read_text().splitlines()]
    gateway = [json.loads(line) for line in (base / 'http-trace.jsonl').read_text().splitlines()]
    groups = {}
    for item in native:
        snapshot = item.get('native_snapshot')
        if snapshot is None:
            continue
        group = groups.setdefault(str(snapshot), {'rows': item['native_snapshot_rows'],
            'snapshot_ns': item['native_snapshot_ns'], 'graph_started_ns': item['native_graph_started_ns'],
            'arrival_ns': [], 'outcome_ns': [], 'written_ns': [], 'errors': []})
        group['arrival_ns'].append(item['proxy_arrived_ns'])
        for source, target in [('native_outcome_received_ns', 'outcome_ns'), ('response_written_ns', 'written_ns')]:
            if item.get(source) is not None:
                group[target].append(item[source])
        if item.get('error_type'):
            group['errors'].append(item['error_type'])
    return {'service_groups': groups,
        'gateway_received': len(gateway),
        'gateway_actual_header_sends': sum(x.get('upstream_headers_send_count', 0) for x in gateway),
        'gateway_header_send_ns': [x['upstream_headers_send_started_monotonic_ns'] for x in gateway
                                   if x.get('upstream_headers_send_started_monotonic_ns') is not None],
        'scope': 'per-service snapshot clock and separate gateway observations; identical bodies have no native row-ID join'}

def derive():
    stages = []
    for name in ('library-daft01', 'library-ray02'):
        value = read(f'artifacts/{name}/summary.json')
        graph = sum(x.get('actual_posts', 0) for x in value['observations'])
        service = sum(x['service_summary']['prepared_calls'] for x in value['observations'] if 'service_summary' in x)
        stages.append({'run': name, 'passed': value['passed'], 'checks': value['tests_run'],
            'skipped': value['skipped'], 'fixture_posts': graph + service,
            'count_basis': 'graph actual_posts plus successful service-test assertions on fixture counts',
            'fixture_graph_posts': graph, 'fixture_service_posts': service})
    for name in ('public-native01', 'public-daft01', 'public-ray02', 'public-semloom02'):
        value = read(f'artifacts/{name}/public-verification.json')
        stages.append({'run': name, 'status': value['status'], 'rows': value['rows'],
            'fixture_posts': value['actual_fixture_posts'], 'runtime': value['runtime']})
    modes = []
    for name in ('cpython-64b6d26641', 'ray-8f31535791'):
        value = read(f'artifacts/public-imlane04/{name}/result.json')
        direct = value['fixture_posts']
        public = value['stages']['lotus']['fixture_posts']
        assert direct == 7 and public == 8 and len(value['kernel_traces']) == 15 and value['passed']
        modes.append({k: value[k] for k in ('runtime', 'passed', 'actual_worker_pids', 'ray_actor_ids',
            'coordinator_shutdown', 'owned_survivors', 'remaining_shm')})
        modes[-1].update(direct_fixture_posts=direct, public_fixture_posts=public,
            public_rows=[4, 2, 2], full_http=value['stages']['full_http'],
            timeout=value['stages']['http_timeout'])
    receipt = read('artifacts/release-receipt.json')
    assert sum(s['fixture_posts'] for s in stages) == 158
    assert 158 + 15 + 30 + 30 + receipt['latest_ray']['fixture_posts'] == 239
    return {'schema': 'sema.six_paths.runtime.v1', 'stages': stages, 'latest_imlane_modes': modes,
        'prior_imlane_failed_combined_runs': [{'run': 'public-imlane02', 'posts': 15}, {'run': 'public-imlane03', 'posts': 30}],
        'latest_ray_failed': receipt['latest_ray'], 'fixture_posts_total': 239, 'fixture_posts_limit': 320,
        'real_model_posts': 0, 'gpu_used': 0, 'release': receipt,
        'timelines': {n: timeline(f'artifacts/{n}/query') for n in ('public-daft01', 'public-ray02', 'public-ray03')},
        'pending': ['successful Ray Data and SemLoom public driver_disconnected evidence after cc8b09bc',
                    'cold Ray Data query completing within its original 20s limit', 'real model quality and matched performance']}

if __name__ == "__main__":
    print(json.dumps(derive(), indent=2))
