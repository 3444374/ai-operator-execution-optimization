"""Own one fixed, finite zero-GPU Ray head with declared ports for software checks."""
import argparse
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--temp', type=Path, required=True)
parser.add_argument('--report', type=Path, required=True)
args = parser.parse_args()
os.environ['DASHBOARD_METRIC_PORT'] = '46529'
assert sorted(os.sched_getaffinity(0)) == list(range(8, 16))
assert not args.temp.is_symlink() and len(os.fsencode(args.temp)) <= 40
if args.temp.exists():
    assert args.temp.is_dir() and not any(args.temp.iterdir()) and args.temp.stat().st_uid == os.getuid()
else:
    args.temp.mkdir(mode=0o700)
assert not args.report.exists()
import psutil
import ray
from ray._private.node import Node
from ray._private.parameter import RayParams
from ray._private.services import get_node_ip_address
assert ray.__version__ == '2.56.1' and not ray.is_initialized()
report = dict(started_ns=time.monotonic_ns(), python=sys.executable, ray=ray.__version__,
              cpu_affinity=sorted(os.sched_getaffinity(0)), temp_preflight='new empty caller-owned short directory',
              gpu_resources=0, model_posts=0, node_source_sha256=hashlib.sha256(Path(inspect.getfile(Node)).read_bytes()).hexdigest(),
              private_runtime_api='fixed Ray Node/RayParams, no global ray stop',
              owned_processes=[], ready=False, shutdown=False)
node = None
try:
    params = RayParams(num_cpus=8, num_gpus=0, object_store_memory=268435456, memory=1073741824,
        node_ip_address=get_node_ip_address(), gcs_server_port=46520, object_manager_port=46521,
        node_manager_port=46522, metrics_agent_port=46523, metrics_export_port=46524,
        dashboard_agent_listen_port=46525, runtime_env_agent_port=46526,
        ray_client_server_port=46527, dashboard_port=46528, min_worker_port=46540,
        max_worker_port=46649, include_dashboard=False, temp_dir=str(args.temp))
    node = Node(params, head=True, shutdown_at_exit=True, spawn_reaper=True)
    report.update(ready=True, address=node.gcs_address,
                  owned_processes=[dict(pid=p.pid, start_time=p.create_time())
                                   for p in psutil.Process().children(recursive=True)])
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(ready=True, address=node.gcs_address)), flush=True)
    sys.stdin.readline()
except BaseException as error:
    report.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    if node is not None:
        node.kill_all_processes(check_alive=False, allow_graceful=True, wait=True)
        report['shutdown'] = True
    survivors = []
    for identity in report['owned_processes']:
        try:
            process=psutil.Process(identity['pid'])
            if process.create_time()==identity['start_time'] and process.status()!=psutil.STATUS_ZOMBIE:
                survivors.append(identity)
        except psutil.NoSuchProcess:
            pass
    report.update(owned_survivors=survivors, ended_ns=time.monotonic_ns())
    args.report.write_text(json.dumps(report, indent=2)+'\n')
