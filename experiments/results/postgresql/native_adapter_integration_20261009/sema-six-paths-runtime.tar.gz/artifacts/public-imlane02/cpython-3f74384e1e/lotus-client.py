DUCKDB_EXTENSION=None
SEMA_BINARY='<server-root>/autodl-tmp/experiment-artifacts/semantic-sema-adapter-20261009/upstream/Sema'
METHODS=('sema',)
MODEL_FIXTURE_PORT=46513
SERVICE_PORT=46511
OBSERVATION_PORT=46512

import json,os,pathlib,sys,sysconfig,time
code,config,native_source,tokenizer,result_file=sys.argv[1:]
value=json.loads(pathlib.Path(config).read_text());value.pop('fixture_endpoint')
bridge=json.loads(pathlib.Path(value['bridge_config_path']).read_text())
driver_site=sysconfig.get_path('purelib')
author_sites={p for p in bridge.get('env',{}).get('PYTHONPATH','').split(os.pathsep)
 if p and pathlib.Path(p).name in ('site-packages','dist-packages') and p!=driver_site}
sys.path[:]=[p for p in sys.path if p not in author_sites]
os.environ['PYTHONPATH']=os.pathsep.join(p for p in os.environ.get('PYTHONPATH','').split(os.pathsep)
 if p and p not in author_sites)
author_root=pathlib.Path(value['author_build_identity']).parents[2]
for name in ('LD_LIBRARY_PATH','PATH'):
 os.environ[name]=os.pathsep.join(p for p in os.environ.get(name,'').split(os.pathsep)
  if p and not pathlib.Path(p).is_relative_to(author_root))
os.environ['PATH']=str(pathlib.Path(sys.executable).parent)+os.pathsep+os.environ['PATH']
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
sys.path.insert(0,code)
from src.baselines.common.private_artifacts import write_private_json
from src.baselines.text.frameworks.imlane_calls import IMLaneCallConfig
from src.baselines.text.frameworks.prepared_map import NativeGraphOptions
from src.execution_provider.adapters.model_config import FixedModelConfig
from src.execution_provider.semantic_map import SemanticMapPlan
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.shared_request_budget import CellBudgetLedger
from src.experiments.postgresql.supplier_adapter_query import run_supplier_query
from src.experiments.postgresql.persistent_native_adapter_query import PersistentAdapterGroup
from src.experiments.postgresql.sema_native_query import SemaServiceConfig
from src.experiments.postgresql import supplier_adapter_query as supplier_module
from src.experiments.postgresql import persistent_native_adapter_query as persistent_module
from tests.experiments import test_native_adapter_query as model_fixture
from tests.experiments.test_native_adapter_query import fixture_server
from integrations.sema.verify_imlane_methods import listen_server_factory
model_fixture.ThreadingHTTPServer=listen_server_factory(model_fixture.ThreadingHTTPServer,MODEL_FIXTURE_PORT)
if OBSERVATION_PORT:
 original_gateway=supplier_module.ObservationGateway
 def gateway(**kwargs):return original_gateway(**dict(kwargs,bind_port=OBSERVATION_PORT))
 supplier_module.ObservationGateway=persistent_module.ObservationGateway=gateway
def optional_path(value):return None if value in (None,'None','') else pathlib.Path(value)
tokenizer_path=optional_path(tokenizer)
sema_binary=optional_path(SEMA_BINARY)
duckdb_library=optional_path(DUCKDB_EXTENSION)
sema_config=SemaServiceConfig(listen_port=SERVICE_PORT)
cfg=IMLaneCallConfig(**value);mode=cfg.runtime
options=NativeGraphOptions(concurrency=8,num_threads=8)
root=pathlib.Path(result_file).parent/'method-queries';root.mkdir()
plan=SemanticMapPlan('Return ok.','fixture',16)
ledger=CellBudgetLedger.create(root/'budget.sqlite',AttemptBudget('imlane-public-methods',64),deadline_utc=time.time()+180)
values=[dict(row_id='a',text='same'),dict(row_id='b',text='same'),dict(row_id='c',text='中文'),dict(row_id='d',text='fourth')]
suffix='-ray' if mode=='ray' else ''
results=[];posts_total=0;models=0
for method in METHODS:
 arm=('sema-native-imlane'+suffix+'-request-service' if method=='sema' else method+'-method-native-imlane'+suffix)
 with fixture_server(content='"ok"' if method=='sema' else 'ok') as (endpoint,posts):
  result=run_supplier_query(arm,load_source=lambda:iter(values),plan=plan,
   model=FixedModelConfig(endpoint,'fixture',20000),ledger=ledger,unit_id=method+'-'+mode,
   root=root/method,options=options,query_timeout_s=20,
   imlane_call_configs={mode:cfg},tokenizer_path=tokenizer_path,
   duckdb_library=duckdb_library,sema_binary=sema_binary,sema_native_threads=2,
   sema_service_config=sema_config if method=='sema' else None,
   reference_outputs={r['row_id']:'ok' for r in values},allowed_outputs=('ok',))
  assert result['status']=='passed' and result['actual_posts']==len(posts)==4,result
  assert result['execution']['recorded_rows']==4,result['execution']
  assert result['identity']['imlane_runtime']==mode,result['identity']
  assert result['runtime']['owner']=='IMLane author Coordinator',result['runtime']
  if method=='sema':
   service=result['request_service']
   assert service['uncertain_requests']==0 and not service['native_bridge_thread_alive'],service
   assert service['held_requests']==0 and service['native_driver_stopped'],service
   close=service['native_close_reports']
   assert all(r['clean'] is True for r in close),close
  elif method=='duckdb':
   close=result['identity']['diagnostics']['executor']['last_close_report']
   assert close['clean'] is True and close['received']==4,close
  results.append(dict(arm=arm,passed=True,posts=len(posts),rows=4,identity=result['identity'],runtime=result['runtime']))
  posts_total+=len(posts)
  write_private_json(root/('progress-'+str(len(results))+'.json'),dict(fixture_posts=posts_total,results=results,models=0))
# Reuse the caller Coordinator and each original method across two public group queries.
for method in (m for m in ('lotus','sema') if m in METHODS):
 arm='sema-native-imlane'+suffix+'-request-service' if method=='sema' else 'lotus-method-native-imlane'+suffix
 with fixture_server(content='"ok"' if method=='sema' else 'ok') as (endpoint,posts):
  with PersistentAdapterGroup((arm,),plan=plan,model=FixedModelConfig(endpoint,'fixture',20000),
   ledger=ledger,root=root/('persistent-'+method),options=options,query_timeout_s=20,
   imlane_call_configs={mode:cfg},tokenizer_path=tokenizer_path,
   sema_binary=sema_binary,sema_native_threads=2,
   sema_service_config=sema_config if method=='sema' else None) as group:
   for i in range(2):
    result=group.run(arm,unit_id='persistent-'+method+'-'+mode+'-'+str(i),
     root=root/('persistent-'+method+'-query-'+str(i)),load_source=lambda:iter(values[:2]),
     phase='qualification',allowed_outputs=('ok',),reference_outputs={r['row_id']:'ok' for r in values[:2]})
    assert result['status']=='passed' and result['actual_posts']==2,result
    assert result['execution']['recorded_rows']==2,result
    if method=='sema':
     service=result['request_service']
     assert service['uncertain_requests']==0 and service['held_requests']==0,service
     assert service['native_driver_stopped'] and not service['native_bridge_thread_alive'],service
     assert service['imlane_runtime']==mode and service['imlane_runtime_verified'],service
     assert all(r['clean'] is True for r in service['native_close_reports']),service
  assert len(posts)==4,posts
  posts_total+=4
 results.append(dict(arm=arm,case='persistent-two-queries',passed=True,posts=4,rows=4))
assert posts_total==4*len(METHODS)+4*sum(m in METHODS for m in ('lotus','sema')),posts_total
write_private_json(pathlib.Path(result_file),dict(passed=True,fixture_posts=posts_total,
 methods=results,models=0,gpu_resources=0,retries=0,imlane_runtime=mode))
