"""Read-only post-audit of the declared C/D follow-up; writes a separate report."""
from pathlib import Path
import hashlib,json,sqlite3,sys

base=Path(sys.argv[1]);root=base/'real-run';proposal=base/'real-proposal'
sys.path.insert(0,str(base/'source/code'))
from src.experiments.postgresql.map_bindings import parse_pg_bindings
from src.experiments.postgresql.organization_evaluation import verify_organization
from src.execution_provider.adapters.map_organization import MapOrganizationConfig
from src.baselines.common.private_artifacts import write_private_json,content_digest

snapshot=json.loads((proposal/'source-snapshot.json').read_text())
assert all(hashlib.sha256((base/'source'/p).read_bytes()).hexdigest()==h for p,h in snapshot['files'].items())
campaign=json.loads((root/'campaign-result.json').read_text())
assert not campaign['errors'] and campaign['ended_utc']<=campaign['deadline_utc']
schedule=json.loads((proposal/'schedule.json').read_text())
reports=[];predictions={}
with sqlite3.connect('file:'+str(root/'budget.sqlite')+'?mode=ro',uri=True) as ledger:
 for unit in schedule['units']:
  config=json.loads((proposal/unit['config_file']).read_text());name=config['unit_id'];r=root/name/'unit'
  summary=json.loads((r/'summary.json').read_text());execution=json.loads((r/'q0/execution.json').read_text())
  assert summary['status']=='passed' and execution['status']==execution['query_status']=='completed'
  result_bytes=(r/'q0/results.jsonl').read_bytes()
  assert hashlib.sha256(result_bytes).hexdigest()==execution['results_sha256'] and len(result_bytes)==execution['recorded_bytes']
  recorded=[json.loads(line) for line in result_bytes.splitlines()]
  assert len(recorded)==config['max_posts']==execution['recorded_rows']
  events=[json.loads(line) for line in (r/'events.jsonl').read_text().splitlines()]
  requests=[e for e in events if e['event']=='request']
  first=ledger.execute('SELECT first_attempt FROM units WHERE unit_id=?',(name,)).fetchone()[0]
  spent=ledger.execute('SELECT sequence,request_sha256 FROM shared_requests WHERE unit_id=? ORDER BY sequence',(name,)).fetchall()
  assert len(spent)==len(requests)==config['max_posts']
  actual={e['attempt']:e['request_bytes_sha256'] for e in requests}
  assert actual=={first+seq-1:digest for seq,digest in spent}
  bindings=parse_pg_bindings((r/'q0-producer.log').read_text().splitlines())
  row_id={b.sequence:b.row_id for b in bindings}
  terminal={e['key']['sequence']:e['monotonic_ns'] for e in events if e['event']=='core_terminal'}
  assert len(terminal)==len(row_id)==len(recorded)
  received={r['row'][0]:r['received_ns'] for r in recorded}
  assert set(received)==set(row_id.values())
  outstanding=[];waits=[]
  for seq,t in terminal.items():
   end=received[row_id[seq]]
   assert end>=t
   waits.append((end-t)/1e9);outstanding.extend([(t,1),(end,-1)])
  count=peak=0
  for _,delta in sorted(outstanding,key=lambda event:(event[0],-event[1])):
   count+=delta;assert count>=0;peak=max(peak,count)
  assert count==0
  start,end=execution['t_release_ns'],execution['t_query_terminal_ns']
  samples=[json.loads(line) for line in (r/'query-rss.jsonl').read_text().splitlines()]
  samples=[v for v in samples if start<=v['monotonic_ns']<=end]
  rss={}
  for sample in samples:
   for label,value in sample['rss_bytes'].items():
    if value is not None:rss[label]=max(rss.get(label,0),value)
  described=[e for e in events if e['event']=='core_map_work_described']
  organization=None
  if config['organization_config']:
   organization=verify_organization(MapOrganizationConfig.load(r/'organization.json'),events,
        max_active_requests=config['concurrency'],expected_max_new_tokens=128)
   assert organization==summary['evaluation']['organization']
  values=dict(r['row'] for r in recorded);predictions[name]=values
  reports.append(dict(unit=name,phase=unit['phase'],control=unit['control'],actual_posts=len(requests),
    config=config,quality=summary['evaluation']['quality'],jct_seconds=execution['query_jct_seconds'],
    first_row_seconds=(execution['t_first_row_ns']-start)/1e9,
    inline_recording_seconds=execution['inline_recording_seconds'],
    pg_memory=summary['evaluation'].get('pg_memory'),logical_resources=summary['evaluation']['logical_resources'],
    plan=summary['evaluation']['plan'],http=summary['evaluation']['http'],organization=organization,
    prediction_sha256=content_digest(values),query_rss_samples=len(samples),query_rss_peaks=rss,
    preparation=dict(attempts=len(described),unique_tasks=len({e['sequence'] for e in described}),
      seconds=sum(e['preparation_seconds'] for e in described)),
    terminal_to_consumer=dict(peak_outstanding=peak,max_seconds=max(waits),mean_seconds=sum(waits)/len(waits),
      scope='Core authoritative terminal to application observation; includes gateway, wire, PG order restoration and consumer; not pure PG ready rows'),
    result_file_sha256=execution['results_sha256']))
 closed=ledger.execute('SELECT count(*) FROM closed_shared_units').fetchone()[0]
 assert closed==16
posts=sum(r['actual_posts'] for r in reports)
log=(root/'model.log').read_text()
server_posts=sum('"POST /v1/chat/completions HTTP/1.1" 200 OK' in line for line in log.splitlines())
assert posts==server_posts==1152
validation=[r for r in reports if r['phase']=='evaluation']
d=[r for r in validation if r['control'].startswith('d-')]
loose=[r for r in d if r['control'].endswith('loose')];tight=[r for r in d if r['control'].endswith('tight')]
assert all(not r['organization']['compute_lifecycle']['work_limit_can_bind'] and
           not r['organization']['compute_lifecycle']['work_limit_binding_observed'] for r in loose)
binding=all(r['organization']['compute_lifecycle']['work_only_block_count']>0 for r in tight)
comparisons={r['unit']:sum(predictions[r['unit']][key]!=value for key,value in predictions[validation[0]['unit']].items()) for r in validation}
report=dict(status='passed',source_files_verified=len(snapshot['files']),closed_units=closed,
 actual_model_posts=posts,server_http_200=server_posts,campaign_seconds=campaign['ended_utc']-campaign['started_utc'],
 work_capacity_binding_conclusion='observed' if binding else 'inconclusive',
 prediction_differences_from_first_validation=comparisons,units=reports)
write_private_json(root/'post-audit.json',report)
print(json.dumps({k:v for k,v in report.items() if k!='units'}))
for r in validation:
 life=r['organization']['compute_lifecycle'] if r['organization'] else {}
 print(r['control'],'JCT',r['jct_seconds'],'HTTP',r['http']['peak_http'],'work',life.get('peak_active_work'),
       'work-only blocks',life.get('work_only_block_count'),'groups',r['organization']['batches'] if r['organization'] else None,
       'first row',r['first_row_seconds'],'outstanding',r['terminal_to_consumer']['peak_outstanding'])
