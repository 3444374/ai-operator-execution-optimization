"""Run the existing first-payload path without HTTP, Ray, or PostgreSQL."""
import argparse
import json
from pathlib import Path
import time

parser = argparse.ArgumentParser()
parser.add_argument('--output', required=True)
parser.add_argument('--max-first-seconds', type=float, default=.5)
args = parser.parse_args()
from src.data.materializers.payloads import PayloadBatchLimits, iter_payload_batches

samples = []
for index in range(3):
    started = time.monotonic_ns()
    stream = iter_payload_batches(((0, index, b'fixture-payload'),), PayloadBatchLimits(64, 2097152), batch_rows=16)
    try:
        table = next(stream)
        elapsed = (time.monotonic_ns() - started) / 1e9
        assert table.num_rows == 1
        assert table['sequence'][0].as_py() == index
        assert table['payload'][0].as_py() == b'fixture-payload'
        assert next(stream, None) is None
    finally:
        stream.close()
    samples.append(elapsed)
report = dict(real_model_posts=0, http_posts=0, first_payload_seconds=samples,
              limit_seconds=args.max_first_seconds,
              slow_first_payload=samples[0] > args.max_first_seconds)
Path(args.output).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
assert samples[0] <= args.max_first_seconds, 'first payload exceeded the declared time threshold'
