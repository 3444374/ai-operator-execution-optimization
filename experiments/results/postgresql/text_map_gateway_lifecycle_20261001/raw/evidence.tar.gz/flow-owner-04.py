"""Restore parent permissions after one finite, fixture-only comparison."""
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time

root=Path('<task-root>')
report=dict(status='failed',fixture_limit=2048,real_model_posts=0,errors=[])
paths=[Path('/root'),Path('/root/autodl-tmp'),root]
acls={str(p):subprocess.check_output(['getfacl','-p',str(p)],text=True) for p in paths}
(root/'comparison-acl-before-04.json').write_text(json.dumps(acls,indent=2))
worker=None
try:
    if json.loads((root/'preflight.json').read_text())['status']!='ok':
        raise ValueError('target environment check did not pass')
    with socket.socket() as sock: sock.bind(('127.0.0.1',55496))
    for path in paths:
        subprocess.run(['setfacl','-m','u:postgres:'+('rwx' if path==root else '--x'),str(path)],check=True)
    env=dict(os.environ,PYTHONPATH=str(root/'s3/code'),RAY_USAGE_STATS_ENABLED='0',DO_NOT_TRACK='true',
             DAFT_NUM_THREADS='8',CUDA_VISIBLE_DEVICES='',PYTHONUNBUFFERED='1')
    env.pop('RAY_ADDRESS',None)
    env.pop('PGOPTIONS',None)
    with (root/'comparison-worker-04.log').open('x') as log:
        worker=subprocess.Popen(['runuser','-u','postgres','--','/root/autodl-tmp/venvs/text-baselines/bin/python',
            str(root/'gateway-flow-04.py'),str(root/'r04'),str(root/'s3'),'<diagnostic-pg-prefix>'],
            stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        (root/'comparison-worker-04-pid.json').write_text(json.dumps(dict(pid=worker.pid,
            start_ticks=Path('/proc/'+str(worker.pid)+'/stat').read_text().split()[21])))
        try: worker.wait(timeout=660)
        except subprocess.TimeoutExpired:
            os.killpg(worker.pid,signal.SIGTERM)
            worker.wait(timeout=30)
            raise
        report['worker_exit']=worker.returncode
        if worker.returncode!=0: raise RuntimeError('fixture comparison failed; preserve its records')
        report['status']='passed'
except BaseException as error:
    report['errors'].append(dict(type=type(error).__name__,message=str(error)))
finally:
    for path,content in acls.items():
        subprocess.run(['setfacl','--restore=-'],input=content,text=True,check=True)
    report['parent_acls_restored']=all(subprocess.check_output(['getfacl','-p',path],text=True)==content for path,content in acls.items())
    report['gpu_compute_processes']=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
    (root/'comparison-owner-summary-04.json').write_text(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
