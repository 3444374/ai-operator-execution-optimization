"""Finite fixture comparison of fresh and persistent PG/Ray gateways."""
from contextlib import ExitStack
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import pwd
import signal
import sys
import threading
import time
import traceback

from src.baselines.common.private_artifacts import new_private_directory, write_private_json
from src.baselines.common.redact import redact_text
from src.baselines.text.sembench_movie import MOVIE_MAP_INSTRUCTION
from src.execution_provider.semantic_map import SemanticMapPlan
from src.execution_provider.adapters.model_config import load_fixed_model_config
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.postgresql.query_config import QueryConfig
from src.experiments.postgresql.query_inputs import QueryInputs
from src.experiments.postgresql.query_tables import install_input_table
from src.experiments.postgresql.query_workloads import prepare, read_prepared
from src.experiments.postgresql.query_supervisor import supervise
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster
from src.experiments.postgresql.persistent_gateway import PersistentMapGateway
from src.experiments.postgresql.flow_timing import analyze_flow

root, source, prefix = map(Path, sys.argv[1:4])
new_private_directory(root)
started = time.monotonic()
deadline = started + 900
limit = 8192
report = dict(status='failed', real_model_posts=0, fixture_limit=limit, prior_fixture_posts=32, cumulative_fixture_limit=8224, completed=[], errors=[], cleanup={})
lock = threading.Lock()
posts = active = peak = 0
server_errors = []
http = server_thread = ray = ledger = None
services = ExitStack()

def identity(path):
    return dict(path=str(path), sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())

def expired(*args):
    raise TimeoutError('fixture comparison duration exceeded')

signal.signal(signal.SIGALRM, expired)
signal.signal(signal.SIGTERM, expired)
signal.alarm(900)

class FixtureServer(ThreadingHTTPServer):
    request_queue_size = 512
    def handle_error(self, *args):
        server_errors.append('fixture handler error')
        super().handle_error(*args)

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def do_POST(self):
        global posts, active, peak
        body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        with lock:
            posts += 1
            active += 1
            peak = max(peak, active)
            permitted = posts <= limit
        try:
            if not permitted:
                self.send_error(429, 'fixture allowance exhausted')
                return
            if body['model'] != 'fixture-model':
                self.send_error(400, 'fixture model differs')
                return
            label = 'POSITIVE' if '[GOOD]' in body['messages'][-1]['content'] else 'NEGATIVE'
            payload = json.dumps(dict(model='fixture-model', choices=[dict(message=dict(content=label), finish_reason='stop')],
                                      usage=dict(prompt_tokens=10, completion_tokens=1))).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        finally:
            with lock:
                active -= 1
    def log_message(self, *args):
        pass

def config(unit, rows, transport):
    return QueryConfig(unit, 'pg', 'map', 'first_rows_' + str(rows), concurrency=64, window=256,
        input_bytes=134217728, result_bytes=134217728, query_timeout_s=120, max_posts=rows,
        map_transport_config=str(transport), map_transport_sha256=identity(transport)['sha256'],
        pg_total_budget=True, pg_window_bytes=268435456, pg_staging_bytes=4194304)

def begin_unit():
    global peak
    if deadline - time.monotonic() < 150:
        raise TimeoutError('insufficient query and cleanup time')
    with lock:
        peak = 0
        return posts

def write_flow_settings(path, settings):
    if path.exists():
        if json.loads(path.read_text()) != settings:
            raise ValueError('existing PG flow settings differ from the requested diagnostic')
    else:
        write_private_json(path, settings)

def accept_unit(unit, mode, rows, repeat, directory, summary, before, flow=False):
    if summary['status'] != 'passed':
        raise ValueError('query did not pass')
    evaluation = summary['evaluation']
    if evaluation['actual_posts'] != rows:
        raise ValueError('query evaluation count differs')
    quality = evaluation['quality']
    if quality['false_positive'] or quality['false_negative']:
        raise ValueError('fixture quality differs')
    with lock:
        if posts - before != rows or active or peak > 64:
            raise ValueError('fixture count, capacity, or outstanding requests differ')
        unit_peak = peak
    if server_errors:
        raise RuntimeError('fixture HTTP handler failed')
    if ray.available_resources().get('CPU', 0) < 6:
        raise RuntimeError('query retained undeclared Ray CPU slots')
    execution = summary['execution']
    t0 = summary['query_preparation_started_ns']
    item = dict(unit=unit, mode=mode, rows=rows, repeat=repeat, summary=identity(directory/'summary.json'),
        fixture_posts=rows, peak_http=unit_peak,
        jct_seconds=(execution['t_query_terminal_ns']-t0)/1e9,
        preparation_seconds=(execution['t_release_ns']-t0)/1e9,
        first_row_seconds=(execution['t_first_row_ns']-execution['t_release_ns'])/1e9,
        stream_seconds=(execution['t_query_terminal_ns']-execution['t_release_ns'])/1e9)
    if flow:
        write_flow_settings(directory/'flow-settings.json', dict(pause_input=-1, pause_ms=0, ready_first=False,
            clock_source=time.get_clock_info('monotonic').implementation))
        try:
            diagnostic = analyze_flow(directory, expected_rows=rows, window=256)
            write_private_json(directory/'flow-analysis.json', diagnostic)
            item['flow'] = {k:diagnostic[k] for k in ('first_input_to_submit_s','first_poll_to_submit_s',
                'first_node_return_s','client_first_row_s','query_jct_s')}
        except ValueError as error:
            item['flow_unavailable'] = redact_text(str(error))
    report['completed'].append(item)
    write_private_json(root/('completed-'+unit+'.json'), item)
    print(json.dumps({k:item[k] for k in ('unit','mode','rows','repeat','jct_seconds','preparation_seconds','first_row_seconds')}), flush=True)

try:
    if os.environ.get('DO_NOT_TRACK') != 'true':
        raise ValueError('fixture comparison requires telemetry opt-out before imports')
    report['versions'] = {n:importlib.metadata.version(n) for n in ('ray','daft','pyarrow','psycopg','httpx')}
    if report['versions']['ray'] != '2.56.1' or report['versions']['daft'] != '0.7.21':
        raise ValueError('runtime version differs')
    report['environment'] = {key:os.environ.get(key) for key in ('DO_NOT_TRACK','DAFT_NUM_THREADS','RAY_USAGE_STATS_ENABLED','CUDA_VISIBLE_DEVICES')}
    report['source_revision'] = __import__('subprocess').check_output(['git','-c','safe.directory='+str(source),'-C',str(source),'rev-parse','HEAD'], text=True).strip()
    report['pg_library'] = identity(prefix/'lib/postgresql/semloom_pg.so')
    prior = root.parent/'r02'
    previous = json.loads((prior/'controller-summary.json').read_text())
    if previous['fixture_posts'] != 32 or not all(v for k,v in previous['cleanup'].items() if k!='http_active'):
        raise ValueError('prior fixture use or cleanup differs')
    report['qualification_references'] = []
    for directory in (prior/'q00/unit',prior/'g16/p00'):
        qualification = json.loads((directory/'summary.json').read_text())
        if qualification['status'] != 'passed' or qualification['evaluation']['actual_posts'] != 16:
            raise ValueError('prior qualification did not pass')
        report['qualification_references'].append(identity(directory/'summary.json'))
    http = FixtureServer(('127.0.0.1', 0), Handler)
    server_thread = threading.Thread(target=http.serve_forever)
    server_thread.start()
    model = root/'model.json'
    write_private_json(model, dict(endpoint_url=f'http://127.0.0.1:{http.server_port}/v1/chat/completions',
                                  model_id='fixture-model', timeout_ms=30000))
    import ray
    ray_start = time.monotonic()
    ray.init(address='local', num_cpus=8, num_gpus=0, include_dashboard=False, _node_ip_address='127.0.0.1',
             object_store_memory=268435456, _temp_dir=str(root/'r'))
    report['ray_service_startup_seconds'] = time.monotonic()-ray_start
    from src.execution_provider.adapters.ray_map_transport import RayMapConfig, owned_map_worker_pool
    fixed = load_fixed_model_config(model)
    transport = {}
    for mode in ('fresh','persistent'):
        physical = RayMapConfig(address=ray.get_runtime_context().gcs_address, workers=1, batch_rows=16,
            window_bytes=2097152, object_bytes=4194304, worker_pool='firstrow-'+mode)
        start = time.monotonic()
        services.enter_context(owned_map_worker_pool(ray, fixed, 64, physical))
        report[mode+'_worker_service_startup_seconds'] = time.monotonic()-start
        transport[mode] = root/(mode+'-transport.json')
        write_private_json(transport[mode], asdict(physical))
    report['initial_available_cpus'] = ray.available_resources().get('CPU', 0)
    if report['initial_available_cpus'] != 6:
        raise ValueError('initial available CPU slots differ')
    budget = AttemptBudget('gateway-lifecycle.fixture.v1', limit)
    ledger = CellBudgetLedger.create(root/'budget.sqlite', budget, deadline_utc=time.time()+780)
    manifests = {}
    pg = root/'pg'
    pg.mkdir()
    with isolated_pg18_cluster(prefix, pg, pwd.getpwuid(os.getuid()), port=55496) as connection:
        report['pg_version'] = connection.info.server_version
        dsn = connection.info.dsn
        os.environ['FIRST_ROW_DSN'] = dsn
        for rows in (16,1024):
            destination = root/('inputs-'+str(rows))
            prepare(destination, 'movie', ((str(i),'fixture-movie', '[GOOD] 很好 review' if i%2==0 else '[BAD] poor review',
                    'POSITIVE' if i%2==0 else 'NEGATIVE', 'original-'+str(i//2)) for i in range(rows)),
                dict(source='gateway lifecycle synthetic diagnosis'), max_rows=rows)
            manifests[rows] = destination/'manifest.json'
            installation = install_input_table(connection, QueryInputs('movie','first_rows_'+str(rows),rows),
                                                read_prepared(manifests[rows], 'raw.jsonl'))
            write_private_json(root/('installation-'+str(rows)+'.json'), installation)
        plan = SemanticMapPlan(MOVIE_MAP_INSTRUCTION, 'fixture-model', 128)
        def fresh(unit, rows, repeat, flow=False):
            cfg = config(unit, rows, transport['fresh'])
            cfg_path = root/(unit+'.json')
            write_private_json(cfg_path, asdict(cfg))
            out = root/unit
            new_private_directory(out)
            command = [sys.executable,'-m','src.experiments.postgresql.query_cli','run','--worker','--config',str(cfg_path),
                '--manifest',str(manifests[rows]),'--model',str(model),'--budget',str(ledger.path),
                '--budget-id',budget.budget_id,'--max-attempts',str(limit),'--output',str(out),
                '--dsn-env','FIRST_ROW_DSN','--pg-log',str(pg/'postgres.log')]
            before = begin_unit()
            if flow: os.environ['PGOPTIONS'] = '-c semloom_pg.test_flow_trace=on'
            try:
                supervise(command, out, lambda:ledger.close_shared_unit(unit), query_timeout_s=120, max_duration_s=120, grace_s=5)
            finally:
                if flow: os.environ.pop('PGOPTIONS', None)
            directory = out/'unit'
            summary = json.loads((directory/'summary.json').read_text())
            accept_unit(unit, 'fresh', rows, repeat, directory, summary, before, flow)
        def make_group(name, rows, count):
            return PersistentMapGateway(config(name, rows, transport['persistent']), plan=plan, manifest_path=manifests[rows],
                model_path=model, ledger=ledger, root=root/name, query_count=count)
        def persistent(group, unit, rows, repeat, flow=False):
            before = begin_unit()
            summary = group.run_query(unit, dsn=dsn, pg_log=pg/'postgres.log', trace_flow=flow)
            accept_unit(unit, 'persistent', rows, repeat, group.root/unit, summary, before, flow)
        schedule = []
        for repeat in range(4):
            order = ('fresh','persistent') if repeat%2==0 else ('persistent','fresh')
            schedule += [(('q' if mode=='fresh' else 'p')+str(repeat+1).zfill(2),mode,1024,repeat) for mode in order]
        write_private_json(root/'schedule.json', dict(units=schedule,fixture_limit=limit,real_model_posts=0,
            independent_worker_services=2,ray_cpu_slots=8,initial_available_cpu_slots=6))
        group_start = time.monotonic()
        with make_group('g1024', 1024, 4) as group:
            report['persistent_gateway_startup_seconds'] = time.monotonic()-group_start
            for unit, mode, rows, repeat in schedule:
                if mode=='fresh': fresh(unit, rows, repeat)
                else: persistent(group, unit, rows, repeat)
        report['persistent_group_summary'] = identity(root/'g1024/summary.json')
    if posts != limit or ledger.snapshot()['allocated_requests'] != limit:
        raise ValueError('final fixture accounting differs')
    report['status'] = 'passed'
except BaseException as error:
    report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
    print(redact_text(traceback.format_exc()), file=sys.stderr, flush=True)
finally:
    signal.alarm(0)
    if ray and ray.is_initialized():
        try:
            services.close()
            until = time.monotonic()+30
            while ray.available_resources().get('CPU',0)<8:
                if time.monotonic()>until: raise RuntimeError('worker CPU slots were not released')
                time.sleep(.1)
            report['cleanup']['worker_cpu_slots_released'] = True
        except BaseException as error:
            report['cleanup']['worker_cpu_slots_released'] = False
            report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
        ray.shutdown()
    if http:
        http.shutdown()
        http.server_close()
    if server_thread: server_thread.join(5)
    report.update(fixture_posts=posts, elapsed_seconds=time.monotonic()-started, budget=ledger.snapshot() if ledger else None)
    report['cleanup'].update(pg_stopped=not (root/'pg/data/postmaster.pid').exists(),
        ray_driver_disconnected=not ray or not ray.is_initialized(),http_active=active,
        server_thread_stopped=not server_thread or not server_thread.is_alive())
    if not all(v for k,v in report['cleanup'].items() if k!='http_active') or active or server_errors or report['errors']:
        report['status']='failed'
    write_private_json(root/'controller-summary.json', report)
raise SystemExit(0 if report['status']=='passed' else 1)
