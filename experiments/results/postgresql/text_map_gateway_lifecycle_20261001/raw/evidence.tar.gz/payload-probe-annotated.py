"""Run the existing first-payload path without HTTP, Ray, or PostgreSQL."""
import argparse
import json
from pathlib import Path
import time

parser = argparse.ArgumentParser()
parser.add_argument('--output', required=True)
parser.add_argument('--max-first-seconds', type=float, default=.5)
parser.add_argument('--preload', action='store_true')
parser.add_argument('--profile', action='store_true')
args = parser.parse_args()
from src.data.materializers.payloads import PayloadBatchLimits, iter_payload_batches

preload = {}
if args.preload:
    for name in ('daft', 'pyarrow', 'src.data.materializers.text'):
        start = time.monotonic_ns()
        __import__(name)
        preload[name] = (time.monotonic_ns() - start) / 1e9
if args.profile:
    import cProfile
    profiler = cProfile.Profile()
    profiler.enable()

samples = []
for index in range(3):
    started = time.monotonic_ns()
    stream = iter_payload_batches(((0, index, b'fixture-payload'),), PayloadBatchLimits(64, 2097152), batch_rows=16)
    try:
        table = next(stream)
        elapsed = (time.monotonic_ns() - started) / 1e9
        assert table.num_rows == 1
        assert table['sequence'][0].as_py() == index
        assert table['payload'][0].as_py() == b'fixture-payload'
        assert next(stream, None) is None
    finally:
        stream.close()
    samples.append(elapsed)
report = dict(real_model_posts=0, http_posts=0, first_payload_seconds=samples,
              limit_seconds=args.max_first_seconds,
              slow_first_payload=samples[0] > args.max_first_seconds,
              preload_seconds=preload, profiler_enabled=args.profile)
if args.profile:
    profiler.disable()
    profiler.dump_stats(args.output + '.pstats')
    import pstats
    stats = pstats.Stats(profiler)
    report['profile_top_cumulative'] = [dict(file=key[0], line=key[1], function=key[2],
        primitive_calls=value[0], total_calls=value[1], self_seconds=value[2], cumulative_seconds=value[3])
        for key, value in sorted(stats.stats.items(), key=lambda pair: pair[1][3], reverse=True)[:45]]
Path(args.output).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
assert samples[0] <= args.max_first_seconds, 'first payload exceeded the declared time threshold'
