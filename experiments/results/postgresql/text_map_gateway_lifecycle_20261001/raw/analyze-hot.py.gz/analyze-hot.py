"""Read unique public evidence and verify row timing, clocks and resource accounting."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import sys
import tarfile

def distribution(values):
    values = sorted(values)
    def percentile(q):
        position = (len(values)-1)*q
        left = int(position)
        right = min(left+1, len(values)-1)
        return values[left]+(values[right]-values[left])*(position-left)
    return dict(count=len(values), sum=sum(values), mean=statistics.mean(values),
                median=statistics.median(values), p95=percentile(.95), maximum=max(values), minimum=min(values))

class Evidence:
    def __init__(self, root):
        self.root = root
        self.entries = {e['path']: e for e in map(json.loads, (root/'hot-storage-manifest.jsonl').read_text().splitlines())}
        self.tar = tarfile.open(root/'hot-evidence.tar.gz')
        self.cache = {}

    def raw(self, name):
        if name in self.cache:
            return self.cache[name]
        item = self.entries[name]
        rule = item['recovery']
        mode = rule['mode']
        if mode == 'archive':
            value = self.tar.extractfile(name).read()
        elif mode == 'alias':
            value = self.raw(rule['source'])
        elif mode == 'slice':
            value = self.raw(rule['source'])[rule['start']:rule['start']+rule['length']]
        else:
            source = self.lines(rule['source'])
            if mode == 'event_projection':
                static = [e for e in source if e['event'] == 'core_map_organization_config']
                source = static[:rule['configuration_events']]+source[rule['first']:rule['last']]
                value = ''.join(json.dumps(e)+'\n' for e in source).encode()
            elif mode == 'compact_events':
                from src.experiments.buffered_events import compact_event
                value = ''.join(json.dumps(compact_event(e), ensure_ascii=False, allow_nan=False,
                             separators=(',', ':'))+'\n' for e in source).encode()
            else:
                raise ValueError('private binary is outside public replay')
        if len(value) != item['public_bytes'] or hashlib.sha256(value).hexdigest() != item['public_sha256']:
            raise ValueError('public member does not match recorded bytes: '+name)
        self.cache[name] = value
        return value

    def record(self, name):
        return json.loads(self.raw(name))

    def lines(self, name):
        return [json.loads(line) for line in self.raw(name).splitlines()]

def analyze(root, repo):
    sys.path.insert(0, str(repo/'code'))
    from src.experiments.postgresql.map_bindings import parse_pg_bindings, verify_bound_map_results
    from src.execution_provider.semantic_map import SemanticMapPlan
    from src.baselines.text.sembench_movie import MOVIE_MAP_INSTRUCTION
    evidence = Evidence(root)
    try:
        storage = json.loads((root/'hot-storage-validation.json').read_text())
        if hashlib.sha256((root/'hot-evidence.tar.gz').read_bytes()).hexdigest() != storage['public_archive_sha256']:
            raise ValueError('public archive identity differs')
        identity = evidence.record('source-identity.json')
        for name in ('code/src/execution_provider/adapters/ray_map_transport.py',
                     'code/src/experiments/choice_gateway_observer.py', 'code/src/experiments/buffered_events.py',
                     'code/src/execution_provider/semantic_map.py', 'code/src/experiments/postgresql/map_bindings.py'):
            if hashlib.sha256((repo/name).read_bytes()).hexdigest() != identity['files'][name]:
                raise ValueError('replay source differs from executed code: '+name)
        controller = evidence.record('o3/r/controller-summary.json')
        cleanup = evidence.record('cleanup-independent.json')
        if controller['status'] != 'passed' or controller['fixture_posts'] != 4112 or cleanup['status'] != 'passed':
            raise ValueError('fixture completion or cleanup differs')
        output = dict(schema='semloom.hot_map_timing.v1', source_revision=identity['revision'],
            source_files=len(identity['files']), real_model_requests=0, fixture_posts=4112,
            fixture_queries=5, controller_elapsed_seconds=controller['elapsed_seconds'],
            public_archive_sha256=storage['public_archive_sha256'],
            ray_startup_seconds=controller['ray_service_startup_seconds'],
            shared_gateway_startup_seconds=controller['persistent_gateway_startup_seconds'],
            initial_available_cpus=controller['initial_available_cpus'], versions=controller['versions'],
            failures=[dict(stage='output-directory permission', posts=0),dict(stage='Ray socket pathname',posts=0)],
            queries=[], limitations=[
                'fixture responses contain no inference; no real-model performance claim',
                'serial guard durations overlap thread work and RPC waits',
                'worker duration includes payload extraction and the HTTP client',
                'submit-call time is nested in RPC and may overlap remote work',
                'HTTP capacity cannot be inferred from the short-lived fixture server peak',
                'same-clock identity uses Linux boot, time namespace and clock implementation',
                'full-model PG node timestamps and actual GPU spans remain unavailable'])
        plan = SemanticMapPlan(MOVIE_MAP_INSTRUCTION, 'fixture-model', 128)
        for item in controller['completed']:
            rows = item['rows']
            base = 'o3/r/'+('g16/' if rows == 16 else 'g1024/')+item['unit']
            summary = evidence.record(base+'/summary.json')
            events = evidence.lines(base+'/events.jsonl')
            groups = defaultdict(list)
            for event in events:
                groups[event['event']].append(event)
            raw_results = evidence.raw(base+'/q0/results.jsonl')
            if hashlib.sha256(raw_results).hexdigest() != summary['execution']['results_sha256']:
                raise ValueError('client result identity differs')
            results = [json.loads(line) for line in raw_results.splitlines()]
            inputs = evidence.lines('o3/r/inputs-'+str(rows)+'/raw.jsonl')
            bindings = parse_pg_bindings(evidence.raw(base+'/q0-producer.log').decode().splitlines())
            association = verify_bound_map_results([(r[1],r[3]) for r in inputs],
                [r['row'] for r in results], bindings, events, evidence.lines(base+'/sessions.jsonl'), plan=plan)
            if [r.row_id for r in bindings] != [r['row'][0] for r in results]:
                raise ValueError('PG input order differs from client output')
            def keyed(name):
                selected = groups[name]
                indexed = {e['key']['sequence']: e for e in selected}
                if len(selected) != rows or set(indexed) != set(range(rows)):
                    raise ValueError('missing or duplicate row observations: '+name)
                return indexed
            submitted = keyed('core_submitted')
            replies = keyed('core_ray_http_completed')
            guards = keyed('core_ray_request_guard')
            ledger = keyed('remote_request_guard')
            values = defaultdict(list)
            for sequence in range(rows):
                reply = replies[sequence]
                if not reply['shared_clock'] or not reply['rpc_started_ns'] <= reply['worker_started_ns'] <= reply['worker_ended_ns'] <= reply['received_ns']:
                    raise ValueError('shared-clock chain is incomplete or noncausal')
                if reply['before_worker_ns']+reply['worker_elapsed_ns']+reply['after_worker_ns'] != reply['rpc_elapsed_ns']:
                    raise ValueError('RPC partition does not close')
                if reply['submit_elapsed_ns']+reply['await_elapsed_ns'] != reply['rpc_elapsed_ns']:
                    raise ValueError('submit and wait do not match RPC duration')
                for event in (guards[sequence], ledger[sequence]):
                    if event['status'] != 'completed' or event['key'] != reply['key']:
                        raise ValueError('pre-send guard failed or changed row identity')
                for field in ('hash_ns','reserve_ns','request_observe_ns'):
                    values[field[:-3]+'_ms'].append(ledger[sequence][field]/1e6)
                if sum(ledger[sequence][k] for k in ('hash_ns','reserve_ns','request_observe_ns')) > ledger[sequence]['elapsed_ns']:
                    raise ValueError('guard components exceed enclosing duration')
                values['guard_ms'].append(guards[sequence]['elapsed_ns']/1e6)
                values['core_to_rpc_ms'].append((reply['rpc_started_ns']-submitted[sequence]['monotonic_ns'])/1e6)
                for field in ('submit_elapsed_ns','await_elapsed_ns','worker_elapsed_ns','before_worker_ns','after_worker_ns','rpc_elapsed_ns'):
                    values[field[:-3]+'_ms'].append(reply[field]/1e6)
            work = {}
            for stage in ('payload_next','object_put','payload_close'):
                selected = [e for e in groups['core_ray_work'] if e['stage'] == stage]
                for event in selected:
                    if event['status'] != 'completed' or any(event[k] < 0 for k in ('queue_ns','work_ns','resume_ns')):
                        raise ValueError('thread work did not complete')
                    if sum(event[k] for k in ('queue_ns','work_ns','resume_ns')) != event['elapsed_ns']:
                        raise ValueError('thread work partition does not close')
                work[stage] = {k[:-3]+'_seconds': sum(e[k] for e in selected)/1e9
                              for k in ('queue_ns','work_ns','resume_ns','elapsed_ns')}
                work[stage]['calls'] = len(selected)
            query = dict(unit=item['unit'], rows=rows, repeat=item['repeat'], association=association,
                jct_seconds=item['jct_seconds'], preparation_seconds=item['preparation_seconds'],
                stream_seconds=item['stream_seconds'], first_row_seconds=item['first_row_seconds'],
                fixture_http_peak=item['peak_http'], work=work,
                row_timings={k:distribution(v) for k,v in values.items()},
                serial_ledger_reserve_seconds=sum(e['reserve_ns'] for e in ledger.values())/1e9,
                serial_guard_seconds=sum(e['elapsed_ns'] for e in guards.values())/1e9,
                object_blocks=summary['evaluation']['ray_transport']['object_blocks'],
                peak_arrow_buffer_bytes=summary['evaluation']['ray_transport']['peak_arrow_buffer_bytes'],
                logical_resources=summary['evaluation']['logical_resources'])
            output['queries'].append(query)
        measured = [q for q in output['queries'] if q['repeat'] > 0]
        output['measured_medians'] = {k:statistics.median(q[k] for q in measured) for k in
            ('jct_seconds','preparation_seconds','stream_seconds','serial_ledger_reserve_seconds','serial_guard_seconds')}
        output['verified_rows'] = sum(q['rows'] for q in output['queries'])
        return output
    finally:
        evidence.tar.close()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--raw', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = analyze(args.raw, args.repo)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(dict(verified_rows=report['verified_rows'], real_model_requests=0, medians=report['measured_medians'])))
