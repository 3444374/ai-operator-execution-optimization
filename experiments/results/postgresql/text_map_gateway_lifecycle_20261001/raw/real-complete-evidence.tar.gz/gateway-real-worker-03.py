"""Approved 12336-POST direct/fresh/persistent model comparison."""
from contextlib import ExitStack
from dataclasses import asdict, replace
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from urllib.request import urlopen

from src.baselines.common.private_artifacts import new_private_directory, write_private_json
from src.baselines.common.redact import redact_text
from src.baselines.text.sembench_movie import MOVIE_MAP_INSTRUCTION
from src.execution_provider.semantic_map import SemanticMapPlan
from src.execution_provider.adapters.model_config import load_fixed_model_config
from src.execution_provider.adapters.ray_map_transport import RayMapConfig, owned_map_worker_pool
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.postgresql.query_config import QueryConfig
from src.experiments.postgresql.query_inputs import QueryInputs
from src.experiments.postgresql.query_tables import install_input_table
from src.experiments.postgresql.query_workloads import load_manifest, read_prepared, file_identity
from src.experiments.postgresql.text_map_candidates import main_candidates
from src.experiments.postgresql.text_map_comparison import read_run, configuration_identity
from src.experiments.postgresql.query_supervisor import supervise
from src.experiments.postgresql.persistent_gateway import PersistentMapGateway
from src.observability.metrics.vllm import scrape_prometheus_metrics

from real_time_budget import query_time_budget

LIMIT=12336
config=json.loads(Path(sys.argv[1]).read_text())
if config['max_posts']!=LIMIT:raise ValueError('exact authorized allowance required')
if os.environ.get('DO_NOT_TRACK')!='true':raise ValueError('declared telemetry setting differs')
root=Path(config['output_root'])
new_private_directory(root)
started=time.monotonic()
deadline=min(started+720,started+config['deadline_utc']-time.time())
report=dict(status='failed',completed=[],errors=[],max_posts=LIMIT,actual_posts=0,
    ray_driver_disconnected=False,modes=['pg-source-direct','semloom-fresh','semloom-persistent'])
ray=None
ledger=None
services=ExitStack()

def metrics():return scrape_prometheus_metrics(config['model_url']+'/metrics',timeout_s=3)
def before_query():
    query_time_budget(deadline,time.monotonic())
    with urlopen(config['model_url']+'/health',timeout=2) as response:
        if response.status!=200:raise ValueError('model health differs')
    value=metrics()
    if any(value.get(k)!=0 for k in ('vllm:num_requests_running','vllm:num_requests_waiting')):
        raise ValueError('model is occupied before query')
    return value

def accepted(unit,mode,split,repeat,cfg,directory,summary,before,record=None):
    if summary['status']!='passed' or summary['config']!=asdict(cfg):
        raise ValueError('query state or resolved configuration differs')
    manifest,table,rows,manifest_sha=manifests[split]
    if summary['manifest_sha256']!=manifest_sha or summary['semantic_reference_sha256']!=plan.digest:
        raise ValueError('query semantic or input identity differs')
    evaluation=summary['evaluation']
    if evaluation['actual_posts']!=rows:raise ValueError('query request count differs')
    if record is not None and (record['unit_id']!=unit or record['config_sha256']!=configuration_identity(asdict(cfg))):
        raise ValueError('offline execution identity differs')
    after=metrics()
    delta=after.get('vllm:request_success_total',0)-before.get('vllm:request_success_total',0)
    if delta!=rows or any(after.get(k)!=0 for k in ('vllm:num_requests_running','vllm:num_requests_waiting')):
        raise ValueError('model success count or occupancy differs after query')
    if ray.available_resources().get('CPU',0)<6:raise ValueError('undeclared Ray CPU reservation remains')
    quality=evaluation['quality']
    timing=summary['execution']
    item=dict(unit=unit,mode=mode,split=split,repeat=repeat,rows=rows,summary=dict(path=str(directory/'summary.json'),
        sha256=file_identity(directory/'summary.json')['sha256']),config_sha256=configuration_identity(asdict(cfg)),
        input_sha256=manifest_sha,actual_posts=rows,model_success_delta=delta,
        jct_seconds=(timing['t_query_terminal_ns']-summary['query_preparation_started_ns'])/1e9,
        preparation_seconds=(timing['t_release_ns']-summary['query_preparation_started_ns'])/1e9,
        stream_seconds=(timing['t_query_terminal_ns']-timing['t_release_ns'])/1e9,
        first_row_seconds=(timing['t_first_row_ns']-timing['t_release_ns'])/1e9,
        cleanup_seconds=(summary['t_execution_cleanup_ns']-timing['t_query_terminal_ns'])/1e9,
        accuracy=(quality['true_positive']+quality['true_negative'])/rows,quality=quality,
        model_usage=evaluation.get('model_usage'),service_before=before,service_after=after,
        executor_lifecycle='per-query' if mode!='semloom-persistent' else 'caller-owned gateway',
        available_cpus_after=ray.available_resources().get('CPU',0))
    if mode=='semloom-fresh':
        item['pg_preparation']=summary['resources']['pg_preparation']
        item['gateway_startup']=json.loads((directory/'observer.json').read_text())['startup']
    if mode.startswith('semloom'):
        events=[json.loads(line) for line in (directory/'events.jsonl').read_text().splitlines()]
        item['ray_startup']=[e for e in events if e['event'] in ('core_ray_startup','core_ray_first_submit')]
    report['completed'].append(item)
    report['actual_posts']+=rows
    write_private_json(root/('completed-'+unit+'.json'),item)
    print(json.dumps({k:item[k] for k in ('unit','mode','repeat','rows','jct_seconds','preparation_seconds','accuracy')}),flush=True)

try:
    import psycopg,ray
    model=Path(config['model_config'])
    fixed=load_fixed_model_config(model)
    plan=SemanticMapPlan(MOVIE_MAP_INSTRUCTION,fixed.model_id,128)
    manifests={}
    with psycopg.connect(os.environ[config['dsn_env']],autocommit=True) as connection:
        if connection.info.server_version!=180003:raise ValueError('PG version differs')
        for split in ('qualification','evaluation'):
            data=config['inputs'][split]
            path=Path(data['path'])
            manifest=load_manifest(path)
            if manifest['sha256']!=data['manifest_sha256']:raise ValueError('declared manifest differs')
            table='gateway_'+split
            installation=install_input_table(connection,QueryInputs('movie',table,manifest['rows'],
                manifest['max_source_bytes'],manifest['max_input_bytes']),read_prepared(path,'raw.jsonl'))
            write_private_json(root/(split+'-installation.json'),installation)
            manifests[split]=(path,table,manifest['rows'],manifest['sha256'])
    begin=time.monotonic()
    ray.init(address='local',num_cpus=8,num_gpus=0,include_dashboard=False,_node_ip_address='127.0.0.1',
        object_store_memory=268435456,_temp_dir=config['ray_root'])
    report['ray_startup_seconds']=time.monotonic()-begin
    report['ray_source_commit']=ray.__commit__
    transport={}
    for mode in ('semloom-fresh','semloom-persistent'):
        physical=RayMapConfig(ray.get_runtime_context().gcs_address,1,16,2097152,4194304,'gw-'+mode)
        begin=time.monotonic()
        services.enter_context(owned_map_worker_pool(ray,fixed,64,physical))
        report[mode+'_worker_startup_seconds']=time.monotonic()-begin
        transport[mode]=root/(mode+'-transport.json')
        write_private_json(transport[mode],asdict(physical))
    report['initial_available_cpus']=ray.available_resources().get('CPU',0)
    if report['initial_available_cpus']!=6:raise ValueError('initial CPU slots differ')
    budget=AttemptBudget(config['budget_id'],LIMIT)
    ledger=CellBudgetLedger.create(root/'budget.sqlite',budget,deadline_utc=config['deadline_utc'])
    def candidate(unit,mode,split):
        manifest,table,rows,_=manifests[split]
        path=transport[mode if mode.startswith('semloom') else 'semloom-fresh']
        role='pg-daft-ray' if mode.startswith('semloom') else mode
        values=main_candidates(table,rows,ray_address=ray.get_runtime_context().gcs_address,
            transport_path=str(path),transport_sha256=file_identity(path)['sha256'])
        found=[value for value in values if value['role']==role and value['config']['concurrency']==64]
        if len(found)!=1:raise ValueError('fixed candidate is absent')
        return replace(QueryConfig(**found[0]['config']),unit_id=unit)
    def fresh(unit,mode,split,repeat):
        cfg=candidate(unit,mode,split)
        path=root/(unit+'.json')
        write_private_json(path,asdict(cfg))
        out=root/unit
        new_private_directory(out)
        before=before_query()
        command=[sys.executable,'-m','src.experiments.postgresql.query_cli','run','--worker','--config',str(path),
            '--manifest',str(manifests[split][0]),'--model',str(model),'--budget',str(ledger.path),
            '--budget-id',config['budget_id'],'--max-attempts',str(LIMIT),'--output',str(out),
            '--dsn-env',config['dsn_env'],'--pg-log',config['pg_log']]
        supervise(command,out,lambda:ledger.close_shared_unit(unit),query_timeout_s=120,
                  max_duration_s=query_time_budget(deadline,time.monotonic()),grace_s=5)
        directory=out/'unit'
        summary=json.loads((directory/'summary.json').read_text())
        record=read_run(dict(path=str(directory/'summary.json'),sha256=file_identity(directory/'summary.json')['sha256']),
                        'pg-daft-ray' if mode.startswith('semloom') else mode)
        accepted(unit,mode,split,repeat,cfg,directory,summary,before,record)
    def group(name,split,count):
        return PersistentMapGateway(candidate(name,'semloom-persistent',split),plan=plan,
            manifest_path=manifests[split][0],model_path=model,ledger=ledger,root=root/name,query_count=count)
    def persistent(service,unit,split,repeat):
        before=before_query()
        cfg=replace(service.config,unit_id=unit)
        summary=service.run_query(unit,dsn=os.environ[config['dsn_env']],pg_log=config['pg_log'])
        accepted(unit,'semloom-persistent',split,repeat,cfg,service.root/unit,summary,before)
    modes=report['modes']
    schedule=[('qualification',mode,-1) for mode in modes]
    for repeat in range(4):
        order=modes[repeat%3:]+modes[:repeat%3]
        schedule += [('evaluation',mode,repeat) for mode in order]
    write_private_json(root/'schedule.json',dict(queries=15,max_posts=LIMIT,orders=schedule,
        capacities={mode:64 for mode in modes},gateway_lifetimes=['per-query','caller-owned service'],
        selection='fixed engineering remeasurement on previously used input'))
    fresh('q00','pg-source-direct','qualification',-1)
    fresh('q01','semloom-fresh','qualification',-1)
    with group('g16','qualification',1) as service:
        persistent(service,'p00','qualification',-1)
    begin=time.monotonic()
    with group('g1024','evaluation',4) as service:
        report['persistent_gateway_startup_seconds']=time.monotonic()-begin
        for index,(split,mode,repeat) in enumerate(schedule[3:],3):
            unit='q'+str(index).zfill(2)
            if mode=='semloom-persistent':persistent(service,unit,split,repeat)
            else:fresh(unit,mode,split,repeat)
    if report['actual_posts']!=LIMIT or ledger.snapshot()['allocated_requests']!=LIMIT:
        raise ValueError('final request allocation differs')
    report['status']='passed'
except BaseException as error:
    report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
    raise
finally:
    try:
        services.close()
        if ray is not None and ray.is_initialized():
            until=time.monotonic()+30
            while ray.available_resources().get('CPU',0)<8:
                if time.monotonic()>until:raise RuntimeError('worker CPU slots remain held')
                time.sleep(.1)
            report['worker_cpu_slots_released']=True
    except BaseException as error:
        report['status']='failed'
        report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
    if ray is not None and ray.is_initialized():ray.shutdown()
    report['ray_driver_disconnected']=ray is None or not ray.is_initialized()
    report['elapsed_seconds']=time.monotonic()-started
    if ledger:report['budget']=ledger.snapshot()
    write_private_json(root/'summary.json',report)
raise SystemExit(0 if report['status']=='passed' else 1)
