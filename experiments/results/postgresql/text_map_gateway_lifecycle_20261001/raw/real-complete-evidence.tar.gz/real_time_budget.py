import math

def query_time_budget(deadline, now, max_query_seconds=120):
    remaining=deadline-now
    if not math.isfinite(remaining) or remaining<=0:
        raise TimeoutError('insufficient query and cleanup time')
    return min(max_query_seconds,remaining)
