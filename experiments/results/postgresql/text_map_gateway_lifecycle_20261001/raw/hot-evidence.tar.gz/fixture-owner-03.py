"""Restore parent permissions after one finite, fixture-only comparison."""
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time

root=Path('<task-root>')
report=dict(status='failed',fixture_limit=4112,real_model_posts=0,errors=[])
paths=[Path('/root'),Path('/root/autodl-tmp'),root]
acls={str(p):subprocess.check_output(['getfacl','-p',str(p)],text=True) for p in paths}
(root/'acl-before-03.json').write_text(json.dumps(acls,indent=2))
worker=None
try:
    if json.loads((root/'preflight.json').read_text())['status']!='ok':
        raise ValueError('target environment check did not pass')
    if (root/'driver-out-02/r/budget.sqlite').exists():
        raise RuntimeError('previous attempt has a ledger; inspect accounting before proceeding')
    with socket.socket() as sock: sock.bind(('127.0.0.1',55496))
    for path in paths:
        subprocess.run(['setfacl','-m','u:postgres:'+'--x',str(path)],check=True)
    for name in ('t3','c3','o3'):
        p=root/name;p.mkdir(mode=0o700)
        __import__('os').chown(p,__import__('pwd').getpwnam('postgres').pw_uid,__import__('pwd').getpwnam('postgres').pw_gid)
    env=dict(os.environ,TMPDIR=str(root/'t3'),XDG_CACHE_HOME=str(root/'c3'),PYTHONPATH=str(root/'s/code'),RAY_USAGE_STATS_ENABLED='0',DO_NOT_TRACK='true',
             DAFT_NUM_THREADS='8',CUDA_VISIBLE_DEVICES='',PYTHONUNBUFFERED='1')
    env.pop('RAY_ADDRESS',None)
    env.pop('PGOPTIONS',None)
    with (root/'fixture-worker-03.log').open('x') as log:
        worker=subprocess.Popen(['runuser','-u','postgres','--','/root/autodl-tmp/venvs/text-baselines/bin/python',
            str(root/'fixture-worker.py'),str(root/'o3/r'),str(root/'s'),'<reference-pg-prefix>'],
            stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        (root/'fixture-worker-pid-03.json').write_text(json.dumps(dict(pid=worker.pid,
            start_ticks=Path('/proc/'+str(worker.pid)+'/stat').read_text().split()[21])))
        try: worker.wait(timeout=780)
        except subprocess.TimeoutExpired:
            os.killpg(worker.pid,signal.SIGTERM)
            worker.wait(timeout=30)
            raise
        report['worker_exit']=worker.returncode
        if worker.returncode!=0: raise RuntimeError('fixture comparison failed; preserve its records')
        report['status']='passed'
except BaseException as error:
    report['errors'].append(dict(type=type(error).__name__,message=str(error)))
finally:
    for path,content in acls.items():
        subprocess.run(['setfacl','--restore=-'],input=content,text=True,check=True)
    report['parent_acls_restored']=all(subprocess.check_output(['getfacl','-p',path],text=True)==content for path,content in acls.items())
    report['gpu_compute_processes']=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
    (root/'owner-summary-03.json').write_text(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
