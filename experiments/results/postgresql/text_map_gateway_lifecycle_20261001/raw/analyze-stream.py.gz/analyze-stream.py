"""Offline accounting for the completed SemLoom shared-gateway measurements.

Read existing observations only. Remote actor timestamps were not retained;
only their durations are subtracted from enclosing gateway intervals.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import tarfile


def distribution(values):
    values=sorted(values)
    if not values:raise ValueError('empty timing population')
    def percentile(p):
        index=(len(values)-1)*p
        lo=int(index);hi=math.ceil(index)
        return values[lo]+(values[hi]-values[lo])*(index-lo)
    return dict(count=len(values),sum=sum(values),mean=statistics.mean(values),
                median=statistics.median(values),p95=percentile(.95),maximum=max(values),minimum=min(values))


def analyze(archive, repo):
    verification=json.loads((archive.parent/'real-complete-storage-verification.json').read_text())
    archive_sha=hashlib.sha256(archive.read_bytes()).hexdigest()
    if archive_sha!=verification['evidence_sha256']:raise ValueError('archive identity differs')
    with tarfile.open(archive) as tar:
        def raw(name):return tar.extractfile(name).read()
        def record(name):return json.loads(raw(name))
        source=record('source.json')
        for name in ('code/src/execution_provider/semantic_map.py','code/src/execution_provider/wire/map_codec.py',
                     'code/src/experiments/postgresql/map_bindings.py','code/src/execution_provider/adapters/ray_map_transport.py'):
            if hashlib.sha256((repo/name).read_bytes()).hexdigest()!=source[name]:
                raise ValueError('analysis source differs from executed version: '+name)
        sys.path.insert(0,str(repo/'code'))
        from src.execution_provider.semantic_map import canonical_messages
        from src.execution_provider.wire.map_codec import semantic_payload_digest
        from src.experiments.postgresql.map_bindings import parse_pg_bindings
        controller=record('real04/controller-summary.json')
        worker=record('real04/worker/summary.json')
        if controller['status']!='passed' or worker['status']!='passed':raise ValueError('matrix did not pass')
        selected=[r for r in worker['completed'] if r['mode']=='semloom-persistent' and r['repeat']>0]
        if Counter(r['repeat'] for r in selected)!=Counter((1,2,3)):raise ValueError('three matched repetitions required')
        output=dict(schema='semloom.shared_map_stream_accounting.v1',analysis_only=True,new_model_requests=0,
            source_archive=dict(path=archive.name,sha256=archive_sha),executed_revision='11714bdc55f6cae814f4b19a017b4cd5c8fe89bd',
            analyzed_units=[r['unit'] for r in selected],queries=[],limitations=[
                'per-row overlapping durations cannot be added to query wall time',
                'RPC guard is recorded before actor.execute.remote; it is not HTTP start',
                'remote worker duration includes payload extraction and the HTTP client',
                'RPC wait before worker entry and result return cannot be separated with retained records',
                'real-model PG node-return timestamps were not recorded',
                'server histograms identify the completed cohort; they are not GPU kernel durations',
                'batch materialization and durable POST accounting lack separate retained spans'])
        for item in sorted(selected,key=lambda r:r['repeat']):
            base='real04/worker/g1024/'+item['unit']
            summary=record(base+'/summary.json')
            execution=summary['execution']
            release,end=execution['t_release_ns'],execution['t_query_terminal_ns']
            if summary['status']!='passed' or execution['status']!='completed':raise ValueError('query did not complete')
            events=[json.loads(line) for line in raw(base+'/events.jsonl').splitlines()]
            results_bytes=raw(base+'/q0/results.jsonl')
            if hashlib.sha256(results_bytes).hexdigest()!=execution['results_sha256']:raise ValueError('result digest differs')
            results=[json.loads(line) for line in results_bytes.splitlines()]
            groups=defaultdict(list)
            for event in events:
                if type(event.get('monotonic_ns')) is not int:raise ValueError('missing event time')
                groups[event['event']].append(event)
            n=item['rows']
            if n!=1024 or len(results)!=n:raise ValueError('unexpected measured row count')
            def keyed(name,key):
                rows=groups[name]
                value={key(r):r for r in rows}
                if len(rows)!=n or set(value)!=set(range(n)):raise ValueError('missing or repeated '+name)
                return value
            tasks=keyed('core_map_task',lambda e:e['sequence'])
            submit=keyed('core_submitted',lambda e:e['key']['sequence'])
            http=keyed('core_ray_http_completed',lambda e:e['key']['sequence'])
            terminal=keyed('core_terminal',lambda e:e['key']['sequence'])
            semantic=keyed('core_map_completion',lambda e:e['sequence'])
            released=keyed('core_released',lambda e:e['key']['sequence'])
            session={e['key']['session_id'] for name in ('core_submitted','core_ray_http_completed','core_terminal','core_released') for e in groups[name]}
            if len(session)!=1:raise ValueError('mixed Core sessions')
            bindings=parse_pg_bindings(raw(base+'/q0-producer.log').decode().splitlines())
            by_sequence={b.sequence:b for b in bindings}
            if len(bindings)!=n or set(by_sequence)!=set(range(n)):raise ValueError('producer mapping differs')
            # The existing matrix checked SQL input order; verify it independently here.
            for k in range(n):
                binding=by_sequence[k]
                if (binding.row_id!=results[k]['row'][0] or binding.payload_digest!=tasks[k]['payload_digest']
                        or binding.payload_digest!=semantic[k]['payload_digest']):raise ValueError('row or payload mapping differs')
            by_digest={e['payload_digest']:k for k,e in tasks.items()}
            if len(by_digest)!=n:raise ValueError('guard timing needs unique payload identities in this cohort')
            guards={}
            for e in groups['request']:
                messages=e['body']['messages']
                digest=semantic_payload_digest(semantic_spec_sha256=summary['semantic_reference_sha256'],
                    input_value=messages[1]['content'],canonical_messages_utf8=canonical_messages(messages[0]['content'],messages[1]['content']))
                k=by_digest[digest]
                if k in guards:raise ValueError('repeated request guard')
                guards[k]=e
            if len(guards)!=n:raise ValueError('request guards incomplete')
            values=defaultdict(list)
            for k in range(n):
                a=tasks[k]['monotonic_ns'];b=submit[k]['monotonic_ns'];c=guards[k]['monotonic_ns']
                d=http[k]['monotonic_ns'];e=terminal[k]['monotonic_ns'];f=semantic[k]['monotonic_ns']
                g=results[k]['received_ns'];duration=http[k]['worker_elapsed_ns']
                if not release<=a<=b<=c<=d<=e<=f<=g<=end or type(duration) is not int or not 0<duration<=d-c:
                    raise ValueError('causal timing or enclosing worker interval differs')
                parts=(c-b,d-c-duration,duration)
                if sum(parts)!=d-b:raise ValueError('per-row timing partition does not close')
                for name,amount in [('accepted_to_core_submit',b-a),('core_to_rpc_guard',c-b),
                    ('rpc_outside_worker',d-c-duration),('worker_execution',duration),('core_to_ray_reply',d-b),
                    ('ray_reply_to_core_terminal',e-d),('core_credit_residence',e-b),
                    ('core_terminal_to_semantic_result',f-e),('semantic_result_to_client',g-f)]:values[name+'_ms'].append(amount/1e6)
            before,after=item['service_before'],item['service_after']
            server={}
            for name in ('e2e_request_latency_seconds','request_queue_time_seconds','request_inference_time_seconds',
                         'request_prefill_time_seconds','request_decode_time_seconds','time_to_first_token_seconds'):
                count=after['vllm:'+name+'_count']-before['vllm:'+name+'_count']
                total=after['vllm:'+name+'_sum']-before['vllm:'+name+'_sum']
                if count!=n or total<0:raise ValueError('server cohort counter differs: '+name)
                server[name]=dict(count=count,sum_seconds=total,mean_ms=1000*total/count)
            if not math.isclose(server['request_inference_time_seconds']['sum_seconds'],
                server['request_prefill_time_seconds']['sum_seconds']+server['request_decode_time_seconds']['sum_seconds'],abs_tol=1e-6):
                raise ValueError('inference and prefill/decode accounting differ')
            reserves={e['block_id']:e for e in groups['core_ray_block_reserved']}
            puts={e['block_id']:e for e in groups['core_ray_block_put']}
            if set(reserves)!=set(puts) or sum(e['rows'] for e in reserves.values())!=n:raise ValueError('payload block accounting differs')
            put_spans=[(puts[k]['monotonic_ns']-e['monotonic_ns'])/1e9 for k,e in reserves.items()]
            if any(value<0 for value in put_spans):raise ValueError('negative put span')
            first=min(e['monotonic_ns'] for e in submit.values());last=max(e['monotonic_ns'] for e in http.values())
            wall=(end-release)/1e9
            cuts=[(first-release)/1e9,(last-first)/1e9,(end-last)/1e9]
            if not math.isclose(sum(cuts),wall,abs_tol=1e-12):raise ValueError('query wall partition differs')
            credit_area=sum(values['core_credit_residence_ms'])/1000
            # Independent event sweep checks the interval sum against active-credit snapshots.
            active=0;previous=release;area_ns=0;full_ns=0;below_ns=0
            for event in events:
                if event['event'] not in ('core_submitted','core_terminal'):continue
                now=event['monotonic_ns']
                if now<previous:raise ValueError('credit events are unordered')
                area_ns+=active*(now-previous)
                if active==64:full_ns+=now-previous
                else:below_ns+=now-previous
                active+=1 if event['event']=='core_submitted' else -1
                if active!=event['usage']['active_requests'] or not 0<=active<=64:raise ValueError('credit snapshot differs')
                previous=now
            if active!=0 or not math.isclose(area_ns/1e9,credit_area,abs_tol=1e-7):raise ValueError('credit area differs')
            below_ns+=end-previous
            delivery=[]
            for k,row in enumerate(results):
                if not delivery or row['received_ns']-results[k-1]['received_ns']>10_000_000:
                    delivery.append(dict(first_sequence=k,last_sequence=k,rows=0,text_datarow_bytes=0,first_received_seconds=(row['received_ns']-release)/1e9))
                group=delivery[-1];group['last_sequence']=k;group['rows']+=1
                group['text_datarow_bytes']+=5+2+4*len(row['row'])+sum(len(str(v).encode('utf8')) for v in row['row'] if v is not None)
            output['queries'].append(dict(unit=item['unit'],repeat=item['repeat'],rows=n,
                input_sha256=item['input_sha256'],semantic_sha256=summary['semantic_reference_sha256'],
                jct_seconds=item['jct_seconds'],preparation_seconds=item['preparation_seconds'],stream_seconds=wall,
                wall_partition=dict(before_first_core_submit=cuts[0],parallel_pipeline=cuts[1],after_last_ray_reply=cuts[2]),
                firsts_seconds={name:(min(e['monotonic_ns'] for e in groups[name])-release)/1e9 for name in
                    ('core_map_task','core_submitted','request','core_ray_http_completed','core_terminal','core_map_completion')},
                first_client_seconds=(results[0]['received_ns']-release)/1e9,
                first_semantic_to_first_client_seconds=(results[0]['received_ns']-semantic[0]['monotonic_ns'])/1e9,
                last_semantic_to_eof_seconds=(end-max(e['monotonic_ns'] for e in semantic.values()))/1e9,
                row_intervals={key:distribution(value) for key,value in values.items()},server_cohort=server,
                credit=dict(peak=64,average=credit_area/wall,capacity=64,full_seconds=full_ns/1e9,below_full_seconds=below_ns/1e9,
                    mean_worker_duration_equivalent_concurrency=sum(values['worker_execution_ms'])/1000/wall,
                    mean_model_e2e_duration_equivalent_concurrency=server['e2e_request_latency_seconds']['sum_seconds']/wall),
                payload_blocks=dict(count=len(reserves),rows_mean=n/len(reserves),rows_histogram=dict(sorted(Counter(e['rows'] for e in reserves.values()).items())),
                    put_seconds=distribution(put_spans),peak_charged_bytes=max(e.get('object_bytes',0) for e in events),object_capacity_bytes=4194304),
                offer_status_counts={status:sum(e['status']==status for e in groups['core_offer']) for status in sorted({e['status'] for e in groups['core_offer']})},
                client_delivery_groups=delivery,validation=dict(independent_producer_binding_rows=n,unique_guard_payloads=n,
                    request_partition_rows=n,credit_area_independently_replayed=True,server_histogram_cohorts_checked=6)))
        return output


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--archive',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    value=analyze(args.archive,args.repo)
    args.output.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    for q in value['queries']:
        m=q['row_intervals']
        print(q['unit'],'stream_s',round(q['stream_seconds'],6),'core_to_guard_ms',round(m['core_to_rpc_guard_ms']['mean'],3),
            'worker_ms',round(m['worker_execution_ms']['mean'],3),'rpc_outside_worker_ms',round(m['rpc_outside_worker_ms']['mean'],3),
            'credit_average',round(q['credit']['average'],3))
    print('validated',sum(q['rows'] for q in value['queries']),'existing rows; new model requests: 0')
