"""Launch once after completed zero-model preparation; no reset or retry."""
import hashlib,json,os,socket,sqlite3,subprocess,time
from pathlib import Path
ROOT=Path(os.environ['MODELRUN_ROOT']);STATE=json.loads((ROOT/'state.json').read_text())
os.sched_setaffinity(0,set(STATE['driver_cpus']))
for name in ('model-start.json','model-matched','model-matched-launch.json','model-matched-watchdog.json','outer-model-matched-launch.json'):
 if (ROOT/name).exists():raise RuntimeError('matched window already started; retain clock and counts')
prepared=json.loads((ROOT/'prepare-result.json').read_text());assert prepared['passed']
identity_file=ROOT/'matched-harness-identity.json';identity_sha=hashlib.sha256(identity_file.read_bytes()).hexdigest()
assert identity_sha==prepared['controller_identity_sha256']
for name,digest in json.loads(identity_file.read_text())['root_files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
pre=json.loads((ROOT/'zero-model-preflight/result.json').read_text());assert pre['passed'] and pre['counts']['total']==0 and not pre['gpu_after']
for name,digest in {**json.loads((ROOT/'harness-identity.json').read_text())['files'],**json.loads((ROOT/'matched-harness-identity.json').read_text())['files']}.items():
 assert hashlib.sha256((ROOT/'validation'/name).read_bytes()).hexdigest()==digest
with sqlite3.connect('file:'+str(ROOT/'sends.sqlite')+'?mode=ro',uri=True) as db:assert db.execute('SELECT count(*) FROM sends').fetchone()[0]==0
gpu=subprocess.run(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_gpu_memory','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10);assert gpu.returncode==0 and not gpu.stdout.strip()
for item in json.loads((ROOT/'old-histories.json').read_text())['histories']:
 old=Path(item['root']);assert hashlib.sha256((old/'sends.sqlite').read_bytes()).hexdigest()==item['ledger_sha256']
 if item['clock_sha256']:assert hashlib.sha256((old/'model-start.json').read_bytes()).hexdigest()==item['clock_sha256']
old=json.loads((Path(STATE['original_model_root'])/'model-resume/result.json').read_text())
for endpoint in [*old['declarations']['single'],*old['declarations']['dual'],old['logical_router_endpoint']]:
 port=int(endpoint.split(':')[2].split('/')[0]);assert port!=46310 and not 46320<=port<=46499
 with socket.socket() as probe:probe.bind(('127.0.0.1',port))
env=dict(os.environ,MODELRUN_MATCHED_IDENTITY_SHA256=identity_sha,MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'validation')+os.pathsep+str(ROOT/'source/code'),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',RAY_USAGE_STATS_ENABLED='0',DO_NOT_TRACK='1',NO_PROXY='127.0.0.1,localhost,::1')
for name in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','RAY_ADDRESS','PYTHONHOME'):env.pop(name,None)
command=['taskset','-c',','.join(map(str,STATE['driver_cpus'])),STATE['driver_python'],'-B',str(ROOT/'validation/matched_runner.py')]
at=time.monotonic_ns();epoch=time.time();clock={'source_head':STATE['source_head'],'clock_scope':'outer controller launch; includes startup/queries/cleanup','started_epoch':epoch,'started_monotonic_ns':at,'deadline_epoch':epoch+2700,'deadline_monotonic_ns':at+2700_000_000_000,'original_window_clock_reset':False}
with (ROOT/'model-start.json').open('x') as output:output.write(json.dumps(clock,indent=2)+'\n')
with (ROOT/'outer-model-matched.stdout.log').open('xb') as stdout,(ROOT/'outer-model-matched.stderr.log').open('xb') as stderr:
 child=subprocess.Popen(command,cwd=ROOT/'source',env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 value={'pid':child.pid,'start_ticks':int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19]),'source_head':STATE['source_head'],'started_epoch':epoch,'clock':clock,'planned_logical':11520,'planned_posts':34560,'hard_logical':14336,'hard_posts':43008,'hard_seconds':2700}
 with (ROOT/'outer-model-matched-launch.json').open('x') as output:output.write(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
