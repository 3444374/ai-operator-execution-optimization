"""Exercise the six unchanged public CLI preflights, no model POST or GPU startup."""
import hashlib,json,os,subprocess,time
from pathlib import Path
from support import ROOT,STATE,SOURCE,ARMS,Registry,author_mode,base_env,config,save,gpu,source_identity,author_identity
from src.baselines.common.private_artifacts import write_private_json
from pre_send_ledger import counts,harness_identity
os.sched_setaffinity(0,set(STATE['driver_cpus']))
root=ROOT/'zero-model-preflight';root.mkdir(exist_ok=False)
assert not (ROOT/'model-start.json').exists() and not counts()['total'] and not gpu()
assert len(STATE['ray_parent'].encode())<=24
token='matched-preflight-'+__import__('uuid').uuid4().hex;os.environ['MODELRUN_SCOPE']=token
registry=Registry(token,STATE['driver_cpus']);result={'passed':False,'cases':[],'model_calls':0,'posts':0,'gpu':0}
try:
 source_identity();author_identity();harness_identity()
 for index,arm in enumerate(ARMS):
  case=root/str(index);case.mkdir();env=base_env();env.update(MODELRUN_QUERY_OBSERVER='0',SEMBENCH_OUTPUT=str(case/'output'))
  model=case/'model.json';write_private_json(model,dict(endpoint_url='http://127.0.0.1:9/v1/chat/completions',model_id=STATE['model_id'],timeout_ms=30000,bearer_token_env='SEMBENCH_LOCAL_TOKEN'));env['SEMBENCH_MODEL_CONFIG']=str(model)
  mode='ray' if arm==ARMS[5] else 'cpython' if arm==ARMS[4] else None
  with author_mode(mode,case,env,registry) as imlane:
   write_private_json(case/'config.json',config(arm,1,'performance',imlane))
   for action in ('--data-preflight','--preflight'):
    command=[STATE['driver_python'],'-B','-m','src.experiments.postgresql.sembench_query_cli','--config',str(case/'config.json'),action]
    with (case/(action[2:]+'.stdout.log')).open('w') as stdout,(case/(action[2:]+'.stderr.log')).open('w') as stderr:
     started=time.monotonic();child=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=stdout,stderr=stderr,start_new_session=True);registry.add(child)
     try:code=child.wait(timeout=120)
     except subprocess.TimeoutExpired:registry.terminate();raise
    row={'arm':arm,'action':action,'returncode':code,'seconds':time.monotonic()-started};result['cases'].append(row);save(root/'result.json',result)
    if code:raise RuntimeError('public zero-model preflight failed: '+arm+' '+action)
  if counts()['total'] or gpu():raise RuntimeError('preflight unexpectedly used model resources or sends')
 result['passed']=True
except BaseException as error:
 import traceback
 result.update(error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
finally:
 registry.observe();result['survivors_before_fallback']=registry.live()
 if result['survivors_before_fallback']:registry.terminate()
 result['cleanup']=registry.finish();result['counts']=counts();result['gpu_after']=gpu();result['source']=source_identity();result['author']=author_identity()
 result['passed']=result['passed'] and not result['survivors_before_fallback'] and not result['cleanup']['owned_survivors'] and not result['cleanup']['affinity_violations'] and not result['counts']['total'] and not result['gpu_after']
 save(root/'result.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['author','cleanup','traceback']}));raise SystemExit(not result['passed'])
