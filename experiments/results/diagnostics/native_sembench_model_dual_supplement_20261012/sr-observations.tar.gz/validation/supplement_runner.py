"""Outer watchdog for the separately clocked ten-minute S/R window."""
import hashlib,json,os,signal,subprocess,time,uuid
from pathlib import Path
from support import ROOT,STATE,Registry,save

os.sched_setaffinity(0,set(STATE['driver_cpus']))
if (ROOT/'model-supplement-launch.json').exists() or (ROOT/'model-supplement').exists():raise RuntimeError('supplement already exists; no repeat')
if not (ROOT/'model-start.json').exists():raise RuntimeError('independent window clock missing')
all_cpus=set(STATE['driver_cpus'])|set(sum(STATE['service_cpus'],[]));token='model-'+uuid.uuid4().hex
class OwnedRegistry(Registry):
 def observe(self):
  super().observe()
  import psutil
  for process in psutil.process_iter():
   if process.pid==os.getpid():continue
   try:
    if process.environ().get('MODELRUN_SCOPE')!=self.token:continue
    row=dict(pid=process.pid,born=process.create_time(),name=process.name(),affinity=process.cpu_affinity())
    with self.lock:self.known[(process.pid,process.create_time())]=row
    if not set(row['affinity'])<=self.cpus:self.violations.append(row)
   except psutil.Error:pass
registry=OwnedRegistry(token,all_cpus);started=time.monotonic();env=dict(os.environ,MODELRUN_SCOPE=token,MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0')
os.environ['MODELRUN_SCOPE']=token
identity=json.loads((ROOT/'supplement-harness-identity.json').read_text())
for name,digest in identity['files'].items():
 if hashlib.sha256((ROOT/'validation'/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('model validation helper identity changed')
command=[STATE['driver_python'],'-B',str(ROOT/'validation/supplement_supervisor.py')]
with (ROOT/'model-supplement-supervisor.stdout.log').open('wb') as out,(ROOT/'model-supplement-supervisor.stderr.log').open('wb') as err:
 child=subprocess.Popen(command,cwd=ROOT/'source',env=env,stdout=out,stderr=err,start_new_session=True);registry.add(child)
 save(ROOT/'model-supplement-launch.json',dict(pid=child.pid,start_ticks=int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19]),scope=token,source_head=STATE['source_head'],argv=command,started_monotonic=started,helpers=identity))
 stopped=False;forced=False;reason=None;latched_force=None;prestart_force=None
 while child.poll() is None:
  now=time.monotonic_ns();start=ROOT/'model-start.json';control=ROOT/'model-supplement-phase-control.json';stop_at=force_at=None
  if start.exists():
   overall=json.loads(start.read_text());stop_at=overall['deadline_monotonic_ns']-120_000_000_000;force_at=overall['deadline_monotonic_ns']-20_000_000_000
  elif time.monotonic()-started>=120:
   if prestart_force is None:prestart_force=now+30_000_000_000
   stop_at=now;force_at=prestart_force;reason='prestart preparation exceeded120s'
  if control.exists():
   phase=json.loads(control.read_text());phase_stop=phase['deadline_monotonic_ns']-int(phase['cleanup_reserve_seconds']*1e9);phase_force=max(phase_stop,phase['deadline_monotonic_ns']-20_000_000_000)
   stop_at=phase_stop if stop_at is None else min(stop_at,phase_stop);force_at=phase_force if force_at is None else min(force_at,phase_force)
   if stop_at==phase_stop:reason='supplement work deadline: '+phase['phase']
  if stop_at is not None and now>=stop_at and not stopped:
   child.send_signal(signal.SIGTERM);stopped=True;latched_force=force_at
  if stopped and latched_force is not None:force_at=latched_force if force_at is None else min(force_at,latched_force)
  if force_at is not None and now>=force_at:
   registry.terminate();forced=True;break
  time.sleep(.1)
 survivors_before_fallback=registry.live()
 if survivors_before_fallback:
  registry.terminate();forced=True;reason='owned survivors after supervisor exit'
cleanup=registry.finish();value=dict(returncode=child.poll(),stop_sent=stopped,forced_cleanup=forced,reason=reason if stopped or forced else None,survivors_before_fallback=survivors_before_fallback,cleanup=cleanup,elapsed_since_supervisor_launch=time.monotonic()-started)
value['passed']=child.poll()==0 and not stopped and not forced and not cleanup['owned_survivors'] and not cleanup['affinity_violations'];save(ROOT/'model-supplement-watchdog.json',value);print(json.dumps(value));raise SystemExit(not value['passed'])
