"""Observe both complete original queries through the pinned native SDK without I/O."""
from collections import Counter
import hashlib, json, os, socket, subprocess, sys, threading, time
from pathlib import Path
from unittest.mock import patch

ROOT=Path(os.environ['MODELRUN_ROOT'])
STATE=json.loads((ROOT/'state.json').read_text())
SOURCE=ROOT/'source'
sys.path.insert(0,str(SOURCE/'code'))
from src.baselines.common.redact import redact_text
from src.baselines.common.private_artifacts import write_private_json
from src.baselines.text.frameworks.prepared_map import NativeGraphOptions
from src.execution_provider.adapters.model_config import FixedModelConfig
from src.execution_provider.semantic_map import SemanticMapPlan
from src.experiments.fixed_request_routes import request_values_sha256
from src.experiments.postgresql.sembench_queries import MovieDataset,MovieQuery,MovieQueryResult
from src.experiments.postgresql.supplier_adapter_query import prepare_lotus_lm
from src.semantic_methods.lotus.sdk import prepare_call,validate_source

os.sched_setaffinity(0,set(STATE['driver_cpus']))
started=time.monotonic_ns()
out=ROOT/'request-preparation';out.mkdir(exist_ok=False)
report=dict(passed=False,models_started=0,model_calls=0,transport_posts=0,
            source_head=STATE['source_head'],native_mock_sends=0,cases=[])
def save(name,value):write_private_json(out/name,value)
def forbid(*_args,**_kwargs):raise RuntimeError('request preparation refuses socket I/O')
try:
    validate_source()
    identity=json.loads((ROOT/'source-identity.json').read_text())
    for name,digest in identity['files'].items():
        if hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('fixed preparation source changed: '+name)
    dataset=MovieDataset(Path(STATE['data']['checkout']),Path(STATE['data']['manifest']),Path(STATE['data']['csv']))
    report['data_preflight']=dataset.preflight()
    rows=dataset.load_rows()
    model=FixedModelConfig(endpoint_url='http://127.0.0.1:9/v1/chat/completions',
        model_id=STATE['model_id'],timeout_ms=30000,bearer_token='local-fixture')
    lm=prepare_lotus_lm(SemanticMapPlan('original SemBench Movie Filter',STATE['model_id'],8),
        model,NativeGraphOptions(concurrency=16,num_threads=8),
        Path(STATE['model_path'])/'tokenizer.json',sembench=True)
    import httpx,lotus
    lock=threading.Lock();prepared=[];actual=[]
    native=lm._process_uncached_messages
    def observe(data,kwargs,show_progress_bar,description):
        prepared.extend(json.loads(prepare_call(lm,item[0],kwargs).payload) for item in data)
        return native(data,kwargs,False,description)
    lm._process_uncached_messages=observe
    def send(client,request,*args,**kwargs):
        if request.method!='POST' or str(request.url)!=model.endpoint_url:
            raise RuntimeError('native SDK attempted an undeclared mock request')
        body=json.loads(request.content)
        with lock:
            actual.append(dict(values=body,body_sha256=hashlib.sha256(request.content).hexdigest(),
                               bytes=len(request.content)))
            if len(actual)>2000:raise RuntimeError('original query native mock count exceeded')
        response=dict(id='native-request-observation',object='chat.completion',created=1,model=body['model'],
            choices=[dict(index=0,message=dict(role='assistant',content='True'),finish_reason='stop')],
            usage=dict(prompt_tokens=1,completion_tokens=1,total_tokens=2))
        return httpx.Response(200,json=response,request=request)
    requests={};all_occurrences=[]
    for q,count in ((2,120),(1,2000)):
        case=out/('q'+str(q));case.mkdir()
        prepared.clear();actual.clear()
        result=MovieQueryResult(MovieQuery(dataset,q),rows,case)
        with patch.object(httpx.Client,'send',send),patch.object(socket.socket,'connect',forbid),\
             patch.object(socket.socket,'connect_ex',forbid),lotus.settings.context(lm=lm,enable_cache=False):
            list(result.execute())
        if len(prepared)!=count or len(actual)!=count:
            raise RuntimeError('complete original native query count differs')
        if Counter(request_values_sha256(v) for v in prepared)!=Counter(request_values_sha256(v['values']) for v in actual):
            raise RuntimeError('native actual SDK values differ from prepared calls')
        observed_ids=[v['row_id'] for v in result.model_rows]
        occurrences=[]
        for sequence,(row,value) in enumerate(zip(result.model_rows,prepared)):
            digest=request_values_sha256(value);requests[digest]=value
            occurrences.append(dict(sequence=sequence,row_id=row['row_id'],query_id=q,values_sha256=digest))
        all_occurrences.extend(occurrences)
        save('q'+str(q)+'-occurrences.json',occurrences)
        save('q'+str(q)+'-native-sdk.json',actual)
        report['cases'].append(dict(query_id=q,occurrences=count,unique_values=len({v['values_sha256'] for v in occurrences}),
            original_rows_in_order=observed_ids,original_method_preserved=True,
            full_native_sdk_request_values_match=True,synthetic_response_role='constant True; request qualification only, no real quality'))
        report['native_mock_sends']+=len(actual)
    save('full-request-values-private.json',requests)
    tokenizer_program='''
import hashlib,json,sys
from pathlib import Path
from collections.abc import Mapping
from transformers import AutoTokenizer
model=Path(sys.argv[1]);t=AutoTokenizer.from_pretrained(model,local_files_only=True)
values=json.loads(Path(sys.argv[2]).read_text());tokens={}
for digest,value in values.items():
    ids=t.apply_chat_template(value['messages'],tokenize=True,add_generation_prompt=True)
    if isinstance(ids,Mapping):ids=ids['input_ids']
    if ids and isinstance(ids[0],(list,tuple)):raise RuntimeError('unexpected batched tokenizer output')
    tokens[digest]=len(ids)
print(json.dumps(dict(tokenizer_class=type(t).__name__,tokenizer_json_sha256=hashlib.sha256((model/'tokenizer.json').read_bytes()).hexdigest(),prompt_tokens=tokens)))
'''
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
             MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0')
    r=subprocess.run([STATE['service_python'],'-B','-c',tokenizer_program,STATE['model_path'],
        str(out/'full-request-values-private.json')],capture_output=True,text=True,env=env,timeout=80)
    (out/'tokenizer.stderr.log').write_text(redact_text(r.stderr))
    if r.returncode:raise RuntimeError('existing real tokenizer failed')
    tokenizer=json.loads(r.stdout);save('real-tokenizer.json',tokenizer)
    weights=Counter(v['values_sha256'] for v in all_occurrences)
    totals={name:dict(requests=0,tokens=0,unique_values=0) for name in ('gpu0','gpu1')};assignments={}
    for digest,weight in sorted(weights.items(),key=lambda pair:(-pair[1],-tokenizer['prompt_tokens'][pair[0]],pair[0])):
        selected=min(totals,key=lambda name:(totals[name]['requests'],totals[name]['tokens'],name))
        assignments[digest]=selected;totals[selected]['requests']+=weight
        totals[selected]['tokens']+=weight*tokenizer['prompt_tokens'][digest];totals[selected]['unique_values']+=1
    route=dict(schema='semloom.original_movie_request_routes.v1',source_head=STATE['source_head'],
        query_occurrences={'1':2000,'2':120},combined_weights=dict(weights),dual_assignments=assignments,
        combined_replica_counts=totals,per_query={})
    for q in (2,1):
        selected=[v for v in all_occurrences if v['query_id']==q]
        route['per_query'][str(q)]=dict(request_weights=dict(Counter(v['values_sha256'] for v in selected)),
            replicas={name:dict(requests=sum(assignments[v['values_sha256']]==name for v in selected),
                tokens=sum(tokenizer['prompt_tokens'][v['values_sha256']] for v in selected if assignments[v['values_sha256']]==name)) for name in totals})
    save('route-manifest.json',route)
    report.update(context_limit=4096,generation_reserve=8,
        max_prompt_tokens=max(tokenizer['prompt_tokens'].values()),
        context_violations=[dict(values_sha256=digest,prompt_tokens=count) for digest,count in tokenizer['prompt_tokens'].items() if count+8>4096],
        dual_assignments=totals,unique_requests=len(requests),source_files_verified=len(identity['files']))
    if report['context_violations']:raise RuntimeError('complete original request exceeds fixed context4096; no truncation')
    report['passed']=True
except BaseException as error:
    import traceback
    report.update(error_type=type(error).__name__,error=redact_text(str(error)),traceback=redact_text(traceback.format_exc()))
finally:
    report['elapsed_seconds']=(time.monotonic_ns()-started)/1e9
    save('result.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ('cases','data_preflight','traceback')},indent=2))
raise SystemExit(not report['passed'])
