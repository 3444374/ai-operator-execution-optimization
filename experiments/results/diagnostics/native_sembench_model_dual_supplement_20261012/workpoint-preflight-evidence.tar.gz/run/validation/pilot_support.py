"""Thin Q2→Q1 config and CLI count substitution; native execution unchanged."""
from support import *

def config(arm,warmups,mode,imlane):
 if arm not in ARMS or warmups!=0 or mode!='performance' or imlane:raise ValueError('only frozen N/S A pilot config allowed')
 values=dict(schema='semloom.sembench_lotus_queries.v1',dataset=dict(checkout_env='SEMBENCH_CHECKOUT',manifest_env='SEMBENCH_MOVIE_MANIFEST',csv_env='SEMBENCH_MOVIE_CSV',manifest_content_digest=STATE['data']['manifest_content_digest']),arms=[arm],queries=[2,1],warmups=0,repeats=1,max_attempts=2120,model_config_env='SEMBENCH_MODEL_CONFIG',output_env='SEMBENCH_OUTPUT',native_options=dict(concurrency=16,num_threads=8,ray_actors=2,ray_async_batches_per_actor=2,ray_batch_rows=1,source_blocks=2),query_timeout_s=120,owner_timeout_s=480,tokenizer_env='SEMBENCH_TOKENIZER',lotus_observation_mode=mode)
 if arm=='lotus-method-semloom':values.update(ray_temp_parent_env='SEMBENCH_RAY_PARENT',max_held_tasks=64,physical=dict(address='resolved',workers=2,batch_rows=2,window_bytes=2097152,object_bytes=8388608,payload_backend='daft'))
 return values

def cli(arm,warmups,observation,out,env,deadline,registry):
 out.mkdir(parents=True,exist_ok=False);case=out.name;slot(case);env=dict(env,MODELRUN_SLOT=case,MODELRUN_QUERY_OBSERVER='1',MODELRUN_OBSERVER_DIR=str(out/'query-metrics'),SEMBENCH_OUTPUT=str(out/'output'))
 mode=None  # This frozen pilot contains only N/S, no author runtime.
 starts=time.monotonic_ns();before=counts()
 with author_mode(mode,out,env,registry) as imlane:
  args=config(arm,warmups,observation,imlane);write_private_json(out/'config.json',args)
  for action in ('--data-preflight','--preflight','--execute'):
   if time.monotonic()>=deadline:raise TimeoutError('remaining phase work time exhausted')
   argv=[STATE['driver_python'],'-B','-m','src.experiments.postgresql.sembench_query_cli','--config',str(out/'config.json'),action]
   with (out/(action[2:]+'.stdout.log')).open('w') as stdout,(out/(action[2:]+'.stderr.log')).open('w') as stderr:
    at=time.monotonic();child=subprocess.Popen(argv,cwd=SOURCE,env=env,stdout=stdout,stderr=stderr,start_new_session=True);registry.add(child)
    if action=='--execute':save(out/'driver-bootstrap.json',release_cli(child,deadline))
    while child.poll() is None:
     if time.monotonic()>=deadline:
      registry.terminate();raise TimeoutError('public CLI work deadline reached; owned resources stopped')
     time.sleep(.1)
   save(out/(action[2:]+'-command.json'),dict(argv=argv,returncode=child.returncode,seconds=time.monotonic()-at,source_head=STATE['source_head']))
   if child.returncode:raise RuntimeError('original public CLI '+action+' failed for '+arm)
  matrix=json.loads((out/'output/matrix.json').read_text())
  if matrix['status']!='passed' or [(c['query_id'],c['actual_posts']) for c in matrix['cells']]!=[(2,120),(1,2000)]:raise ValueError('full original Q2 then Q1 public query count/status failed')
 ended=time.monotonic_ns();facts=dict(arm=arm,warmups=warmups,observer_mode=observation,start_ns=starts,end_ns=ended,full_slot_seconds=(ended-starts)/1e9,matrix=matrix,count_before=before,count_after=counts())
 save(out/'slot-result.json',facts);return facts
