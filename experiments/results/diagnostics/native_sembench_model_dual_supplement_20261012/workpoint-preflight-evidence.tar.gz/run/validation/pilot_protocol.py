"""Four exact original Q1 requests through the selected actual executor; not a Q1 query."""
from collections import Counter
import json,os,sys,threading,time
from pathlib import Path
from pilot_support import ROOT,STATE,SOURCE,save,config
from pre_send_ledger import unit
from src.execution_provider.adapters.model_config import load_fixed_model_config
from src.execution_provider.adapters.ray_map_transport import RayMapConfig
from src.execution_provider.semantic_map import SemanticMapPlan
from src.baselines.text.frameworks.prepared_map import NativeGraphOptions
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.postgresql.persistent_native_adapter_query import PersistentAdapterGroup
from src.experiments.postgresql.sembench_queries import MovieDataset
from src.experiments.fixed_request_routes import request_values_sha256
from src.semantic_methods.lotus.batch import LotusBatchExecutor

arm=sys.argv[1];out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
unit('protocol-first-four-q1')
args=config(arm,0,'performance',{})
model=load_fixed_model_config(Path(os.environ['SEMBENCH_MODEL_CONFIG']))
dataset=MovieDataset(Path(STATE['data']['checkout']),Path(STATE['data']['manifest']),Path(STATE['data']['csv']))
ledger=CellBudgetLedger.create(out/'budget.sqlite',AttemptBudget('protocol-original-q1',4),deadline_utc=time.time()+300)
ledger.reserve_unit('protocol',4);claimed=ledger.claim_unit('protocol')
occurrences=json.loads((ROOT/'request-preparation/q1-occurrences.json').read_text())[:4]
values=json.loads((ROOT/'request-preparation/full-request-values-private.json').read_text())
expected=[values[v['values_sha256']] for v in occurrences]
responses=[];lock=threading.Lock();events=[]
def before(_route,body):
    import hashlib
    value=json.loads(body)
    if request_values_sha256(value) not in {v['values_sha256'] for v in occurrences}:raise RuntimeError('protocol request changed')
    claimed.reserve(hashlib.sha256(body).hexdigest())
def after(_route,body,response,status):
    with lock:
        responses.append(dict(request=json.loads(body),response=json.loads(response),http_status=status))
    if status!=200:raise RuntimeError('protocol non200 response; preserve and stop')
options=NativeGraphOptions(**args['native_options'])
is_s=arm=='lotus-method-semloom'
started=time.monotonic_ns();passed=False
try:
    with PersistentAdapterGroup((arm,),plan=SemanticMapPlan('original SemBench Movie Filter',STATE['model_id'],8),
        model=model,ledger=ledger,root=out/'owner',options=options,
        physical=RayMapConfig(**args['physical']) if is_s else None,
        ray_temp_root=Path(STATE['ray_parent'])/('p'+str(os.getpid())) if is_s else None,
        query_timeout_s=120,owner_timeout_s=480,max_held_tasks=64 if is_s else None,
        tokenizer_path=Path(STATE['model_path'])/'tokenizer.json',sembench_dataset=dataset,
        lotus_observation_mode='performance') as group:
        owner=group.owners[arm]
        with owner.query('protocol-first-four-q1',out,before,after,events.append):
            lm=owner.lotus_lm();data=[(value['messages'],None) for value in expected]
            if is_s:
                call=LotusBatchExecutor(owner.execution,owner.model,query_id='protocol-first-four-q1',
                    operator_id='lotus-filter',prevalidate_batch=True,retain_full_responses=False)
                outputs=call(lm,data,lm.kwargs,False,'protocol')
            else:outputs=lm._process_uncached_messages(data,lm.kwargs,False,'protocol')
            if len(outputs)!=4 or any(isinstance(value,Exception) for value in outputs):raise RuntimeError('protocol SDK response missing')
            choices=[lm._get_top_choice(value) for value in outputs]
        lifecycle=owner.lifecycle()
        if owner.execution is not None and (lifecycle['core_jobs'] or any(lifecycle['core_usage'].values())):
            raise RuntimeError('protocol retains Core responsibility')
        if len(responses)!=4 or Counter(request_values_sha256(v['request']) for v in responses)!=Counter(v['values_sha256'] for v in occurrences):
            raise RuntimeError('protocol exact original occurrence multiset differs')
        if any(v['response'].get('model')!=STATE['model_id'] or len(v['response'].get('choices',[]))!=1 for v in responses):
            raise RuntimeError('protocol full response identity differs')
        passed=True
finally:
    save(out/'protocols.json',responses);save(out/'events.json',events)
    save(out/'result.json',dict(passed=passed,arm=arm,logical_calls=claimed.attempts,
        original_occurrences=occurrences,query_scope='four fixed complete original Q1 requests; not full Q1',
        model_or_quality_claim=False,started_ns=started,ended_ns=time.monotonic_ns(),
        outputs=locals().get('choices'),lifecycle=locals().get('lifecycle'),budget=ledger.snapshot()))

