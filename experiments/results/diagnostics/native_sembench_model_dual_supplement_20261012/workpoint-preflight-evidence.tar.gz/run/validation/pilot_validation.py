"""Check each complete original unit before the CLI may begin its next query."""
from collections import Counter
import json
from pathlib import Path
from support import ROOT,STATE,save
from src.experiments.fixed_request_routes import request_values_sha256
from src.experiments.postgresql.sembench_queries import MovieDataset

def check_query(unit_root,arm,q):
    unit_root=Path(unit_root);count={1:2000,2:120}[q]
    manifest=json.loads((ROOT/'request-preparation/route-manifest.json').read_text())
    summary=json.loads((unit_root/'summary.json').read_text())
    protocols=[json.loads(v) for v in (unit_root/'protocols.jsonl').read_text().splitlines()]
    if Counter(request_values_sha256(v['request']) for v in protocols)!=Counter(manifest['per_query'][str(q)]['request_weights']):
        raise RuntimeError('complete original request multiset differs')
    dataset=MovieDataset(Path(STATE['data']['checkout']),Path(STATE['data']['manifest']),Path(STATE['data']['csv']))
    rows=dataset.load_rows();eligible=[r['row_id'] for r in rows if q==1 or r['movie_id']=='taken_3']
    calls=json.loads((unit_root/'calls.json').read_text());decisions=json.loads((unit_root/'filter-decisions.json').read_text())
    if len(calls)!=count or len({(c['row_id'],c['stage_id'],c['call_id']) for c in calls})!=count or {c['row_id'] for c in calls}!=set(eligible) or [d[0] for d in decisions]!=eligible:
        raise RuntimeError('original row associations/order/count differ')
    identity=summary['identity']
    if not identity['original_method_preserved'] or identity['original_query']['commit']!='c814e3807e72d4cf876b852b17e77f3cc94575c2' or identity['original_query']['query_id']!=q:
        raise RuntimeError('original method or query changed')
    if summary['native_http_audit']['readable_json_responses']!=count or any(v['http_status']!=200 for v in protocols):
        raise RuntimeError('full original responses incomplete or non200')
    audit=summary['quality']['classification_audit']
    if audit['invalid'] or audit['missing_rows'] or audit['evaluated_rows']!=count:raise RuntimeError('invalid/missing complete classifications')
    if q==2 and summary['quality']!=json.loads((ROOT/'reference-quality.json').read_text()):
        raise RuntimeError('Q2 quality differs from retained reference; preserve and stop')
    matched=None
    if arm=='lotus-method-semloom':
        baseline=ROOT/'model-matched/N-A/original-query-slot/output'/unit_root.name
        if (summary['quality']!=json.loads((baseline/'summary.json').read_text())['quality']
            or decisions!=json.loads((baseline/'filter-decisions.json').read_text())
            or json.loads((unit_root/'original-query-result.json').read_text())!=json.loads((baseline/'original-query-result.json').read_text())):
            raise RuntimeError('same-input N/S original decisions/result/quality differ; preserve and stop')
        matched=True
    save(unit_root/'model-method-check.json',dict(passed=True,original_requests=count,
        full_values=True,original_method=True,original_parser_evaluator=True,quality=summary['quality'],
        role='first small/cold query' if q==2 else 'first complete2000-row query',
        matched_N_S_quality=matched,no_cross_version_performance_comparison=True))
    return summary['quality']
