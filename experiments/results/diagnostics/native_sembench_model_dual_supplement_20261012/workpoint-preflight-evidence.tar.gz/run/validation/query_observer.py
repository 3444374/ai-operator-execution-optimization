"""Task arrival through usable EOF and nested ready time; observer cost remains charged."""
import json,os,time,urllib.request
from pathlib import Path
from pre_send_ledger import unit
def metrics():
    rows=[]
    for endpoint in json.loads(os.environ.get('MODELRUN_MODEL_ENDPOINTS','[]')):
        started=time.monotonic_ns()
        try:
            request=urllib.request.Request(endpoint.rsplit('/v1/chat/completions',1)[0]+'/metrics',headers={'Authorization':'Bearer ***'})
            with urllib.request.urlopen(request,timeout=3) as r:text=r.read().decode()
            rows.append(dict(endpoint=endpoint,started_ns=started,ended_ns=time.monotonic_ns(),text=text))
        except Exception as error:rows.append(dict(endpoint=endpoint,started_ns=started,error_type=type(error).__name__))
    return rows
def install():
    from src.experiments.postgresql.persistent_native_adapter_query import PersistentAdapterGroup
    original=PersistentAdapterGroup.run
    def observed(self,*args,**kwargs):
        identity=kwargs['unit_id'];arrival=time.monotonic_ns();unit(identity)
        record=dict(unit_id=identity,phase=kwargs.get('phase'),slot=os.environ.get('MODELRUN_SLOT'),
                    t_job_arrival_ns=arrival,before=metrics())
        failure=None
        try:
            value=original(self,*args,**kwargs)
            from pilot_validation import check_query
            check_query(kwargs['root'],args[0],kwargs['sembench_query'].query_id)
            execution=value['execution'];usable=execution['t_query_terminal_ns'];ready=execution['t_submit_ns']
            if not arrival<=value['query_preparation_started_ns']<=ready<=usable:
                raise RuntimeError('task/ready/usable timing is not nested')
            record.update(t_declared_ready_ns=ready,t_result_usable_ns=usable,
                task_completion_seconds=(usable-arrival)/1e9,ready_completion_seconds=(usable-ready)/1e9,
                public_full_query_seconds=value['full_query_seconds'],
                public_timing_preserved=True,definition='arrival before task-specific work and observations; usable consumer EOF; ready shares end',
                post_query_evaluation_seconds=value['stages']['evaluation_seconds'])
            return value
        except BaseException as error:
            failure=error;record['query_error_type']=type(error).__name__;raise
        finally:
            try:
                record.update(observer_end_ns=time.monotonic_ns(),after=metrics())
                target=Path(os.environ['MODELRUN_OBSERVER_DIR']);target.mkdir(exist_ok=True)
                (target/(identity+'-metrics.json')).write_text(json.dumps(record,indent=2)+'\n')
            except Exception as error:
                if failure is not None:failure.add_note('Query observation save failed: '+type(error).__name__)
                if failure is None:raise
    PersistentAdapterGroup.run=observed

