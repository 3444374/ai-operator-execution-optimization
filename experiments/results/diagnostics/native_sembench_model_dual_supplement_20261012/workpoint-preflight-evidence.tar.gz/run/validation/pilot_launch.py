"""Freeze one fresh600s pilot clock and detach the retained matched watchdog."""
import hashlib,json,os,socket,subprocess,time
from pathlib import Path
from support import ROOT,STATE,save,source_identity,gpu
from pre_send_ledger import initialize,counts

os.sched_setaffinity(0,set(STATE['driver_cpus']))
identity_bytes=(ROOT/'matched-harness-identity.json').read_bytes();identity=json.loads(identity_bytes)
for name,digest in identity['root_files'].items():
    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('frozen pilot file changed: '+name)
for name,digest in identity['files'].items():
    if hashlib.sha256((ROOT/'validation'/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('frozen pilot helper changed: '+name)
source_identity()
plan=json.loads((ROOT/'pilot-plan.json').read_text())
if (plan['max_seconds'],plan['max_logical'],plan['max_posts'])!=(600,4608,13824):raise RuntimeError('pilot limits changed')
if any((ROOT/name).exists() for name in ('model-start.json','model-matched-launch.json','model-matched','model-launch.json')):
    raise RuntimeError('pilot already attempted; no repeat or clock reset')
if (Path(STATE['host_scope'])/'.host-runner-scope/.runner-lease.json').exists() or gpu():raise RuntimeError('shared lease or GPU occupied before pilot')
for number in [plan['router_port'],*[int(v.split(':')[2].split('/')[0]) for v in plan['endpoints']]]:
    with socket.socket() as s:s.bind(('127.0.0.1',number))
initialize()
if counts()['total']:raise RuntimeError('fresh pilot has retained sends; no reset')
clock=dict(started_epoch=time.time(),started_monotonic_ns=time.monotonic_ns(),
           max_seconds=600,planned_logical=4248,max_logical=4608,max_posts=13824,source_head=STATE['source_head'])
clock['deadline_monotonic_ns']=clock['started_monotonic_ns']+600_000_000_000
with (ROOT/'model-start.json').open('x') as f:json.dump(clock,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
env=dict(os.environ,MODELRUN_MATCHED_IDENTITY_SHA256=hashlib.sha256(identity_bytes).hexdigest(),
    MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0',MODELRUN_ROLE='watchdog',
    CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',
    OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false',
    PYTHONPATH=str(ROOT/'validation')+os.pathsep+str(ROOT/'source/code'),PYTHONDONTWRITEBYTECODE='1',
    LITELLM_LOCAL_MODEL_COST_MAP='True',NO_PROXY='127.0.0.1,localhost,::1')
for name in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','RAY_ADDRESS','PYTHONHOME'):env.pop(name,None)
command=[STATE['driver_python'],'-B',str(ROOT/'validation/matched_runner.py')]
with (ROOT/'watchdog.stdout.log').open('x') as stdout,(ROOT/'watchdog.stderr.log').open('x') as stderr:
    child=subprocess.Popen(command,cwd=ROOT/'source',env=env,stdout=stdout,stderr=stderr,start_new_session=True)
ticks=int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19])
value=dict(pid=child.pid,start_ticks=ticks,argv=command,clock=clock,controller_identity_sha256=hashlib.sha256(identity_bytes).hexdigest())
save(ROOT/'model-launch.json',value);print(json.dumps(value))
