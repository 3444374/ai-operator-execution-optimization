"""Existing strict master only; install a disclosed fresh payload or launch once."""
import argparse,importlib.util,json,shlex,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('action',choices=('install','launch'));args=p.parse_args()
spec=importlib.util.spec_from_file_location('ssh',HERE.parent.parent/'matched-validation/ssh_existing.py')
ssh=importlib.util.module_from_spec(spec);spec.loader.exec_module(ssh)
check=subprocess.run([*ssh.SSH,'-O','check',ssh.TARGET],capture_output=True,text=True,timeout=10)
if check.returncode:raise RuntimeError('existing strict master unavailable; no fallback')
manifest=json.loads((HERE/'manifest.json').read_text());state=json.loads((HERE/'state.json').read_text());root=state['remote_root']
if args.action=='install':
    script=(HERE/'install_remote.py').read_text()
    prefix='import os;os.environ["FRESH_WINDOW_INSTALL_SPEC"]='+repr(json.dumps(manifest))+'\n'
    script=prefix+script;payload=(HERE/'wrappers.tar.gz').read_bytes();timeout=110
else:
    script='''
import json,os,subprocess,sys
from pathlib import Path
root=Path(%r);state=json.loads((root/'state.json').read_text())
env=dict(os.environ,MODELRUN_ROOT=str(root),MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0',CUDA_VISIBLE_DEVICES='',
    PYTHONPATH=str(root/'validation')+os.pathsep+str(root/'source/code'),PYTHONDONTWRITEBYTECODE='1')
command=['taskset','-c',','.join(map(str,state['driver_cpus'])),state['driver_python'],'-B',str(root/'validation/pilot_launch.py')]
r=subprocess.run(command,cwd=root/'source',env=env,capture_output=True,text=True,timeout=30)
sys.stdout.write(r.stdout);sys.stderr.write(r.stderr);raise SystemExit(r.returncode)
'''%root
    payload=b'';timeout=45
command=state['driver_python']+' -B -c '+shlex.quote(script)
r=subprocess.run([*ssh.SSH,ssh.TARGET,command],input=payload,capture_output=True,timeout=timeout)
(HERE/(args.action+'.stdout.log')).write_bytes(r.stdout);(HERE/(args.action+'.stderr.log')).write_bytes(r.stderr)
print('strict existing master verified;',args.action,'returncode',r.returncode)
if r.returncode:print(r.stderr.decode()[-2000:]);raise SystemExit(r.returncode)
value=json.loads(r.stdout)
if args.action=='launch':
    from datetime import datetime,timezone
    clock=value['clock'];print(json.dumps(dict(run_id=state['run_id'],pid=value['pid'],controller=value['controller_identity_sha256'],
        started_utc=datetime.fromtimestamp(clock['started_epoch'],timezone.utc).isoformat(),max_seconds=clock['max_seconds'],
        planned_logical=clock['planned_logical'],max_logical=clock['max_logical'],max_posts=clock['max_posts'])))
else:print(json.dumps({k:v for k,v in value.items() if k not in ('preparation_reused_from','source_reused_from')}))
