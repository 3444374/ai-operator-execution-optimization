"""Install one immutable fresh scope; copy verified old preparation read-only."""
import hashlib,io,json,os,shutil,subprocess,sys,tarfile,time
from pathlib import Path
import psutil
spec=json.loads(os.environ['FRESH_WINDOW_INSTALL_SPEC'])
raw=sys.stdin.buffer.read()
if hashlib.sha256(raw).hexdigest()!=spec['archive_sha256']:raise RuntimeError('fresh disclosed archive changed')
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
    members=t.getmembers()
    if not all(v.isfile() and not v.name.startswith('/') and '..' not in Path(v.name).parts for v in members):raise RuntimeError('unsafe payload')
    files={v.name:t.extractfile(v).read() for v in members}
if set(files)!=set(spec['files']):raise RuntimeError('undeclared fresh upload member')
for name,row in spec['files'].items():
    if len(files[name])!=row['bytes'] or hashlib.sha256(files[name]).hexdigest()!=row['sha256']:raise RuntimeError('fresh member changed')
state=json.loads(files['state.json']);gate=spec['install'];root=Path(gate['root']);old=Path(gate['previous']);source=Path(gate['source_root']);ray=Path(gate['ray_parent'])
if root!=Path(state['remote_root']) or root.parent!=Path('<private-path>') or not root.name.startswith('native-workpoint-20261013-'):
    raise RuntimeError('fresh target differs')
if root.exists() or ray.exists() or len(str(ray).encode())>24:raise RuntimeError('fresh scope or short directory already exists; no reuse')
if state['driver_cpus']!=list(range(72,82)) or state['service_cpus']!=[list(range(82,90)),list(range(90,98))]:raise RuntimeError('CPUs changed')
if hashlib.sha256((old/'matched-harness-identity.json').read_bytes()).hexdigest()!=gate['previous_controller_sha256']:raise RuntimeError('failed controller changed')
sys.path.insert(0,str(source/'code'))
from src.infrastructure.runner_lease import acquire_host_runner_lease
lease_path=Path(state['host_scope'])/'.host-runner-scope/.runner-lease.json'
if lease_path.exists():raise RuntimeError('common lease occupied; do not start')
gpu=subprocess.run(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_gpu_memory','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
if gpu.returncode or gpu.stdout.strip():raise RuntimeError('GPU occupied; do not start')
ours={(p.pid,p.create_time()) for p in [psutil.Process(),*psutil.Process().parents()]}
for p in psutil.process_iter():
    try:
        if (p.pid,p.create_time()) in ours or p.status()==psutil.STATUS_ZOMBIE:continue
        mask=p.cpu_affinity();env=p.environ();cmd=' '.join(p.cmdline())
        if env.get('MODELRUN_SCOPE') or any(v in cmd for v in ('vllm','raylet','gcs_server','pilot_supervisor','matched_supervisor','stage-tail','stage_tail','fixture','query-sharing')):
            raise RuntimeError('another experiment process is live; do not start')
        if len(mask)<=32 and set(range(72,98)).intersection(mask):raise RuntimeError('dedicated CPU occupation; do not start')
    except psutil.Error:pass
os.sched_setaffinity(0,set(state['driver_cpus']))
with acquire_host_runner_lease(Path(state['host_scope']),repository_commit=state['source_head']):
    for row in json.loads(files['old-histories.json'])['histories']:
        previous=Path(row['root'])
        if hashlib.sha256((previous/'sends.sqlite').read_bytes()).hexdigest()!=row['ledger_sha256']:raise RuntimeError('old history changed')
        if row['clock_sha256'] and hashlib.sha256((previous/'model-start.json').read_bytes()).hexdigest()!=row['clock_sha256']:raise RuntimeError('old clock changed')
    for name,row in gate['preparation_files'].items():
        r=(old/name).read_bytes()
        if len(r)!=row['bytes'] or hashlib.sha256(r).hexdigest()!=row['sha256']:raise RuntimeError('retained original preparation changed')
    source_identity=json.loads((old/'source-identity.json').read_text())
    if source_identity['source_head']!=state['source_head'] or len(source_identity['files'])!=407:raise RuntimeError('common source identity differs')
    for name,digest in source_identity['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:raise RuntimeError('unsafe copied source path')
        if hashlib.sha256((source/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('common source changed')
    stat=os.statvfs(root.parent)
    if stat.f_bavail*stat.f_frsize<4*1024**3:raise RuntimeError('data disk low before fresh install')
    root.mkdir(exist_ok=False)
    for name,r in files.items():
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(r)
    for name in gate['preparation_files']:
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/name,target)
    for name in source_identity['files']:
        target=root/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,target)
    identity=json.loads(files['matched-harness-identity.json'])
    for name,digest in identity['root_files'].items():
        if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('fresh copied/frozen root mismatch')
    for name,digest in identity['files'].items():
        if hashlib.sha256((root/'validation'/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('fresh helper mismatch')
    (root/'bootstrap').mkdir();ray.mkdir()
    env=dict(os.environ,MODELRUN_ROOT=str(root),MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0',CUDA_VISIBLE_DEVICES='',
        PYTHONPATH=str(root/'source/code'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',
        TOKENIZERS_PARALLELISM='false',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',
        LITELLM_LOCAL_MODEL_COST_MAP='True',NO_PROXY='127.0.0.1,localhost,::1')
    for name in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','RAY_ADDRESS','PYTHONHOME'):env.pop(name,None)
    command=[state['driver_python'],'-B',str(root/'source/code/scripts/environment/manage_environment.py'),'--env-file',state['runtime_env'],
        'check','--groups','core,text,semantic-benchmarks','--json-out',str(root/'runtime-preflight.json')]
    with (root/'runtime-preflight.stdout.log').open('x') as stdout,(root/'runtime-preflight.stderr.log').open('x') as stderr:
        r=subprocess.run(command,cwd=root/'source',env=env,stdout=stdout,stderr=stderr,timeout=90)
    if r.returncode:raise RuntimeError('fresh read-only runtime preflight failed; no models started')
    # Reuse the matched asset check's streaming hashes and exact serving-source
    # comparison, without rerunning request preparation or touching frozen files.
    def sha(path):
        h=hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
        return h.hexdigest()
    model=Path(state['model_path'])
    model_files={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(model.iterdir())
        if p.is_file() and (p.suffix in ('.json','.safetensors') or p.name in ('merges.txt','vocab.json'))}
    fingerprint=hashlib.sha256(json.dumps(model_files,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    retained_assets=json.loads((root/'asset-check.json').read_text())
    if fingerprint!=state['model_files_fingerprint'] or model_files!=retained_assets['model_file_sha256']:raise RuntimeError('fixed cached model changed')
    program="import importlib.metadata,importlib.util,json,pathlib,hashlib; names=['vllm','torch','transformers']; package=pathlib.Path(importlib.util.find_spec('vllm').origin).parent; files={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.rglob('*.py'))};print(json.dumps(dict(versions={n:importlib.metadata.version(n) for n in names},vllm_source_files=files)))"
    r=subprocess.run([state['service_python'],'-B','-c',program],capture_output=True,text=True,env=env,timeout=30)
    if r.returncode or json.loads(r.stdout)!=retained_assets['serving']:raise RuntimeError('fixed serving versions/source changed')
    program="import importlib.metadata,json; print(json.dumps({n:importlib.metadata.version(n) for n in ['lotus-ai','litellm','openai','pandas','ray','daft','aiohttp','httpx','tokenizers']}))"
    r=subprocess.run([state['driver_python'],'-B','-c',program],capture_output=True,text=True,env=env,timeout=20)
    expected={'lotus-ai':'1.2.4','litellm':'1.95.0','openai':'2.50.0','pandas':'2.3.3','ray':'2.56.1','daft':'0.7.21','aiohttp':'3.14.3','httpx':'0.28.1','tokenizers':'0.22.2'}
    if r.returncode or json.loads(r.stdout)!=expected:raise RuntimeError('fixed driver versions changed')
    (root/'fresh-asset-verification.json').write_text(json.dumps(dict(passed=True,checked_epoch=time.time(),
        model_files_fingerprint=fingerprint,model_sha256_unchanged=True,serving_versions_and_all_python_source_unchanged=True,
        driver_versions=expected,runtime_preflight_passed=True,models=0,posts=0),indent=2)+'\n')
    value=dict(run_id=state['run_id'],installed_epoch=time.time(),payload_files=len(files),payload_bytes=sum(map(len,files.values())),
        payload_sha256=hashlib.sha256(raw).hexdigest(),controller_sha256=gate['controller_sha256'],source_files=407,
        preparation_reused_from=str(old),source_reused_from=str(source),old_histories_guarded=5,helpers_byte_identical=True,
        new_ledger_exists=(root/'sends.sqlite').exists(),new_clock_exists=(root/'model-start.json').exists(),models=0,posts=0,
        preflight_passed=True,disk_free_bytes=stat.f_bavail*stat.f_frsize)
    (root/'wrappers-installed.json').write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps(value))
