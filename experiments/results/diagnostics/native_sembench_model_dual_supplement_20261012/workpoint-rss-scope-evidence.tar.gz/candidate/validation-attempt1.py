"""Offline behavior checks of the candidate function, including retained samples."""
import ast,json,tarfile
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent
original=ast.parse((HERE/'payload/validation/pilot_supervisor.py').read_text())
candidate=ast.parse((HERE/'rss-candidate/pilot_supervisor.py').read_text())
before={n.name:ast.dump(n,include_attributes=False) for n in original.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
after={n.name:ast.dump(n,include_attributes=False) for n in candidate.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert {k for k in before if before[k]!=after[k]}=={'sample_resources'}
assert set(after)-set(before)=={'classify_resource_members'}
node=next(n for n in candidate.body if isinstance(n,ast.FunctionDef) and n.name=='classify_resource_members')
class Missing(Exception):pass
class Denied(Exception):pass
data={}
class Process:
    def __init__(self,pid):
        if pid not in data:raise Missing()
        self.pid=pid;self.row=data[pid]
    def create_time(self):return self.row['born']
    def cpu_affinity(self):return self.row['cpus']
    def children(self,recursive=False):return [Process(v) for v in self.row.get('children',[])]
    def memory_info(self):
        if self.row.get('denied'):raise Denied()
        return SimpleNamespace(rss=self.row['rss'])
    def environ(self):raise AssertionError('candidate must not use environment labels')
state=json.loads((HERE/'state.json').read_text())
namespace={'psutil':SimpleNamespace(Process=Process,NoSuchProcess=Missing),'STATE':state}
exec(compile(ast.Module(body=[node],type_ignores=[]),'<candidate-resource-classifier>','exec'),namespace)
classify=namespace['classify_resource_members']
driver=state['driver_cpus'];service=state['service_cpus'][0];seen={};checks=[]
def row(pid,born,rss,cpus,**kwargs):data[pid]=dict(born=born,rss=rss,cpus=cpus,**kwargs)
def entries(*pids):return [dict(pid=pid,born=data[pid]['born']) for pid in pids]
def throws(expected,call):
    try:call()
    except expected:return
    raise AssertionError('required failure was not raised')
row(10,1,40,service,children=[20]);row(20,2,9*1024**3,service);row(30,3,100,driver)
clients,services=classify(entries(10,20,30),{10:1},seen)
assert [v['pid'] for v in clients]==[30] and {v['pid'] for v in services}=={10,20}
checks.append('large engine without environment role excluded by verified ancestry')
del data[10]
clients,services=classify(entries(20,30),{10:1},seen)
assert [v['pid'] for v in services]==[20]
checks.append('verified engine remains service after API exit/reparenting')
row(20,5,123,driver)
clients,services=classify(entries(20),{10:1},seen)
assert clients[0]['rss_bytes']==123 and not services
checks.append('reused engine PID with different birth is charged as a new client')
data.clear();row(10,99,40,service,children=[20]);row(20,2,100,service)
throws(RuntimeError,lambda:classify(entries(20),{10:1},{}))
checks.append('reused API PID cannot establish service ancestry')
data.clear();row(30,3,8*1024**3+1,driver)
clients,services=classify(entries(30),{},{});assert sum(v['rss_bytes'] for v in clients)>8*1024**3
checks.append('genuine over-limit client remains charged without environment reliance')
data.clear();row(40,4,100,service)
throws(RuntimeError,lambda:classify(entries(40),{},{}))
checks.append('unknown process outside client CPUs fails instead of silently excluding RSS')
data.clear();row(10,1,40,service,children=[20]);row(20,2,100,driver)
throws(RuntimeError,lambda:classify(entries(10,20),{10:1},{}))
checks.append('service descendant CPU mismatch fails')
data.clear();row(30,3,100,driver,denied=True)
throws(Denied,lambda:classify(entries(30),{},{}))
checks.append('unreadable RSS fails rather than producing a partial zero')
data.clear();assert classify([dict(pid=50,born=5)],{}, {})==([],[])
checks.append('already-exited process contributes no live RSS')
with tarfile.open(HERE/'closed-run-private.tar.gz') as t:
    samples=[json.loads(v) for v in t.extractfile('model-matched/client-server-timeseries.jsonl').read().decode().splitlines()]
proof=json.loads((HERE/'release-private.json').read_text())['proof'];known={v['pid']:v for v in proof['result']['cleanup']['processes']}
diagnosis=json.loads((HERE/'resource-scope-diagnosis.json').read_text())
engines=diagnosis['service_engines'];results=[]
for sample in samples:
    data.clear();roots={}
    for api,engine in zip(proof['result']['services'],engines):
        pid=api['api_pid'];born=known[pid]['born'];roots[pid]=born
        row(pid,born,0,api['cpu_affinity'],children=[engine['pid']])
        row(engine['pid'],engine['born'],0,engine['affinity'])
    for value in sample['clients']:
        row(value['pid'],value['born'],value['rss_bytes'],known.get(value['pid'],{}).get('affinity',driver))
    clients,service_rows=classify(sample['clients'],roots,{})
    corrected=sum(v['rss_bytes'] for v in clients)+sample['supervisor_rss_bytes']
    expected=next(v['corrected_diagnostic_sum_bytes'] for v in diagnosis['per_sample_diagnostic'] if v['at_ns']==sample['at_ns'])
    assert corrected==expected
    results.append(dict(at_ns=sample['at_ns'],corrected_bytes=corrected,excluded_service_engine_bytes=sum(v['rss_bytes'] for v in service_rows)))
body=(HERE/'rss-candidate/pilot_supervisor.py').read_text()
assert "if row['client_rss_bytes']>8*1024**3:" in body
assert "row['supervisor_rss_bytes']" in body and "role='watchdog'" in body
result=dict(passed=True,behavior_checks=checks,retained_sample_replays=len(results),
    max_diagnostic_client_bytes=max(v['corrected_bytes'] for v in results),
    unchanged_functions=len(before)-1,hard_rss_bytes=8*1024**3,original_stop_preserved=True,
    scope='offline function-level process-identity cases plus retrospective retained-sample replay; no OS processes, SDK, fixture or model',
    model_window_executed=False,network_posts=0)
(HERE/'rss-candidate/validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
