"""Offline behavior checks of the candidate function, including retained samples."""
import ast,json,tarfile,threading
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent
original=ast.parse((HERE/'payload/validation/pilot_supervisor.py').read_text())
candidate=ast.parse((HERE/'rss-candidate/pilot_supervisor.py').read_text())
before={n.name:ast.dump(n,include_attributes=False) for n in original.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
after={n.name:ast.dump(n,include_attributes=False) for n in candidate.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert {k for k in before if before[k]!=after[k]}=={'sample_resources'}
assert set(after)-set(before)=={'classify_resource_members'}
node=next(n for n in candidate.body if isinstance(n,ast.FunctionDef) and n.name=='classify_resource_members')
class Missing(Exception):pass
class Denied(Exception):pass
data={}
class Process:
    def __init__(self,pid):
        if pid not in data:raise Missing()
        self.pid=pid;self.row=data[pid]
    def create_time(self):return self.row['born']
    def cpu_affinity(self):return self.row['cpus']
    def children(self,recursive=False):return [Process(v) for v in self.row.get('children',[])]
    def memory_info(self):
        if self.row.get('denied'):raise Denied()
        return SimpleNamespace(rss=self.row['rss'])
    def environ(self):raise AssertionError('candidate must not use environment labels')
state=json.loads((HERE/'state.json').read_text())
namespace={'psutil':SimpleNamespace(Process=Process,NoSuchProcess=Missing),'STATE':state}
exec(compile(ast.Module(body=[node],type_ignores=[]),'<candidate-resource-classifier>','exec'),namespace)
classify=namespace['classify_resource_members']
driver=state['driver_cpus'];service=state['service_cpus'][0];seen={};checks=[]
def row(pid,born,rss,cpus,**kwargs):data[pid]=dict(born=born,rss=rss,cpus=cpus,**kwargs)
def entries(*pids):return [dict(pid=pid,born=data[pid]['born']) for pid in pids]
def throws(expected,call):
    try:call()
    except expected:return
    raise AssertionError('required failure was not raised')
row(10,1,40,service,children=[20]);row(20,2,9*1024**3,service);row(30,3,100,driver)
clients,services=classify(entries(10,20,30),{10:1},seen)
assert [v['pid'] for v in clients]==[30] and {v['pid'] for v in services}=={10,20}
checks.append('large engine without environment role excluded by verified ancestry')
del data[10]
clients,services=classify(entries(20,30),{10:1},seen)
assert [v['pid'] for v in services]==[20]
checks.append('verified engine remains service after API exit/reparenting')
row(20,5,123,driver)
clients,services=classify(entries(20),{10:1},seen)
assert clients[0]['rss_bytes']==123 and not services
checks.append('reused engine PID with different birth is charged as a new client')
data.clear();row(10,99,40,service,children=[20]);row(20,2,100,service)
throws(RuntimeError,lambda:classify(entries(20),{10:1},{}))
checks.append('reused API PID cannot establish service ancestry')
data.clear();row(30,3,8*1024**3+1,driver)
clients,services=classify(entries(30),{},{});assert sum(v['rss_bytes'] for v in clients)>8*1024**3
checks.append('genuine over-limit client remains charged without environment reliance')
data.clear();row(40,4,100,service)
throws(RuntimeError,lambda:classify(entries(40),{},{}))
checks.append('unknown process outside client CPUs fails instead of silently excluding RSS')
data.clear();row(10,1,40,service,children=[20]);row(20,2,100,driver)
throws(RuntimeError,lambda:classify(entries(10,20),{10:1},{}))
checks.append('service descendant CPU mismatch fails')
data.clear();row(30,3,100,driver,denied=True)
throws(Denied,lambda:classify(entries(30),{},{}))
checks.append('unreadable RSS fails rather than producing a partial zero')
data.clear();assert classify([dict(pid=50,born=5)],{}, {})==([],[])
checks.append('already-exited process contributes no live RSS')
sample=next(n for n in candidate.body if isinstance(n,ast.FunctionDef) and n.name=='sample_resources')
sample_source=ast.get_source_segment((HERE/'rss-candidate/pilot_supervisor.py').read_text(),sample)
assert 'registry.live()' not in sample_source and 'registry.known.values()' in sample_source
parent_loop=next(n for n in ast.walk(sample) if isinstance(n,ast.For) and isinstance(n.iter,ast.Call)
    and isinstance(n.iter.func,ast.Attribute) and n.iter.func.attr=='parents')
class FakePath:
    def __init__(self,*parts):self.parts=parts
    def __truediv__(self,name):return FakePath(name)
    def exists(self):return True
    def read_text(self):
        if self.parts[-1]=='model-launch.json':return json.dumps(dict(pid=30,start_ticks=42))
        return '1 (fake) S '+'0 '*18+'42'
data.clear();row(30,3,100,driver,denied=True)
parent=Process(30)
parent_namespace=dict(namespace,json=json,Path=FakePath,ROOT=FakePath(),row={'client_rss_bytes':0,'clients':[]},
    psutil=SimpleNamespace(Process=lambda:SimpleNamespace(parents=lambda:[parent]),NoSuchProcess=Missing))
throws(Denied,lambda:exec(compile(ast.Module(body=[parent_loop],type_ignores=[]),'<watchdog-sampling>','exec'),parent_namespace))
checks.append('watchdog AccessDenied propagates to fail-closed resource observer')
original_lifecycle=ast.parse((HERE/'payload/validation/matched_lifecycle.py').read_text())
candidate_lifecycle=ast.parse((HERE/'rss-candidate/matched_lifecycle.py').read_text())
old_functions={n.name:ast.dump(n,include_attributes=False) for n in original_lifecycle.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_functions={n.name:ast.dump(n,include_attributes=False) for n in candidate_lifecycle.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert {n for n in old_functions if old_functions[n]!=new_functions[n]}=={'start_services'}
start=next(n for n in candidate_lifecycle.body if isinstance(n,ast.FunctionDef) and n.name=='start_services')
critical=next(n for n in ast.walk(start) if isinstance(n,ast.With) and isinstance(n.items[0].context_expr,ast.Name)
    and n.items[0].context_expr.id=='SERVICE_PUBLISH_LOCK')
snapshot=next(n for n in ast.walk(sample) if isinstance(n,ast.With) and isinstance(n.items[0].context_expr,ast.Name)
    and n.items[0].context_expr.id=='SERVICE_PUBLISH_LOCK')
assert isinstance(snapshot.body[0],ast.With)
lock=threading.Lock();entered=threading.Event();allow=threading.Event();sampled=threading.Event();roots={};published=[];observed=[];thread_errors=[]
class FakeRegistry:
    def add(self,child):
        entered.set()
        if not allow.wait(1):raise AssertionError('test registration deadline')
        roots[child.pid]=123.0
context=dict(SERVICE_PUBLISH_LOCK=lock,subprocess=SimpleNamespace(STDOUT=None,Popen=lambda *a,**k:SimpleNamespace(pid=10)),
    command=[],SOURCE=None,env={},writer=None,registry=FakeRegistry(),Path=FakePath,phase='N-A',index=0,
    endpoint='http://127.0.0.1:1',cpu=service,at=1,records=[],result={'services':[]},services=published,write=lambda:None,
    time=SimpleNamespace(monotonic=lambda:0,monotonic_ns=lambda:1),work_until=100,ROOT=FakePath())
def publish():
    try:exec(compile(ast.Module(body=[critical],type_ignores=[]),'<candidate-publish>','exec'),context)
    except BaseException as error:thread_errors.append(str(error))
def observe():
    with lock:observed.append({p.pid:roots.get(p.pid) for p in published})
    sampled.set()
publisher=threading.Thread(target=publish);publisher.start();assert entered.wait(1)
observer=threading.Thread(target=observe);observer.start();assert not sampled.wait(.02)
allow.set();publisher.join(1);observer.join(1)
assert not publisher.is_alive() and not observer.is_alive() and not thread_errors
assert observed==[{10:123.0}]
checks.append('sampling cannot observe a spawned service before PID/birth registration completes')
lock.acquire();reached=threading.Event();attempts=[];deadline_errors=[];clock={'now':99}
expired=dict(context,services=[],records=[],result={'services':[]},
    time=SimpleNamespace(monotonic=lambda:clock['now'],monotonic_ns=lambda:1),
    subprocess=SimpleNamespace(STDOUT=None,Popen=lambda *a,**k:attempts.append(True)))
def expired_publish():
    reached.set()
    try:exec(compile(ast.Module(body=[critical],type_ignores=[]),'<candidate-expired-publish>','exec'),expired)
    except TimeoutError:deadline_errors.append(True)
waiter=threading.Thread(target=expired_publish);waiter.start();assert reached.wait(1)
clock['now']=101;lock.release();waiter.join(1)
assert not waiter.is_alive() and deadline_errors==[True] and not attempts and not expired['services']
checks.append('startup/work deadline reached while waiting on publication lock prevents new API spawn')
with tarfile.open(HERE/'closed-run-private.tar.gz') as t:
    samples=[json.loads(v) for v in t.extractfile('model-matched/client-server-timeseries.jsonl').read().decode().splitlines()]
proof=json.loads((HERE/'release-private.json').read_text())['proof'];known={v['pid']:v for v in proof['result']['cleanup']['processes']}
diagnosis=json.loads((HERE/'resource-scope-diagnosis.json').read_text())
engines=diagnosis['service_engines'];results=[];engine_pids={v['pid'] for v in engines};api_pids={v['api_pid'] for v in proof['result']['services']}
for sample in samples:
    data.clear();roots={}
    for api,engine in zip(proof['result']['services'],engines):
        pid=api['api_pid'];born=known[pid]['born'];roots[pid]=born
        row(pid,born,0,api['cpu_affinity'],children=[engine['pid']])
        row(engine['pid'],engine['born'],0,engine['affinity'])
    for value in sample['clients']:
        children=data.get(value['pid'],{}).get('children',[])
        row(value['pid'],value['born'],value['rss_bytes'],known.get(value['pid'],{}).get('affinity',driver),children=children)
    verified=[v for v in sample['clients'] if v['pid'] in engine_pids|api_pids or set(data[v['pid']]['cpus'])<=set(driver)]
    unknown=[v for v in sample['clients'] if v not in verified]
    clients,service_rows=classify(verified,roots,{})
    expected_engine_bytes=sum(v['rss_bytes'] for v in sample['clients'] if v['pid'] in engine_pids)
    excluded_engine_bytes=sum(v['rss_bytes'] for v in service_rows if v['pid'] in engine_pids)
    assert excluded_engine_bytes==expected_engine_bytes
    assert not engine_pids.intersection(v['pid'] for v in clients)
    if unknown:throws(RuntimeError,lambda:classify(unknown,roots,{}))
    results.append(dict(at_ns=sample['at_ns'],excluded_service_engine_bytes=excluded_engine_bytes,
        withheld_unknown_service_affinity_rows=len(unknown)))
body=(HERE/'rss-candidate/pilot_supervisor.py').read_text()
assert "if row['client_rss_bytes']>8*1024**3:" in body
assert "row['supervisor_rss_bytes']" in body and "role='watchdog'" in body
result=dict(passed=True,behavior_checks=checks,retained_sample_replays=len(results),
    replay_scope='logged API/EngineCore identities and driver-affinity members only; other service-affinity members lack captured ancestry and remain required failures',
    replay_frames_with_unknown_service_members=sum(bool(v['withheld_unknown_service_affinity_rows']) for v in results),
    unchanged_functions=len(before)-1,hard_rss_bytes=8*1024**3,original_stop_preserved=True,
    lifecycle_changed_functions=['start_services'],shared_publication_lock_verified=True,known_member_snapshot_verified=True,
    scope='offline function-level process-identity cases plus targeted retained-sample replay; no OS processes, SDK, fixture or model',
    model_window_executed=False,network_posts=0)
(HERE/'rss-candidate/validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
