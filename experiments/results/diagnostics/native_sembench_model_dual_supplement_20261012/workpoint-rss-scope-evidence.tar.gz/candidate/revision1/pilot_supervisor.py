"""Bounded dual N/S A original-query pilot over the retained matched lifecycle."""
from collections import Counter
import hashlib,json,os,signal,sqlite3,subprocess,threading,time,urllib.request,uuid
from pathlib import Path
import psutil
from pilot_support import ROOT,STATE,SOURCE,ARMS,Registry,base_env,cli,save,source_identity,gpu
from pre_send_ledger import activate,counts,install,slot
from src.baselines.common.redact import redact_text
from src.experiments.fixed_request_routes import FixedRequestRoutes,request_values_sha256
from src.observability.request_gateway import GatewayRoute,ObservationGateway
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.experiments.postgresql.sembench_queries import MovieDataset
import matched_lifecycle as lifecycle

os.sched_setaffinity(0,set(STATE['driver_cpus']))
FIRST_CLOCK_BYTES=(ROOT/'model-start.json').read_bytes();CLOCK=json.loads(FIRST_CLOCK_BYTES)
OLD_ROOT=Path(STATE['original_model_root']);OLD_FIRST_CLOCK_BYTES=(OLD_ROOT/'model-start.json').read_bytes()
HISTORIES=json.loads((ROOT/'old-histories.json').read_text())['histories']
PLAN=json.loads((ROOT/'pilot-plan.json').read_text())
IDENTITY_BYTES=(ROOT/'matched-harness-identity.json').read_bytes()
def check_identity():
    if hashlib.sha256(IDENTITY_BYTES).hexdigest()!=os.environ['MODELRUN_MATCHED_IDENTITY_SHA256'] or (ROOT/'matched-harness-identity.json').read_bytes()!=IDENTITY_BYTES:
        raise RuntimeError('frozen pilot identity changed')
    identity=json.loads(IDENTITY_BYTES)
    for name,digest in identity['root_files'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('pilot fixed file changed: '+name)
    for name,digest in identity['files'].items():
        if hashlib.sha256((ROOT/'validation'/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('pilot helper changed: '+name)
    for row in HISTORIES:
        old=Path(row['root'])
        if hashlib.sha256((old/'sends.sqlite').read_bytes()).hexdigest()!=row['ledger_sha256']:raise RuntimeError('old send history changed')
        if row['clock_sha256'] and hashlib.sha256((old/'model-start.json').read_bytes()).hexdigest()!=row['clock_sha256']:raise RuntimeError('old clock changed')
    return True
check_identity()
if PLAN['arms']!=ARMS or PLAN['queries']!=[2,1] or PLAN['warmups']!=0 or PLAN['repeats']!=1 or PLAN['planned_logical']!=4248 or PLAN['planned_posts']!=12744:
    raise RuntimeError('authorized pilot schedule differs')
if (PLAN['max_seconds'],PLAN['max_logical'],PLAN['max_posts'],PLAN['startup_seconds'],PLAN['cleanup_reserve_seconds'])!=(600,4608,13824,180,120):
    raise RuntimeError('authorized pilot hard limits differ')
if CLOCK['deadline_monotonic_ns']-CLOCK['started_monotonic_ns']!=600_000_000_000 or counts()['total']:
    raise RuntimeError('independent pilot clock or empty ledger differs')
PREP=json.loads((ROOT/'request-preparation/result.json').read_text())
MANIFEST=json.loads((ROOT/'request-preparation/route-manifest.json').read_text())
ASSETS=json.loads((ROOT/'asset-check.json').read_text())
if not PREP['passed'] or PREP['native_mock_sends']!=2120 or PREP['context_violations'] or not ASSETS['passed']:
    raise RuntimeError('complete native requests/tokenizer/assets not qualified')
ROOT_MODEL=ROOT/'model-matched';ROOT_MODEL.mkdir(exist_ok=False)
MODEL_SCOPE=os.environ['MODELRUN_SCOPE'];ALL_CPUS=set(STATE['driver_cpus'])|set(sum(STATE['service_cpus'],[]))
ANCESTOR_IDENTITIES={(p.pid,p.create_time()) for p in psutil.Process().parents()}
registry=lifecycle.OwnedRegistry(MODEL_SCOPE,ALL_CPUS)
result=dict(passed=False,source_head=STATE['source_head'],phases={},services=[],
    planned_logical_calls=4248,max_logical_calls=4608,max_transmission_posts=13824,max_seconds=600,
    startup_seconds_limit=180,startup_seconds_used=0,cleanup_actions=[],forced_service_cleanup=False,
    plan=PLAN,all_failures_preserved=True,clock= CLOCK)
services=[];writers=[];router=None;lease=None;sampler_stop=threading.Event();sampler=None;metrics_thread=None
def write():
    value=counts('dual');result.update(model_calls=value['gateway'],model_transmission_posts=value['total'])
    save(ROOT_MODEL/'result.json',result)
def control(phase,start_ns,seconds,reserve):
    # Startup has its own internal180s work check; the outer watchdog still
    # leaves the original global120s cleanup, including a startup failure.
    if phase.startswith('startup-'):
        start_ns=CLOCK['started_monotonic_ns'];seconds=600;reserve=120
    save(ROOT/'model-matched-phase-control.json',dict(phase=phase,started_monotonic_ns=start_ns,
        deadline_monotonic_ns=start_ns+int(seconds*1e9),cleanup_reserve_seconds=reserve))
for name in ('ROOT','STATE','SOURCE','ROOT_MODEL','FIRST_CLOCK_BYTES','OLD_FIRST_CLOCK_BYTES','MODEL_SCOPE',
             'ALL_CPUS','ANCESTOR_IDENTITIES','registry','result','services','writers','sampler_stop','sampler','write','control','gpu','base_env','save'):
    lifecycle.__dict__[name]=globals()[name]
active_endpoints=[]
SERVICE_MEMBERS={}

def classify_resource_members(entries,service_roots,service_members):
    # Persist actual owned API-descendant PID/birth identities across reparenting.
    # Environment labels are not a reliable process-family ownership contract.
    for pid,born in service_roots.items():
        if born is None:continue
        try:
            api=psutil.Process(pid)
            if api.create_time()!=born:continue
            mask=set(api.cpu_affinity())
            if mask not in [set(v) for v in STATE['service_cpus']]:
                raise RuntimeError('owned API affinity differs during resource sampling')
            for process in [api,*api.children(recursive=True)]:
                try:
                    identity=(process.pid,process.create_time())
                    if not set(process.cpu_affinity())<=mask:
                        raise RuntimeError('owned service descendant escaped its API CPU group')
                    service_members[identity]=dict(api_pid=pid,api_born=born,cpu_affinity=sorted(mask))
                except psutil.NoSuchProcess:pass
        except psutil.NoSuchProcess:pass
    clients=[];service_rows=[]
    for entry in entries:
        try:
            process=psutil.Process(entry['pid'])
            if process.create_time()!=entry['born']:continue
            identity=(process.pid,entry['born']);mask=set(process.cpu_affinity())
            service=service_members.get(identity)
            if service is None:
                if not mask<=set(STATE['driver_cpus']):
                    raise RuntimeError('owned nonclient process has no verified API ancestry')
                target=clients
            else:
                if not mask<=set(service['cpu_affinity']):
                    raise RuntimeError('recorded service descendant CPU group changed')
                target=service_rows
            row=dict(pid=process.pid,born=entry['born'],rss_bytes=process.memory_info().rss)
            if service is not None:row.update(role='service',**service)
            target.append(row)
        except psutil.NoSuchProcess:pass
    return clients,service_rows

def sample_resources():
    with (ROOT_MODEL/'client-server-timeseries.jsonl').open('x') as f:
        while not sampler_stop.is_set():
            row=dict(at_ns=time.monotonic_ns(),client_rss_bytes=0,clients=[],replicas=[])
            live=registry.live()
            with registry.lock:service_roots={child.pid:registry.roots.get(child.pid) for child in services}
            row['clients'],row['service_processes']=classify_resource_members(live,service_roots,SERVICE_MEMBERS)
            row['client_rss_bytes']=sum(v['rss_bytes'] for v in row['clients'])
            row['resource_scope']='owned API PID/birth descendants separated from client/observer RSS; environment labels unused'
            row['supervisor_rss_bytes']=psutil.Process().memory_info().rss
            row['client_rss_bytes']+=row['supervisor_rss_bytes']
            for parent in psutil.Process().parents():
                try:
                    watchdog=json.loads((ROOT/'model-launch.json').read_text())
                    if parent.pid!=watchdog['pid'] or int(Path('/proc',str(parent.pid),'stat').read_text().rsplit(')',1)[1].split()[19])!=watchdog['start_ticks']:continue
                    rss=parent.memory_info().rss;row['client_rss_bytes']+=rss
                    row['clients'].append(dict(pid=parent.pid,born=parent.create_time(),rss_bytes=rss,role='watchdog'))
                except psutil.Error:pass
            for endpoint in tuple(active_endpoints):
                try:row['replicas'].append(dict(endpoint=endpoint,text=lifecycle.api_get(endpoint,'/metrics',1).decode()))
                except Exception as error:row['replicas'].append(dict(endpoint=endpoint,error_type=type(error).__name__))
            f.write(json.dumps(row)+'\n');f.flush()
            if row['client_rss_bytes']>8*1024**3:
                result['resource_failure']='sampled client process RSS exceeded8GiB';write();os.kill(os.getpid(),signal.SIGTERM);return
            sampler_stop.wait(.5)
def resource_sampler():
    try:sample_resources()
    except BaseException as error:
        result['resource_failure']='resource observer failed: '+type(error).__name__
        try:write()
        finally:os.kill(os.getpid(),signal.SIGTERM)
def stopped(_signum,_frame):raise TimeoutError('matched watchdog requested bounded pilot cleanup')
signal.signal(signal.SIGTERM,stopped)
def run_protocol(arm,out,env,deadline):
    slot(out.name);env=dict(env,MODELRUN_ROLE='client',MODELRUN_QUERY_OBSERVER='0')
    with out.with_suffix('.stdout.log').open('x') as stdout,out.with_suffix('.stderr.log').open('x') as stderr:
        command=[STATE['driver_python'],'-B',str(ROOT/'validation/pilot_protocol.py'),arm,str(out)]
        child=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=stdout,stderr=stderr,start_new_session=True);registry.add(child)
        while child.poll() is None:
            if time.monotonic()>=deadline:raise TimeoutError('pilot protocol global work deadline reached')
            time.sleep(.1)
    if child.returncode:raise RuntimeError('actual executor protocol subset failed')
    return json.loads((out/'result.json').read_text())
from pilot_validation import check_query
def check_unit(case,cell):
    return check_query(case/'output'/cell['unit_id'],cell['arm'],cell['query_id'])

try:
    lifecycle.resource_preflight();source_check=source_identity()
    lease=acquire_host_runner_lease(Path(STATE['host_scope']),repository_commit=STATE['source_head'])
    save(ROOT_MODEL/'run-signature.json',dict(schema='semloom.original_movie_dual_NS_A.v1',source_head=STATE['source_head'],
        source=source_check,plan=PLAN,clock=CLOCK,state=STATE,prepared_request_sha256=hashlib.sha256((ROOT/'request-preparation/route-manifest.json').read_bytes()).hexdigest(),
        asset_preflight=ASSETS,native_model_quality='Q1 not previously acquired; Q2 reference preserved',
        routing='shared fixed original full-value mapping; zero failover; unknown rejects',
        generation='original LOTUS1.2.4 Filter SDK; temperature0/top_p1/max_completion_tokens8/stop newline/nonstream/cachefalse/retry0',
        timing='task-specific source preparation through usable consumer EOF; ready has same end; quality postEOF; observers charged'))
    declarations=PLAN['endpoints'];os.environ['MODELRUN_MODEL_ENDPOINTS']=json.dumps(declarations);install()
    selected={'routes':None}
    def choose(route,body):
        if selected['routes'] is None:raise RuntimeError('no active model group routing')
        return selected['routes'](route,body)
    def query_tag():
        with sqlite3.connect(ROOT/'sends.sqlite',timeout=10) as db:row=db.execute('SELECT phase,slot,unit FROM control WHERE id=1').fetchone()
        return None if row is None else '/'.join(row)
    router=ObservationGateway(bind_port=PLAN['router_port'],query_identity=query_tag,
        routes=(GatewayRoute('model-plan','model',declarations[0]),),trace_path=ROOT_MODEL/'router-http-trace.jsonl',
        request_timeout_s=30,preserve_http=True,select_upstream=choose)
    router.start();router_url=router.endpoint_url('model-plan','model');os.environ['MODELRUN_ROUTER_URL']=router_url
    result.update(logical_router_endpoint=router_url,declarations=declarations);write()
    metrics_thread=threading.Thread(target=resource_sampler,daemon=True);metrics_thread.start()
    deadline=CLOCK['deadline_monotonic_ns']/1e9-120
    for index,arm in enumerate(ARMS):
        check_identity();label=('N-A','S-A')[index];records=lifecycle.start_services(label,declarations)
        active_endpoints[:]=declarations
        control(label,CLOCK['started_monotonic_ns'],600,120);activate('dual',label,CLOCK['started_epoch'],600,120)
        selected['routes']=FixedRequestRoutes({r['replica']:r['endpoint'] for r in records},MANIFEST['dual_assignments']);router.reset_upstream_connections()
        group=ROOT_MODEL/label;save(group/'model.json',dict(endpoint_url=router_url,model_id=STATE['model_id'],timeout_ms=30000,bearer_token_env='SEMBENCH_LOCAL_TOKEN'))
        env=base_env();env.update(SEMBENCH_MODEL_CONFIG=str(group/'model.json'),MODELRUN_ROUTER_URL=router_url,
            MODELRUN_MODEL_ENDPOINTS=json.dumps(declarations),MODELRUN_ROLE='client')
        before=counts('dual');entry=dict(arm=arm,started_ns=time.monotonic_ns(),cases=[]);result['phases'][label]=entry;write()
        protocol=run_protocol(arm,group/'protocol-first4',env,deadline);entry['protocol']=protocol;write()
        value=cli(arm,0,'performance',group/'original-query-slot',env,deadline,registry)
        entry['cases'].append(value);write()
        for cell in value['matrix']['cells']:check_unit(group/'original-query-slot',cell)
        actual=counts('dual');delta={k:actual[k]-before[k] for k in actual}
        if delta!=dict(total=6372,gateway=2124,router=2124,model=2124,fixture=0):raise RuntimeError('group three-hop send accounting differs')
        entry.update(counts_delta=delta,ended_ns=time.monotonic_ns())
        for record in records:(group/('service-'+record['replica'][-1])/'final-metrics.txt').write_bytes(lifecycle.api_get(record['endpoint'],'/metrics'))
        lifecycle.stop_services(records);active_endpoints.clear();selected['routes']=None
        entry.update(passed=True,cleanup_ended_ns=time.monotonic_ns());write()
    if counts('dual')!=dict(total=12744,gateway=4248,router=4248,model=4248,fixture=0):raise RuntimeError('planned cumulative three-hop send count differs')
    result['passed']=True
except BaseException as error:
    import traceback
    result.update(error_type=type(error).__name__,error=redact_text(str(error)))
    save(ROOT_MODEL/'exception.json',dict(error_type=type(error).__name__,error=redact_text(str(error)),traceback=redact_text(traceback.format_exc())))
    write()
finally:
    control('final-cleanup',time.monotonic_ns(),90,0)
    try:
        if router is not None:router.stop()
    except Exception as error:result['router_cleanup_error_type']=type(error).__name__
    try:
        if any(c.poll() is None for c in services):lifecycle.stop_services(result['services'])
    except Exception as error:result['service_cleanup_error_type']=type(error).__name__
    registry.observe();result['fallback_processes_before_final_cleanup']=registry.live()
    if result['fallback_processes_before_final_cleanup']:registry.terminate()
    sampler_stop.set()
    for thread in (lifecycle.sampler,metrics_thread):
        if thread is not None:
            thread.join(5)
            if thread.is_alive():result['resource_failure']='observer failed to finish within5s'
    result.update(cleanup=registry.finish(),gpu_after=gpu(),counts=counts(),elapsed_seconds=(time.monotonic_ns()-CLOCK['started_monotonic_ns'])/1e9,
        independent_clock_unchanged=(ROOT/'model-start.json').read_bytes()==FIRST_CLOCK_BYTES)
    if lease is not None:lease.release()
    for writer in writers:writer.close()
    result['source_after_cleanup']=source_identity();result['old_histories_unchanged']=check_identity()
    result['passed']=result['passed'] and result['independent_clock_unchanged'] and not result['fallback_processes_before_final_cleanup'] and not result['forced_service_cleanup'] and not result['cleanup']['owned_survivors'] and not result['cleanup']['affinity_violations'] and not result['gpu_after'] and result['elapsed_seconds']<=600 and result['startup_seconds_used']<=180 and not result.get('resource_failure') and not result.get('service_cleanup_error_type') and not result.get('router_cleanup_error_type')
    write()
raise SystemExit(not result['passed'])
