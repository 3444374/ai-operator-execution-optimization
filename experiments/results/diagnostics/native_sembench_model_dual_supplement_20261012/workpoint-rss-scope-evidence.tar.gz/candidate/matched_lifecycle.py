"""Retained matched lifecycle; startup180 and explicit service RSS role only."""
import hashlib,json,os,socket,subprocess,threading,time,urllib.request
from pathlib import Path
import psutil
from support import Registry
class OwnedRegistry(Registry):
 def observe(self):
  super().observe()
  for p in psutil.process_iter():
   if p.pid==os.getpid():continue
   try:
    if (p.pid,p.create_time()) in ANCESTOR_IDENTITIES:continue
    if p.environ().get('MODELRUN_SCOPE')!=self.token:continue
    row=dict(pid=p.pid,born=p.create_time(),name=p.name(),affinity=p.cpu_affinity())
    with self.lock:self.known[(p.pid,p.create_time())]=row
    if not set(row['affinity'])<=self.cpus:self.violations.append(row)
   except psutil.Error:pass

def port():
 with socket.socket() as probe:probe.bind(('127.0.0.1',0));return probe.getsockname()[1]

def api_get(endpoint,path,timeout=3):
 request=urllib.request.Request(endpoint.rsplit('/v1/chat/completions',1)[0]+path,headers={'Authorization':'Bearer ***'})
 with urllib.request.urlopen(request,timeout=timeout) as response:return response.read()

def resource_preflight():
 occupied=[]
 for process in psutil.process_iter():
  if process.pid==os.getpid():continue
  try:
   if process.status()==psutil.STATUS_ZOMBIE or (process.pid,process.create_time()) in ANCESTOR_IDENTITIES or process.environ().get('MODELRUN_SCOPE')==MODEL_SCOPE:continue
   mask=set(process.cpu_affinity())
   if len(mask)<=32 and mask&ALL_CPUS:occupied.append(dict(pid=process.pid,born=process.create_time(),affinity=sorted(mask),name=process.name()))
  except psutil.Error:pass
 if occupied:raise RuntimeError('requested CPU group has other dedicated processes; leave other owners running')
 if gpu():raise RuntimeError('GPU compute is already occupied; leave other owners running')
 save(ROOT_MODEL/'resource-preflight.json',dict(at_monotonic_ns=time.monotonic_ns(),dedicated_other_processes=occupied,gpu_compute=[],driver_cpus=STATE['driver_cpus'],service_cpus=STATE['service_cpus'],source_head=STATE['source_head'],host_background_load_role='host CPU background outside visible process scope can remain; report separately'))

def sample_gpu():
 with (ROOT_MODEL/'gpu-timeseries.jsonl').open('w') as output:
  while not sampler_stop.is_set():
   at=time.monotonic_ns()
   try:
    query=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,utilization.gpu,utilization.memory,memory.used,power.draw','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=4)
    value=dict(started_ns=at,ended_ns=time.monotonic_ns(),returncode=query.returncode,rows=query.stdout.splitlines())
   except Exception as error:value=dict(started_ns=at,error_type=type(error).__name__)
   output.write(json.dumps(value)+'\n');output.flush();sampler_stop.wait(.25)

def start_services(phase,endpoints):
 global sampler
 resource_preflight()
 started=time.monotonic();remaining=180-result['startup_seconds_used'];overall=ROOT/'model-start.json'
 if remaining<=0:raise TimeoutError('independent startup allowance cannot preserve its cleanup reserve; no new service started')
 if overall.read_bytes()!=FIRST_CLOCK_BYTES:raise RuntimeError('independent window clock changed')
 if sampler is None:
  sampler=threading.Thread(target=sample_gpu,daemon=True);sampler.start()
 global_deadline=json.loads(overall.read_text())['deadline_monotonic_ns']/1e9
 until=min(started+remaining,global_deadline-120);control('startup-'+phase,int(started*1e9),max(0,until-started),0);work_until=until
 records=[]
 try:
  for index,endpoint in enumerate(endpoints):
   root=ROOT_MODEL/phase/('service-'+str(index));root.mkdir(parents=True)
   cpu=STATE['service_cpus'][index];number=int(endpoint.split(':')[2].split('/')[0]);tmp=Path(STATE['ray_parent'])/('v'+phase+str(index));tmp.mkdir(exist_ok=False)
   if len(str(tmp).encode())+37>107:raise RuntimeError('declared vLLM IPC path exceeds UNIX socket limit before API launch')
   options=['--host','127.0.0.1','--port',str(number),'--model',STATE['model_path'],'--served-model-name',STATE['model_id'],'--dtype','bfloat16','--max-model-len','4096','--max-num-seqs','16','--max-num-batched-tokens','2048','--gpu-memory-utilization','0.80','--tensor-parallel-size','1','--pipeline-parallel-size','1','--enforce-eager','--no-enable-prefix-caching','--api-key','***']
   command=['taskset','-c',','.join(map(str,cpu)),STATE['service_python'],'-B',str(SOURCE/'code/scripts/services/launch_vllm_with_identity.py'),'--identity-output',str(root/'identity.json'),'--port',str(number),'--',*options]
   env=base_env();env.update(MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0',MODELRUN_ROLE='service',CUDA_VISIBLE_DEVICES=str(index),VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',HF_HUB_DISABLE_TELEMETRY='1',HF_HOME=str(root/'cache'),VLLM_CACHE_ROOT=str(root/'cache/vllm'),TMPDIR=str(tmp),VLLM_RPC_BASE_PATH=str(tmp));writer=(root/'vllm.log').open('w');writers.append(writer)
   if time.monotonic()>=work_until:raise TimeoutError('startup or overall work deadline reached before API launch; no new service started')
   with SERVICE_PUBLISH_LOCK:
    if time.monotonic()>=work_until:raise TimeoutError('startup or overall work deadline reached while waiting for service publication lock; no new service started')
    at=time.monotonic_ns()
    if not (ROOT/'model-matched-first-api.json').exists():save(ROOT/'model-matched-first-api.json',dict(first_api_started_ns=at,first_api_started_epoch=time.time(),independent_window_clock_sha256=hashlib.sha256(FIRST_CLOCK_BYTES).hexdigest(),original_first_clock_sha256=hashlib.sha256(OLD_FIRST_CLOCK_BYTES).hexdigest()))
    child=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=writer,stderr=subprocess.STDOUT,start_new_session=True)
    registry.add(child)
    row=dict(phase=phase,replica='gpu'+str(index),api_pid=child.pid,api_start_ticks=int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19]),endpoint=endpoint,cpu_affinity=cpu,started_ns=at,argv=command,service_history_before=0)
    services.append(child);records.append(row);result['services'].append(row);write()
  for row,child in zip(records,services[-len(records):]):
   while True:
    if child.poll() is not None:raise RuntimeError('fresh owned model service exited before ready')
    if time.monotonic()>=work_until:raise TimeoutError('cumulative startup or global cleanup reserve reached')
    try:
     models=json.loads(api_get(row['endpoint'],'/v1/models',2))
     if [v['id'] for v in models['data']]==[STATE['model_id']]:break
    except (OSError,ValueError):pass
    time.sleep(.5)
   row['ready_ns']=time.monotonic_ns();row['readiness_seconds']=(row['ready_ns']-row['started_ns'])/1e9
   row['actual_api_affinity']=psutil.Process(child.pid).cpu_affinity()
   if set(row['actual_api_affinity'])!=set(row['cpu_affinity']):raise RuntimeError('model API CPU assignment changed')
  registry.observe();compute=gpu();expected=['gpu-0','gpu-1'][:len(records)]
  if len(compute)!=len(records) or {r.split(',')[1].strip() for r in compute}!=set(expected):raise RuntimeError('actual GPU engine identities do not match planned replicas')
  for row,gpu_uuid in zip(records,expected):
   pid=int(next(line.split(',')[0] for line in compute if gpu_uuid in line));process=psutil.Process(pid)
   if (pid,process.create_time()) not in registry.known:raise RuntimeError('model engine is not an owned API descendant')
   row.update(gpu_uuid=gpu_uuid,engine_pid=pid,engine_start_ticks=int(Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()[19]),engine_affinity=process.cpu_affinity())
   if set(row['engine_affinity'])!=set(row['cpu_affinity']):raise RuntimeError('model engine CPU assignment changed')
   (ROOT_MODEL/phase/('service-'+row['replica'][-1])/'ready-metrics.txt').write_bytes(api_get(row['endpoint'],'/metrics'))
  return records
 finally:
  result['startup_seconds_used']+=time.monotonic()-started;write()

def stop_services(records):
 for row in records:
  for child in services:
   if child.pid==row['api_pid'] and child.poll() is None and int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19])==row['api_start_ticks']:
    result['cleanup_actions'].append(dict(pid=child.pid,start_ticks=row['api_start_ticks'],signal='TERM',planned=True,at_ns=time.monotonic_ns()));child.terminate()
 until=time.monotonic()+35
 while any(child.poll() is None for child in services) and time.monotonic()<until:time.sleep(.2)
 for child in services:
  if child.poll() is None:
   row=next(r for r in result['services'] if r['api_pid']==child.pid)
   if int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19])==row['api_start_ticks']:
    result['forced_service_cleanup']=True;result['cleanup_actions'].append(dict(pid=child.pid,start_ticks=row['api_start_ticks'],signal='KILL',planned=False,at_ns=time.monotonic_ns()));child.kill();child.wait(timeout=5)
 registry.observe()
 # API termination must also settle its separately recorded engine process.
 for row in records:
  if 'engine_pid' in row:
   try:
    process=psutil.Process(row['engine_pid'])
    if int(Path('/proc',str(process.pid),'stat').read_text().rsplit(')',1)[1].split()[19])==row['engine_start_ticks'] and process.status()!=psutil.STATUS_ZOMBIE:
     result['forced_service_cleanup']=True;result['cleanup_actions'].append(dict(pid=process.pid,start_ticks=row['engine_start_ticks'],signal='TERM',planned=False,at_ns=time.monotonic_ns()));process.terminate();process.wait(timeout=10)
   except psutil.NoSuchProcess:pass
 if gpu():raise RuntimeError('GPU compute remains after owned service cleanup; stop next phase')
 if result['forced_service_cleanup']:raise RuntimeError('unplanned service cleanup used; preserve diagnostic and stop next phase')
 for row in records:row['api_exit']=next(c.returncode for c in services if c.pid==row['api_pid'])
