"""Process-shared POST accounting for a once-claimed native benchmark unit."""
from dataclasses import dataclass, field
from pathlib import Path
import re

from .attempt_ledger import AttemptBudget, BudgetError, BudgetExhausted
from .cell_budget import CellBudgetLedger


@dataclass(frozen=True)
class SharedClaimedUnit:
    path: Path
    budget: AttemptBudget
    unit_id: str
    _ledger: CellBudgetLedger = field(init=False, repr=False, compare=False)

    def __post_init__(self):
        # Reuse only the path/budget wrapper, never a connection or transaction.
        # Each operation still opens and validates the existing durable ledger.
        object.__setattr__(self, '_ledger', CellBudgetLedger(self.path, self.budget))

    def _state(self, connection, allocated):
        row = connection.execute('''SELECT first_attempt,requests,claimed FROM units
            JOIN shared_units USING(unit_id) WHERE unit_id=?''', (self.unit_id,)).fetchone()
        if row is None or row[2] != 1 or row[0] < 1 or row[1] < 1 or row[0]+row[1]-1 > allocated:
            raise BudgetError('shared unit is not a valid exclusive claim')
        count, last = connection.execute('SELECT count(*),max(sequence) FROM shared_requests WHERE unit_id=?',
                                        (self.unit_id,)).fetchone()
        if count > row[1] or (count and last != count):
            raise BudgetError('shared request history invalid')
        return row[0], row[1], count

    def reserve(self, request_sha256):
        return self.reserve_many((request_sha256,))[0]

    def reserve_many(self, request_sha256s):
        """Commit a finite, nonempty list/tuple of ready requests atomically.

        Attempt numbers are returned only after commit. Every entry is charged,
        including identical digests and requests never sent after this returns.
        This method does not collect requests or wait for a batch to fill.
        """
        if not isinstance(request_sha256s, (list, tuple)) or not request_sha256s:
            raise BudgetError('a nonempty request digest list or tuple is required')
        digests = tuple(request_sha256s)
        if any(not isinstance(digest, str) or not re.fullmatch('[0-9a-f]{64}', digest)
               for digest in digests):
            raise BudgetError('invalid request digest')
        ledger = self._ledger
        with ledger._transaction() as connection:
            allocated, _ = ledger._active(connection)
            if connection.execute('SELECT 1 FROM closed_shared_units WHERE unit_id=?',(self.unit_id,)).fetchone():
                raise BudgetExhausted('shared query unit has been closed')
            first, maximum, used = self._state(connection, allocated)
            if len(digests) > maximum - used:
                raise BudgetExhausted('shared unit budget exhausted')
            rows = [(self.unit_id, used+index, digest) for index, digest in enumerate(digests, 1)]
            if len(rows) == 1:
                connection.execute('INSERT INTO shared_requests VALUES(?,?,?)', rows[0])
            else:
                connection.executemany('INSERT INTO shared_requests VALUES(?,?,?)', rows)
        return tuple(range(first+used, first+used+len(digests)))

    @property
    def attempts(self):
        ledger = self._ledger
        with ledger._transaction() as connection:
            allocated, _ = ledger._header(connection)
            return self._state(connection, allocated)[2]

    @property
    def remaining(self):
        ledger = self._ledger
        with ledger._transaction() as connection:
            allocated, _ = ledger._header(connection)
            _, maximum, used = self._state(connection, allocated)
            return maximum-used
