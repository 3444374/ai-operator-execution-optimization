import json,os,pathlib,subprocess,sys,time,traceback,sqlite3,hashlib
from dataclasses import asdict
from src.infrastructure.redact import redact_text
from src.baselines.common.private_artifacts import file_identity
from src.execution_provider.adapters.model_config import FixedModelConfig
from tests.experiments.test_mmqa_service_observer import full_fixture_dataset,observed_service
from tokenizers import Tokenizer,models
root=pathlib.Path(os.environ['OBSERVER_CPU_ROOT']);source=root/'source-exact';start=time.time()
try:
 case=root/'exact-cli';case.mkdir()
 dataset=full_fixture_dataset(case/'input',pathlib.Path(os.environ['SEMLOOM_TEST_SEMBENCH_ROOT']))
 tokenizer=case/'tokenizer.json';Tokenizer(models.WordLevel({'[UNK]':0},unk_token='[UNK]')).save(str(tokenizer))
 with observed_service(case) as (endpoint,calls,profiles):
  model=FixedModelConfig(endpoint,'fixture-mmqa',10000);(case/'model.json').write_text(json.dumps(asdict(model)))
  profile=dict(model=dict(id=model.model_id,revision='software-fixture',dtype='software-fixture'),generation=dict(temperature=0,top_p=1,max_tokens=32,retries=0),service_preprocess=dict(processor_revision='software-fixture',parameters=dict(no_model=True)),tokenizer_sha256=file_identity(tokenizer)['sha256']);(case/'model-profile.json').write_text(json.dumps(profile))
  argv=[sys.executable,'-B',str(source/'code/scripts/experiments/run_sembench_mmqa.py'),'--checkout',str(dataset.checkout),'--execute','--manifest',str(dataset.manifest),'--manifest-digest',json.loads(dataset.manifest.read_text())['sha256'],'--output',str(case/'run'),'--model',str(case/'model.json'),'--tokenizer',str(tokenizer),'--model-profile',str(case/'model-profile.json'),'--lease-root',str(case/'scope'),'--repository-commit','0c6759ab6a84ae8815e6d77291989ad0dc136a43','--max-attempts','650','--concurrency','4','--max-tokens','32','--max-request-bytes','1048576','--max-prepared-bytes','33554432','--max-result-bytes','1048576','--deadline-seconds','120']
  # MmqaDataset's manifest digest is read from its retained manifest below.
  index=argv.index('--manifest-digest')+1;argv[index]=json.loads(dataset.manifest.read_text())['sha256']
  result=subprocess.run(argv,cwd=source,env=os.environ,capture_output=True,text=True,timeout=140)
  (root/'exact-cli.log').write_text(redact_text(result.stdout+result.stderr));assert result.returncode==0,redact_text(result.stderr[-4000:])
  assert len(calls)==650
 summary=json.loads((case/'run/unit/q0/summary.json').read_text());supervisor=json.loads((case/'run/supervisor.json').read_text());footer=json.loads((case/'run/unit/q0/observation-footer.json').read_text())
 con=sqlite3.connect('file:'+str(case/'run/budget.sqlite')+'?mode=ro',uri=True);attempts=con.execute('select count(*) from shared_requests').fetchone()[0];closed=con.execute('select count(*) from closed_shared_units').fetchone()[0]==1;con.close()
 value=dict(status='passed',repository_commit='0c6759ab6a84ae8815e6d77291989ad0dc136a43',seconds=time.time()-start,real_model_calls=0,fixture_HTTP_POSTs=len(calls),Join=summary['stages'][0]['input_members'],Extract=summary['stages'][1]['input_members'],allocated_attempts=650,actual_attempts=attempts,unknown_or_failed=summary['unknown_or_failed_attempts'],identity_receipts=len(profiles.read_text().splitlines()),worker_exit=supervisor['worker_exit'],remaining_owned_pids=supervisor['remaining_owned_pids'],lease_released=not (case/'scope/.runner-lease.json').exists(),budget_closed=closed,footer_verified=all(file_identity(case/'run/unit/q0'/n)==v for n,v in footer['files'].items()),files={n:file_identity(case/'run/unit/q0'/n) for n in ('summary.json','observation-footer.json','requests.jsonl','responses.jsonl','http-trace.jsonl')},scope='exact candidate; original native Q2b and evaluator; 25-image/13-row software fixture; no real model or GPU')
 assert value['worker_exit']==0 and not value['remaining_owned_pids'] and value['budget_closed'] and value['lease_released'] and value['footer_verified'] and value['unknown_or_failed']==0
 (root/'exact-cli-result.json').write_text(json.dumps(value,indent=2)+'\n')
except BaseException:
 (root/'exact-cli-error.log').write_text(redact_text(traceback.format_exc()));raise SystemExit(1)
