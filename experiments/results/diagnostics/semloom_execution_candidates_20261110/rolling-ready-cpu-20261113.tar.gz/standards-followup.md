# Standards follow-up

Reviewed only `6ddad4583338a1351a415b9c2b3138ce32bd3f9f..db61d178c64f30759f0ac5a07d27cdc5dfae0a2d` for the previously reported CPU-run provenance gap. The original `standards-review.md` is preserved.

**Disposition: resolved.** `commands.json` now maps the retained runs to their argv, checkout/source identity, explicit environment overrides, output log, exit code and test count. `runtime-identity.json` records Python build/executable identity, platform, relevant SDK versions and source hashes. The manifest provides direct member pointers, and the report explains the evidence scope. This addresses the missing command/environment information required by `experiments/AGENTS.md:26-27` and `experiments/results/AGENTS.md:10-12`.

The environment record explicitly states that it was collected after the checks and that this task did not change dependencies; it does not claim a contemporaneous snapshot or a complete inherited environment. Unfrozen intermediate fixtures are identified as historical diagnostics and do not borrow the final source's qualification.

Verification was read-only: the archive and all 21 member sizes/hashes match the manifest; all 17 original members remain byte-for-byte unchanged; all 12 invocation records agree with their retained log test counts, outcomes and selected test identities. The four runtime source hashes match the reviewed source, and the original standards report is unchanged. The diff contains no production or test-code change.

**Remaining issues within this follow-up: none.** The previously disclosed intermittent late-close failure and unfrozen intermediate diagnostic snapshots remain limitations, without any new claim of a green full suite or model/performance qualification. No tests, server, GPU or model tasks were run.
