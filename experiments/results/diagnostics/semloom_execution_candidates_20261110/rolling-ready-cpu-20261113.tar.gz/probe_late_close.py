"""Bounded CPU diagnostic of the existing late-close test, with original thresholds."""
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
from src.execution_provider.adapters.lotus_record_chain_core import SemLoomRecordChainCore
from tests.execution_provider.test_lotus_record_local_query import QueryOwnerTests
reports=[]
original=SemLoomRecordChainCore.close
def close(owner, *args, **kwargs):
    result=original(owner,*args,**kwargs)
    if kwargs.get('timeout') == 3 and result.get('status') != 'closed':
        reports.append(dict(report=result,ready_options=owner._ready_options,independent_budget=owner.capacity.budget))
    return result
name='test_close_collects_late_known_receipt_without_parser_or_successor_replay'
suite=unittest.TestSuite(QueryOwnerTests(name) for _ in range(5))
with patch.object(SemLoomRecordChainCore,'close',close):
    result=unittest.TextTestRunner(verbosity=2).run(suite)
Path(sys.argv[1]).write_text(json.dumps(dict(runs=result.testsRun,failures=len(result.failures),errors=len(result.errors),unconfirmed_close_reports=reports),default=str,indent=2)+'\n')
raise SystemExit(not result.wasSuccessful())
