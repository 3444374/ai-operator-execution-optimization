"""PR99 independent workload with verified support-source host supervision."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,signal,sys,tempfile,time
R=Path('<data-root>/semloom-pr100-ready-work-20261112'); OLD=Path('<data-root>/semloom-pr99-step-actions-20261112-r1'); S=R/'source'; P=R/'packet'
SUP=OLD/'support'
COMMIT='6d281376d4b7a0354856921be3fd1a45439a1f78'; MODE='batch-invariant'
os.umask(0o077);os.sched_setaffinity(0,set(range(8)));sys.path.insert(0,str(SUP/'code'))
from src.baselines.image.ray_animals_q7.host_adapter import from_bound,load_host
template=json.loads(Path('<data-root>/ray-animals-q7-909-engine-1111-r2/RUN-BOUND.json').read_text())
bound=dict(source=str(SUP),source_commit='933157666e1db81d47872fe21422ac8315ea7be3',code_tree='e973cd44d8c971942bcc8bd1fc312f9906449906',root=str(R),host_adapter=template['host_adapter'],workload_source=str(S),workload_commit=COMMIT,model_calls=624)
bound['host_adapter']['host_helper']=dict(path='<data-root>/semloom-host-helper-argv0-20261111-r1/host_helpers.py',sha256='7c1d0d3f9f9ed9738559524516a547d8bc88a663d1fb2fae7ba7b19a4ad3e1da')
host=load_host('host',bound['host_adapter']['host_helper']);api=host.production_api(SUP/'code')
resources=json.loads(Path(bound['host_adapter']['resource_config']['path']).read_text())
O=R/'host';O.mkdir(mode=0o700,exist_ok=False)
import subprocess,threading,psutil
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
D='<data-root>/venvs/sembench-query-0910/bin/python'
entry=str(S/'code/scripts/experiments/validate_record_chain_options.py')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==COMMIT
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
before=host.snapshot(api,resources,'pr100-ready-work-before');host.private_json(O/'BEFORE.json',before);host.assert_idle(before,resources)
lease=api.acquire_runner_lease(Path('<data-root>/experiment-artifacts/.host-runner-scope'),config_fingerprint=api.HOST_SCOPE_FINGERPRINT,repository_commit=COMMIT,recover_stale=False)
before_shm={p.name:(p.stat().st_ino,p.stat().st_size)for p in Path('/dev/shm').iterdir()}
short=Path(tempfile.mkdtemp(prefix='p100rw-',dir='/tmp'))
owned=set();failure=None;receipts=[];pairs=[];started=time.monotonic_ns();deadline=time.time()+2100
master=CellBudgetLedger.create(R/'budget.sqlite',AttemptBudget('pr100-ready-work-20261112',624),deadline_utc=deadline)
master.reserve_unit('pair-0',48)
for cycle in (1,2,3):master.reserve_unit('pair-'+str(cycle),192)
stop_reason=None

def alarm(*_):raise TimeoutError('bounded PR100 ready-work allocation')
signal.signal(signal.SIGALRM,alarm);signal.alarm(max(1,int(deadline-time.time())))
os.environ.update(PYTHONPATH=str(S/'code'),CUDA_VISIBLE_DEVICES='0',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',LITELLM_LOCAL_MODEL_COST_MAP='True',TOKENIZERS_PARALLELISM='false',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',GIT_ALLOW_PROTOCOL='file',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',AI_OPERATOR_ENV_FILE=str(P/'runtime.env'),VLLM_BATCH_INVARIANT='1',VLLM_LOGGING_LEVEL='INFO')

def observe_native_environment(stop,samples):
 while not stop.is_set():
  try:
   p=subprocess.run(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=8)
   if p.returncode==0:
    for line in p.stdout.splitlines():
     pid=int(line.strip())
     try:
      born=psutil.Process(pid).create_time();raw=(Path('/proc')/str(pid)/'environ').read_bytes()
      env=dict(x.split(b'=',1)for x in raw.split(b'\0')if b'='in x)
      samples[(pid,born)]=dict(pid=pid,create_time=born,VLLM_BATCH_INVARIANT=env.get(b'VLLM_BATCH_INVARIANT',b'').decode() or None,CUDA_VISIBLE_DEVICES=env.get(b'CUDA_VISIBLE_DEVICES',b'').decode() or None,initial_env_key_count=len(env),read_scope='selected initial environment keys on actual NVIDIA compute PID; missing is unavailable, not false')
     except (OSError,psutil.Error):pass
  except (ValueError,subprocess.TimeoutExpired):pass
  stop.wait(1)

stage_number=0
try:
 host.private_json(O/'STARTED.json',dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),source=COMMIT,supervisor_source=bound['source_commit'],short=str(short),affinity=sorted(os.sched_getaffinity(0)),environment_profile='VLLM_BATCH_INVARIANT=1 both arms; not original R1 profile'))
 for name,python,groups in [('driver',D,'core,text,text-qwen7b'),('model',json.loads((P/'config-template.json').read_text())['engine']['model_python'],'text,text-qwen7b')]:
  with (O/('preflight-'+name+'.log')).open('w') as log:
   subprocess.run([python,str(S/'code/scripts/environment/manage_environment.py'),'check','--groups',groups,'--json-out',str(O/('preflight-'+name+'.json'))],cwd=S,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
  print('PREFLIGHT',name,'passed',flush=True)
 for cycle,order in enumerate([['ready-fifo'],['ready-fifo','ready-shortest','ready-longest','ready-progress'],['ready-longest','ready-progress','ready-fifo','ready-shortest'],['ready-progress','ready-longest','ready-shortest','ready-fifo']],0):
  master.claim_unit('pair-'+str(cycle)).bind_execution()
  cell=R/('pair-'+str(cycle));cell.mkdir(mode=0o700)
  c=json.loads((P/'config-template.json').read_text());c.update(run_id='pr100-ready-work-cycle-'+str(cycle),target_root=str(cell),public_git_commit=COMMIT,execution_enabled=True,artifact_root=str(cell/'artifacts'),external_owner=dict(artifact_root='<data-root>/experiment-artifacts',lease_sha256=hashlib.sha256(Path('<data-root>/experiment-artifacts/.host-runner-scope/.runner-lease.json').read_bytes()).hexdigest()))
  c['suite']='ready-work-calibration' if cycle==0 else 'ready-work'
  if cycle:
   c['ready_work_profile']=dict(path=str(R/'COST-PROFILE.json'),sha256=hashlib.sha256((R/'COST-PROFILE.json').read_bytes()).hexdigest())
  c['ray_roots']={m:str(short/('r'+str(cycle)+'-'+m))for m in order}
  config=cell/'CONFIG.json';ready=cell/'READY.json';host.private_json(config,c)
  host.private_json(cell/'environment.json',dict(VLLM_BATCH_INVARIANT='1',source=COMMIT,order=order,model_calls_limit=48*len(order)))
  for action,extra in [('check',[]),('qualify',['--count-only','--output',str(ready)])]:
   with (cell/(action+'.log')).open('w') as log:subprocess.run([D,'-B',entry,action,'--config',str(config)]+extra,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
  Path(c['artifact_root']).mkdir(mode=0o700)
  ledger=CellBudgetLedger.create(Path(c['artifact_root'])/'budget.sqlite',AttemptBudget(c['run_id'],48*len(order)),deadline_utc=min(deadline,time.time()+900))
  for name in order:ledger.reserve_unit(name,48)
  for name in order:
   host.check_lease(lease);bound['host_adapter']['stage_timeout_s']=min(460,deadline-time.time()-90)
   command=[D,'-B',entry,'case','--config',str(config),'--ready',str(ready),'--case',name,'--execute-model']
   host.private_json(cell/('COMMAND-'+name+'.json'),command);host.private_json(cell/('BOUND-'+name+'.json'),bound)
   stop=threading.Event();samples={};thread=threading.Thread(target=observe_native_environment,args=(stop,samples),daemon=True);thread.start()
   print('START',cycle,name,flush=True)
   try:receipt=from_bound(bound)(command,stage_number,short);stage_number+=1;receipts.append(receipt)
   finally:
    stop.set();thread.join(timeout=10)
    host.private_json(cell/('NATIVE-ENV-'+name+'.json'),dict(samples=list(samples.values()),sampler_stopped=not thread.is_alive()))
   assert receipt['worker_exit_zero'] and receipt['physical_idle'] and receipt['resource_passed']
   host.private_json(cell/('RESULT-'+name+'.json'),receipt)
   case=json.loads((cell/'artifacts/cases'/name/'case.json').read_text())
   evidence=case['close']['model_owner']['model_ready']['native_execution_profile']
   host.private_json(cell/('PROFILE-'+name+'.json'),evidence)
   assert (evidence['status']=='observed_worker_execution_profile' and
           evidence['batch_invariant_requested'] is True and evidence['batch_invariant_active'] is True), 'actual initialized native batch-invariance profile unconfirmed'
   print('DONE',json.dumps(dict(cycle=cycle,case=name,status=case['status'],actual_calls=case['actual_calls'],full_relation_s=case['timing']['caller_to_full_relation_ready_s'],worker_to_full_relation_s=(case['timing']['full_relation_ready_ns']-case['process_start_ns'])/1e9)),flush=True)
  if cycle==0:
   code="from pathlib import Path;import json,hashlib;from src.experiments.ready_work_validation import calibrate;p=Path("+repr(str(cell/'artifacts/cases/ready-fifo/case.json'))+");v=calibrate(json.loads(p.read_text()),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest());Path("+repr(str(R/'COST-PROFILE.json'))+").write_text(json.dumps(v,indent=2)+'\\n');print(json.dumps(v['service_ns']))"
   subprocess.run([D,'-B','-c',code],cwd=S,check=True,timeout=30)
   host.private_json(cell/'BUDGET-final.json',ledger.snapshot())
   print('CALIBRATION frozen',flush=True)
   continue
  command=[D,'-B',entry,'compare','--config',str(config),'--output',str(cell/'COMPARISON.json')]
  bound['host_adapter']['stage_timeout_s']=30
  receipt=from_bound(bound)(command,stage_number,short);stage_number+=1;receipts.append(receipt)
  comparison=json.loads((cell/'COMPARISON.json').read_text())
  host.private_json(cell/'BUDGET-final.json',ledger.snapshot());pairs.append(dict(cycle=cycle,order=order,strict=comparison['outputs_strictly_comparable']))
  print('PAIR',json.dumps(pairs[-1]),flush=True)
  assert receipt['worker_exit_zero'] and receipt['physical_idle'] and receipt['resource_passed'] and comparison['outputs_strictly_comparable']
  selected={name:json.loads((cell/'artifacts/cases'/name/'case.json').read_text())['ready_work_selection'] for name in order}
  changes={name:v['changed_accepted'] for name,v in selected.items()}
  assert all(v['accepted_choices']==48 for v in selected.values())
  host.private_json(cell/'MECHANISM.json',dict(changed_accepted=changes))
  print('MECHANISM',json.dumps(changes),flush=True)
  if cycle==1 and not all(changes[name]>0 for name in order if name!='ready-fifo'):
   stop_reason='candidate did not change an accepted choice; stop further timing cycles'
   break
except BaseException as error:failure=host.error_record(error)
finally:
 signal.alarm(0)
 for path in short.glob('stage-*-supervision/supervisor.json'):owned.update(host.report_identities(json.loads(path.read_text())))
 if host.live_owned(api,owned):host.cleanup_owned(api,owned,20)
 live=host.live_owned(api,owned);after=host.snapshot(api,resources,'pr100-ready-work-after',owned);gpu=host.gpu_snapshot(resources)
 shm={p.name:(p.stat().st_ino,p.stat().st_size)for p in Path('/dev/shm').iterdir()};clean=not live and not gpu['compute'] and gpu['used_mib']==1 and shm==before_shm
 try:host.assert_idle(after,resources)
 except BaseException as error:failure=failure or host.error_record(error);clean=False
 try:
  copied=[];excluded=[]
  for source in sorted(short.rglob('*')):
   if source.is_symlink():continue
   if source.is_file():
    target=O/'RUNS'/source.relative_to(short);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    digest=hashlib.sha256(source.read_bytes()).hexdigest();assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
    copied.append(dict(path=str(source.relative_to(short)),sha256=digest,bytes=target.stat().st_size))
   elif not source.is_dir():excluded.append(str(source.relative_to(short)))
  host.private_json(O/'ARCHIVE.json',dict(files=copied,excluded_nonregular=excluded))
 except BaseException as error:failure=failure or host.error_record(error);host.private_json(O/'ARCHIVE-ERROR.json',host.error_record(error))
 host.private_json(O/'AFTER.json',after)
 if clean:host.check_lease(lease);lease.release()
 final=dict(status='passed'if failure is None and clean else'failed',failure=failure,source=COMMIT,start_ns=started,end_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),pairs=pairs,receipts=receipts,remaining_owned=sorted(live),GPU=gpu,SHM_unchanged=shm==before_shm,lease_released=clean,short=str(short),global_budget=master.snapshot(),stop_reason=stop_reason)
 host.private_json(O/'FINAL.json',final)
print('PR100 DONE',json.dumps(dict(status=final['status'],pairs=pairs,lease_released=clean,failure=failure)),flush=True)
raise SystemExit(0 if final['status']=='passed'else 1)
