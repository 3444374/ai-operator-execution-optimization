"""Recompute actual choice opportunities and strict output gates, not speedup."""
import argparse,collections,hashlib,json
from pathlib import Path
FIELDS=['query_id','model_role','algorithm_stage','call_id','row_id','source_position','call_index','messages_sha256','prompt_token_ids_json','output_token_ids_json','text','finish_reason','prompt_tokens','completion_tokens','total_tokens','parent_call_ids','decision','status','submission_confirmed']
def analyze(root):
    final=json.loads((root/'host/FINAL.json').read_text());rows=[];reference=None;equal=True
    for path in sorted(root.glob('pair-*/artifacts/cases/*/case.json')):
        d=json.loads(path.read_text());calls=d['calls'];selection=d['ready_work_selection'];choices=selection['choices'];accepted=[c for c in choices if c['accepted']]
        assert len(calls)==48 and len(accepted)==selection['accepted_choices']==48
        changed=sum(c['differs_from_fifo']for c in accepted);contended=sum(len(c['candidates'])>1 for c in accepted)
        assert changed==selection['changed_accepted'] and contended==selection['contended_accepted']
        native=d['close']['model_owner']['model_ready']['native_execution_profile']
        assert native['status']=='observed_worker_execution_profile' and native['batch_invariant_requested']is True and native['batch_invariant_active']is True
        normalized=sorted([{k:c.get(k)for k in FIELDS}for c in calls],key=lambda c:c['call_id'])
        value=dict(calls=normalized,outputs=d['outputs'])
        if reference is None:reference=value
        else:equal &= value==reference
        rows.append(dict(phase=path.parts[-5],case=d['case_id'],calls=len(calls),status=d['status'],source=d['public_git_commit'],
            accepted=len(accepted),contended_accepted=contended,changed_accepted=changed,
            all_candidate_count_histogram=dict(collections.Counter(len(c['candidates'])for c in choices)),
            full_relation_s=d['timing']['caller_to_full_relation_ready_s'],
            worker_to_full_relation_s=(d['timing']['full_relation_ready_ns']-d['process_start_ns'])/1e9,
            worker_wall_s=d['worker_wall_before_final_write_s'],
            model_api_span_s=max(c['model_end_monotonic']for c in calls)-min(c['model_start_monotonic']for c in calls),
            strict_fields_sha256=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest(),
            native_profile=native,capacity=d['capacity'],peak_usage=d['close']['peak_core_usage']))
    return dict(schema='semloom.ready_work_real.v1',source=final['source'],status=final['status'],failure=final['failure'],
        stop_reason=final['stop_reason'],lease_released=final['lease_released'],SHM_unchanged=final['SHM_unchanged'],
        GPU=final['GPU'],calibration=json.loads((root/'COST-PROFILE.json').read_text()),
        comparison=json.loads((root/'pair-1/COMPARISON.json').read_text()),all_calls_and_outputs_equal_including_calibration=equal,
        cases=rows,physical_calls=sum(x['calls']for x in rows),budget=final['global_budget'],
        conclusion='Strict functional comparison passed; no contended accepted choices, so no priority-policy performance effect was exercised.')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);a=p.parse_args();d=analyze(a.root);a.output.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:d[k]for k in ('status','stop_reason','all_calls_and_outputs_equal_including_calibration','physical_calls')},ensure_ascii=False));print(json.dumps(d['cases'],ensure_ascii=False))
