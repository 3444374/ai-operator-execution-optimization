"""Diagnostic-only snapshots of the unchanged transport's deque selection."""
from collections import deque
from contextlib import contextmanager
import time
from unittest.mock import patch


def row_metadata(row):
    task = row.task
    return dict(session_id=task.key.session_id, sequence=task.key.sequence,
                job_id=task.spec.job_id, payload_bytes=len(task.task.payload),
                cancelled=row.cancelled, sent=row.sent)


class RecordingDeque(deque):
    def __init__(self):
        super().__init__()
        self.before = None
        self.selected = []
        self.began_ns = None
        self.capture_ns = 0

    def popleft(self):
        started = time.monotonic_ns()
        if self.before is None:
            self.began_ns = started
            self.before = [row_metadata(row) for row in self]
        row = super().popleft()
        self.selected.append(row_metadata(row))
        self.capture_ns += time.monotonic_ns()-started
        return row

    def seal(self, data, capacity, window_bytes):
        began = time.monotonic_ns()
        if self.before is None or not self.selected:
            raise AssertionError('selection was not observed in the owning deque')
        selected = self.selected
        expected = [(row['session_id'],row['sequence'],row['payload_bytes']) for row in selected]
        actual = [(session,sequence,len(payload)) for session,sequence,payload in data]
        if actual != expected or selected != self.before[:len(selected)]:
            raise AssertionError('selected identities differ from the observed prefix')
        remaining = [row_metadata(row) for row in self]
        if remaining != self.before[len(selected):]:
            raise AssertionError('pending membership changed during atomic selection')
        job = selected[0]['job_id']
        used = sum(row['payload_bytes']+24 for row in selected)
        if not 1 <= len(selected) <= capacity or used > window_bytes or any(row['job_id']!=job for row in selected):
            raise AssertionError('observed selection differs from transport capacities')
        conditions = []
        if not remaining:
            conditions.append('empty')
        if len(selected) == capacity:
            conditions.append('row_limit')
        if remaining:
            if remaining[0]['job_id'] != job:
                conditions.append('different_job')
            if used+remaining[0]['payload_bytes']+24 > window_bytes:
                conditions.append('input_bytes')
        if not conditions:
            raise AssertionError('window has no explainable stop condition')
        value = dict(before=self.before, selected=selected, remaining=remaining,
                     capacity=capacity, window_bytes=window_bytes, selected_input_bytes=used,
                     stop_conditions=conditions, selection_started_ns=self.began_ns,
                     selection_ended_ns=time.monotonic_ns())
        self.before = None
        self.selected = []
        self.began_ns = None
        value['instrumented_deque_and_seal_ns'] = self.capture_ns+time.monotonic_ns()-began
        self.capture_ns = 0
        return value


class TraceScope:
    def __init__(self):
        self.samples = []

    def summary(self):
        return dict(windows=len(self.samples),
                    instrumented_deque_and_seal_ns=sum(row['instrumented_deque_and_seal_ns'] for row in self.samples),
                    observer_call_ns=sum(row['observer_call_ns'] for row in self.samples),
                    samples=self.samples)


@contextmanager
def trace_ready_windows(transport, module):
    """Install only in an empty, caller-owned diagnostic transport; preserve delegation."""
    if transport.pending or transport.rows:
        raise AssertionError('ready tracing requires a transport before task admission')
    original = module.iter_payload_batches
    if getattr(original,'ready_trace_active',False):
        raise AssertionError('another ready trace already owns the materializer hook')
    old_pending = transport.pending
    pending = RecordingDeque()
    scope = TraceScope()
    transport.pending = pending
    def observe(data,*args,**kwargs):
        snapshot = pending.seal(data,transport.capacity,transport.physical.window_bytes)
        snapshot['window_id'] = len(scope.samples)
        started = time.monotonic_ns()
        transport._observe('ray_ready_window',snapshot=snapshot)
        elapsed = time.monotonic_ns()-started
        scope.samples.append(dict(window_id=snapshot['window_id'],
            instrumented_deque_and_seal_ns=snapshot['instrumented_deque_and_seal_ns'],observer_call_ns=elapsed))
        return original(data,*args,**kwargs)
    observe.ready_trace_active = True
    try:
        with patch.object(module,'iter_payload_batches',observe):
            yield scope
    finally:
        old_pending.extend(pending)
        transport.pending = old_pending
