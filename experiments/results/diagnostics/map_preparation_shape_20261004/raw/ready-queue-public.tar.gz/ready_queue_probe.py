"""Observe existing queue selection with matched recording-off controls; no model work."""
import argparse
import json
from pathlib import Path
import signal
import statistics
import time

from src.baselines.common.private_artifacts import new_private_directory,write_private_json
from src.execution_provider.adapters import ray_map_transport as transport_module
import preparation_core_v2 as reference
from ready_window_trace import trace_ready_windows

TRACE_ON=False
SCOPES=[]
BASE_TRANSPORT=reference.RayMapTransport

class ObservedTransport(BASE_TRANSPORT):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if TRACE_ON:
            manager=trace_ready_windows(self,transport_module)
            try:
                scope=manager.__enter__()
            except BaseException:
                self.abort_startup()
                raise
            SCOPES.append((self,manager,scope))


def main():
    global TRACE_ON
    parser=argparse.ArgumentParser()
    parser.add_argument('output',type=Path)
    parser.add_argument('ray_tmp',type=Path)
    parser.add_argument('socket_root',type=Path)
    args=parser.parse_args()
    new_private_directory(args.output);new_private_directory(args.ray_tmp);new_private_directory(args.socket_root)
    reference.RayMapTransport=ObservedTransport
    reference.MAX_CALLS=4160
    import ray
    if ray.is_initialized():raise AssertionError('queue probe requires its own Ray runtime')
    start=time.monotonic_ns()
    ray.init(address='local',num_cpus=4,num_gpus=0,include_dashboard=False,object_store_memory=134217728,
             _node_ip_address='127.0.0.1',_temp_dir=str(args.ray_tmp))
    ray_ready=time.monotonic_ns()
    endpoint=reference.Endpoint();cases=[]
    original_materializer=transport_module.iter_payload_batches
    def timeout(signum,frame):raise TimeoutError('one ready-queue case exceeded sixty seconds')
    signal.signal(signal.SIGALRM,timeout)
    cells=tuple((shape,backend,trace) for shape in ('one','two') for backend in ('daft','arrow') for trace in (False,True))
    try:
        for phase_index,(phase,repeat,rows) in enumerate([('check',0,8),('warmup',0,128)]+[('measurement',i,128) for i in range(1,4)]):
            order=cells[phase_index%len(cells):]+cells[:phase_index%len(cells)]
            matched=[]
            for shape,backend,trace in order:
                if time.monotonic_ns()-start>600*10**9:raise TimeoutError('ready-queue suite exceeded ten minutes')
                TRACE_ON=trace
                name=f'{phase}-{repeat}-{shape}-{backend}-'+('on' if trace else 'off')
                path=args.output/name
                signal.alarm(60)
                try:
                    result=reference.run_case(path,shape,backend,rows,endpoint,ray.get_runtime_context().gcs_address,
                                              args.socket_root/f's{len(cases)}')
                finally:
                    signal.alarm(0)
                    for transport,manager,scope in reversed(SCOPES):manager.__exit__(None,None,None)
                traces=[scope.summary() for transport,manager,scope in SCOPES]
                if bool(traces)!=trace or len(traces)>1 or transport_module.iter_payload_batches is not original_materializer:
                    raise AssertionError('diagnostic hook ownership was not restored')
                if trace:
                    if not traces[0]['windows']:raise AssertionError('no queue snapshot was recorded')
                    write_private_json(path/'trace-cost.json',traces[0])
                SCOPES.clear()
                result.update(phase=phase,repeat=repeat,observation=trace,case_name=name)
                cases.append(result);matched.append(result)
                write_private_json(args.output/f'progress-{len(cases)}.json',dict(case_name=name,status=result['status'],http_requests=result['http_requests']))
            if any(case['request_hashes']!=matched[0]['request_hashes'] for case in matched[1:]):
                raise AssertionError('request bytes differ between ready-queue configurations')
        if len(endpoint.calls)!=4160 or endpoint.active or endpoint.failures:raise AssertionError('finite HTTP totals differ')
    finally:
        signal.alarm(0);endpoint.close();ray.shutdown()
    summary=dict(status='passed',cases=cases,http_requests=len(endpoint.calls),model_requests=0,pg_queries=0,
        comparison_role='project_scheduled_method',formal_baseline_eligible=False,
        ray_startup_ms=(ray_ready-start)/1e6,suite_seconds=(time.monotonic_ns()-start)/1e9,
        unchanged_reference='d4edc80393ae0c605c1386008024cbe333d5f058',
        metrics={f'{shape}-{backend}-'+('on' if trace else 'off'):{name:dict(values=[case[name] for case in cases
                 if case['phase']=='measurement' and case['shape']==shape and case['payload_backend']==backend and case['observation']==trace],
                 median=statistics.median(case[name] for case in cases if case['phase']=='measurement' and case['shape']==shape and case['payload_backend']==backend and case['observation']==trace))
                 for name in ('consume_ms','complete_case_ms','gateway_prepare_ms')}
                 for shape,backend,trace in cells})
    write_private_json(args.output/'summary.json',summary)
    print(json.dumps({key:value for key,value in summary.items() if key!='cases'}))


if __name__=='__main__':main()
