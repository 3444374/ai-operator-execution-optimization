import json,os,signal,subprocess,sys,time
from pathlib import Path
from src.baselines.common.private_artifacts import write_private_json
from src.baselines.common.redact import redact_text
root=Path('/root/autodl-tmp/experiment-artifacts/ready-queue-20261004a')
if json.loads((root/'preflight.json').read_text())['status']!='ok' or not json.loads((root/'tests.json').read_text())['passed']:
 raise AssertionError('ready-queue prerequisites did not pass')
active=[]
for line in subprocess.check_output(['ps','-eo','pid=,stat=,args='],text=True).splitlines():
 f=line.split(None,2)
 if len(f)==3 and not f[1].startswith('Z') and any(s in f[2] for s in ['gcs_server','raylet','ready_queue_probe.py']):active.append(int(f[0]))
if active:raise AssertionError('unexpected active data runtime')
start=time.monotonic();process=None;code=None;status='failed'
def timeout(signum,frame):raise TimeoutError('ready-queue diagnostic exceeded ten minutes')
signal.signal(signal.SIGALRM,timeout);signal.alarm(600)
try:
 process=subprocess.Popen([sys.executable,'-u',str(root/'ready_queue_probe.py'),str(root/'suite'),'/root/autodl-tmp/rq04a','/root/autodl-tmp/rqs04a'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 write_private_json(root/'runner.json',dict(supervisor_pid=os.getpid(),probe_pid=process.pid,started_utc=time.time(),max_http_requests=4160,model_requests=0))
 with (root/'probe.log').open('x') as stream:
  for line in process.stdout:stream.write(redact_text(line));stream.flush()
 code=process.wait(timeout=10);status='passed' if code==0 else 'failed'
except BaseException as error:
 with (root/'failure.log').open('x') as stream:stream.write(redact_text(type(error).__name__+chr(10)))
 if process is not None and process.poll() is None:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=15)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
 if process is not None:code=process.returncode
finally:
 signal.alarm(0)
 write_private_json(root/'runner-exit.json',dict(status=status,returncode=code,elapsed_seconds=time.monotonic()-start,ended_utc=time.time(),model_requests=0))
