import asyncio
from collections import deque
from dataclasses import replace
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from ready_window_trace import RecordingDeque, trace_ready_windows
from src.execution_provider.adapters import ray_map_transport as transport_module
from src.execution_provider.adapters.model_config import FixedModelConfig
from src.execution_provider.adapters.ray_map_transport import RayMapConfig, RayMapTransport
from src.experiments.map_observation_probe import SyntheticTable
from tests.execution_provider.test_ray_map_transport import FakeRay, task


def row(sequence,job='A',payload=b'data',session=0):
    return SimpleNamespace(task=SimpleNamespace(key=SimpleNamespace(session_id=session,sequence=sequence),
        spec=SimpleNamespace(job_id=job),task=SimpleNamespace(payload=payload)),cancelled=False,sent=False)


def data(rows):
    return tuple((r.task.key.session_id,r.task.key.sequence,r.task.task.payload) for r in rows)


def select(pending,capacity,window):
    selected=[];size=0
    while pending and len(selected)<capacity:
        current=pending[0];amount=len(current.task.task.payload)+24
        if selected and (size+amount>window or current.task.spec.job_id!=selected[0].task.spec.job_id):break
        selected.append(pending.popleft());size+=amount
    return data(selected)


class RecorderTests(unittest.TestCase):
    def inspect(self,rows,capacity=4,window=1024):
        pending=RecordingDeque();pending.extend(rows)
        selected=select(pending,capacity,window)
        snapshot=pending.seal(selected,capacity,window)
        return pending,snapshot

    def test_interleaving_records_same_job_rows_after_the_prefix(self):
        pending,s=self.inspect([row(0),row(1,'B'),row(2),row(3,'B')])
        self.assertEqual([r['sequence'] for r in s['selected']],[0])
        self.assertEqual([r['sequence'] for r in s['before'] if r['job_id']=='A'],[0,2])
        self.assertEqual(s['stop_conditions'],['different_job'])
        self.assertEqual(len(pending),3)

    def test_single_ready_row_records_no_hidden_input(self):
        pending,s=self.inspect([row(0)])
        self.assertEqual(len(s['before']),1)
        self.assertEqual(s['stop_conditions'],['empty'])

    def test_full_same_job_window_preserves_all_members(self):
        pending,s=self.inspect([row(i) for i in range(4)])
        self.assertEqual(len(s['selected']),4)
        self.assertEqual(s['stop_conditions'],['empty','row_limit'])

    def test_input_byte_stop_is_separate_from_job_stop(self):
        pending,s=self.inspect([row(0,payload=b'1234'),row(1,payload=b'1234')],window=40)
        self.assertEqual(s['selected_input_bytes'],28)
        self.assertEqual(s['stop_conditions'],['input_bytes'])

    def test_joint_stop_conditions_are_not_assigned_a_false_unique_reason(self):
        pending,s=self.inspect([row(0),row(1,'B')],window=40)
        self.assertEqual(s['stop_conditions'],['different_job','input_bytes'])

    def test_cancelled_member_and_different_sessions_keep_original_identity(self):
        first,second=row(0,session=2),row(0,session=3)
        second.cancelled=True
        pending,s=self.inspect([first,second])
        self.assertEqual([r['session_id'] for r in s['selected']],[2,3])
        self.assertEqual([r['cancelled'] for r in s['selected']],[False,True])

    def test_wrong_payload_key_fails_instead_of_guessing_a_trace(self):
        pending=RecordingDeque();pending.append(row(0));pending.popleft()
        with self.assertRaisesRegex(AssertionError,'identities'):
            pending.seal(((9,0,b'data'),),4,1024)

    def test_state_change_during_selection_is_detected(self):
        pending=RecordingDeque();pending.extend([row(0),row(1)]);first=pending.popleft();pending.append(row(2))
        with self.assertRaisesRegex(AssertionError,'membership'):
            pending.seal(data([first]),4,1024)

    def test_windows_reset_without_retaining_row_objects(self):
        pending,s=self.inspect([row(0),row(1,'B')])
        selected=select(pending,4,1024);second=pending.seal(selected,4,1024)
        self.assertEqual(len(second['before']),1)
        self.assertIsNone(pending.before)
        self.assertEqual(pending.selected,[])

    def test_hook_passes_the_exact_tuple_and_restores_after_caller_error(self):
        seen=[];events=[]
        module=SimpleNamespace(iter_payload_batches=lambda *args,**kwargs:seen.append((args,kwargs)) or 'stream')
        original=module.iter_payload_batches;old=deque()
        transport=SimpleNamespace(pending=old,rows={},capacity=4,physical=SimpleNamespace(window_bytes=1024),
            _observe=lambda event,**kwargs:events.append(dict(event=event,**kwargs)))
        with self.assertRaisesRegex(RuntimeError,'consumer'):
            with trace_ready_windows(transport,module) as scope:
                transport.pending.extend([row(0),row(1,'B')]);selected=select(transport.pending,4,1024)
                self.assertEqual(module.iter_payload_batches(selected,'limits',batch_rows=4),'stream')
                self.assertIs(seen[0][0][0],selected)
                self.assertEqual(seen[0][1],dict(batch_rows=4))
                self.assertEqual(scope.summary()['windows'],1)
                raise RuntimeError('consumer failed')
        self.assertIs(module.iter_payload_batches,original)
        self.assertIs(transport.pending,old)
        self.assertEqual(len(old),1)
        self.assertEqual(events[0]['event'],'ray_ready_window')

    def test_nested_owner_is_rejected(self):
        module=SimpleNamespace(iter_payload_batches=lambda *args:None)
        t=lambda:SimpleNamespace(pending=deque(),rows={},capacity=4,physical=SimpleNamespace(window_bytes=1024),_observe=lambda *args,**kwargs:None)
        with trace_ready_windows(t(),module):
            with self.assertRaisesRegex(AssertionError,'another'):
                with trace_ready_windows(t(),module):pass


class TransportTests(unittest.IsolatedAsyncioTestCase):
    async def test_actual_flush_records_two_interleaved_jobs_without_changing_calls(self):
        sent=[];events=[]
        async def execute(table,index,template):
            sent.append(template.key)
            return template.key,table['payload'][index].as_py(),1,2
        ray=FakeRay(execute)
        transport=RayMapTransport(FixedModelConfig('http://localhost/fixture','model',1000),4,events.append,
            physical=RayMapConfig('fixture-cluster',1,4,1024,2048),ray_api=ray)
        requests=[replace(task(i),spec=replace(task(i).spec,job_id='A' if i%2==0 else 'B')) for i in range(4)]
        def batches(rows,*args,**kwargs):
            yield SyntheticTable(rows)
        try:
            with patch.object(transport_module,'iter_payload_batches',batches):
                with trace_ready_windows(transport,transport_module):
                    results=await asyncio.gather(*(transport.execute(request,'model') for request in requests))
                    await transport.close()
            self.assertEqual(results,[b'payload']*4)
            self.assertEqual(set(sent),{request.key for request in requests})
            snapshots=[event['snapshot'] for event in events if event['event']=='ray_ready_window']
            self.assertEqual([len(s['selected']) for s in snapshots],[1,1,1,1])
            self.assertEqual([r['job_id'] for r in snapshots[0]['before']],['A','B','A','B'])
            self.assertEqual((transport.rows,transport.blocks,transport.used_bytes),({}, {}, 0))
        finally:
            if transport.actors:await transport.close()


if __name__=='__main__':
    unittest.main(verbosity=2)
