import json,os,signal,subprocess,sys,time
from pathlib import Path
from src.baselines.common.private_artifacts import write_private_json
from src.baselines.common.redact import redact_text
root=Path('/root/autodl-tmp/experiment-artifacts/map-preparation-20261004a')
if json.loads((root/'preflight.json').read_text())['status']!='ok' or not json.loads((root/'tests.json').read_text())['passed']:
 raise AssertionError('preparation prerequisites did not pass')
active=[]
for line in subprocess.check_output(['ps','-eo','pid=,stat=,args='],text=True).splitlines():
 f=line.split(None,2)
 if len(f)==3 and not f[1].startswith('Z') and any(s in f[2] for s in ['gcs_server','raylet','preparation_core.py','preparation_component.py']):active.append(int(f[0]))
if active:raise AssertionError('unexpected active data runtime or diagnostic')
start=time.monotonic();process=None;status='failed';code=None;completed=[]
def timeout(signum,frame):raise TimeoutError('combined preparation diagnostic exceeded ten minutes')
signal.signal(signal.SIGALRM,timeout);signal.alarm(600)
try:
 for kind,arguments in [('component',[str(root/'preparation_component.py'),str(root/'component')]),('core',[str(root/'preparation_core.py'),str(root/'suite'),'/root/autodl-tmp/mps4r01','/root/autodl-tmp/mps4s01'])]:
  process=subprocess.Popen([sys.executable,'-u',*arguments],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
  write_private_json(root/f'{kind}-runner.json',dict(supervisor_pid=os.getpid(),probe_pid=process.pid,started_utc=time.time(),model_requests=0,max_http_requests=2080 if kind=='core' else 0))
  with (root/f'{kind}.log').open('x') as stream:
   for line in process.stdout:stream.write(redact_text(line));stream.flush()
  code=process.wait(timeout=10)
  if code:raise RuntimeError(f'{kind} preparation diagnostic failed')
  completed.append(kind)
 status='passed'
except BaseException as error:
 with (root/'failure.log').open('x') as stream:stream.write(redact_text(type(error).__name__+chr(10)))
 if process is not None and process.poll() is None:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=15)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
 if process is not None:code=process.returncode
finally:
 signal.alarm(0)
 write_private_json(root/'runner-exit.json',dict(status=status,returncode=code,completed=completed,elapsed_seconds=time.monotonic()-start,model_requests=0,ended_utc=time.time()))
