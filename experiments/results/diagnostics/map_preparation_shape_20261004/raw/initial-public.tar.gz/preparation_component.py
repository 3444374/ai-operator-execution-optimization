"""Replay fixed finite windows through actual payload preparation, without Ray or HTTP."""
import argparse
import cProfile
import hashlib
import importlib
import json
from pathlib import Path
import pstats
import socket
import statistics
import time

from src.baselines.common.private_artifacts import new_private_directory, write_private_json
from src.data.materializers.payloads import PayloadBatchLimits, iter_payload_batches
from src.execution_provider.adapters.incremental_execution import prepare_map_task
from src.execution_provider.completion import CompletionRequest
from src.execution_provider.semantic_map import SemanticMapPlan
from src.execution_provider.wire import v6
from src.execution_provider.wire.framing import encode_frame


def input_rows(count):
    plan = SemanticMapPlan('Echo.', 'model', 8)
    opened = json.loads(encode_frame(v6.build_open_message(plan))[4:])
    context = v6.validate_open(opened)
    rows = []
    for sequence in range(count):
        message = json.loads(encode_frame(v6.build_task_message(plan, sequence=sequence,
            input_value=f'row:{sequence}'))[4:])
        _, digest = v6.validate_task(message, expected_sequence=sequence, open_context=context)
        request = CompletionRequest(digest, context.model_id, tuple(dict(m) for m in message['canonical_messages']),
                                    dict(opened['generation_constraints']), protocol_version=6)
        rows.append((1, sequence, prepare_map_task(request, sequence).payload))
    return tuple(rows)


def run_case(output, backend, window_rows, rows):
    new_private_directory(output)
    windows = tuple(rows[start:start + window_rows] for start in range(0, len(rows), window_rows))
    began = time.monotonic_ns()
    observed, observations, peak = [], [], 0
    for window_index, window in enumerate(windows):
        stream = iter_payload_batches(window, PayloadBatchLimits(4, 2097152), batch_rows=4, backend=backend)
        try:
            while True:
                start = time.monotonic_ns()
                table = next(stream, None)
                ended = time.monotonic_ns()
                observations.append(dict(window=window_index, stage='next' if table is not None else 'exhaust',
                    elapsed_ns=ended-start, rows=table.num_rows if table is not None else 0))
                if table is None:
                    break
                if not 1 <= table.num_rows <= 4 or table.get_total_buffer_size() > 4194304:
                    raise AssertionError('finite table capacity differs')
                peak = max(peak, table.get_total_buffer_size())
                observed.extend(tuple(row[name] for name in ('session_id', 'sequence', 'payload'))
                                for row in table.to_pylist())
                del table
        finally:
            start = time.monotonic_ns()
            stream.close()
            observations.append(dict(window=window_index, stage='close', elapsed_ns=time.monotonic_ns()-start, rows=0))
    ended = time.monotonic_ns()
    if tuple(observed) != rows:
        raise AssertionError('complete row keys or payload bytes differ')
    result = dict(status='passed', backend=backend, window_rows=window_rows, input_rows=len(rows),
        windows=len(windows), total_ms=(ended-began)/1e6, observations=observations,
        max_table_buffer_bytes=peak, model_requests=0, http_requests=0, ray_calls=0, pg_queries=0,
        payload_sha256=[hashlib.sha256(row[2]).hexdigest() for row in rows])
    write_private_json(output/'result.json', result)
    return result


def profile_rows(stats):
    result = []
    for (filename, line, name), (primitive, calls, self_time, cumulative, callers) in stats.stats.items():
        # Use stable package-relative identities rather than machine paths.
        if '/site-packages/' in filename:
            filename = filename.split('/site-packages/', 1)[1]
        elif '/code/' in filename:
            filename = 'code/' + filename.split('/code/', 1)[1]
        else:
            filename = Path(filename).name
        result.append(dict(file=filename, line=line, function=name, calls=calls, primitive_calls=primitive,
                           self_seconds=self_time, cumulative_seconds=cumulative))
    return sorted(result, key=lambda row: row['cumulative_seconds'], reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    new_private_directory(args.output)
    suite_start = time.monotonic_ns()
    # This component has no intended socket access. Reject any accidental connect.
    def reject_connect(*args, **kwargs):
        raise AssertionError('network connection is outside the fixed-window component')
    socket.socket.connect = reject_connect
    imports = {}
    for package in ('pyarrow', 'daft'):
        began = time.monotonic_ns()
        importlib.import_module(package)
        imports[package] = (time.monotonic_ns()-began)/1e6
    all_rows = input_rows(128)
    cells = tuple((backend, width) for width in (1, 2, 4) for backend in ('daft', 'arrow'))
    cases, profiles = [], []
    try:
        for index, (phase, repeat, count) in enumerate([('check', 0, 8), ('warmup', 0, 128)] +
                                                       [('measurement', i, 128) for i in range(1, 4)]):
            order = cells[index%len(cells):] + cells[:index%len(cells)]
            for backend, width in order:
                if time.monotonic_ns()-suite_start > 300*10**9:
                    raise TimeoutError('fixed-window component exceeded five minutes')
                result = run_case(args.output/f'{phase}-{repeat}-{backend}-{width}', backend, width, all_rows[:count])
                result.update(phase=phase, repeat=repeat)
                cases.append(result)
        for backend in ('daft', 'arrow'):
            for width in (1, 4):
                profiler = cProfile.Profile()
                profiler.enable()
                try:
                    result = run_case(args.output/f'profile-{backend}-{width}', backend, width, all_rows)
                finally:
                    profiler.disable()
                stats = profile_rows(pstats.Stats(profiler))
                profiler.dump_stats(str(args.output/f'profile-{backend}-{width}.pstats'))
                write_private_json(args.output/f'profile-{backend}-{width}.json', stats)
                profiles.append(dict(backend=backend, window_rows=width, total_ms=result['total_ms'],
                                     functions=len(stats)))
    except BaseException as error:
        write_private_json(args.output/'failure.json', dict(type=type(error).__name__,
            completed_cases=len(cases), model_requests=0, http_requests=0, pg_queries=0))
        raise
    rows_prepared = sum(case['input_rows'] for case in cases) + 128*len(profiles)
    if rows_prepared != 3632:
        raise AssertionError('component row budget differs')
    summary = dict(status='passed', prepared_rows=rows_prepared, cases=cases, profiles=profiles,
        python_import_ms=imports, suite_seconds=(time.monotonic_ns()-suite_start)/1e9,
        model_requests=0, http_requests=0, pg_queries=0, ray_calls=0,
        metrics={f'{backend}-{width}':dict(values=[c['total_ms'] for c in cases
                    if c['backend']==backend and c['window_rows']==width and c['phase']=='measurement'],
            median=statistics.median(c['total_ms'] for c in cases
                    if c['backend']==backend and c['window_rows']==width and c['phase']=='measurement'))
                 for backend, width in cells})
    write_private_json(args.output/'summary.json', summary)
    print(json.dumps({key: value for key, value in summary.items() if key not in ('cases',)}))


if __name__ == '__main__':
    main()
