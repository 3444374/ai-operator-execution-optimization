"""Finite real-Ray data preparation diagnostic; all HTTP is a loopback fixture."""
import argparse
from dataclasses import asdict
from functools import partial
import gzip
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import socket
import statistics
import threading
import time

from src.baselines.common.private_artifacts import new_private_directory, write_private_json
from src.baselines.common.redact import redact_json_values
from src.execution_provider.adapters.async_fixed_model import exception_details
from src.execution_provider.adapters.incremental_execution import build_fixed_model_execution
from src.execution_provider.adapters.model_config import FixedModelConfig
from src.execution_provider.adapters.ray_map_transport import RayMapConfig, RayMapTransport
from src.execution_provider.multiplexed_gateway import MultiSessionMapGateway
from src.execution_provider.session_dispatch import run_session
from src.experiments.gateway_isolation_probe import Capture, Client, output_value
from src.scheduling.core.session_jobs import shared_compute_job_budget
from src.execution_provider.semantic_map import SemanticMapPlan
from src.execution_provider.completion import CompletionRequest
from src.execution_provider.adapters.incremental_execution import prepare_map_task
from src.execution_provider.wire import v6
from src.execution_provider.wire.framing import encode_frame, read_frame
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.choice_gateway_observer import _guard_remote_request
from src.experiments.expected_requests import ExpectedRequests, expected_request_manifest

CAPACITY, MAX_CALLS = 4, 2080
MAX_JOB_ROWS = 128


class Endpoint:
    def __init__(self):
        self.lock = threading.Lock()
        self.calls, self.active, self.peak, self.failures = [], 0, 0, []
        self.capture = None
        endpoint = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def log_message(self, *args):
                pass

            def do_POST(self):
                counted = False
                try:
                    if self.path != '/fixture' or not 0 < int(self.headers['Content-Length']) <= 1048576:
                        raise AssertionError('fixture route or body size differs')
                    body = self.rfile.read(int(self.headers['Content-Length']))
                    request = json.loads(body)
                    label, sequence = request['messages'][-1]['content'].split(':')
                    sequence = int(sequence)
                    if request['model'] != 'model' or label != 'row' or not 0 <= sequence < 128:
                        raise AssertionError('fixture semantic input differs')
                    with endpoint.lock:
                        if len(endpoint.calls) >= MAX_CALLS or endpoint.active >= CAPACITY:
                            raise AssertionError('finite fixture request capacity exceeded')
                        endpoint.active += 1
                        endpoint.peak = max(endpoint.peak, endpoint.active)
                        counted = True
                        capture = endpoint.capture
                        fields = dict(label=label, sequence=sequence,
                                      request_sha256=hashlib.sha256(body).hexdigest())
                        endpoint.calls.append(fields)
                        capture.record('loopback_http_started', active=endpoint.active, **fields)
                    time.sleep(.010 + sequence % 3 * .001)
                    with endpoint.lock:
                        endpoint.active -= 1
                        counted = False
                    capture.record('loopback_service_ended', **fields)
                    response = json.dumps(dict(model='model', choices=[dict(message=dict(
                        content=output_value(label, sequence, 'platform')), finish_reason='stop')],
                        usage=dict(prompt_tokens=2, completion_tokens=1))).encode()
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(response)))
                    self.end_headers()
                    self.wfile.write(response)
                    self.wfile.flush()
                    capture.record('loopback_http_finished', **fields)
                except BaseException as error:
                    endpoint.failures.append(type(error).__name__)
                    self.close_connection = True
                finally:
                    if counted:
                        with endpoint.lock:
                            endpoint.active -= 1

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, name='loopback-fixture')
        self.thread.start()
        self.config = FixedModelConfig(f'http://127.0.0.1:{self.server.server_port}/fixture', 'model', 5000)

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(3)
        if self.thread.is_alive() or self.active:
            raise AssertionError('loopback fixture did not stop')



class LogicalClient(Client):
    """Vary Job membership while keeping the complete model input set identical."""
    def __init__(self, path, label, capture, offset):
        super().__init__(path, label, capture)
        self.offset = offset

    def offer(self, sequence):
        ordinal = self.offset + sequence
        message = v6.build_task_message(self.plan, sequence=sequence, input_value=f'row:{ordinal}')
        self.capture.record('fixture_offer_started', label=self.label, sequence=sequence, ordinal=ordinal)
        self.stream.sendall(encode_frame(message))
        accepted = read_frame(self.stream)
        if (accepted is None or accepted.get('type') != 'accepted'
                or accepted.get('protocol_version') != 6 or accepted.get('sequence') != str(sequence)
                or accepted.get('accepted_prefix_count') != 1):
            raise AssertionError('fixture input not accepted exactly once')
        self.digests[sequence] = message['semantic_payload_digest']
        self.capture.record('fixture_offer_accepted', label=self.label, sequence=sequence, ordinal=ordinal)

    def consume(self, rows, scenario, reader):
        for _ in range(rows):
            self.stream.sendall(encode_frame(dict(type='poll', protocol_version=6)))
            message = read_frame(self.stream)
            if message is None or message.get('type') != 'completion':
                raise AssertionError('fixture completion missing')
            sequence = int(message['sequence'])
            if sequence in self.results or sequence not in self.digests:
                raise AssertionError('fixture result association or multiplicity differs')
            completion = v6.validate_completion(message, expected_sequence=sequence,
                payload_digest=self.digests[sequence], open_context=self.context)
            ordinal = self.offset + sequence
            if completion.raw_output != output_value('row', ordinal, scenario):
                raise AssertionError('fixture output content differs')
            self.results.append(sequence)
            self.capture.record('fixture_result_validated', label=self.label, sequence=sequence, ordinal=ordinal,
                                output_sha256=hashlib.sha256(completion.raw_output.encode()).hexdigest())
        if sorted(self.results) != list(range(rows)):
            raise AssertionError('fixture ordered reconstruction differs')
        self.capture.record('fixture_consumer_completed', label=self.label)


def run_case(output, shape, backend, total_rows, endpoint, address, socket_path):
    arm = f"{shape}-{backend}"
    labels = ("A",) if shape == "one" else ("A", "B")
    rows = total_rows // len(labels)
    if rows * len(labels) != total_rows:
        raise ValueError("aggregate input must divide evenly among producing Jobs")
    new_private_directory(output)
    capture = Capture()
    endpoint.capture = capture
    before = len(endpoint.calls)
    stop, ready = threading.Event(), threading.Event()
    gateways, transports, clients, producers, errors = [], [], [], [], []
    began = time.monotonic_ns()
    ready_ns = None
    plan=SemanticMapPlan('Echo.','model',8)
    opened=json.loads(encode_frame(v6.build_open_message(plan))[4:])
    context=v6.validate_open(opened)
    bodies=[]
    for job_index, label in enumerate(labels):
        for i in range(rows):
            message=json.loads(encode_frame(v6.build_task_message(plan,sequence=i,input_value=f'row:{job_index * rows + i}'))[4:])
            _,digest=v6.validate_task(message,expected_sequence=i,open_context=context)
            request=CompletionRequest(digest,context.model_id,tuple(dict(m) for m in message['canonical_messages']),dict(opened['generation_constraints']),protocol_version=6)
            bodies.append(prepare_map_task(request,i).payload)
    ledger=CellBudgetLedger.create(output/'ledger.sqlite',AttemptBudget('preparation.shape.real-ray.fixture',total_rows),deadline_utc=time.time()+600)
    ledger.reserve_unit('query',total_rows)
    counter=ledger.claim_shared_unit('query')
    budget_ready=time.monotonic_ns()
    expected_requests=ExpectedRequests(expected_request_manifest([json.loads(b) for b in bodies]),available_attempts=total_rows)
    def observe_request(attempt,body):
        expected_requests.accept(json.loads(body))
        capture.record('fixture_request_counted',attempt=attempt,request_sha256=hashlib.sha256(body).hexdigest())
    def guard(task):
        return _guard_remote_request(task,counter,observe_request,capture)
    counter_snapshot=None
    handles_closed=False
    result = dict(arm=arm, shape=shape, payload_backend=backend, producing_jobs=len(labels),
                  total_rows=total_rows, rows_per_job=rows, status='failed', errors=errors,
                  started_utc=time.time(),
                  model_requests=0, pg_queries=0, source_identity='external finite producer')

    def transport_factory(config, maximum, observer):
        value = RayMapTransport(config, maximum, observer, before_request=guard, physical=RayMapConfig(
            address, 1, 4, 2097152, 4194304, payload_backend=backend))
        transports.append(value)
        return value

    def factory(config, **kwargs):
        kwargs.pop('execute')
        return build_fixed_model_execution(config, **kwargs, allocate_job=shared_compute_job_budget,
            transport_factory=transport_factory)

    path = str(socket_path)
    if len(path.encode()) >= 100:
        raise AssertionError('UDS path exceeds platform check allowance')

    def serve():
        gateway = None
        try:
            with socket.socket(socket.AF_UNIX) as listener:
                gateway = MultiSessionMapGateway(endpoint.config, max_jobs=3, max_connections=8,
                    max_tasks=3*MAX_JOB_ROWS, max_active_requests=4, input_bytes=12582912, result_bytes=3*MAX_JOB_ROWS*1048576,
                    frame_timeout_ms=10000, observer=capture, execution_factory=factory)
                gateways.append(gateway)
                listener.bind(path)
                listener.listen(8)
                ready.set()
                gateway.serve(listener, stop, handler=partial(run_session,
                    completion_adapter=gateway, response_delay_ms=0, tamper_evidence_digest=False,
                    disconnect_on_task=False, completion_fixture=None))
        except BaseException as error:
            errors.append(dict(where='gateway', type=type(error).__name__, reason=exception_details(error)))
        finally:
            ready.set()
            if gateway is not None:
                try:
                    if not gateway.close():
                        raise AssertionError('backend close was not confirmed')
                except BaseException as error:
                    errors.append(dict(where='gateway_close', type=type(error).__name__, reason=exception_details(error)))

    release_sources = threading.Event()

    def produce(client):
        try:
            if not release_sources.wait(10):
                raise TimeoutError("source release was not observed")
            for sequence in range(rows):
                client.offer(sequence)
            client.consume(rows, 'platform', ready)
        except BaseException as error:
            errors.append(dict(where=client.label, type=type(error).__name__, reason=exception_details(error)))

    thread = threading.Thread(target=serve, name='gateway-platform-owner')
    try:
        thread.start()
        if not ready.wait(40) or not gateways or errors:
            raise AssertionError('gateway startup did not complete')
        ready_ns = time.monotonic_ns()
        for job_index, label in enumerate((*labels, 'C')):
            offset = job_index * rows if label != 'C' else -1
            clients.append(LogicalClient(path, label, capture, offset))
            clients[-1].stream.settimeout(10)
        if any(r.peer != (os.getuid(), os.getpid()) for r in gateways[0].queries.registrations.values()):
            raise AssertionError('Linux gateway peer identity differs')
        clients[-1].offer(0)
        capture.record('fixture_cancel_requested', label='C')
        clients[-1].control.close()
        for client in clients[:-1]:
            producer = threading.Thread(target=produce, args=(client,), name=f'producer-{client.label}')
            producers.append(producer)
            producer.start()
        release_sources.set()
        deadline = time.monotonic() + 25
        while any(p.is_alive() for p in producers):
            if errors or time.monotonic() > deadline:
                raise AssertionError('finite producer failed or timed out')
            for p in producers:
                p.join(.005)
        result['consume_ended_ns'] = time.monotonic_ns()
    except BaseException as error:
        errors.append(dict(where='driver', type=type(error).__name__, reason=exception_details(error)))
    finally:
        for client in clients:
            client.close()
        stop.set()
        if gateways:
            gateways[0].request_stop()
        for p in producers:
            p.join(15)
        thread.join(15)
        if thread.is_alive() or any(p.is_alive() for p in producers):
            errors.append(dict(where='threads', type='UnconfirmedExit'))
    ended = time.monotonic_ns()
    counter_snapshot=dict(attempts=counter.attempts,remaining=counter.remaining)
    ledger.close_shared_unit('query')
    handles_closed=True
    counter_closed=time.monotonic_ns()
    try:
        events = capture.events
        http = [e for e in events if e['event'] == 'loopback_http_started']
        finished = [e for e in events if e['event'] == 'loopback_http_finished']
        expected = {('row', i) for i in range(total_rows)}
        for observed in (http, finished):
            if len(observed) != total_rows or {(e['label'], e['sequence']) for e in observed} != expected:
                raise AssertionError('HTTP identity or multiplicity differs')
        terminals = [e for e in events if e['event'] == 'terminal']
        if len(terminals) != total_rows or len({tuple(e['key'].values()) for e in terminals}) != total_rows:
            raise AssertionError('Core terminal identity differs')
        usage = asdict(gateways[0].engine.capacity.usage())
        if any(usage.values()) or endpoint.failures or errors:
            raise AssertionError('Core resources, fixture or gateway exit differ')
        if any(t.rows or t.blocks or t.unknown or t.used_bytes for t in transports):
            raise AssertionError('Ray payload references remain charged')
        peaks = {name:max(e['usage'][name] for e in events if 'usage' in e) for name in usage}
        if peaks['active_requests'] > 4 or peaks['held_tasks'] > 3*MAX_JOB_ROWS or peaks['input_bytes'] > 12582912 or peaks['result_bytes'] > 3*MAX_JOB_ROWS*1048576:
            raise AssertionError('Core capacity exceeded')
        offered = [e['monotonic_ns'] for e in events if e['event'] == 'fixture_offer_started' and e['label'] in labels]
        consumed = [e['monotonic_ns'] for e in events if e['event'] == 'fixture_consumer_completed']
        c_job = [e['job_id'] for e in events if e['event'] == 'job_opened'][-1]
        c_drain = [e for e in events if e['event'] == 'job_drained' and e['job_id'] == c_job]
        if len(c_drain) != 1:
            raise AssertionError('queued cancellation drain differs')
        c_start = next(e['monotonic_ns'] for e in events if e['event'] == 'fixture_cancel_requested')
        counted=[e for e in events if e['event']=='fixture_request_counted']
        if sorted(e['attempt'] for e in counted)!=list(range(1,total_rows+1)) or expected_requests.remaining or counter_snapshot['attempts']!=total_rows or ledger.snapshot()['allocated_requests']!=total_rows or not handles_closed:
            raise AssertionError('prepaid count, identity or handles differ')
        result.update(budget_setup_ms=(budget_ready-began)/1e6,counter_snapshot=counter_snapshot,
            budget_handle_cleanup_ms=(counter_closed-ended)/1e6,budget_handles_closed=handles_closed,
            allocated_requests=ledger.snapshot()['allocated_requests'])
        result.update(status='passed', core_final_usage=usage, core_observed_peak=peaks,
            http_requests=len(endpoint.calls)-before, gateway_prepare_ms=(ready_ns-began)/1e6,
            consume_ms=(max(consumed)-min(offered))/1e6,
            queued_cancel_ms=(c_drain[0]['monotonic_ns']-c_start)/1e6,
            close_ms=(ended-result['consume_ended_ns'])/1e6,
            complete_case_ms=(counter_closed-began)/1e6,
            request_hashes={f"{e['label']}:{e['sequence']}":e['request_sha256'] for e in http},
            actual_http_peak=max(e['active'] for e in http),
            kernel_peer_credentials='unpatched SO_PEERCRED', transport_drained=True, ended_utc=time.time())
    except BaseException as error:
        errors.append(dict(where='analysis', type=type(error).__name__, reason=exception_details(error)))
        result['status']='failed'
    with gzip.open(output/'events.jsonl.gz','xt') as stream:
        for event in capture.events:
            stream.write(json.dumps(redact_json_values(event),separators=(',',':'))+'\n')
    write_private_json(output/'result.json',redact_json_values(result))
    if result['status']!='passed':
        raise AssertionError('server platform check failed; evidence retained')
    return result



def main():
    import signal
    parser=argparse.ArgumentParser()
    parser.add_argument('output',type=Path)
    parser.add_argument('ray_tmp',type=Path)
    parser.add_argument('socket_root',type=Path)
    args=parser.parse_args()
    new_private_directory(args.output)
    new_private_directory(args.ray_tmp)
    new_private_directory(args.socket_root)
    import ray
    if ray.is_initialized():
        raise AssertionError('preparation diagnostic requires its own Ray runtime')
    start=time.monotonic_ns()
    ray.init(address='local',num_cpus=4,num_gpus=0,include_dashboard=False,
        object_store_memory=134217728,_node_ip_address='127.0.0.1',_temp_dir=str(args.ray_tmp))
    ray_ready=time.monotonic_ns()
    endpoint=Endpoint()
    cases=[]
    def timeout(signum, frame):
        raise TimeoutError('one preparation case exceeded sixty seconds')
    signal.signal(signal.SIGALRM, timeout)
    arms=(('one','daft'),('one','arrow'),('two','daft'),('two','arrow'))
    try:
        for index,(phase,repeat,total_rows) in enumerate([('check',0,8),('warmup',0,128)]+
                                                       [('measurement',i,128) for i in range(1,4)]):
            order=arms[index%4:]+arms[:index%4]
            matched=[]
            for shape,backend in order:
                if time.monotonic_ns()-start>600*10**9:
                    raise TimeoutError('preparation suite exceeded ten minutes')
                signal.alarm(60)
                try:
                    result=run_case(args.output/f'{phase}-{repeat}-{shape}-{backend}',shape,backend,total_rows,
                                    endpoint,ray.get_runtime_context().gcs_address,args.socket_root/f's{len(cases)}')
                finally:
                    signal.alarm(0)
                result.update(phase=phase,repeat=repeat)
                cases.append(result);matched.append(result)
                write_private_json(args.output/f'progress-{len(cases)}.json',cases)
            if any(c['request_hashes']!=matched[0]['request_hashes'] for c in matched[1:]):
                raise AssertionError('complete input bytes differ between execution shapes')
        if len(endpoint.calls)!=MAX_CALLS or endpoint.active or endpoint.failures:
            raise AssertionError('finite suite request or active count differs')
    finally:
        signal.alarm(0)
        endpoint.close()
        ray.shutdown()
    summary=dict(status='passed',model_requests=0,pg_queries=0,http_requests=len(endpoint.calls),cases=cases,
        comparison_role='project_scheduled_method',formal_baseline_eligible=False,
        ray_startup_ms=(ray_ready-start)/1e6,suite_seconds=(time.monotonic_ns()-start)/1e9,
        limits=dict(active_requests=4,held_tasks=384,per_job_tasks=128,input_bytes=12582912,result_bytes=402653184,
                    batch_rows=4,window_bytes=2097152,object_bytes=4194304,ray_cpus=4,ray_gpus=0,
                    object_store_bytes=134217728,workers=1,daft_threads=4),
        metrics={f'{shape}-{backend}':{name:dict(values=[c[name] for c in cases if c['arm']==f'{shape}-{backend}' and c['phase']=='measurement'],
                        median=statistics.median(c[name] for c in cases if c['arm']==f'{shape}-{backend}' and c['phase']=='measurement'))
                  for name in ('budget_setup_ms','gateway_prepare_ms','consume_ms','queued_cancel_ms','close_ms',
                               'budget_handle_cleanup_ms','complete_case_ms')}
                 for shape,backend in arms})
    write_private_json(args.output/'summary.json',summary)
    print(json.dumps({key:value for key,value in summary.items() if key!='cases'}))


if __name__=='__main__':
    main()
