import json,os,signal,subprocess,sys,time
from pathlib import Path
from src.baselines.common.private_artifacts import write_private_json
from src.baselines.common.redact import redact_text
root=Path('/root/autodl-tmp/experiment-artifacts/map-preparation-20261004b')
initial=Path('/root/autodl-tmp/experiment-artifacts/map-preparation-20261004a')
if json.loads((initial/'preflight.json').read_text())['status']!='ok' or not json.loads((initial/'tests.json').read_text())['passed']:
 raise AssertionError('preparation prerequisites did not pass')
active=[]
for line in subprocess.check_output(['ps','-eo','pid=,stat=,args='],text=True).splitlines():
 f=line.split(None,2)
 if len(f)==3 and not f[1].startswith('Z') and any(s in f[2] for s in ['gcs_server','raylet','preparation_core_v2.py']):active.append(int(f[0]))
if active:raise AssertionError('unexpected active data runtime or diagnostic')
start=time.monotonic();process=None;status='failed';code=None
def timeout(signum,frame):raise TimeoutError('preparation Core diagnostic exceeded ten minutes')
signal.signal(signal.SIGALRM,timeout);signal.alarm(600)
try:
 process=subprocess.Popen([sys.executable,'-u',str(root/'preparation_core_v2.py'),str(root/'suite'),'/root/autodl-tmp/mps4r02','/root/autodl-tmp/mps4s02'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 write_private_json(root/'runner.json',dict(supervisor_pid=os.getpid(),probe_pid=process.pid,started_utc=time.time(),model_requests=0,max_http_requests=2080))
 with (root/'core.log').open('x') as stream:
  for line in process.stdout:stream.write(redact_text(line));stream.flush()
 code=process.wait(timeout=10)
 status='passed' if code==0 else 'failed'
except BaseException as error:
 with (root/'failure.log').open('x') as stream:stream.write(redact_text(type(error).__name__+chr(10)))
 if process is not None and process.poll() is None:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=15)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
 if process is not None:code=process.returncode
finally:
 signal.alarm(0)
 write_private_json(root/'runner-exit.json',dict(status=status,returncode=code,elapsed_seconds=time.monotonic()-start,model_requests=0,ended_utc=time.time()))
