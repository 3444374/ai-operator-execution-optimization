import datetime,hashlib,json,os,pathlib,subprocess,sys,time
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.experiments.postgresql.query_supervisor import supervise
from src.baselines.common.private_artifacts import write_private_json
from tests.modalities.image.test_lotus_stage_ray import guarded_sampler
root=pathlib.Path(os.environ["STAGE_TAIL_ROOT"])
identity=json.loads((root/"source-identity-2.json").read_text())
for name,digest in identity["files"].items():assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest,name
with acquire_host_runner_lease(pathlib.Path("<common-artifact-root>"),repository_commit=identity["base_commit"]):
    gpu=subprocess.run(["nvidia-smi","--query-compute-apps=pid","--format=csv,noheader"],capture_output=True,text=True,check=True).stdout.strip()
    if gpu:raise RuntimeError("GPU process appeared; defer CPU diagnostic to avoid a model window")
    now=datetime.datetime.now(datetime.timezone.utc);started=time.monotonic();deadline=started+600
    write_private_json(root/"window.json",dict(t0=now.isoformat(),deadline=(now+datetime.timedelta(seconds=600)).isoformat(),cpu_affinity=[24,25,26,27],max_sampled_summed_rss_bytes=4*1024**3,max_fixture_posts=38,model_posts=0,ray_gpus=0,source_manifest_sha256=identity["manifest_sha256"]))
    sampler=guarded_sampler(root/"window-rss.jsonl");reports=[]
    try:
        with sampler:
            cases=[("component",["-m","unittest","tests.modalities.image.test_stage_block_trace","-v"]),("software",["-m","unittest","tests.modalities.image.test_lotus_stage_ray.LotusStageRayTests.test_fixed_small_blocks_against_existing_stage_rows","-v"])]
            for name,args in cases:
                if sampler.error:raise sampler.error
                remaining=deadline-time.monotonic()
                if remaining<=30:raise TimeoutError("original stage-tail deadline nearly expired")
                attempt=root/name;attempt.mkdir(mode=0o700)
                write_private_json(attempt/"remaining-window.json",dict(remaining_s=remaining,original_deadline=(now+datetime.timedelta(seconds=600)).isoformat()))
                reports.append(supervise(["taskset","-c","24-27",sys.executable,*args],attempt,lambda:None,query_timeout_s=120,preparation_s=remaining,finish_s=30,grace_s=5,max_duration_s=remaining))
        write_private_json(root/"window-result.json",dict(status="passed",reports=reports,elapsed_s=time.monotonic()-started,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    finally:write_private_json(root/"window-resources.json",sampler.summary())
