import datetime,hashlib,json,os,pathlib,time,sys
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.experiments.postgresql.query_supervisor import supervise
from src.baselines.common.private_artifacts import write_private_json
from tests.modalities.image.test_lotus_stage_ray import guarded_sampler
root=pathlib.Path(os.environ["STAGE_REVIEW_ROOT"])
identity=json.loads((root/"source-identity-2.json").read_text())
for name,digest in identity["files"].items():assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest,name
window=json.loads((root/"window.json").read_text())
deadline=datetime.datetime.fromisoformat(window["deadline"])
first=json.loads((root/"fixture/static_bytes-0/record.json").read_text())
assert len(first["responses"])==19 and first["status"]=="failed"
assert 19+86<=window["max_stage_fixture_posts"]
with acquire_host_runner_lease(pathlib.Path("<common-artifact-root>"),repository_commit=identity["base_commit"]):
    remaining=(deadline-datetime.datetime.now(datetime.timezone.utc)).total_seconds()
    if remaining<=60:raise TimeoutError("original fixed window expired before recovery")
    attempt=root/"stage-ray-2";attempt.mkdir(mode=0o700)
    write_private_json(attempt/"remaining-window.json",dict(remaining_s=remaining,original_deadline=window["deadline"],previous_stage_posts=19,this_attempt_stage_cap=86,total_stage_cap=110,source_manifest_sha256=identity["manifest_sha256"]))
    sampler=guarded_sampler(root/"resume-rss.jsonl")
    try:
        with sampler:
            report=supervise(["taskset","-c","24-27",sys.executable,"-m","unittest","tests.modalities.image.test_lotus_stage_ray","-v"],attempt,lambda:None,query_timeout_s=120,preparation_s=remaining,finish_s=30,grace_s=5,max_duration_s=remaining)
        write_private_json(root/"resume-result.json",dict(status="passed",report=report,original_deadline=window["deadline"],ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    finally:write_private_json(root/"resume-resources.json",sampler.summary())
