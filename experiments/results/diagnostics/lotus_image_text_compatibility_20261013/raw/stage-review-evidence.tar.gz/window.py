import datetime,hashlib,json,os,pathlib,time
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.experiments.postgresql.query_supervisor import supervise
from src.baselines.common.private_artifacts import write_private_json
from tests.modalities.image.test_lotus_stage_ray import guarded_sampler
root=pathlib.Path(os.environ["STAGE_REVIEW_ROOT"])
identity=json.loads((root/"source-identity.json").read_text())
for name,digest in identity["files"].items():
    assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest,name
lease_root=pathlib.Path("<common-artifact-root>")
with acquire_host_runner_lease(lease_root,repository_commit=identity["base_commit"]):
    started=time.monotonic();deadline=started+600
    now=datetime.datetime.now(datetime.timezone.utc)
    write_private_json(root/"window.json",dict(t0=now.isoformat(),deadline=(now+datetime.timedelta(seconds=600)).isoformat(),cpu_affinity=[24,25,26,27],num_ray_cpus=2,num_ray_gpus=0,max_sampled_summed_rss_bytes=4*1024**3,max_stage_fixture_posts=110,max_sdk_httpx_posts=250,weakref_urllib_posts=2,model_posts=0,source_manifest_sha256=identity["manifest_sha256"]))
    import sys
    reports=[]
    sampler=guarded_sampler(root/"window-rss.jsonl")
    try:
        with sampler:
            for name,command in [("sdk-checks",[sys.executable,str(root/"sdk_checks.py")]),("stage-ray",[sys.executable,"-m","unittest","tests.modalities.image.test_lotus_stage_ray","-v"])]:
                if sampler.error:raise sampler.error
                remaining=deadline-time.monotonic()
                if remaining<=30:raise TimeoutError("insufficient original window time for bounded software validation")
                attempt=root/name;attempt.mkdir(mode=0o700)
                write_private_json(attempt/"remaining-window.json",dict(remaining_s=remaining,original_deadline=(now+datetime.timedelta(seconds=600)).isoformat()))
                reports.append(supervise(["taskset","-c","24-27",*command],attempt,lambda:None,query_timeout_s=120,preparation_s=remaining,finish_s=30,grace_s=5,max_duration_s=remaining))
            write_private_json(root/"window-result.json",dict(status="passed",reports=reports,elapsed_s=time.monotonic()-started,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    finally:
        write_private_json(root/"window-resources.json",sampler.summary())
