import json,os,pathlib,threading,unittest
from unittest.mock import patch
import httpx
from src.baselines.common.private_artifacts import write_private_json
modules=["tests.semantic_methods.test_lotus_adapter","tests.semantic_methods.test_lotus_control","tests.semantic_methods.test_lotus_cleanup","tests.semantic_methods.test_lotus_call_limits","tests.semantic_methods.test_lotus_wait","tests.semantic_methods.test_lotus_multimodal","tests.semantic_methods.test_lotus_response_replay","tests.semantic_methods.test_lotus_batch_preflight","tests.semantic_methods.test_lotus_stage_lifecycle","tests.modalities.image.test_stage_asset_snapshot","tests.modalities.image.test_stage_http_fixture"]
original=httpx.HTTPTransport.handle_request
state={"network_httpx_posts":0,"network_httpx_requests":0,"other_network_hosts":[]}
lock=threading.Lock()
def local_only(transport,request):
    if request.url.host not in ("localhost","127.0.0.1","::1"):
        raise RuntimeError("SDK qualification attempted a non-local HTTP transport")
    with lock:
        state["network_httpx_requests"]+=1
        if request.method=="POST":state["network_httpx_posts"]+=1
        if state["network_httpx_posts"]>250:raise RuntimeError("SDK fixture POST budget exceeded")
    return original(transport,request)
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
with patch.object(httpx.HTTPTransport,"handle_request",local_only):
    result=unittest.TextTestRunner(verbosity=2).run(suite)
summary=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),**state,weakref_urllib_posts=2,model_requests=0,gpu_starts=0)
write_private_json(pathlib.Path(os.environ["STAGE_REVIEW_ROOT"])/"sdk-checks.json",summary)
if not result.wasSuccessful() or result.skipped:raise SystemExit(1)
