"""Real Ray SDK callers; HTTP is replaced by finite local response fixtures."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import time
from unittest.mock import patch

from src.baselines.common.private_artifacts import new_private_directory, write_private_json
from src.experiments.attempt_ledger import AttemptBudget, BudgetExhausted
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.mapped_request_budget import MappedUnitOwner
from src.experiments.native_http_observer import NativeSessionFactory, observe_native_httpx
from src.experiments.request_budget_client import open_request_budget
from src.experiments.request_identity import RAY_IDENTITY_FIELD
from src.execution_provider.adapters.ray_map_transport import _clock_domain

BODY, ENDPOINT = b'{"messages":[]}', 'http://localhost/fixture'


class Reply:
    status, reason = 200, 'OK'
    async def __aenter__(self):return self
    async def __aexit__(self,*error):return False
    async def json(self):return {'choices':[]}


class Session:
    def __init__(self):self.bodies=[]
    async def post(self,url,*,data,headers,allow_redirects):
        if url!=ENDPOINT or data.encode()!=BODY or allow_redirects:
            raise AssertionError('fixture SDK request differs')
        self.bodies.append(data.encode());return Reply()
    async def close(self):pass


class Caller:
    def __init__(self,descriptor,mode,directory):
        self.descriptor,self.mode,self.directory=descriptor,mode,Path(directory)
        self.budget=None
        self.events,self.bodies=[],[]

    async def invoke(self):
        import httpx
        if self.mode=='httpx':
            scope=open_request_budget(self.descriptor)
            with scope as budget:
                self.budget=budget
                def receive(request):
                    if request.content!=BODY:raise AssertionError('HTTPX body differs')
                    self.bodies.append(request.content)
                    return httpx.Response(200,json={'choices':[]})
                with observe_native_httpx(budget,self.events.append,ENDPOINT):
                    async with httpx.AsyncClient(transport=httpx.MockTransport(receive)) as client:
                        for _ in range(37):
                            try:await client.post(ENDPOINT,content=BODY)
                            except BudgetExhausted:break
        else:
            session=Session()
            with patch('aiohttp.ClientSession',return_value=session):
                async with NativeSessionFactory(self.descriptor,str(self.directory),ENDPOINT,2)() as observer:
                    self.budget=observer.budget
                    for i in range(37):
                        try:
                            response=await observer.post(ENDPOINT,data=json.dumps({'messages':[],
                                RAY_IDENTITY_FIELD:{'row_id':str(i),'source_position':i}}),headers={})
                        except BudgetExhausted:break
                        async with response:
                            value=await response.json()
                            if value[RAY_IDENTITY_FIELD]['row_id']!=str(i):raise AssertionError('SDK occurrence differs')
            self.bodies.extend(session.bodies)
            self.events=[json.loads(line) for p in self.directory.glob('*.jsonl') for line in p.read_text().splitlines()]
        if any(value is not None for value in (self.budget._state_fd,self.budget._lease_fd,self.budget._mapping)):
            raise AssertionError('SDK scope kept mapped handles')
        attempts=[e['attempt'] for e in self.events if e['event']=='request']
        return dict(mode=self.mode,pid=os.getpid(),clock_domain=_clock_domain(),attempts=attempts,
            mock_posts=len(self.bodies),handles_closed=True)

    async def denied_after_owner_close(self):
        with open_request_budget(self.descriptor) as budget:
            try:budget.reserve(hashlib.sha256(BODY).hexdigest())
            except BudgetExhausted:return True
        raise AssertionError('closed owner granted a new request')


def run_sdk(ray,output):
    new_private_directory(output)
    ledger=CellBudgetLedger.create(output/'ledger.sqlite',AttemptBudget('mapped.real-ray.fixture',37),
        deadline_utc=time.time()+600)
    ledger.reserve_unit('sdk',37)
    owner=MappedUnitOwner.prepare(ledger,'sdk',[hashlib.sha256(BODY).hexdigest()]*37,output/'mapped')
    actors=[]
    started=time.monotonic_ns()
    try:
        remote=ray.remote(num_cpus=1,max_restarts=0,max_task_retries=0)(Caller)
        for mode in ('httpx','aiohttp'):
            directory=output/mode;directory.mkdir(mode=0o700)
            actors.append(remote.remote(owner.descriptor,mode,str(directory)))
        results=ray.get([a.invoke.remote() for a in actors],timeout=60)
        attempts=sorted(i for r in results for i in r['attempts'])
        if attempts!=list(range(1,38)) or sum(r['mock_posts'] for r in results)!=37:
            raise AssertionError('real-Ray shared SDK counts differ')
        if len({r['pid'] for r in results})!=2 or any(r['clock_domain']!=_clock_domain() for r in results):
            raise AssertionError('Ray caller process or Linux clock identity differs')
        snapshot=owner.client.snapshot()
        owner.close()
        if not all(ray.get([a.denied_after_owner_close.remote() for a in actors],timeout=10)):
            raise AssertionError('owner close did not stop every caller')
        result=dict(status='passed',caller_results=results,snapshot=snapshot,
            allocated_requests=ledger.snapshot()['allocated_requests'],model_requests=0,http_network_requests=0,
            mock_posts=37,elapsed_seconds=(time.monotonic_ns()-started)/1e9)
        write_private_json(output/'result.json',result)
        return result
    finally:
        owner.close()
        for actor in actors:ray.kill(actor,no_restart=True)
