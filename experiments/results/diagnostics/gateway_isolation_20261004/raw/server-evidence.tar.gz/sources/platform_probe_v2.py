"""Finite Linux gateway/real-Ray platform check with loopback HTTP fixtures."""
import argparse
from dataclasses import asdict
from functools import partial
import gzip
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import socket
import statistics
import threading
import time

from src.baselines.common.private_artifacts import new_private_directory, write_private_json
from src.baselines.common.redact import redact_json_values
from src.execution_provider.adapters.async_fixed_model import exception_details
from src.execution_provider.adapters.incremental_execution import build_fixed_model_execution
from src.execution_provider.adapters.model_config import FixedModelConfig
from src.execution_provider.adapters.ray_map_transport import RayMapConfig, RayMapTransport
from src.execution_provider.multiplexed_gateway import MultiSessionMapGateway
from src.execution_provider.session_dispatch import run_session
from src.experiments.gateway_isolation_probe import Capture, Client, output_value
from src.scheduling.core.session_jobs import shared_compute_job_budget

CAPACITY, MAX_CALLS = 4, 272


class Endpoint:
    def __init__(self):
        self.lock = threading.Lock()
        self.calls, self.active, self.peak, self.failures = [], 0, 0, []
        self.capture = None
        endpoint = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def log_message(self, *args):
                pass

            def do_POST(self):
                counted = False
                try:
                    if self.path != '/fixture' or not 0 < int(self.headers['Content-Length']) <= 1048576:
                        raise AssertionError('fixture route or body size differs')
                    body = self.rfile.read(int(self.headers['Content-Length']))
                    request = json.loads(body)
                    label, sequence = request['messages'][-1]['content'].split(':')
                    sequence = int(sequence)
                    if request['model'] != 'model' or label not in ('A', 'B') or not 0 <= sequence < 16:
                        raise AssertionError('fixture semantic input differs')
                    with endpoint.lock:
                        if len(endpoint.calls) >= MAX_CALLS or endpoint.active >= CAPACITY:
                            raise AssertionError('finite fixture request capacity exceeded')
                        endpoint.active += 1
                        endpoint.peak = max(endpoint.peak, endpoint.active)
                        counted = True
                        capture = endpoint.capture
                        fields = dict(label=label, sequence=sequence,
                                      request_sha256=hashlib.sha256(body).hexdigest())
                        endpoint.calls.append(fields)
                        capture.record('loopback_http_started', active=endpoint.active, **fields)
                    time.sleep(.010 + sequence % 3 * .001)
                    with endpoint.lock:
                        endpoint.active -= 1
                        counted = False
                    capture.record('loopback_service_ended', **fields)
                    response = json.dumps(dict(model='model', choices=[dict(message=dict(
                        content=output_value(label, sequence, 'platform')), finish_reason='stop')],
                        usage=dict(prompt_tokens=2, completion_tokens=1))).encode()
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(response)))
                    self.end_headers()
                    self.wfile.write(response)
                    self.wfile.flush()
                    capture.record('loopback_http_finished', **fields)
                except BaseException as error:
                    endpoint.failures.append(type(error).__name__)
                    self.close_connection = True
                finally:
                    if counted:
                        with endpoint.lock:
                            endpoint.active -= 1

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, name='loopback-fixture')
        self.thread.start()
        self.config = FixedModelConfig(f'http://127.0.0.1:{self.server.server_port}/fixture', 'model', 5000)

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(3)
        if self.thread.is_alive() or self.active:
            raise AssertionError('loopback fixture did not stop')


def run_case(output, arm, rows, endpoint, address):
    new_private_directory(output)
    capture = Capture()
    endpoint.capture = capture
    before = len(endpoint.calls)
    stop, ready = threading.Event(), threading.Event()
    gateways, transports, clients, producers, errors = [], [], [], [], []
    began = time.monotonic_ns()
    ready_ns = None
    result = dict(arm=arm, rows_per_job=rows, status='failed', errors=errors,
                  model_requests=0, pg_queries=0, source_identity='external finite producer')

    def transport_factory(config, maximum, observer):
        value = RayMapTransport(config, maximum, observer, physical=RayMapConfig(
            address, 1, 4, 2097152, 4194304, payload_backend='daft'))
        transports.append(value)
        return value

    def factory(config, **kwargs):
        kwargs.pop('execute')
        return build_fixed_model_execution(config, **kwargs, allocate_job=shared_compute_job_budget,
            transport_factory=transport_factory if arm == 'ray_http' else None)

    path = str(output / 's')
    if len(path.encode()) >= 100:
        raise AssertionError('UDS path exceeds platform check allowance')

    def serve():
        gateway = None
        try:
            with socket.socket(socket.AF_UNIX) as listener:
                gateway = MultiSessionMapGateway(endpoint.config, max_jobs=3, max_connections=8,
                    max_tasks=48, max_active_requests=4, input_bytes=12582912, result_bytes=50331648,
                    frame_timeout_ms=10000, observer=capture, execution_factory=factory)
                gateways.append(gateway)
                listener.bind(path)
                listener.listen(8)
                ready.set()
                gateway.serve(listener, stop, handler=partial(run_session,
                    completion_adapter=gateway, response_delay_ms=0, tamper_evidence_digest=False,
                    disconnect_on_task=False, completion_fixture=None))
        except BaseException as error:
            errors.append(dict(where='gateway', type=type(error).__name__, reason=exception_details(error)))
        finally:
            ready.set()
            if gateway is not None:
                try:
                    if not gateway.close():
                        raise AssertionError('backend close was not confirmed')
                except BaseException as error:
                    errors.append(dict(where='gateway_close', type=type(error).__name__, reason=exception_details(error)))

    def produce(client):
        try:
            for sequence in range(rows):
                client.offer(sequence)
            client.consume(rows, 'platform', ready)
        except BaseException as error:
            errors.append(dict(where=client.label, type=type(error).__name__, reason=exception_details(error)))

    thread = threading.Thread(target=serve, name='gateway-platform-owner')
    try:
        thread.start()
        if not ready.wait(40) or not gateways or errors:
            raise AssertionError('gateway startup did not complete')
        ready_ns = time.monotonic_ns()
        for label in ('A', 'B', 'C'):
            clients.append(Client(path, label, capture))
            clients[-1].stream.settimeout(10)
        if any(r.peer != (os.getuid(), os.getpid()) for r in gateways[0].queries.registrations.values()):
            raise AssertionError('Linux gateway peer identity differs')
        clients[2].offer(0)
        capture.record('fixture_cancel_requested', label='C')
        clients[2].control.close()
        for client in clients[:2]:
            producer = threading.Thread(target=produce, args=(client,), name=f'producer-{client.label}')
            producers.append(producer)
            producer.start()
        deadline = time.monotonic() + 15
        while any(p.is_alive() for p in producers):
            if errors or time.monotonic() > deadline:
                raise AssertionError('finite producer failed or timed out')
            for p in producers:
                p.join(.005)
        result['consume_ended_ns'] = time.monotonic_ns()
    except BaseException as error:
        errors.append(dict(where='driver', type=type(error).__name__, reason=exception_details(error)))
    finally:
        for client in clients:
            client.close()
        stop.set()
        if gateways:
            gateways[0].request_stop()
        for p in producers:
            p.join(15)
        thread.join(15)
        if thread.is_alive() or any(p.is_alive() for p in producers):
            errors.append(dict(where='threads', type='UnconfirmedExit'))
    ended = time.monotonic_ns()
    try:
        events = capture.events
        http = [e for e in events if e['event'] == 'loopback_http_started']
        finished = [e for e in events if e['event'] == 'loopback_http_finished']
        expected = {(label, i) for label in ('A', 'B') for i in range(rows)}
        for observed in (http, finished):
            if len(observed) != 2 * rows or {(e['label'], e['sequence']) for e in observed} != expected:
                raise AssertionError('HTTP identity or multiplicity differs')
        terminals = [e for e in events if e['event'] == 'terminal']
        if len(terminals) != 2 * rows or len({tuple(e['key'].values()) for e in terminals}) != 2 * rows:
            raise AssertionError('Core terminal identity differs')
        usage = asdict(gateways[0].engine.capacity.usage())
        if any(usage.values()) or endpoint.failures or errors:
            raise AssertionError('Core resources, fixture or gateway exit differ')
        if any(t.rows or t.blocks or t.unknown or t.used_bytes for t in transports):
            raise AssertionError('Ray payload references remain charged')
        peaks = {name:max(e['usage'][name] for e in events if 'usage' in e) for name in usage}
        if peaks['active_requests'] > 4 or peaks['held_tasks'] > 48 or peaks['input_bytes'] > 12582912 or peaks['result_bytes'] > 50331648:
            raise AssertionError('Core capacity exceeded')
        offered = [e['monotonic_ns'] for e in events if e['event'] == 'fixture_offer_started' and e['label'] in ('A','B')]
        consumed = [e['monotonic_ns'] for e in events if e['event'] == 'fixture_consumer_completed']
        c_job = [e['job_id'] for e in events if e['event'] == 'job_opened'][2]
        c_drain = [e for e in events if e['event'] == 'job_drained' and e['job_id'] == c_job]
        if len(c_drain) != 1:
            raise AssertionError('queued cancellation drain differs')
        c_start = next(e['monotonic_ns'] for e in events if e['event'] == 'fixture_cancel_requested')
        result.update(status='passed', core_final_usage=usage, core_observed_peak=peaks,
            http_requests=len(endpoint.calls)-before, gateway_prepare_ms=(ready_ns-began)/1e6,
            consume_ms=(max(consumed)-min(offered))/1e6,
            queued_cancel_ms=(c_drain[0]['monotonic_ns']-c_start)/1e6,
            close_ms=(ended-result['consume_ended_ns'])/1e6,
            complete_case_ms=(ended-began)/1e6,
            request_hashes={f"{e['label']}:{e['sequence']}":e['request_sha256'] for e in http},
            actual_http_peak=max(e['active'] for e in http),
            kernel_peer_credentials='unpatched SO_PEERCRED', transport_drained=True)
    except BaseException as error:
        errors.append(dict(where='analysis', type=type(error).__name__, reason=exception_details(error)))
        result['status']='failed'
    with gzip.open(output/'events.jsonl.gz','xt') as stream:
        for event in capture.events:
            stream.write(json.dumps(redact_json_values(event),separators=(',',':'))+'\n')
    write_private_json(output/'result.json',redact_json_values(result))
    if result['status']!='passed':
        raise AssertionError('server platform check failed; evidence retained')
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('output',type=Path)
    parser.add_argument('ray_tmp',type=Path)
    args=parser.parse_args()
    new_private_directory(args.output)
    new_private_directory(args.ray_tmp)
    import ray
    if ray.is_initialized():
        raise AssertionError('platform check requires its own Ray runtime')
    start=time.monotonic_ns()
    ray.init(address='local',num_cpus=4,num_gpus=0,include_dashboard=False,
        object_store_memory=134217728,_node_ip_address='127.0.0.1',_temp_dir=str(args.ray_tmp))
    ray_ready=time.monotonic_ns()
    endpoint=Endpoint()
    cases=[]
    try:
        for index,(phase,repeat,rows) in enumerate([('check',0,4),('warmup',0,16)]+[('measurement',i,16) for i in range(1,4)]):
            arms=('direct_http','ray_http') if index%2==0 else ('ray_http','direct_http')
            pair=[]
            for arm in arms:
                if time.monotonic_ns()-start>600*10**9:
                    raise TimeoutError('finite server suite exceeded ten minutes')
                result=run_case(args.output/f'{phase}-{repeat}-{arm}',arm,rows,endpoint,ray.get_runtime_context().gcs_address)
                result.update(phase=phase,repeat=repeat)
                cases.append(result);pair.append(result)
                write_private_json(args.output/'progress.json',cases)
            if pair[0]['request_hashes']!=pair[1]['request_hashes']:
                raise AssertionError('matched HTTP request bodies differ')
        if len(endpoint.calls)!=MAX_CALLS or endpoint.active or endpoint.failures:
            raise AssertionError('finite suite request or active count differs')
    finally:
        endpoint.close()
        ray.shutdown()
    summary=dict(status='passed',model_requests=0,pg_queries=0,http_requests=len(endpoint.calls),cases=cases,
        ray_startup_ms=(ray_ready-start)/1e6,suite_seconds=(time.monotonic_ns()-start)/1e9,
        metrics={arm:{name:dict(values=[c[name] for c in cases if c['arm']==arm and c['phase']=='measurement'],
                                median=statistics.median(c[name] for c in cases if c['arm']==arm and c['phase']=='measurement'))
                      for name in ('gateway_prepare_ms','consume_ms','queued_cancel_ms','close_ms','complete_case_ms')}
                 for arm in ('direct_http','ray_http')})
    write_private_json(args.output/'summary.json',summary)
    print(json.dumps({key:value for key,value in summary.items() if key!='cases'}))


if __name__=='__main__':
    main()
