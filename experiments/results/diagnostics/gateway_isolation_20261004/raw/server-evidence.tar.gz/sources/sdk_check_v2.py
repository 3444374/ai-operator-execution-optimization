import json,ray
from pathlib import Path
from mapped_ray_calls_v2 import run_sdk
ray.init(address="local",num_cpus=4,num_gpus=0,include_dashboard=False,object_store_memory=134217728,_node_ip_address="127.0.0.1",_temp_dir="/root/autodl-tmp/sr04a")
try:
 result=run_sdk(ray,Path("/root/autodl-tmp/experiment-artifacts/mapped-runtime-20261004c/sdk-both"))
 print(json.dumps(result))
finally:ray.shutdown()
