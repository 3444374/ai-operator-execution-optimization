import json,os,signal,subprocess,sys,time
from pathlib import Path
from src.baselines.common.redact import redact_text
from src.baselines.common.private_artifacts import write_private_json
root=Path('/root/autodl-tmp/experiment-artifacts/gateway-platform-20261004c')
tests=json.loads((root/'platform-tests.json').read_text())
preflight=json.loads((root/'preflight.json').read_text())
if not tests['passed'] or preflight['status']!='ok':
 raise AssertionError('platform prerequisites did not pass')
start=time.monotonic()
process=subprocess.Popen([sys.executable,'-u','platform_probe_v3.py',str(root/'suite'),'/root/autodl-tmp/gr04c'],
 stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
write_private_json(root/'runner.json',dict(supervisor_pid=os.getpid(),probe_pid=process.pid,started_utc=time.time(),max_http_requests=256,model_requests=0))
def timeout(signum,frame):
 raise TimeoutError('server platform probe exceeded ten minutes')
signal.signal(signal.SIGALRM,timeout)
signal.alarm(600)
status='failed'
try:
 with (root/'probe.log').open('x') as stream:
  for line in process.stdout:
   stream.write(redact_text(line));stream.flush()
 code=process.wait(timeout=15)
 status='passed' if code==0 else 'failed'
except BaseException as error:
 with (root/'probe.log').open('a') as stream:
  stream.write(redact_text(type(error).__name__+'\n'))
 os.killpg(process.pid,signal.SIGTERM)
 try:process.wait(timeout=15)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
 code=process.returncode
finally:
 signal.alarm(0)
 write_private_json(root/'runner-exit.json',dict(status=status,returncode=code,elapsed_seconds=time.monotonic()-start,model_requests=0))
