import datetime
import json
import os
from pathlib import Path
import signal
import sqlite3
import subprocess
import time

import psutil

ROOT=Path(os.environ['SDK9_ROOT'])
STATE=json.loads((ROOT/'state.json').read_text())
os.sched_setaffinity(0,set(STATE['cpu_affinity']))
if (ROOT/'started.json').exists():
    record=json.loads((ROOT/'started.json').read_text())
    start_epoch=record['started_epoch']
    started=time.monotonic()-(time.time()-start_epoch)
    deadline=time.monotonic()+(record['deadline_epoch']-time.time())
else:
    started=time.monotonic();start_epoch=time.time();deadline=started+STATE['max_seconds']
    record=dict(started_epoch=start_epoch,deadline_epoch=start_epoch+STATE['max_seconds'],source_head=STATE['source_head'],cpu_affinity=STATE['cpu_affinity'],max_seconds=STATE['max_seconds'],max_posts=STATE['max_fixture_and_proxy_posts'])
    (ROOT/'started.json').write_text(json.dumps(record,indent=2)+'\n')
LOG_ROOT=ROOT/os.environ.get('SDK9_ATTEMPT','attempt02')
LOG_ROOT.mkdir(exist_ok=True)
(ROOT/'results').mkdir(exist_ok=True)
owned={}
affinity_violations=[]
outcomes=[]

def posts():
    p=ROOT/'post-budget.sqlite'
    if not p.exists():return 0
    try:
        with sqlite3.connect(p) as db:
            return db.execute('SELECT count(*) FROM requests').fetchone()[0]
    except sqlite3.OperationalError:
        return 0

def observe(child):
    try:processes=[psutil.Process(child.pid),*psutil.Process(child.pid).children(recursive=True)]
    except psutil.Error:return
    for p in processes:
        try:
            identity=p.create_time()
            mask=p.cpu_affinity()
            owned[(p.pid,identity)]=dict(pid=p.pid,created_epoch=identity,name=p.name(),cpu_affinity=mask)
            if not set(mask)<=set(STATE['cpu_affinity']):
                affinity_violations.append(dict(pid=p.pid,cpu_affinity=mask))
        except psutil.Error:pass

def stop_owned():
    candidates=[]
    for (pid,stamp),info in owned.items():
        try:
            p=psutil.Process(pid)
            if abs(p.create_time()-stamp)<.001 and p.create_time()>=start_epoch-1 and p.status()!=psutil.STATUS_ZOMBIE:
                p.terminate();candidates.append(p)
        except psutil.Error:pass
    _gone,alive=psutil.wait_procs(candidates,timeout=3)
    for p in alive:
        try:p.kill()
        except psutil.Error:pass
    psutil.wait_procs(alive,timeout=3)

env=dict(os.environ,PYTHONPATH=str(ROOT/'validation')+os.pathsep+str(ROOT/'source/code'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='',
    OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false',
    HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',LITELLM_LOCAL_MODEL_COST_MAP='True',RAY_USAGE_STATS_ENABLED='0',
    RAY_DATA_DEFAULT_ASYNC_BATCH_UDF_MAX_CONCURRENCY='2',SEMLOOM_NATIVE_CALL_TEST='1',SEMLOOM_LOTUS_NATIVE_TEST='1')
for name in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','RAY_ADDRESS','SEMLOOM_SUPPLIER_ACTUAL_ARM','SEMLOOM_MOVIE_ACTUAL_ARMS'):
    env.pop(name,None)
env['NO_PROXY']='localhost,127.0.0.1,::1'
for group,upper in [('cookie-followup',18),('close-followup',12),('observation-modes',144)]:
    remaining=deadline-time.monotonic()-STATE['cleanup_reserve_seconds']
    if remaining<=0 or posts()+upper>STATE['max_fixture_and_proxy_posts']:
        outcomes.append(dict(group=group,status='not_run',reason='remaining shared time or POST allowance is insufficient'))
        continue
    suffix=group[0]+str(len(outcomes))
    env['SEMLOOM_NATIVE_CALL_RAY_TMP']='<private-data-disk>/s9.'+ROOT.name.split('.')[-1]+'.'+suffix
    env['SDK9_RAY_BASE']=env['SEMLOOM_NATIVE_CALL_RAY_TMP']+'.m'
    env['SEMLOOM_NATIVE_CALL_ARTIFACT']=str(ROOT/'results'/(group+'-fixtures'))
    before=posts();at=time.monotonic()
    command=[STATE.get('cookie_python',STATE['driver_python']) if group=='cookie-followup' else STATE['driver_python'],str(ROOT/'validation/matrix.py'),group]
    with (LOG_ROOT/(group+'.log')).open('wb') as log:
        child=subprocess.Popen(command,cwd=ROOT/'source',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        (ROOT/'progress.json').write_text(json.dumps(dict(group=group,pid=child.pid,elapsed_seconds=time.monotonic()-started,posts=posts()),indent=2)+'\n')
        timed_out=False
        while child.poll() is None:
            observe(child)
            if time.monotonic()>=deadline-STATE['cleanup_reserve_seconds'] or posts()>=240 or affinity_violations:
                timed_out=True;stop_owned();break
            time.sleep(.2)
        try:returncode=child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill();returncode=child.wait(timeout=5)
    stop_owned()
    outcomes.append(dict(group=group,returncode=returncode,timed_out=timed_out,seconds=time.monotonic()-at,posts=posts()-before,total_posts=posts()))
    (ROOT/'progress.json').write_text(json.dumps(dict(elapsed_seconds=time.monotonic()-started,posts=posts(),completed=outcomes),indent=2)+'\n')
    if timed_out:break
stop_owned()
residual=[]
for (pid,stamp),info in owned.items():
    try:
        p=psutil.Process(pid)
        if abs(p.create_time()-stamp)<.001 and p.status()!=psutil.STATUS_ZOMBIE:residual.append(info)
    except psutil.Error:pass
value=dict(source_head=STATE['source_head'],outcomes=outcomes,elapsed_seconds=time.monotonic()-started,posts=posts(),max_posts=STATE['max_fixture_and_proxy_posts'],
    max_seconds=STATE['max_seconds'],within_limits=posts()<=STATE['max_fixture_and_proxy_posts'] and time.monotonic()-started<=STATE['max_seconds'],
    owned_processes=list(owned.values()),owned_residual_processes=residual,cpu_affinity_violations=affinity_violations,models=0,gpu_work=0,
    success=len(outcomes)==3 and all(v.get('returncode')==0 for v in outcomes) and not residual and not affinity_violations)
(ROOT/'supervisor-result.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({key:value[key] for key in ('success','elapsed_seconds','posts','within_limits','owned_residual_processes')}),flush=True)
