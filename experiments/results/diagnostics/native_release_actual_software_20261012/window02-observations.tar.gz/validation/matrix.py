import asyncio
from collections import Counter
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import io
import importlib.util
import json
import os
from pathlib import Path
import sys
import threading
import time
import unittest
from unittest.mock import patch

ROOT=Path(os.environ['SDK9_ROOT'])
SOURCE=ROOT/'source'
sys.path[:0]=[str(SOURCE/'code'),str(SOURCE/'code/tests/semantic_methods'),str(SOURCE/'code/tests/baselines')]
spec=importlib.util.spec_from_file_location('sdk9_common',Path(__file__).with_name('common.py'))
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
common.instrument_fixture_servers()
from src.baselines.common.redact import redact_text

@contextmanager
def cookie_server(status=307):
    received=[]
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.1'
        def do_POST(self):
            raw=self.rfile.read(int(self.headers['Content-Length']))
            value=json.loads(raw)
            cookie=self.headers.get('Cookie')
            received.append(dict(path=self.path,index=value['index'],cookie=cookie))
            if self.path=='/start':
                self.send_response(status)
                self.send_header('Set-Cookie','sid='+str(value['index'])+'; Path=/')
                self.send_header('Location','/finish?index='+str(value['index']))
                body=b''
            else:
                self.send_response(200)
                body=json.dumps(dict(index=value['index'],cookie=cookie)).encode()
            self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body)
        def do_GET(self):
            from urllib.parse import parse_qs,urlsplit
            index=int(parse_qs(urlsplit(self.path).query)['index'][0])
            cookie=self.headers.get('Cookie')
            received.append(dict(path='/finish',index=index,cookie=cookie))
            body=json.dumps(dict(index=index,cookie=cookie)).encode()
            self.send_response(200);self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body)
        def log_message(self,*args):pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever);thread.start()
    try:yield f'http://localhost:{server.server_port}/start',received
    finally:
        server.shutdown();server.server_close();thread.join(5)
        if thread.is_alive():raise RuntimeError('cookie fixture did not stop')

class ActualHttpSessionTests(unittest.TestCase):
    def test_redirect_cookies_are_call_local_across_concurrency_and_two_loops(self):
        import aiohttp
        self.assertEqual(aiohttp.__version__,'3.14.5')
        cases=[]
        for status in (307,302):cases.append(self.check_redirect_cookies(status))
        common.save('actual-cookie-loop.json',dict(passed=True,aiohttp_version=aiohttp.__version__,posts=18,gets=6,cases=cases))

    def check_redirect_cookies(self,status):
        from src.baselines.text.frameworks import native_calls as native
        identities=[]
        clients=[]
        with cookie_server(status) as (endpoint,received):
            for repeat in range(2):
                control=native._GraphControl()
                async def run():
                    def call(index):return native.NativeCall(str(index),index,json.dumps(dict(index=index)).encode(),endpoint,(),3,follow_redirects=True)
                    try:
                        result=await asyncio.gather(native._request(call(repeat*3),control),native._request(call(repeat*3+1),control))
                        result.append(await native._request(call(repeat*3+2),control))
                        for value in result:
                            body=json.loads(value.response.body)
                            self.assertEqual(body['cookie'],'sid='+str(body['index']))
                        self.assertEqual(len(control._clients),1)
                        client=next(iter(control._clients.values()))
                        clients.append(client)
                        identities.append(dict(loop_id=id(asyncio.get_running_loop()),client_id=id(client)))
                    finally:
                        control.stop()
                        await asyncio.gather(*(asyncio.wrap_future(f) for f in control._client_closes.values()))
                asyncio.run(run())
                control.wait_clients_closed(0)
                self.assertTrue(all(c.closed for c in control._clients.values()))
            self.assertEqual(len(received),12)
            self.assertIsNot(clients[0],clients[1])
            self.assertTrue(all(v['cookie'] is None for v in received if v['path']=='/start'))
        return dict(status=status,loops=identities,receipts=received,all_clients_closed=True)

    def test_actual_body_limit_keeps_primary_after_injected_real_pool_close_error(self):
        from src.baselines.text.frameworks import native_calls as native
        from tests.baselines.test_native_calls import complete_server,call
        original=native._HttpClient.close
        closed=[]
        async def close(client):
            await original(client);closed.append(client.session.closed)
            raise OSError('injected after real pool close')
        with complete_server(body=b'oversized') as (endpoint,requests,raw),patch.object(native._HttpClient,'close',close):
            with self.assertRaisesRegex(ValueError,'byte allowance') as caught:
                asyncio.run(native._request(call(endpoint,maximum=1)))
            self.assertIn('OSError','\n'.join(caught.exception.__notes__))
            self.assertEqual(closed,[True])
        common.save('actual-first-error.json',dict(passed=True,posts=1,scope='real aiohttp HTTP and session close, followed by an injected cleanup diagnostic',primary_type=type(caught.exception).__name__,notes=caught.exception.__notes__))

class ActualObservationModes(unittest.TestCase):
    def test_real_lotus_modes_keep_two_queries_values_outputs_and_closed_budget(self):
        from src.baselines.text.frameworks.prepared_map import NativeGraphOptions
        from src.execution_provider.adapters.model_config import FixedModelConfig
        from src.execution_provider.semantic_map import SemanticMapPlan
        from src.experiments.attempt_ledger import AttemptBudget,BudgetExhausted
        from src.experiments.cell_budget import CellBudgetLedger
        from src.experiments.shared_request_budget import SharedClaimedUnit
        from src.experiments.postgresql.persistent_native_adapter_query import PersistentAdapterGroup
        from src.experiments.postgresql.sembench_queries import MovieQuery
        from tests.experiments.test_sembench_queries import fixture_dataset
        from tests.experiments.test_sembench_lotus_libraries import movie_fixture_server
        arms=('lotus-adapted-native','lotus-method-native-daft','lotus-method-native-ray-data')
        root=ROOT/'mode-cells';root.mkdir()
        dataset=fixture_dataset(root/'workload',Path('<sembench-source>'))
        dataset.preflight()
        ledger=CellBudgetLedger.create(root/'budget.sqlite',AttemptBudget('sdk9-movie-modes',72),deadline_utc=json.loads((ROOT/'started.json').read_text())['deadline_epoch'])
        canonical={};values=[]
        with movie_fixture_server(limit=72) as (endpoint,requests):
            for mode in ('qualification','performance'):
                with PersistentAdapterGroup(arms,plan=SemanticMapPlan('original Movie profile','fixture',8),model=FixedModelConfig(endpoint,'fixture',5000),ledger=ledger,
                        root=root/('owner-'+mode),options=NativeGraphOptions(concurrency=4,num_threads=8,ray_actors=2,source_blocks=2),
                        ray_temp_root=Path(os.environ['SDK9_RAY_BASE']+'.'+mode[0]),query_timeout_s=30,owner_timeout_s=300,lotus_observation_mode=mode,sembench_dataset=dataset) as group:
                    for arm in arms:
                        owner=None
                        for query_id in (2,3):
                            unit=mode+'-'+arm+'-q'+str(query_id);case=root/unit
                            result=group.run(arm,unit_id=unit,root=case,phase='measurement',sembench_query=MovieQuery(dataset,query_id))
                            self.assertEqual((result['status'],result['actual_posts']),('passed',6))
                            self.assertEqual(result['lotus_observation_mode'],mode)
                            self.assertEqual(len(result['method_calls']),6)
                            self.assertEqual(result['identity']['original_query']['query_id'],query_id)
                            self.assertEqual(result['sembench_preflight']['role'],'software_fixture')
                            self.assertEqual((result['quality']['classification_audit']['false_positive'],result['quality']['classification_audit']['false_negative']),(1,1))
                            self.assertFalse(result['performance_qualified'])
                            identity=(result['persistent_lifecycle']['owner_id'],result['persistent_lifecycle']['lm_id'])
                            if owner is None:owner=identity
                            self.assertEqual(identity,owner)
                            expected='unavailable' if mode=='performance' and arm=='lotus-adapted-native' else 'passed'
                            self.assertEqual(result['method_http_values_audit']['status'],expected)
                            bodies=Counter(json.dumps(json.loads(line)['request'],sort_keys=True,ensure_ascii=False) for line in (case/'protocols.jsonl').read_text().splitlines())
                            key=(arm,query_id)
                            if mode=='qualification':canonical[key]=bodies
                            self.assertEqual(bodies,canonical[key])
                            with self.assertRaises(BudgetExhausted):SharedClaimedUnit(ledger.path,ledger.budget,unit).reserve('a'*64)
                            output=json.loads((case/'original-query-result.json').read_text())
                            if query_id==3:self.assertEqual(output['dataframe']['data'],[[5]])
                            values.append(dict(unit=unit,mode=mode,arm=arm,query_id=query_id,posts=6,quality=result['quality'],result=output,audit=result['method_http_values_audit']))
            self.assertEqual(len(requests),72)
        snapshot=ledger.snapshot();self.assertEqual(snapshot['allocated_requests'],72)
        self.assertEqual(len(snapshot['units']),12);self.assertTrue(all(v['claimed']==1 for v in snapshot['units']))
        common.save('actual-observation-modes.json',dict(passed=True,upstream_posts=72,role='software_fixture',method='original SemBench Q2/Q3 and official evaluator',fixture_plus_proxy_upper_posts=144,units=values,budget=snapshot,timing_subtraction=False))

    def test_insufficient_budget_refuses_real_lotus_before_any_post(self):
        from src.baselines.text.frameworks.prepared_map import NativeGraphOptions
        from src.execution_provider.adapters.model_config import FixedModelConfig
        from src.execution_provider.semantic_map import SemanticMapPlan
        from src.experiments.attempt_ledger import AttemptBudget,BudgetExhausted
        from src.experiments.cell_budget import CellBudgetLedger
        from src.experiments.postgresql.supplier_adapter_query import run_supplier_query
        from tests.experiments.test_native_adapter_query import fixture_server
        results=[]
        with fixture_server(delay=0) as (endpoint,requests):
            for mode in ('qualification','performance'):
                root=ROOT/('budget-refusal-'+mode);root.mkdir()
                ledger=CellBudgetLedger.create(root/'budget.sqlite',AttemptBudget('refusal',1),deadline_utc=time.time()+30)
                with self.assertRaises(BudgetExhausted):
                    run_supplier_query('lotus-adapted-native',load_source=lambda:iter([dict(row_id='a',text='same'),dict(row_id='b',text='same')]),
                        plan=SemanticMapPlan('Return ok.','fixture',16),model=FixedModelConfig(endpoint,'fixture',5000),ledger=ledger,unit_id='query',root=root/'query',
                        options=NativeGraphOptions(num_threads=8),lotus_observation_mode=mode)
                summary=json.loads((root/'query/summary.json').read_text())
                self.assertEqual((summary['status'],summary['attempted_posts'],summary['lotus_observation_mode']),('failed',0,mode))
                self.assertEqual(ledger.snapshot()['allocated_requests'],0)
                results.append(summary)
            self.assertEqual(requests,[])
        common.save('actual-budget-refusal.json',dict(passed=True,posts=0,results=results))

class CloseFollowupTests(unittest.TestCase):
    def test_real_graphs_close_without_new_request_start_and_keep_remote_unknown(self):
        import sqlite3
        import ray
        from src.baselines.text.frameworks import native_calls as native
        from src.baselines.text.frameworks.prepared_map import NativeGraphOptions
        from src.infrastructure.daft_runtime import configure_daft_runner
        from tests.baselines.test_native_calls import complete_server
        import sdk9_trace
        sdk9_trace.initialize()
        configure_daft_runner('native',num_threads=8)
        ray.init(address='local',num_cpus=8,num_gpus=0,include_dashboard=False,object_store_memory=134217728,
                 _temp_dir=os.environ['SEMLOOM_NATIVE_CALL_RAY_TMP'])
        reports=[]
        real_client=native._new_http_client
        try:
            for backend in ('daft','ray-data'):
                case='close-'+backend
                with self.subTest(backend=backend),complete_server(delay=.1) as (endpoint,requests,raw), \
                     patch.object(native,'_new_http_client',lambda:sdk9_trace.observe_client(real_client())), \
                     patch.object(native,'_ProcessorSession',sdk9_trace.MeasuredProcessorSession):
                    options=NativeGraphOptions(concurrency=4,num_threads=8,ray_actors=2,source_blocks=2)
                    executor=native.NativeCallExecutor(backend,options)
                    calls=tuple(native.NativeCall(str(i),i,b'{"messages":["fixture"]}',endpoint,
                        (('X-Sdk9-Case',case),('X-Sdk9-Call',str(i))),3) for i in range(6))
                    iterator=executor.iter_batch(calls,timeout_s=30)
                    first=next(iterator);self.assertIsNotNone(first.response)
                    close_enter=time.monotonic_ns();iterator.close();close_return=time.monotonic_ns()
                    count_at_return=len(requests)
                    deadline=time.monotonic()+6
                    while requests.active and time.monotonic()<deadline:time.sleep(.01)
                    time.sleep(.3)
                    with sqlite3.connect(sdk9_trace.DB) as db:
                        rows=[dict(kind=kind,call_id=call,pid=pid,at_ns=at,loop_id=loop,session_id=session)
                              for kind,call,pid,at,loop,session in db.execute('SELECT kind,call_id,pid,at_ns,loop_id,session_id FROM events WHERE case_id=? ORDER BY at_ns',(case,))]
                    late=[v for v in rows if v['kind']=='request_start' and v['at_ns']>close_return]
                    record=dict(backend=backend,close_enter_ns=close_enter,close_return_ns=close_return,
                        arrivals_at_close_return=count_at_return,arrivals_after_settle=len(requests),
                        request_starts_after_close_return=late,trace=rows,report=executor.last_close_report,active_after_settle=requests.active)
                    reports.append(record);common.save('actual-close-followup.json',dict(cases=reports,scope='real vendor graph with pass-through aiohttp trace callbacks; arrival changes are retained'))
                    self.assertFalse(late,record)
                    self.assertEqual(requests.active,0)
                    self.assertTrue(executor.last_close_report['graph_consumer_stopped'])
                    self.assertFalse(executor.last_close_report['clean'])
                    self.assertEqual(executor.last_close_report['remote_http_stopped'],'unavailable')
                    if backend=='daft':self.assertTrue(executor.last_close_report['http_pools_closed'])
                    self.assertEqual(native._DAFT_CONTROLS,{})
        finally:ray.shutdown()


class Result(common.ResultsMixin,unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.starts={};self.timings={};self.subtests=[]
    def addSubTest(self,test,subtest,error):
        self.subtests.append(dict(test=test.id(),parameters=repr(subtest.params),passed=error is None))
        super().addSubTest(test,subtest,error)

group=sys.argv[1]
if group=='sdk-http':
    names=['tests.semantic_methods.test_lotus_response_replay.PinnedSDKReplayTests','tests.baselines.test_native_http_lifecycle.NativeHttpLifecycleTests.test_real_keepalive_preserves_occurrences_and_reuses_connection']
    extra=[ActualHttpSessionTests]
elif group=='lotus-native':
    prefix='tests.semantic_methods.test_lotus_native.LotusNativeTests.'
    names=[prefix+v for v in ('test_map_and_cache_usage_logprobs_match_original_without_parser_http','test_original_http_json_and_missing_content_errors_keep_type_and_usage','test_staged_two_map_keeps_whole_stage_wait_and_original_prompts','test_invalid_parameters_and_cancellation_before_preparation_send_zero_posts')]
    extra=[]
elif group=='native-graphs':
    names=['tests.baselines.test_native_calls.NativeGraphTests'];extra=[]
elif group=='observation-modes':
    names=['__main__.ActualObservationModes.test_real_lotus_modes_keep_two_queries_values_outputs_and_closed_budget'];extra=[]
elif group=='ray-core-reference':
    names=['tests.semantic_methods.test_lotus_native.LotusRayCoreTests.test_map_and_cache_usage_logprobs_match_original_without_parser_http',
           'tests.baselines.test_native_calls.RayCoreReferenceTests.test_actor_cpu_allowance_and_termination_belong_to_this_reference'];extra=[]
elif group=='cookie-followup':
    names=['__main__.ActualHttpSessionTests.test_redirect_cookies_are_call_local_across_concurrency_and_two_loops'];extra=[]
elif group=='close-followup':
    names=['__main__.CloseFollowupTests'];extra=[]
else:raise ValueError('unknown matrix group')
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
for cls in extra:suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
stream=io.StringIO()
result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Result).run(suite)
value=dict(group=group,tests_run=result.testsRun,skipped=[dict(test=t.id(),reason=r) for t,r in result.skipped],errors=[dict(test=t.id(),text=redact_text(s)) for t,s in result.errors],failures=[dict(test=t.id(),text=redact_text(s)) for t,s in result.failures],timings=result.timings,subtests=result.subtests,log=redact_text(stream.getvalue()),success=result.wasSuccessful() and not result.skipped,total_posts=common.count_posts())
common.save(group+'.json',value)
print(value['log'],end='');print(json.dumps({k:value[k] for k in ('group','tests_run','success','total_posts')}))
raise SystemExit(not value['success'])
