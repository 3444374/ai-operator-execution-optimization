import asyncio
import os
from pathlib import Path
import sqlite3
import time

from src.baselines.text.frameworks import native_calls as native

DB=Path(os.environ['SDK9_ROOT'])/'send-traces.sqlite'

def initialize():
    with sqlite3.connect(DB) as db:
        db.execute('CREATE TABLE IF NOT EXISTS events (kind TEXT, case_id TEXT, call_id TEXT, pid INTEGER, loop_id INTEGER, session_id INTEGER, at_ns INTEGER)')

def event(kind,case,call,loop,session):
    at=time.monotonic_ns()
    with sqlite3.connect(DB,timeout=10) as db:
        db.execute('INSERT INTO events VALUES(?,?,?,?,?,?,?)',(kind,case,call,os.getpid(),loop,session,at))

def observe_client(client):
    import aiohttp
    config=aiohttp.TraceConfig()
    loop=id(asyncio.get_running_loop());session=id(client.session)
    async def started(session,context,params):
        context.case=params.headers.get('X-Sdk9-Case','unknown')
        context.call=params.headers.get('X-Sdk9-Call','unknown')
        event('request_start',context.case,context.call,loop,id(session))
    async def headers(session,context,params):
        event('headers_sent',context.case,context.call,loop,id(session))
    async def body(session,context,params):
        event('chunk_sent',context.case,context.call,loop,id(session))
    config.on_request_start.append(started)
    config.on_request_headers_sent.append(headers)
    config.on_request_chunk_sent.append(body)
    config.freeze()
    client.session._trace_configs.append(config)
    return client

class MeasuredProcessorSession(native._ProcessorSession):
    async def __aenter__(self):
        result=await super().__aenter__()
        observe_client(self._client)
        return result
