import base64
import hashlib
import http.server
import io
import json
import os
from pathlib import Path
import sqlite3
import threading
import time

ROOT=Path(os.environ['SDK9_ROOT'])
STATE=json.loads((ROOT/'state.json').read_text())
DB=ROOT/'post-budget.sqlite'
LOCK=threading.Lock()
CASE='startup'

def initialize_budget():
    with sqlite3.connect(DB) as db:
        db.execute('CREATE TABLE IF NOT EXISTS requests (sequence INTEGER PRIMARY KEY, case_id TEXT, handler TEXT, method TEXT, path TEXT, start_epoch REAL, done_epoch REAL, body_bytes INTEGER, body_sha256 TEXT, body_base64 TEXT, cookie TEXT)')

def count_posts():
    with sqlite3.connect(DB) as db:
        return db.execute('SELECT count(*) FROM requests').fetchone()[0]

def instrument_fixture_servers():
    initialize_budget()
    original=http.server.HTTPServer.__init__
    def initialize(server,address,handler,*args,**kwargs):
        if address[0] not in ('127.0.0.1','localhost','::1'):
            raise ValueError('software validation may bind only localhost')
        identity=handler.__module__+'.'+handler.__name__
        class Measured(handler):
            def do_POST(self):
                with LOCK,sqlite3.connect(DB,timeout=10) as db:
                    db.execute('BEGIN IMMEDIATE')
                    count=db.execute('SELECT count(*) FROM requests').fetchone()[0]
                    if count>=STATE['max_fixture_and_proxy_posts']:
                        raise RuntimeError('shared POST allowance exhausted')
                    cursor=db.execute('INSERT INTO requests(case_id,handler,method,path,start_epoch,cookie) VALUES(?,?,?,?,?,?)',
                        (CASE,identity,'POST',self.path,time.time(),self.headers.get('Cookie')))
                    sequence=cursor.lastrowid
                source=self.rfile
                chunks=[]
                class Tee:
                    def read(_,size=-1):
                        value=source.read(size);chunks.append(value);return value
                    def __getattr__(_,name):
                        return getattr(source,name)
                self.rfile=Tee()
                try:
                    super().do_POST()
                finally:
                    self.rfile=source
                    body=b''.join(chunks)
                    with LOCK,sqlite3.connect(DB,timeout=10) as db:
                        db.execute('UPDATE requests SET done_epoch=?,body_bytes=?,body_sha256=?,body_base64=? WHERE sequence=?',
                            (time.time(),len(body),hashlib.sha256(body).hexdigest(),base64.b64encode(body).decode(),sequence))
        return original(server,address,Measured,*args,**kwargs)
    http.server.HTTPServer.__init__=initialize

def save(name,value):
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results'/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

class ResultsMixin:
    def startTest(self,test):
        global CASE
        CASE=test.id()
        self.starts[test.id()]=(time.monotonic(),count_posts())
        super().startTest(test)
    def stopTest(self,test):
        seconds,posts=self.starts[test.id()]
        self.timings[test.id()]=dict(seconds=time.monotonic()-seconds,posts=count_posts()-posts)
        super().stopTest(test)
