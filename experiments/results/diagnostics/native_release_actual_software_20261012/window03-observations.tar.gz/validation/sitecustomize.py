import os

if os.environ.get('SDKCLI_ROOT') and os.environ.get('SDKCLI_FIXTURE_URL'):
    from pre_send_ledger import install
    install()
