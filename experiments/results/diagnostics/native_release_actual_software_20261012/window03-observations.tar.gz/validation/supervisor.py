"""Supervise only this task's fixed public CLI processes and local fixture."""
from collections import Counter
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import threading
import time

import psutil

ROOT = Path(os.environ['SDKCLI_ROOT'])
STATE = json.loads((ROOT / 'state.json').read_text())
os.sched_setaffinity(0, set(STATE['cpu_affinity']))
from pre_send_ledger import initialize, counts
initialize()
if (ROOT / 'started.json').exists():
    raise RuntimeError('this new software window was already started')
started_epoch = (ROOT / 'model.json').stat().st_mtime
started = time.monotonic() - (time.time() - started_epoch)
deadline = started + STATE['max_seconds']
(ROOT / 'started.json').write_text(json.dumps(dict(source_head=STATE['source_head'], started_epoch=started_epoch,
    deadline_epoch=started_epoch + STATE['max_seconds'], max_seconds=STATE['max_seconds'],
    timer_scope='conservative: private placeholder model file created immediately before first read-only public CLI preflight; no reset at execute',
    max_transmission_posts=STATE['max_transmission_posts'], max_logical_calls=STATE['max_logical_calls']), indent=2) + '\n')
owned, violations, outcomes = {}, [], []
for name in ('run', 'results'):
    (ROOT / name).mkdir(exist_ok=True)
with sqlite3.connect(ROOT / 'fixture-receipts.sqlite') as db:
    db.execute('CREATE TABLE receipts (sequence INTEGER PRIMARY KEY, start_epoch REAL, start_ns INTEGER, end_ns INTEGER, status INTEGER, body_sha256 TEXT, messages_sha256 TEXT, answer TEXT)')

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def do_POST(self):
        at_epoch, at_ns = time.time(), time.monotonic_ns()
        payload = self.rfile.read(int(self.headers['Content-Length']))
        request = json.loads(payload)
        messages = json.dumps(request['messages'], sort_keys=True, ensure_ascii=False).encode()
        digest = hashlib.sha256(messages).hexdigest()
        answer = 'True' if int(digest[-2:], 16) % 2 == 0 else 'False'
        with sqlite3.connect(ROOT / 'fixture-receipts.sqlite', timeout=10) as db:
            cursor = db.execute('INSERT INTO receipts(start_epoch,start_ns,status,body_sha256,messages_sha256,answer) VALUES(?,?,?,?,?,?)',
                (at_epoch, at_ns, 200, hashlib.sha256(payload).hexdigest(), digest, answer))
            sequence = cursor.lastrowid
        body = json.dumps(dict(id='software-fixture', object='chat.completion', created=1, model='fixture',
            choices=[dict(index=0, message=dict(role='assistant', content=answer), finish_reason='stop')],
            usage=dict(prompt_tokens=2, completion_tokens=1, total_tokens=3))).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        finally:
            with sqlite3.connect(ROOT / 'fixture-receipts.sqlite', timeout=10) as db:
                db.execute('UPDATE receipts SET end_ns=? WHERE sequence=?', (time.monotonic_ns(), sequence))
    def log_message(self, *_args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
thread = threading.Thread(target=server.serve_forever)
thread.start()
fixture = 'http://127.0.0.1:' + str(server.server_port) + '/v1/chat/completions'
(ROOT / 'model.json').write_text(json.dumps(dict(endpoint_url=fixture, model_id='fixture', timeout_ms=5000)) + '\n')
env = dict(os.environ, PYTHONPATH=str(ROOT/'validation') + os.pathsep + str(ROOT/'source/code'),
    PYTHONDONTWRITEBYTECODE='1', SDKCLI_FIXTURE_URL=fixture, CUDA_VISIBLE_DEVICES='',
    OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false',
    HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', LITELLM_LOCAL_MODEL_COST_MAP='True', RAY_USAGE_STATS_ENABLED='0')
for name in ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy', 'RAY_ADDRESS',
             'SEMLOOM_MOVIE_ACTUAL_ARMS', 'SEMLOOM_SUPPLIER_ACTUAL_ARM'):
    env.pop(name, None)
env['NO_PROXY'] = '127.0.0.1,localhost,::1'
env.update(SEMBENCH_CHECKOUT=STATE['data']['checkout'], SEMBENCH_MOVIE_MANIFEST=STATE['data']['manifest'],
    SEMBENCH_MOVIE_CSV=STATE['data']['csv'], SEMBENCH_MODEL_CONFIG=str(ROOT/'model.json'),
    SEMBENCH_RAY_PARENT=STATE['ray_parent'])

def observe(child):
    try:
        processes = [psutil.Process(child.pid), *psutil.Process(child.pid).children(recursive=True)]
    except psutil.Error:
        return
    for process in processes:
        try:
            stamp, mask = process.create_time(), process.cpu_affinity()
            owned[(process.pid, stamp)] = dict(pid=process.pid, created_epoch=stamp, name=process.name(), cpu_affinity=mask)
            if not set(mask) <= set(STATE['cpu_affinity']):
                violations.append(dict(pid=process.pid, cpu_affinity=mask))
        except psutil.Error:
            pass

def stop_owned():
    live = []
    for (pid, stamp) in owned:
        try:
            process = psutil.Process(pid)
            if abs(process.create_time()-stamp) < .001 and process.create_time() >= started_epoch-1 and process.status() != psutil.STATUS_ZOMBIE:
                process.terminate()
                live.append(process)
        except psutil.Error:
            pass
    _, alive = psutil.wait_procs(live, timeout=3)
    for process in alive:
        try:
            process.kill()
        except psutil.Error:
            pass
    psutil.wait_procs(alive, timeout=3)

try:
    for case, logical in (('main', 960), ('paired', 120)):
        before = counts()
        if time.monotonic() >= deadline-STATE['cleanup_reserve_seconds'] or before['total']+2*logical > STATE['max_transmission_posts'] or before['gateway']+logical > STATE['max_logical_calls']:
            outcomes.append(dict(case=case, status='not_run', reason='finite remaining time or request allowance'))
            break
        env['SDKCLI_CASE'] = case
        env['SEMBENCH_OUTPUT'] = str(ROOT / (case + '-output'))
        command = [STATE['driver_python'], '-m', 'src.experiments.postgresql.sembench_query_cli',
                   '--config', str(ROOT / (case + '-config.json')), '--execute']
        (ROOT/'results'/(case+'-command.json')).write_text(json.dumps(dict(argv=command, source_head=STATE['source_head']))+'\n')
        at = time.monotonic()
        with (ROOT/'run'/(case+'.stdout.log')).open('wb') as stdout, (ROOT/'run'/(case+'.stderr.log')).open('wb') as stderr:
            child = subprocess.Popen(command, cwd=ROOT/'source', env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            timed_out = False
            while child.poll() is None:
                observe(child)
                current = counts()
                (ROOT/'progress.json').write_text(json.dumps(dict(case=case, pid=child.pid, elapsed_seconds=time.monotonic()-started, counts=current),indent=2)+'\n')
                if time.monotonic() >= deadline-STATE['cleanup_reserve_seconds'] or violations:
                    timed_out = True
                    stop_owned()
                    break
                time.sleep(.2)
            try:
                returncode = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                returncode = child.wait(timeout=5)
        stop_owned()
        current = counts()
        outcome = dict(case=case, returncode=returncode, timed_out=timed_out, seconds=time.monotonic()-at,
            counts={key: current[key]-before[key] for key in current}, cumulative_counts=current,
            bootstrap_installed=(ROOT/'bootstrap-pids'/(str(child.pid)+'.json')).exists())
        if (ROOT/(case+'-output/matrix.json')).exists():
            matrix = json.loads((ROOT/(case+'-output/matrix.json')).read_text())
            outcome.update(matrix_status=matrix['status'], cells=len(matrix['cells']), logical_posts=sum(cell['actual_posts'] for cell in matrix['cells']))
        outcomes.append(outcome)
        (ROOT/'results'/(case+'-outcome.json')).write_text(json.dumps(outcome,indent=2)+'\n')
        if returncode or timed_out:
            break
finally:
    server.shutdown()
    server.server_close()
    thread.join(5)
    stop_owned()
residual = []
for (pid, stamp), info in owned.items():
    try:
        process = psutil.Process(pid)
        if abs(process.create_time()-stamp) < .001 and process.status() != psutil.STATUS_ZOMBIE:
            residual.append(info)
    except psutil.Error:
        pass
final = counts()
with sqlite3.connect(ROOT/'fixture-receipts.sqlite') as db:
    fixture_count, unsettled = db.execute('SELECT count(*),sum(end_ns IS NULL) FROM receipts').fetchone()
summary = dict(source_head=STATE['source_head'], elapsed_seconds=time.monotonic()-started, counts=final,
    fixture_arrivals=fixture_count, fixture_unsettled=unsettled or 0, outcomes=outcomes,
    owned_processes=list(owned.values()), owned_residual_processes=residual, cpu_affinity_violations=violations,
    max_transmission_posts=STATE['max_transmission_posts'], max_logical_calls=STATE['max_logical_calls'], max_seconds=STATE['max_seconds'],
    within_limits=final['total'] <= STATE['max_transmission_posts'] and final['gateway'] <= STATE['max_logical_calls'] and time.monotonic()-started <= STATE['max_seconds'],
    models=0, gpu=0, fixture_thread_stopped=not thread.is_alive(),
    success=len(outcomes)==2 and all(item.get('returncode')==0 and item.get('bootstrap_installed') for item in outcomes) and not residual and not violations and not thread.is_alive())
(ROOT/'supervisor-result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:summary[key] for key in ('success','elapsed_seconds','counts','fixture_arrivals','within_limits','owned_residual_processes')}),flush=True)
