"""Pass-through request accounting for this private software-only CLI window."""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import time
from urllib.parse import urlsplit

ROOT = Path(os.environ['SDKCLI_ROOT'])
STATE = json.loads((ROOT / 'state.json').read_text())
DB = ROOT / 'transmission.sqlite'

def initialize():
    with sqlite3.connect(DB, timeout=10) as db:
        db.execute('CREATE TABLE IF NOT EXISTS sends (sequence INTEGER PRIMARY KEY, kind TEXT, case_id TEXT, pid INTEGER, url TEXT, at_epoch REAL, at_ns INTEGER, returned_ns INTEGER, status INTEGER, error_type TEXT, body_sha256 TEXT)')

def counts():
    with sqlite3.connect(DB, timeout=10) as db:
        result = dict(db.execute('SELECT kind,count(*) FROM sends GROUP BY kind'))
    return dict(total=sum(result.values()), gateway=result.get('gateway', 0), fixture=result.get('fixture', 0))

def selected(method, url):
    if str(method).upper() != 'POST':
        return None
    parsed = urlsplit(str(url))
    if parsed.hostname not in ('localhost', '127.0.0.1', '::1'):
        raise RuntimeError('software CLI window refuses external HTTP POSTs')
    if str(url) == os.environ.get('SDKCLI_FIXTURE_URL'):
        return 'fixture'
    if parsed.path.startswith('/observe/') and parsed.path.endswith('/model/v1/chat/completions'):
        return 'gateway'
    return None

def reserve(kind, url, body):
    start = json.loads((ROOT / 'started.json').read_text())
    if time.time() >= start['deadline_epoch'] - STATE['cleanup_reserve_seconds']:
        raise TimeoutError('software CLI window preserves its cleanup reserve')
    with sqlite3.connect(DB, timeout=10) as db:
        db.execute('BEGIN IMMEDIATE')
        total = db.execute('SELECT count(*) FROM sends').fetchone()[0]
        logical = db.execute("SELECT count(*) FROM sends WHERE kind='gateway'").fetchone()[0]
        if total >= STATE['max_transmission_posts'] or kind == 'gateway' and logical >= STATE['max_logical_calls']:
            raise RuntimeError('software CLI transport or logical allowance exhausted before send')
        cursor = db.execute('INSERT INTO sends(kind,case_id,pid,url,at_epoch,at_ns,body_sha256) VALUES(?,?,?,?,?,?,?)',
                            (kind, os.environ.get('SDKCLI_CASE'), os.getpid(), str(url), time.time(), time.monotonic_ns(),
                             hashlib.sha256(body).hexdigest() if isinstance(body, bytes) else None))
        return cursor.lastrowid

def finish(sequence, response=None, error=None):
    status = getattr(response, 'status', getattr(response, 'status_code', None))
    with sqlite3.connect(DB, timeout=10) as db:
        db.execute('UPDATE sends SET returned_ns=?,status=?,error_type=? WHERE sequence=?',
                   (time.monotonic_ns(), status, type(error).__name__ if error else '', sequence))

def install():
    initialize()
    import aiohttp
    import httpx
    original_aio = aiohttp.ClientSession._request
    original_sync = httpx.Client.send
    original_async = httpx.AsyncClient.send

    async def aio(session, method, url, *args, **kwargs):
        kind = selected(method, url)
        if kind is None:
            return await original_aio(session, method, url, *args, **kwargs)
        sequence = reserve(kind, url, kwargs.get('data'))
        try:
            result = await original_aio(session, method, url, *args, **kwargs)
        except BaseException as error:
            finish(sequence, error=error)
            raise
        finish(sequence, result)
        return result

    def sync(client, request, *args, **kwargs):
        if isinstance(client._transport, httpx.MockTransport):
            return original_sync(client, request, *args, **kwargs)
        kind = selected(request.method, request.url)
        if kind is None:
            return original_sync(client, request, *args, **kwargs)
        sequence = reserve(kind, request.url, request.content)
        try:
            result = original_sync(client, request, *args, **kwargs)
        except BaseException as error:
            finish(sequence, error=error)
            raise
        finish(sequence, result)
        return result

    async def asynchronous(client, request, *args, **kwargs):
        if isinstance(client._transport, httpx.MockTransport):
            return await original_async(client, request, *args, **kwargs)
        kind = selected(request.method, request.url)
        if kind is None:
            return await original_async(client, request, *args, **kwargs)
        sequence = reserve(kind, request.url, request.content)
        try:
            result = await original_async(client, request, *args, **kwargs)
        except BaseException as error:
            finish(sequence, error=error)
            raise
        finish(sequence, result)
        return result

    aiohttp.ClientSession._request = aio
    httpx.Client.send = sync
    httpx.AsyncClient.send = asynchronous
    marker = ROOT / 'bootstrap-pids'
    marker.mkdir(exist_ok=True)
    (marker / (str(os.getpid()) + '.json')).write_text(json.dumps(dict(pid=os.getpid(), installed=True,
        aiohttp=aiohttp.__version__, httpx=httpx.__version__, scope='real aiohttp/HTTPX sends; reference MockTransport excluded')) + '\n')
