from pathlib import Path
import json,sqlite3,sys
root=Path('<data-root>/semloom-stage-revalidation-20261111');sys.path.insert(0,str(root/'source/code'))
from src.infrastructure.private_artifacts import write_private_json
with sqlite3.connect(root/'budget.sqlite')as c:
 row=c.execute('SELECT schema,budget_id,limit_count,allocated,deadline FROM budget').fetchone();units=c.execute('SELECT unit_id,first_attempt,requests,claimed FROM units ORDER BY first_attempt').fetchall()
d=dict(zip(('schema','budget_id','limit','allocated_requests','deadline_utc'),row),units=[dict(zip(('unit_id','first_attempt','requests','claimed'),r))for r in units]);write_private_json(root/'budget-snapshot-final.json',d)
f=json.loads((root/'final-inventory.json').read_text());print(json.dumps({'allocated_requests':d['allocated_requests'],'gpu_empty':f['gpu_empty'],'lease_absent_at_inventory':f['lease_absent'],'source_clean':f['source_clean']}))
p=json.loads((root/'pr98-paired-comparison.json').read_text())
print(json.dumps({k:{'capture_status':v['capture_status'],'summary':v['summary'],'native_aliases':v['native_aliases'],'covered':v['call_ids_covered'],'missing':len(v['missing_native_ids']),'unknown_adds':len(v['unknown_adds']),'unmatched':len(v['unmatched_after_business'])}for k,v in p['observation'].items()}))
