from pathlib import Path
import argparse,json,statistics,re
from src.infrastructure.redact import redact_text

artifact=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--evidence-dir',type=Path,default=artifact/'server-originals-final')
parser.add_argument('--output',type=Path,default=Path.cwd()/'experiments/results/diagnostics/native_stage_handoff_20261110/revalidation-summary.json')
args=parser.parse_args();root=args.evidence_dir;output=args.output
frozen=json.loads((root/'frozen.json').read_text())
for choice in frozen.values():
    choice['reused_window_calibration']=dict(source_head=choice['previous_source_head'],half_window_mean_s=choice.pop('half_window_mean_s'),full_window_mean_s=choice.pop('full_window_mean_s'))
cells=[]
for directory in sorted(root.iterdir()):
    if not directory.is_dir() or not (directory/'config.json').exists():continue
    config=json.loads((directory/'config.json').read_text())
    if 'arm' not in config:continue
    report_path=directory/'worker/report.json'
    report=json.loads(report_path.read_text()) if report_path.exists() else {}
    measured=[r for r in report.get('rounds',[]) if not r['warmup']]
    record=dict(run_id=directory.name,arm=config['arm'],status=report.get('status','missing_report'),
        error=report.get('error'),transfer_error=report.get('transfer_error'),logical_rows=len(config['rows']),
        capacity=config['engine']['max_num_seqs'],prefill_window=config['prefill_window'],batch_size=config['batch_size'],
        requested_rounds=config['rounds'],completed_measurement_rounds=len(measured),
        reserved_physical_calls=config['reserved_physical_calls'],startup_s=report.get('startup_s'),
        measured_s=report.get('measured_s'),result_sha256=report.get('result_sha256'),
        mean_round_s=None if not measured else statistics.mean(r['elapsed_s'] for r in measured),
        source_head=json.loads((directory/'source.json').read_text())['head'],
        closed=report.get('close',{}).get('status'),measurement_over_60s=(report.get('measured_s',0)>=60))
    for name,key in [('gpu-after.json','gpu_empty'),('resources.json','resource_check')]:
        data=json.loads((directory/name).read_text())
        record[key]=data.get('empty') if name=='gpu-after.json' else data.get('passed')
        if name=='resources.json':record['peak_observed_rss_sum_bytes']=max((s['observed_rss_sum_bytes']for s in data['samples']),default=0)
    samples=json.loads((directory/'gpu-samples.json').read_text())
    record['peak_gpu_memory_mib']=max((int(line.split(',')[4].strip())for sample in samples for line in sample['gpu'].splitlines()),default=0)
    first=directory/'worker/first-results.json'
    if first.exists():
        receipts=json.loads(first.read_text())
        record['token_lengths']={}
        for key in ('prompt_tokens','completion_tokens'):
            values=[r[key]for r in receipts if type(r.get(key))is int]
            record['token_lengths'][key]=None if not values else dict(min=min(values),median=statistics.median(values),max=max(values),total=sum(values))
    if config['arm']=='pipeline':
        native={name:value.get('engine_api',{}) for name,value in report.get('close',{}).get('stages',{}).items()}
        record['native_scheduler']={k:v.get('native_scheduler_final')for k,v in native.items()}
        record['native_kv_transfer']={k:v.get('native_kv_transfer_final')for k,v in native.items()}
        record['logical_inflight_peak']=max((r['pipeline']['peak_logical_inflight']for r in report.get('rounds',[])),default=0)
        record['overlapping_stage_rounds']=sum(r['pipeline']['simultaneous_stage_ownership']for r in report.get('rounds',[]))
        record['all_pipeline_rounds_passed']=all(r['pipeline']['status']=='passed' for r in report.get('rounds',[]))
        record['native_capacity']={name:stage.get('native_capacity')for name,stage in report.get('ready',{}).get('stages',{}).items()}
        record['native_finished_matches_expected']=all(v.get('native_scheduler_final',{}).get('finished_total')==len(config['rows'])*(config['rounds']+config['warmup_rounds'])for v in native.values()) and len(native)==2
    else:
        record['native_capacity']=report.get('ready',{}).get('native_capacity')
        record['native_reserved_model_calls']=report.get('close',{}).get('engine_api',{}).get('reserved_model_calls')
    cells.append(record)

formal={}
for name,choice in frozen.items():
    arms={arm:sorted((c for c in cells if c['run_id'].startswith('formal01-'+name+'-'+arm+'-')),key=lambda c:c['run_id'])for arm in ('colocated','pipeline')}
    assert all(len(rows)==3 for rows in arms.values())
    assert all(c['status']=='passed' and c['closed']=='closed' and c['gpu_empty'] and c['resource_check']
               and c['completed_measurement_rounds']==choice['rounds'] and c['result_sha256']==choice['result_sha256']
               and c['source_head']==choice['source_head'] for rows in arms.values()for c in rows)
    assert all(c['native_finished_matches_expected'] for c in arms['pipeline'])
    medians={arm:statistics.median(c['mean_round_s']for c in rows)for arm,rows in arms.items()}
    formal[name]=dict(configuration=choice,session_mean_round_s={arm:[c['mean_round_s']for c in rows]for arm,rows in arms.items()},
        session_measured_s={arm:[c['measured_s']for c in rows]for arm,rows in arms.items()},
        session_startup_s={arm:[c['startup_s']for c in rows]for arm,rows in arms.items()},
        median_session_mean_round_s=medians,pipeline_over_colocated=medians['pipeline']/medians['colocated'],
        pipeline_time_increase_percent=(medians['pipeline']/medians['colocated']-1)*100,
        all_measurement_blocks_over_60s=all(c['measurement_over_60s']for rows in arms.values()for c in rows),
        logical_requests_per_arm_including_warmup=sum(c['logical_rows']*(c['completed_measurement_rounds']+1)for c in arms['colocated']),
        physical_calls_total=sum(c['reserved_physical_calls']for rows in arms.values()for c in rows),
        gpu_memory_peak_mib={arm:max(c['peak_gpu_memory_mib']for c in rows)for arm,rows in arms.items()},
        observed_rss_sum_peak_bytes={arm:max(c['peak_observed_rss_sum_bytes']for c in rows)for arm,rows in arms.items()})

observation=dict(status='not_repeated_for_this_source',scope='Prior instrumented batching evidence remains bound to its original source; current native scheduler and NIXL counters retained per cell')
summary=dict(schema='semloom.native_stage_revalidation.summary.v1',source_head=next(iter(frozen.values()))['source_head'],
    model='Qwen/Qwen2.5-1.5B-Instruct',device='one RTX4090',vllm='0.25.1',nixl='1.3.0',
    resource_contract='same one GPU; shared 8-CPU affinity; total declared GPU memory0.6; total batch-token cap4096; BF16; eager; native prefix cache enabled',
    timing='run_prepared on resident owners; one separate warmup; input preparation, parity hashing, evidence writes, startup and shutdown excluded',
    inference='Repeated same prepared request sets with warm prefix state, not full query JCT or general workload throughput',
    cells=cells,formal=formal,observed_native_batches=observation,
    budget=json.loads((root/'budget-snapshot-final.json').read_text()),
    final_inventory=json.loads((root/'final-inventory.json').read_text()),
    limitations=['single GPU','eager only','request replay not full LOTUS query','synthetic long-output task not real dataset quality',
                 'actual GPU batch proof belongs to separate instrumented probe; no kernel simultaneity or duration measurement',
                 'no multiGPU or live decode migration qualification','Real request failure and cancel were injected; 50ms cancel preserves unknown but left two named semaphores; raw resource failure retained and scoped external recovery recorded'])
summary['calibration_reuse']=json.loads((root/'calibration-reuse-identity.json').read_text())
summary['freeze_checks']=json.loads((root/'freeze-checks.json').read_text())
summary['boundary_checks']={}
for name in ('capture','cancel'):
    directory=root/('boundaries01-'+name)
    report=json.loads((directory/'boundary-report.json').read_text())
    resources=json.loads((directory/'resources.json').read_text())
    summary['boundary_checks'][name]=dict(functional_status=report['status'],checks=report['checks'],short_close_elapsed_s=report.get('short_close_elapsed_s'),raw_close_status=report.get('short_close',{}).get('status'),raw_resource_passed=resources['passed'],remaining_new_shm_names=resources['remaining_new_shm_names'],gpu_empty=json.loads((directory/'gpu-after.json').read_text())['empty'])
summary['scoped_resource_recovery']=json.loads((root/'cancel-scoped-resource-recovery.json').read_text())
summary['CPU_checks']={}
for name in ('cpu-serving','cpu02-serving','cpu02-experiments','cpu02-pr99'):
    text=(root/(name+'.log')).read_text()
    match=re.search(r'Ran (\d+) tests? in ([0-9.]+)s',text)
    skipped=re.search(r'OK \(skipped=(\d+)\)',text)
    summary['CPU_checks'][name]=dict(status='passed'if'\nOK'in text else'failed',test_count=None if not match else int(match[1]),elapsed_s=None if not match else float(match[2]),skipped=int(skipped[1])if skipped else None)
optional=root/'pr98-paired-comparison.json'
summary['pr98_diagnostic']=json.loads(optional.read_text())if optional.exists()else dict(status='not_completed')
summary['pr98_post_capture_cleanup']=json.loads((root/'pr98-post-capture-cleanup.json').read_text())
summary['pr98_raw_controller_results']={arm:json.loads((root/name/'RESULT.json').read_text())for arm,name in json.loads((root/'pr98-comparison-cells.json').read_text()).items()}

# Inventory contains private model paths. Public exports use the same sanitization as raw evidence.
encoded=redact_text(json.dumps(summary,ensure_ascii=False,indent=2))
connection=json.loads((artifact/'ssh-connection.json').read_text()) if (artifact/'ssh-connection.json').exists() else {}
if connection.get('host'):encoded=encoded.replace(connection['host'],'<private-host>')
encoded=encoded.replace('<data-root>/','<data-root>/')
encoded=encoded.replace('<system-python>/','<system-python>/').replace('<system-home>/','<system-home>/').replace('<local-home>/','<local-home>/')
encoded=re.sub(r'autodl-container-[A-Za-z0-9-]+','<worker-host>',encoded)
encoded=re.sub(r'(?<![A-Za-z0-9_])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?![A-Za-z0-9_])',lambda m:m[0]if m[0]in('127.0.0.1','0.0.0.0')else'<private-ip>',encoded)
output.write_text(encoded+'\n')
print(json.dumps(formal,ensure_ascii=False,indent=2));print('cells',len(cells))
