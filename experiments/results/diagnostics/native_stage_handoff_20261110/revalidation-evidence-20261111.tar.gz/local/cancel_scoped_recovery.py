from pathlib import Path
import os,sys,json,time,psutil,subprocess
root=Path('<data-root>/semloom-stage-revalidation-20261111');sys.path.insert(0,str(root/'source/code'))
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.infrastructure.private_artifacts import write_private_json
from src.infrastructure.redact import redact_json_values
old=json.loads((root/'cancel-cleanup-investigation.json').read_text());case=json.loads((root/'boundaries01-cancel/resources.json').read_text())
names=case['remaining_new_shm_names'];expected={x['name']:x for x in old['shm']if x['name']in names}
assert set(names)=={'sem.mp-9p5y_mcz','sem.mp-qds3_7r5'}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root/'source',text=True).strip()
with acquire_host_runner_lease(Path('<data-root>/experiment-artifacts'),repository_commit=head):
 assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
 live=[]
 for x in case['observed_identities']:
  try:
   p=psutil.Process(x['pid'])
   if p.create_time()==x['create_time'] and p.status()not in(psutil.STATUS_ZOMBIE,psutil.STATUS_DEAD):live.append(p.pid)
  except psutil.NoSuchProcess:pass
 assert not live
 references=[]
 for p in psutil.process_iter():
  try:
   for m in p.memory_maps(grouped=False):
    if any('/dev/shm/'+n in m.path for n in names):references.append([p.pid,m.path])
  except psutil.NoSuchProcess:pass
 assert not references
 before={p.name:dict(inode=p.stat().st_ino,bytes=p.stat().st_size,ctime=p.stat().st_ctime)for p in Path('/dev/shm').iterdir()}
 for n in names:
  e=expected[n];actual=before[n];assert actual==dict(inode=e['inode'],bytes=e['bytes'],ctime=e['ctime'])
 for n in names:(Path('/dev/shm')/n).unlink()
 after={p.name:dict(inode=p.stat().st_ino,bytes=p.stat().st_size,ctime=p.stat().st_ctime)for p in Path('/dev/shm').iterdir()}
 assert after=={k:v for k,v in before.items()if k not in names}
 v=os.statvfs('/dev/shm');used=(v.f_blocks-v.f_bfree)*v.f_frsize
 out=dict(status='physical_baseline_restored_after_scoped_external_cleanup',removed=names,before=before,after=after,shm_used_after=used,live_owned_processes=live,live_mappings=references,
   original_resource_status_preserved=False if case['passed']else True,raw_close_status='unknown',scope='only two names first observed in this exclusive diagnostic window; birth-matched processes exited; inode and creation time unchanged; no mappings; historical SHM preserved',time=time.time())
 write_private_json(root/'cancel-scoped-resource-recovery.json',redact_json_values(out));print(json.dumps({k:out[k]for k in ['status','removed','shm_used_after','original_resource_status_preserved']}))
