from pathlib import Path
import sys,json,hashlib,time,psutil,subprocess,os
root=Path('<data-root>/semloom-stage-revalidation-20261111');sys.path.insert(0,str(root/'source/code'))
from src.infrastructure.runner_lease import RunnerOwner,RunnerLease
from src.infrastructure.private_artifacts import write_private_json
from src.infrastructure.redact import redact_json_values
case=root/'pr98-prefix';config=json.loads((case/'config.json').read_text());path=Path(config['external_owner']['lease_path'])
raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==config['external_owner']['lease_sha256'];lease=json.loads(raw);assert lease['pid']==919678
assert not psutil.pid_exists(lease['pid'])
final=json.loads((case/'FINAL.json').read_text());live=[]
for item in final['cleanup']['observed_owned']:
 try:
  p=psutil.Process(item['pid'])
  if p.create_time()==item['create_time']and p.status()not in(psutil.STATUS_ZOMBIE,psutil.STATUS_DEAD):live.append(p.pid)
 except psutil.NoSuchProcess:pass
assert not live
foreign=final['snapshot']['foreign_work'];assert len(foreign)==1
p=psutil.Process(foreign[0]['pid']);cmd=p.cmdline();assert p.create_time()==foreign[0]['create_time']and hashlib.sha256(' '.join(cmd).encode()).hexdigest()==foreign[0]['cmdline_sha256']
assert "'readonly_wait_before_Q7_128'"in cmd[-1] and "'starts_tests':False"in cmd[-1]
compute=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True);assert not compute.strip()
assert json.loads((case/'REVALIDATION-RESOURCES.json').read_text())['passed']
record=dict(status='owned_cleanup_confirmed_external_readonly_waiter_explained',checked_epoch_s=time.time(),raw_global_idle_gate_preserved=False,owned_processes_live=live,gpu_compute_empty=True,
 readonly_waiter={k:foreign[0][k]for k in ['pid','create_time','cmdline_sha256']},waiter_behavior='Reads lease and /proc owner identity, prints status and sleeps; explicitly starts_tests=False; not signalled or changed',source_head=config['expected_source']['head'],
 resource_scope='all supervisor-observed birth-matched task processes exited; sampled RSS/SHM and GPU checks passed; no claim that all host Python processes are absent')
RunnerLease(path,RunnerOwner(**{k:lease[k]for k in ['hostname','pid','process_start_id','owner_token']})).release()
record['owned_lease_released']=not path.exists();write_private_json(root/'pr98-post-capture-cleanup.json',redact_json_values(record));print(json.dumps({'status':record['status'],'lease_released':record['owned_lease_released']}))
p=root/'pr98-external-process.json';write_private_json(p,redact_json_values(json.loads(p.read_text())))
