from pathlib import Path
import os,sys,json,time,psutil,subprocess,shutil
root=Path(sys.argv[1]);source=Path('<data-root>/semloom-stage-revalidation-20261111/source')
sys.path.insert(0,str(source/'code'));sys.path.insert(0,str(source/'code/scripts/profiling/record_observation'))
from src.infrastructure.private_artifacts import write_private_json
from src.infrastructure.redact import redact_json_values
from src.observability.process_resources.supervised import ResourceMonitor
import workflow,control_resource_C2
config=workflow.check(root/'PREPARED-CONFIG.json')
resources=ResourceMonitor(dict(cpu_affinity_slots=config['cpu_affinity'],max_sampled_owned_rss_bytes=32*1024**3,max_owned_shm_bytes=8*1024**3),sample_seconds=.5)
seen={};last=[0.0]
def monitor(identities):
 resources(identities)
 if time.monotonic()-last[0]<.5:return
 last[0]=time.monotonic()
 if shutil.disk_usage(root).free<10*1024**3:raise RuntimeError('disk reserve reached')
 if control_resource_C2.trace_storage_bytes({root.parent})>8*1024**3:raise RuntimeError('campaign artifact bound reached')
 for pid,born in identities:
  if pid in seen:continue
  try:
   p=psutil.Process(pid)
   if p.create_time()!=born:continue
   command=p.cmdline()
   if command and (command[0]==config['engine']['model_python'] or p.name().startswith('VLLM')):
    env=p.environ();seen[pid]=dict(pid=pid,create_time=born,name=p.name(),batch_invariant=env.get('VLLM_BATCH_INVARIANT'),run_id=env.get('SEM_RECORD_RUN_ID'))
  except psutil.NoSuchProcess:pass
try:
 control_resource_C2.main(root,monitor=monitor)
finally:
 report=resources.finish();write_private_json(root/'REVALIDATION-RESOURCES.json',redact_json_values(report))
 write_private_json(root/'BATCH-INVARIANT-PROCESSES.json',dict(processes=list(seen.values()),all_observed_enabled=bool(seen)and all(x['batch_invariant']=='1'for x in seen.values()),scope='observed native-process environments; source semantics supplied by fixed vLLM'))
if not report['passed']:raise RuntimeError('PR98 resource cleanup did not pass')
if not seen or not all(x['batch_invariant']=='1'for x in seen.values()):raise RuntimeError('native model environment flag unconfirmed')
