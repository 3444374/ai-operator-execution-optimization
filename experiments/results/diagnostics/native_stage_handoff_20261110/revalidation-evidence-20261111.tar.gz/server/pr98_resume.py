from pathlib import Path
import sys,os,time,json,subprocess
root=Path('<data-root>/semloom-stage-revalidation-20261111');source=root/'source';sys.path[:0]=[str(source/'code'),str(source/'code/scripts/profiling/record_observation')]
import workflow
from src.infrastructure.private_artifacts import write_private_json,file_identity
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.lotus_records_supervisor import supervise
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();ledger=CellBudgetLedger(root/'budget.sqlite',AttemptBudget('native-stage-revalidation-20261111',500000))
old=json.loads((root/'pr98-fifo/RESULT.json').read_text());assert old['actual_known_model_requests']==0 and old['physical_cleanup_confirmed'] and old['lease_released']
with acquire_host_runner_lease(Path('<data-root>/experiment-artifacts'),repository_commit=head):
 for arm in ['fifo','prefix']:
  c=json.loads((root/('pr98-base-'+arm+'.json')).read_text());Path(c['ray_options']['_plasma_directory']).mkdir(mode=0o700)
 workflow.prepare(root/'pr98-base-fifo.json',root/'pr98-cpu-fifo/CPU-READY.json',root/'pr98-fifo-retry01','pr98-invariant-fifo-retry01','on','full')
 write_private_json(root/'pr98-directory-repair.json',dict(cause='Configured Ray plasma directory was missing; installed Ray determine_plasma_store_config rejects it before worker startup',old_model_calls=0,action='created both declared private directories; unchanged base/CPU qualification and business configuration; new FIFO cell; no refund'))
write_private_json(root/'pr98-comparison-cells.json',dict(fifo='pr98-fifo-retry01',prefix='pr98-prefix'))
write_private_json(root/'pr98-resume-source.json',dict(head=head,script=file_identity(Path(__file__)),wrapper=file_identity(root/'pr98_cell.py'),budget=ledger.snapshot()))
for arm,name in [('fifo','pr98-fifo-retry01'),('prefix','pr98-prefix')]:
 c=workflow.check(root/name/'PREPARED-CONFIG.json');driver=c['engine']['driver_python'];os.sched_setaffinity(0,set(c['cpu_affinity']))
 assert ledger.snapshot()['deadline_utc']-time.time()>=1000
 unit=c['run_id'];ledger.reserve_unit(unit,48);ledger.claim_unit(unit).bind_execution()
 write_private_json(root/name/'GLOBAL-RESERVATION.json',dict(unit_id=unit,calls=48,budget=ledger.snapshot(),hierarchy='campaign precharge and per-cell cap cover the same attempts'))
 print('START',name,flush=True)
 supervise([driver,'-B',str(root/'pr98_cell.py'),str(root/name)],root/name/'outer-supervision',timeout_s=1100,grace_s=90,natural_exit_grace_s=3)
 result=json.loads((root/name/'RESULT.json').read_text());print(json.dumps(result),flush=True)
 assert result['status']=='completed'and result['actual_call_count_complete']and result['physical_cleanup_confirmed']and result['lease_released']
print('DONE pr98-resume',flush=True)
