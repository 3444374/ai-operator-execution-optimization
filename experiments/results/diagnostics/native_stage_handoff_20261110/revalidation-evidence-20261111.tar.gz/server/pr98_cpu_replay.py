from pathlib import Path
from dataclasses import asdict
import json,csv,itertools,sys,hashlib
root=Path('<data-root>/semloom-stage-revalidation-20261111');source=root/'source';sys.path.insert(0,str(source/'code'))
from src.experiments.record_chain_validation import make_chain
from src.experiments.prepared_order_replay import replay
from src.semantic_methods.lotus.record_types import RecordOccurrence
from src.serving.backends.vllm_protocol import EngineSpec,GenerationSpec,_prepared,IDENTITY_FIELDS
from src.infrastructure.private_artifacts import write_private_json,content_digest,file_identity
from transformers import AutoTokenizer
config=json.loads((root/'pr98-base-fifo.json').read_text());old=json.loads((root/'pr98-old-calls.json').read_text())
binding=config['workload']['input'];path=Path(binding['csv']);assert file_identity(path)['sha256']==binding['sha256']
with path.open(newline='')as stream:original=list(itertools.islice(csv.DictReader(stream),16))
records=[RecordOccurrence('movie:'+str(i),i,r[binding['id_column']],{'text':r[binding['text_column']]})for i,r in enumerate(original)]
engine=EngineSpec.from_dict(config['engine']);generation=GenerationSpec.from_dict(config['generation']);chain=make_chain(config['model_name'],generation)
tokenizer=AutoTokenizer.from_pretrained(engine.tokenizer_path,local_files_only=True);by_id={x['call_id']:x for x in old['calls']};seen=set();requests=[]
def infer(prepared,*,generation):
 identities,conversations=_prepared(prepared);answers=[]
 for row,ident,conversation in zip(prepared,identities,conversations,strict=True):
  key=ident['call_id'];assert key not in seen;call=by_id[key];assert all(call.get(k)==v for k,v in ident.items())
  ids=tokenizer.apply_chat_template(conversation,tokenize=True,add_generation_prompt=True,return_dict=False)
  assert ids==json.loads(call['prompt_token_ids_json']);seen.add(key);answers.append(call)
  requests.append(dict(row={name:row[name]for name in (*IDENTITY_FIELDS,'messages_json')},generation=asdict(generation),token_ids=ids,prompt_tokens=len(ids)))
 return answers
result=chain.run_batch(records,infer);assert seen==set(by_id)and len(result['records'])==old['output_rows']
for call in result['calls']:
 for field in ['parent_call_ids','decision']:assert call.get(field)==by_id[call['call_id']].get(field)
digest=content_digest([dict(row=x['row'],generation=x['generation'],token_ids=x['token_ids'])for x in requests])
capture=dict(schema='semloom.semantic_request_capture.v1',requests=requests,request_digest=digest,complete_initial_operator=False)
write_private_json(root/'pr98-current-request-capture.json',capture)
report=replay(capture,candidate_limit=32,group_requests=1,prefix_token_limit=512,block_tokens=16,repeats=1)
report.update(current_source=config['expected_source'],original_source=old['source_commit'],original_report_sha256=old['original_report_sha256'],native_prompt_ids_match=True,original_output_row_count_matches=True,
 replay_scope='current original method with 48 retained original answers; exact identity/message/prompt-token reconstruction; saved final-row count, parent and decision checks; ordering readiness is simulated')
write_private_json(root/'pr98-current-request-replay.json',report)
print(json.dumps({'status':'passed','requests':len(requests),'models':0,'native_prompt_ids_match':True}))
