from pathlib import Path
import sys,time,json
root=Path('<data-root>/semloom-stage-revalidation-20261111');sys.path.insert(0,str(root/'source/code'))
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.lotus_records_supervisor import supervise
from src.infrastructure.private_artifacts import write_private_json
assert 'DONE formal01' in (root/'formal01-controller.log').read_text()
for cell in root.glob('formal01-*/config.json'):
 assert json.loads((cell.parent/'worker/report.json').read_text())['status']=='passed'
 assert json.loads((cell.parent/'resources.json').read_text())['passed']
 assert json.loads((cell.parent/'gpu-after.json').read_text())['empty']
ledger=CellBudgetLedger(root/'budget.sqlite',AttemptBudget('native-stage-revalidation-20261111',500000))
remaining=ledger.snapshot()['deadline_utc']-time.time();assert remaining>=2200
report=supervise(['<data-root>/venvs/sembench-query-0910/bin/python','-B',str(root/'pr98_campaign.py')],root/'pr98-campaign02-supervision',timeout_s=min(2200,remaining-5),grace_s=90,natural_exit_grace_s=3)
write_private_json(root/'pr98-outer02-result.json',report)
print(json.dumps({'status':report['status'],'worker_exit':report['worker_exit']}))
