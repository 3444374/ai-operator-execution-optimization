from pathlib import Path
import json,math,statistics,time,sys,subprocess
root=Path('<data-root>/semloom-stage-revalidation-20261111');old=Path('<data-root>/semloom-stage-pipeline-20261111')
sys.path.insert(0,str(root/'source/code'))
from src.infrastructure.private_artifacts import write_private_json,content_digest
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
ledger=CellBudgetLedger(root/'budget.sqlite',AttemptBudget('native-stage-revalidation-20261111',500000))
previous=json.loads((old/'frozen.json').read_text());frozen={};checks={}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root/'source',text=True).strip()
identity=json.loads((root/'calibration-reuse-identity.json').read_text())
assert all(v for v in identity.values()if type(v)is bool)
for name,choice in previous.items():
 means={};starts={};checks[name]={}
 for arm in ('colocated','pipeline'):
  cell=root/('recheck01-'+name+'-'+arm);reference=old/('formal01-'+name+'-'+arm+'-r0')
  report=json.loads((cell/'worker/report.json').read_text());config=json.loads((cell/'config.json').read_text());baseline=json.loads((reference/'config.json').read_text())
  source=json.loads((cell/'source.json').read_text());oldsource=json.loads((reference/'source.json').read_text())
  invariants={key:config[key]==baseline[key]for key in ['arm','rows','generation','engine','limits','prefill','decode','prefill_window','batch_size','warmup_rounds']}
  invariants['cpu_affinity']=source['cpu_affinity']==oldsource['cpu_affinity']
  invariants['input_digest']=source['input_digest']==oldsource['input_digest']
  checks[name][arm]=invariants;assert all(invariants.values()),(name,arm,invariants)
  assert report['status']=='passed'and report['result_sha256']==choice['result_sha256']
  assert report['close']['status']=='closed'
  assert json.loads((cell/'resources.json').read_text())['passed']and json.loads((cell/'gpu-after.json').read_text())['empty']
  means[arm]=statistics.mean(x['elapsed_s']for x in report['rounds']if not x['warmup']);starts[arm]=report['startup_s']
 rounds=max(choice['rounds'],math.ceil(65/min(means.values())))
 frozen[name]=dict(choice,source_head=head,rounds=rounds,previous_source_head=choice['source_head'],previous_rounds=choice['rounds'],recheck_mean_s=means,
  selected_calibration_mean_s=means,expected_physical_calls_three_repetitions=(rounds+1)*(120 if name=='q8' else 64)*9,
  predicted_measured_s={arm:rounds*mean for arm,mean in means.items()},reuse_scope='same verified hardware, model/native files, requests, generation, capacities, CPU slots and lifecycle; output/calibration spot recheck passed')
available=ledger.snapshot()['limit']-ledger.snapshot()['allocated_requests']-96
required=sum(x['expected_physical_calls_three_repetitions']for x in frozen.values())
if required>available:
 for name,choice in frozen.items():
  choice.update(rounds=previous[name]['rounds'],duration_target_reduced_to_fit_budget=True)
  choice['expected_physical_calls_three_repetitions']=(choice['rounds']+1)*(120 if name=='q8' else 64)*9
  choice['predicted_measured_s']={arm:choice['rounds']*mean for arm,mean in choice['recheck_mean_s'].items()}
 required=sum(x['expected_physical_calls_three_repetitions']for x in frozen.values())
assert required<=available
assert not (root/'frozen.json').exists()
write_private_json(root/'frozen.json',frozen)
write_private_json(root/'freeze-checks.json',dict(source_head=head,config_checks=checks,allocated_before=ledger.snapshot()['allocated_requests'],formal_reserved_calls=required,optional_diagnostic_reserve=96,remaining_after_formal=available-required,freeze_time_epoch_s=time.time()))
print(json.dumps(dict(frozen=frozen,physical_call_total=required,remaining_after_formal=available-required),indent=2))
