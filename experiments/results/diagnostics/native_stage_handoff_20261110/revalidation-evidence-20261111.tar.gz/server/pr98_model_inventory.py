from pathlib import Path
import hashlib,json,sys
root=Path('<data-root>/semloom-stage-revalidation-20261111');sys.path.insert(0,str(root/'source/code'))
from src.infrastructure.private_artifacts import write_private_json
c=json.loads((root/'pr98-templates.json').read_text())['fifo'];model=Path(c['engine']['model_path'])
entries=[]
for p in sorted(model.iterdir()):
 if p.suffix not in('.safetensors','.json'):continue
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 entries.append(dict(file=p.name,bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns,sha256=h.hexdigest()))
assert any(x['file'].endswith('.safetensors')for x in entries)
report=dict(model_name='Qwen/Qwen2.5-7B-Instruct',files=entries,snapshot_metadata=[dict(file=str(p.relative_to(model)),metadata=p.read_text().splitlines())for p in sorted((model/'.cache/huggingface/download').glob('*.metadata'))],historical_weight_hash_equality='not asserted; original local path reused and this pair has its own complete hashes')
write_private_json(root/'pr98-model-identity.json',report);print(json.dumps({'weight_files':sum(x['file'].endswith('.safetensors')for x in entries),'files':len(entries)}))
