"""Finite real-model failure diagnostics; raw failures remain failures."""
from pathlib import Path
from dataclasses import asdict
import argparse,json,sys,time,threading
from src.infrastructure.private_artifacts import write_private_json,file_identity
from src.infrastructure.redact import redact_json_values,redact_text
from src.experiments.request_capture_run import run_capture
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.attempt_ledger import AttemptBudget
from src.semantic_methods.lotus.records import identity
from src.serving.backends.async_engine_process import AsyncEngineProcess
from src.serving.backends.pipelined_prefill_decode import PipelinedPrefillDecodeProcess
from src.serving.backends.prefill_decode_process import NixlPlacement
from src.serving.backends.stage_process_cleanup import StageEngineCleanup
from src.serving.backends.vllm_protocol import EngineSpec,GenerationSpec,AsyncEngineLimits
from src.serving.backends.vllm_sync_process import _publish

p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);args=p.parse_args()
c=json.loads(args.config.read_text());root=Path(c['artifact_root']);control=root/'control';control.mkdir(mode=0o700)
report=dict(status='failed',kind=c['kind']);owner=None;thread=None

def save():write_private_json(root/'boundary-report.json',redact_json_values(report))
def rows(text):
 return [dict(identity('boundary-'+c['kind'],'row-'+str(i),i),messages_json=json.dumps([dict(role='user',content=s)]))for i,s in enumerate(text)]
try:
 if c['kind']=='capture':
  generation=asdict(GenerationSpec(max_tokens=512,temperature=0,seed=0,stop=()))
  records=rows(['x '*6000,'Write the integers from 1 to 500 separated by spaces. Do not stop early.','Return OK.'])
  capture=dict(schema='semloom.semantic_request_capture.v1',requests=[dict(row=row,generation=generation,token_ids=[])for row in records])
  write_private_json(root/'capture.json',capture)
  config=dict(workload=dict(kind='request_capture',expected_calls=3,input=dict(capture=str(root/'capture.json'),**file_identity(root/'capture.json'))),
   generation=generation,engine=dict(c['engine'],max_model_calls=3,max_model_len=4096),
   ipc_limits=dict(max_inflight=2,item_input_bytes=256*1024,item_result_bytes=256*1024),request_group_rows=2,
   artifact_root=str(root),units={c['unit_id']:3},resources=dict(startup_timeout_s=240,query_timeout_s=120),limits=dict(owner_close_s=30))
  write_private_json(root/'capture-config.json',config)
  class ObservedProcess(AsyncEngineProcess):
   def close(self,timeout=15):
    report.setdefault('close_snapshots',[]).append(self.snapshot())
    return super().close(timeout)
  def factory(*a,**kw):
   global owner
   owner=ObservedProcess(*a,**kw,worker_log=control/'native.log')
   _publish(control/'engine-capture.json',dict(model_pid=owner.process.pid,process_created=owner.process_created,process_exit_confirmed=False,status='ready',cleanup_errors=[]))
   return owner
  ledger=CellBudgetLedger(Path(c['ledger']),AttemptBudget('native-stage-revalidation-20261111',500000))
  raw=run_capture(config,ledger,process_type=factory)
  report['capture_summary']={k:raw[k] for k in ['status','error_type','actual_calls','actual_calls_scope','submitted_requests','received_terminal_events','confirmed_terminal_events','unreceived_request_ids','close']}
  report['retained_calls']=[dict(call_id=x['call_id'],status=x['status'],completion_tokens=x.get('completion_tokens'),prompt_tokens=x.get('prompt_tokens'))for x in raw['calls']]
  report['checks']=dict(failure_preserved=raw['status']=='failed',only_first_group=raw['submitted_requests']==2,
   both_receipts_retained=raw['actual_calls']==raw['received_terminal_events']==2,
   retained_members={x['call_id']for x in raw['calls']}=={x['call_id']for x in records[:2]},
   no_unreceived=raw['unreceived_request_ids']==[],close_snapshot_present=bool(report.get('close_snapshots')))
  assert all(report['checks'].values()),report['checks']
 elif c['kind']=='cancel':
  generation=GenerationSpec(max_tokens=1024,temperature=0,seed=0,stop=())
  records=rows(['Write every integer from 1 to 1000 separated by spaces. Do not stop early. '+str(i)for i in range(2)])
  class ObservedPipeline(PipelinedPrefillDecodeProcess):
   def close(self,timeout=30):
    start=time.monotonic();value=super().close(timeout)
    report.setdefault('close_observations',[]).append(dict(timeout_s=timeout,elapsed_s=time.monotonic()-start,report=value))
    return value
  owner=ObservedPipeline(EngineSpec.from_dict(dict(c['engine'],max_model_calls=2)),generation,control,time.monotonic()+360,240,
   prefill=NixlPlacement('0',15700),decode=NixlPlacement('0',15701),limits=AsyncEngineLimits(max_inflight=4,item_input_bytes=256*1024,item_result_bytes=256*1024,feedback_interval_s=.01),
   batch_size=2,prefill_window=2,close_timeout_s=c['close_budget_s'])
  report['ready']=owner.ready()
  def execute():
   try:report['results']=owner.run_prepared(records,generation=generation)
   except BaseException as e:report['run_error']=redact_text(type(e).__name__+': '+str(e))
  thread=threading.Thread(target=execute);thread.start();until=time.monotonic()+60
  while True:
   snap=owner.stages['decode'].snapshot();native=snap.get('native_feedback')or{}
   if native.get('running',0)>0 and snap['active_requests']>0:break
   if not thread.is_alive() or time.monotonic()>until:raise RuntimeError('native decode in flight was not observed')
   time.sleep(.01)
  report['cancel_point']=snap;owner.cancel();thread.join(timeout=35)
  first=report['close_observations'][0]
  report['short_close']=first['report'];report['short_close_elapsed_s']=first['elapsed_s']
  report['run_thread_stopped']=not thread.is_alive();report['pipeline']=owner.last_run_report
  report['retry_close']=owner.close(timeout=2)
  report['checks']=dict(native_inflight_observed=native.get('running',0)>0,
   short_close_bounded=report['short_close_elapsed_s']<c['close_observation_limit_s'],
   deadline_cleanup_exercised='registered_process_cleanup' in report['short_close'],
   unknown_preserved=report['short_close']['status']=='unknown',run_thread_stopped=report['run_thread_stopped'],
   request_run_failed=report['pipeline'] is not None and report['pipeline']['status']=='failed',
   no_identity_loss=all(x.get('model_pid') and x.get('process_created')for x in owner._process_records.values()))
  assert all(report['checks'].values()),report['checks']
 else:raise ValueError('unknown boundary kind')
 report['status']='passed'
except BaseException as e:
 report['error']=redact_text(type(e).__name__+': '+str(e));raise
finally:
 if owner is not None:
  try:report['final_close']=owner.close(timeout=3)
  except Exception as e:report['final_close_error']=type(e).__name__
 report['cleanup']=StageEngineCleanup(control).stop(grace_s=3,started=owner is not None)
 if not report['cleanup']['process_exit_confirmed']:report['status']='failed'
 save()
print(json.dumps({'kind':c['kind'],'status':report['status'],'checks':report.get('checks')}))
if report['status']!='passed':raise SystemExit(1)
