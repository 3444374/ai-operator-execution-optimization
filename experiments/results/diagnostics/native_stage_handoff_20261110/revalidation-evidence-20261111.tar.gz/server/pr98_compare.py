from pathlib import Path
from collections import Counter
import json,sys,csv,itertools
root=Path('<data-root>/semloom-stage-revalidation-20261111');source=root/'source';sys.path.insert(0,str(source/'code'))
from src.infrastructure.private_artifacts import write_private_json,file_identity,content_digest
from src.experiments.record_chain_validation import make_chain,FIELDS
from src.semantic_methods.lotus.record_types import RecordOccurrence
from src.serving.backends.vllm_protocol import GenerationSpec,_prepared
from src.experiments.native_gpu_diagnostics import analyze_directory
cells=json.loads((root/'pr98-comparison-cells.json').read_text());arms={};orders={};relations={};observation={};files={}
for arm in ['fifo','prefix']:
 cell=root/cells[arm];p=cell/'WORKER-RESULT.json';d=json.loads(p.read_text());c=json.loads((cell/'config.json').read_text());files[arm]=file_identity(p)
 calls=d['close']['calls'];assert d['status']=='completed'and len(calls)==48 and len({x['call_id']for x in calls})==48
 assert all(x['status']=='succeeded'and x['submission_confirmed'] is True and x['engine_terminal_confirmed'] is True for x in calls)
 arms[arm]={x['call_id']:x for x in calls};orders[arm]=[x['call_id']for x in sorted(calls,key=lambda x:x['model_start_monotonic'])]
 binding=c['workload']['input'];path=Path(binding['csv']);assert file_identity(path)['sha256']==binding['sha256']
 with path.open(newline='')as stream:original=list(itertools.islice(csv.DictReader(stream),16))
 records=[RecordOccurrence('movie:'+str(i),i,x[binding['id_column']],{'text':x[binding['text_column']]})for i,x in enumerate(original)]
 chain=make_chain(c['model_name'],GenerationSpec.from_dict(c['generation']));seen=set()
 def infer(prepared,*,generation):
  identities,_=_prepared(prepared);out=[]
  for ident in identities:
   key=ident['call_id'];assert key not in seen;call=arms[arm][key];assert all(call.get(k)==v for k,v in ident.items());out.append(call);seen.add(key)
  return out
 replay=chain.run_batch(records,infer);assert seen==set(arms[arm]);relations[arm]=[x.describe()for x in replay['records']]
 diagnostics=analyze_directory(cell/'events',max_events=1000000);write_private_json(cell/'native-decisions.json',diagnostics)
 events=[json.loads(line)for f in sorted((cell/'events').glob('events-*.jsonl'))for line in f.read_text().splitlines()]
 opens={}
 for e in events:
  if e['event']=='native_open':
   assert len(e['identities'])==1;opens[(e['pid'],e['request_id'])]=e['identities'][0]['call_id']
 aliases={};unknown_adds=[]
 for e in events:
  if e['event']=='native_api_native_add_return':
   call=opens.get((e['pid'],e['request_id']));native=(e.get('native_identity')or{}).get('mapped_internal_ids',[])
   if not call or not native:unknown_adds.append([e['pid'],e['request_id']])
   for key in native:
    assert key not in aliases;aliases[key]=call
 first=min(e['monotonic_ns']for e in events if e['event']=='native_open');covered=set();hist=Counter();modes=Counter();early=[];unmatched=[]
 for e in events:
  if e['event']!='native_graph_decision':continue
  members=e.get('scheduled_tokens')or{}
  if members and set(members)<=set(aliases):covered.update(members);hist[len(members)]+=1;modes[e.get('cudagraph_mode')]+=1
  elif e.get('observation_ns',e['monotonic_ns'])<first:early.append([e['pid'],e['observer_execute_id']])
  else:unmatched.append([e['pid'],e['observer_execute_id'],list(members)])
 observation[arm]=dict(capture_status=diagnostics['capture_status'],capture_issues=diagnostics['capture_issues'],summary=diagnostics['summary'],native_aliases=len(aliases),call_ids_covered=len({aliases[k]for k in covered}),
  missing_native_ids=sorted(set(aliases)-covered),unknown_adds=unknown_adds,unmatched_after_business=unmatched,initial_unassociated=len(early),batch_histogram=dict(hist),graph_modes=dict(modes),
  scope='actual native graph/input-preparation members linked through returned native aliases; not kernel time or exhaustive CUPTI coverage')
 write_private_json(cell/'business-member-coverage.json',observation[arm])
assert set(arms['fifo'])==set(arms['prefix'])
differences=[]
for key,a in arms['fifo'].items():
 b=arms['prefix'][key];changed=[field for field in FIELDS if a.get(field)!=b.get(field)]
 if changed:differences.append(dict(call_id=key,fields=changed,reference_output_token_ids=a['output_token_ids_json'],candidate_output_token_ids=b['output_token_ids_json']))
strict=not differences and relations['fifo']==relations['prefix']
report=dict(schema='semloom.pr98_batch_invariant_diagnostic.v1',status='passed'if strict else'failed_strict_comparison',current_source=json.loads((root/cells['fifo']/'config.json').read_text())['expected_source'],
 configuration=dict(vllm_batch_invariant='1',model='Qwen2.5-7B-Instruct',rows=16,stages=3,C=4,B=1,max_tokens=8,stop=['\n'],seed=0),
 actual_calls={k:len(v)for k,v in arms.items()},strictly_equal_calls=48-len(differences),differences=differences,outputs_strictly_comparable=strict,
 relation_equal=relations['fifo']==relations['prefix'],output_rows={k:len(v)for k,v in relations.items()},relation_digests={k:content_digest(v)for k,v in relations.items()},
 differing_submission_positions=sum(a!=b for a,b in zip(orders['fifo'],orders['prefix'],strict=True)),submission_order=orders,
 environment_checks={k:json.loads((root/cells[k]/'BATCH-INVARIANT-PROCESSES.json').read_text())for k in arms},observation=observation,original_file_hashes=files,
 performance_advantage_claim=False,interpretation='one pair on a new batch-invariant configuration and current source/observer; no causal isolation of the original two differences and no reuse of original performance times')
write_private_json(root/'pr98-paired-comparison.json',report)
print(json.dumps({k:report[k]for k in ['status','actual_calls','strictly_equal_calls','relation_equal','differing_submission_positions']}))
raise SystemExit(0 if strict else 1)
