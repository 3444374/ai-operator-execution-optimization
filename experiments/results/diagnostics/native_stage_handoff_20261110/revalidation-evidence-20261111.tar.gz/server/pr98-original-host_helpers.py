"""One-shot, host-exclusive qualification controller; no implicit retries.

The normal invocation performs real work and must run only on the approved host.
--self-test runs local CPU fixtures without SSH, NVIDIA commands or model imports.
"""

import argparse
import csv
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time
from types import SimpleNamespace
import uuid


SCHEMA = "semloom.records_model_qualification.v1"
LEASE_SCOPE = "<data-root>/experiment-artifacts/.host-runner-scope"
UNITS = (("engine-native", 4, "n"), ("ray-data", 2, "r"), ("static", 4, "s"))
CMDLINE_DIGEST_FORMAT = "space-joined-argv-v1"
MINIMUM_SOURCE = {
    "code/src/experiments/attempt_ledger.py",
    "code/src/experiments/cell_budget.py",
    "code/src/experiments/lotus_records_supervisor.py",
    "code/src/infrastructure/runner_lease.py",
    "code/src/baselines/common/private_artifacts.py",
    "code/src/baselines/common/redact.py",
}
_REDACT = None
_REDACT_JSON = None


def digest_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_digest(value):
    return hashlib.sha256(json.dumps(
        value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")).hexdigest()


def error_record(error):
    # Before trusted production imports, omit details instead of persisting an
    # unredacted configuration or traceback through a fallback implementation.
    return {
        "error_type": type(error).__name__,
        "error": _REDACT(str(error)) if _REDACT else "details omitted before trusted redactor import",
    }


def private_json(path, value, *, replace=False):
    path = Path(path)
    value = _REDACT_JSON(value) if _REDACT_JSON else value
    payload = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
    target = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp") if replace else path
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        if replace:
            os.replace(target, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if replace:
            target.unlink(missing_ok=True)


def absolute_path(value, name):
    if type(value) is not str or "\0" in value or not Path(value).is_absolute():
        raise ValueError(name + " must be an absolute path")
    return Path(value)


def validate_config(raw):
    if type(raw) is not dict or raw.get("schema") != SCHEMA:
        raise ValueError("unsupported qualification configuration")
    cfg = json.loads(json.dumps(raw, allow_nan=False))
    if not re.fullmatch(r"[0-9a-f]{40}", cfg.get("repository_commit", "")):
        raise ValueError("repository_commit must be a full declared Git SHA")
    for name in ("repository_root", "artifact_root", "driver_python", "unit_script",
                 "controller_script", "ledger_path", "source_manifest", "sembench_checkout",
                 "ray_temp_root", "source_archive_path"):
        absolute_path(cfg.get(name), name)
    if cfg.get("budget_limit") != 32 or type(cfg.get("budget_limit")) is not int:
        raise ValueError("this qualification has exactly one global request cap of 32")
    if cfg.get("automatic_retries") != 0 or type(cfg.get("automatic_retries")) is not int:
        raise ValueError("automatic retries are forbidden")
    if cfg.get("model_downloads") is not False:
        raise ValueError("model downloads are forbidden")
    if cfg.get("lease_scope") != LEASE_SCOPE:
        raise ValueError("qualification must use the normal shared host-runner scope")
    if cfg.get("unit_timeout_s") != 600 or type(cfg.get("unit_timeout_s")) is not int:
        raise ValueError("unit timeout is fixed at 600 seconds including cleanup reserve")
    if cfg.get("unit_grace_s") != 15 or type(cfg.get("unit_grace_s")) is not int:
        raise ValueError("unit cleanup grace is fixed at 15 seconds")
    if cfg.get("gpu_count") != 1 or type(cfg.get("gpu_count")) is not int:
        raise ValueError("this qualification requires exactly one GPU")
    if (type(cfg.get("gpu_expected_name")) is not str
            or "RTX 4090" not in cfg["gpu_expected_name"]
            or cfg.get("gpu_expected_total_mib") != 24564
            or type(cfg.get("gpu_expected_total_mib")) is not int
            or cfg.get("gpu_idle_max_mib") != 1
            or type(cfg.get("gpu_idle_max_mib")) is not int):
        raise ValueError("GPU identity and the one-MiB idle baseline must remain fixed")
    root = Path(cfg["artifact_root"])
    if Path(cfg["ledger_path"]) != root / "budget.sqlite":
        raise ValueError("ledger_path must be the new artifact root's budget.sqlite")
    if (type(cfg.get("engine")) is not dict or cfg["engine"].get("max_model_calls") != 8
            or type(cfg["engine"].get("max_model_calls")) is not int):
        raise ValueError("every model owner must enforce a hard call cap of eight")
    if cfg["engine"].get("driver_python") != cfg["driver_python"]:
        raise ValueError("controller and model profile must share the selected driver")
    incoming = cfg.get("units")
    if type(incoming) is not list or len(incoming) != 3:
        raise ValueError("exactly three fixed qualification units are required")
    units = []
    for item, (unit_id, nominal, suffix) in zip(incoming, UNITS, strict=True):
        declared_nominal = item.get("nominal_calls", item.get("expected_calls")) if type(item) is dict else None
        declared_cap = item.get("request_cap", item.get("max_model_calls")) if type(item) is dict else None
        if (type(item) is not dict or item.get("unit_id", item.get("id")) != unit_id
                or declared_nominal != nominal or type(declared_nominal) is not int
                or declared_cap != 8 or type(declared_cap) is not int
                or item.get("ray_temp_suffix") != suffix):
            raise ValueError("qualification unit order, nominal calls or reserved caps differ")
        units.append(dict(unit_id=unit_id, mode=unit_id, nominal_calls=nominal,
                          request_cap=8, ray_temp_suffix=suffix,
                          output_dir=str(root / "units" / unit_id)))
    cfg["units"] = units
    cfg["total_request_cap"] = 32
    cfg["cmdline_digest_format"] = CMDLINE_DIGEST_FORMAT
    for item in cfg.get("allowed_idle_processes", []):
        if (type(item) is not dict or type(item.get("pid")) is not int or item["pid"] < 1
                or type(item.get("create_time")) not in (int, float)
                or not math.isfinite(item["create_time"])
                or not re.fullmatch(r"[0-9a-f]{64}", item.get("cmdline_sha256", ""))):
            raise ValueError("idle-process exceptions require exact PID, creation time and argv SHA")
    return cfg


def verify_sources(cfg):
    root = Path(cfg["repository_root"]).resolve(strict=True)
    mapping = cfg.get("production_source_sha256")
    if type(mapping) is not dict or not MINIMUM_SOURCE <= set(mapping):
        raise ValueError("archive qualification requires its complete production-source byte map")
    for relative, expected in mapping.items():
        path = root / relative
        if (type(relative) is not str or Path(relative).is_absolute()
                or ".." in Path(relative).parts or path.is_symlink()
                or not path.resolve(strict=True).is_relative_to(root)
                or not re.fullmatch(r"[0-9a-f]{64}", expected)
                or digest_file(path) != expected):
            raise ValueError("production source bytes differ from the frozen archive map")
    if digest_file(cfg["source_archive_path"]) != cfg.get("source_archive_sha256"):
        raise ValueError("source archive bytes differ from their fixed SHA256")
    for key, path in (("controller_script_sha256", cfg["controller_script"]),
                      ("unit_script_sha256", cfg["unit_script"])):
        if not re.fullmatch(r"[0-9a-f]{64}", cfg.get(key, "")) or digest_file(path) != cfg[key]:
            raise ValueError("qualification harness bytes differ from their fixed SHA256")
    if Path(__file__).resolve() != Path(cfg["controller_script"]).resolve():
        raise ValueError("controller is running from a different path than its frozen harness")
    return dict(source_mode="git_archive", git_checkout_verified=False,
                declared_repository_commit=cfg["repository_commit"],
                matched_files=len(mapping), source_archive_sha256=cfg["source_archive_sha256"])


def production_api(code_root):
    global _REDACT, _REDACT_JSON
    sys.path.insert(0, str(code_root))
    import psutil
    from src.infrastructure.private_artifacts import new_private_directory
    from src.infrastructure.redact import redact_json_values, redact_text
    from src.experiments.attempt_ledger import AttemptBudget
    from src.experiments.cell_budget import CellBudgetLedger
    from src.experiments.lotus_records_supervisor import supervise
    from src.infrastructure.runner_lease import acquire_runner_lease, HOST_SCOPE_FINGERPRINT
    _REDACT, _REDACT_JSON = redact_text, redact_json_values
    if not {"command", "output_dir", "timeout_s", "grace_s"} <= set(inspect.signature(supervise).parameters):
        raise RuntimeError("production supervisor API differs from the reviewed contract")
    if inspect.signature(acquire_runner_lease).parameters["recover_stale"].default is not False:
        raise RuntimeError("production lease no longer defaults to explicit stale recovery")
    return SimpleNamespace(psutil=psutil, new_private_directory=new_private_directory,
                           AttemptBudget=AttemptBudget, CellBudgetLedger=CellBudgetLedger,
                           supervise=supervise, acquire_runner_lease=acquire_runner_lease,
                           HOST_SCOPE_FINGERPRINT=HOST_SCOPE_FINGERPRINT)


def gpu_snapshot(cfg):
    def query(fields, selector):
        result = subprocess.run(
            ["nvidia-smi", selector + "=" + fields, "--format=csv,noheader,nounits"],
            check=True, capture_output=True, text=True, timeout=10,
        )
        return list(csv.reader(result.stdout.strip().splitlines(), skipinitialspace=True))
    gpus = query("index,name,uuid,memory.total,memory.used", "--query-gpu")
    if len(gpus) != 1 or len(gpus[0]) != 5:
        raise RuntimeError("GPU inventory is unavailable or no longer single-device")
    index, name, gpu_uuid, total, used = [value.strip() for value in gpus[0]]
    if (index != "0" or name != cfg["gpu_expected_name"]
            or int(total) != cfg["gpu_expected_total_mib"]):
        raise RuntimeError("GPU hardware differs from the frozen qualification identity")
    compute = []
    for values in query("gpu_uuid,pid,used_gpu_memory", "--query-compute-apps"):
        if len(values) != 3:
            raise RuntimeError("NVIDIA compute inventory has an unsupported row")
        device, pid, memory = [value.strip() for value in values]
        compute.append(dict(gpu_uuid=device, pid=int(pid), used_memory_mib=int(memory)))
    return dict(index=0, name=name, uuid=gpu_uuid, total_mib=int(total), used_mib=int(used),
                compute=compute, compute_inventory_complete=True)


def snapshot(api, cfg, label, owned=()):
    psutil = api.psutil
    own_process = psutil.Process(os.getpid())
    excluded = {(own_process.pid, own_process.create_time())}
    excluded.update((item.pid, item.create_time()) for item in own_process.parents())
    owned = set(owned)
    allowed = {(item["pid"], item["create_time"]): item["cmdline_sha256"]
               for item in cfg.get("allowed_idle_processes", [])}
    observed_allowed, rows, foreign, errors = set(), [], [], []
    for process in psutil.process_iter(["pid", "create_time", "name", "cmdline", "status"]):
        try:
            info = process.info
            pid, created, name, argv = (info[k] for k in ("pid", "create_time", "name", "cmdline"))
            if (type(pid) is not int or type(created) not in (int, float)
                    or not math.isfinite(created) or type(name) is not str or type(argv) is not list):
                raise RuntimeError("incomplete psutil process identity")
            key = (pid, created)
            cmd_sha = hashlib.sha256(" ".join(argv).encode("utf-8")).hexdigest()
            rows.append(dict(pid=pid, create_time=created, name=name, cmdline_sha256=cmd_sha,
                             status=info["status"]))
            if key in allowed and cmd_sha == allowed[key]:
                observed_allowed.add(key)
                continue
            if key in excluded or key in owned:
                continue
            tokens = [Path(arg).name.lower() for arg in argv if type(arg) is str]
            candidate = (
                "python" in name.lower()
                or any(marker in name.lower() for marker in ("ray::", "raylet", "gcs_server", "vllm", "imlane"))
                or any(re.search(r"(?:sembench|qualification_(?:unit|controller)|vllm|imlane|_controller\.py)", token)
                       for token in tokens)
            )
            if candidate and info["status"] not in (psutil.STATUS_ZOMBIE, psutil.STATUS_DEAD):
                foreign.append(dict(pid=pid, create_time=created, name=name, cmdline_sha256=cmd_sha))
        except psutil.NoSuchProcess:
            continue
        except BaseException as error:
            errors.append(error_record(error))
    missing_allowed = [dict(pid=pid, create_time=created)
                       for pid, created in sorted(set(allowed) - observed_allowed)]
    return dict(label=label, captured_epoch_s=time.time(),
                inventory_complete=not errors, inventory_errors=errors,
                processes=rows, foreign_work=foreign,
                idle_allowlist_unverified=missing_allowed,
                cmdline_digest_format=CMDLINE_DIGEST_FORMAT, gpu=gpu_snapshot(cfg))


def assert_idle(value, cfg):
    if not value["inventory_complete"] or value["idle_allowlist_unverified"]:
        raise RuntimeError("process inventory or exact idle-service identity is unconfirmed")
    if value["foreign_work"]:
        raise RuntimeError("foreign Python, Ray or model work was observed; nothing was signalled")
    gpu = value["gpu"]
    if not gpu["compute_inventory_complete"] or gpu["compute"]:
        raise RuntimeError("GPU compute processes remain; nothing unknown may be signalled")
    if gpu["used_mib"] > cfg["gpu_idle_max_mib"]:
        raise RuntimeError("GPU memory has not returned to the frozen one-MiB idle baseline")


def live_owned(api, identities):
    live = []
    for pid, created in sorted(set(identities)):
        try:
            process = api.psutil.Process(pid)
            if (process.create_time() == created
                    and process.status() not in (api.psutil.STATUS_ZOMBIE, api.psutil.STATUS_DEAD)):
                live.append(process)
        except api.psutil.NoSuchProcess:
            pass
    return live


def cleanup_owned(api, identities, grace_s):
    """Signal only observed, creation-time-matched processes; never use pkill."""
    identities = set(identities)
    signals, errors = [], []
    deadline = time.monotonic() + grace_s
    for sig, fraction in ((signal.SIGTERM, 0.5), (signal.SIGKILL, 1.0)):
        for process in live_owned(api, identities):
            try:
                for child in process.children(recursive=True):
                    identities.add((child.pid, child.create_time()))
            except api.psutil.NoSuchProcess:
                pass
        for process in live_owned(api, identities):
            try:
                created = process.create_time()
                if (process.pid, created) in identities:
                    process.send_signal(sig)
                    signals.append(dict(pid=process.pid, create_time=created,
                                        signal=signal.Signals(sig).name))
            except api.psutil.NoSuchProcess:
                pass
            except BaseException as error:
                errors.append(error_record(error))
        until = deadline if fraction == 1 else (time.monotonic() + deadline) / 2
        while live_owned(api, identities) and time.monotonic() < until:
            time.sleep(min(0.05, max(0, until - time.monotonic())))
    return dict(observed_owned=[dict(pid=p, create_time=c) for p, c in sorted(identities)],
                signals=signals, errors=errors,
                remaining_owned_pids=[p.pid for p in live_owned(api, identities)])


def check_lease(lease):
    value = json.loads(lease.path.read_text())
    if (value.get("owner_token") != lease.owner.owner_token
            or value.get("pid") != os.getpid()):
        raise RuntimeError("shared lease ownership changed; controller will not release it")


def reserve_all(api, cfg):
    budget = api.AttemptBudget(cfg["budget_id"], 32)
    ledger = api.CellBudgetLedger.create(
        Path(cfg["ledger_path"]), budget, deadline_utc=cfg["budget_deadline_utc"],
    )
    for unit in cfg["units"]:
        ledger.reserve_unit(unit["unit_id"], 8)
    state = ledger.snapshot()
    if state["allocated_requests"] != 24 or any(unit["claimed"] for unit in state["units"]):
        raise RuntimeError("initial permanent unit reservations differ from the fixed 24-call allocation")
    return ledger


def report_identities(*reports):
    owned = set()
    for report in reports:
        if not isinstance(report, dict):
            continue
        for row in report.get("observed_owned", []):
            if (type(row) is not dict or type(row.get("pid")) is not int or row["pid"] < 1
                    or type(row.get("create_time")) not in (int, float)
                    or not math.isfinite(row["create_time"])):
                raise RuntimeError("owned process report lacks a verified creation identity")
            owned.add((row["pid"], row["create_time"]))
    return owned


def run_unit(api, cfg, unit, frozen_path, lease, owned, update):
    root = Path(cfg["artifact_root"])
    unit_id = unit["unit_id"]
    result = dict(unit_id=unit_id, nominal_calls=unit["nominal_calls"], request_cap=8,
                  status="failed", unit_report_path=str(Path(unit["output_dir"]) / "unit_report.json"))
    check_lease(lease)
    update("before-unit", unit_id)
    before = snapshot(api, cfg, unit_id + "-before", owned)
    private_json(root / "snapshots" / (unit_id + "-before.json"), before)
    assert_idle(before, cfg)
    if live_owned(api, owned):
        raise RuntimeError("a preceding unit still owns a live process")
    verify_sources(cfg)
    Path(unit["output_dir"]).mkdir(mode=0o700)
    supervisor, child, primary = {}, {}, None
    try:
        update("running-unit", unit_id)
        supervisor = api.supervise(
            [cfg["driver_python"], "-u", cfg["unit_script"], "--config", str(frozen_path),
             "--unit-id", unit_id],
            root / "supervision" / unit_id,
            timeout_s=cfg["unit_timeout_s"], grace_s=cfg["unit_grace_s"],
        )
    except BaseException as error:
        primary = error
        supervisor = getattr(error, "report", {})
        result.update(error_record(error))
    finally:
        report_path = Path(result["unit_report_path"])
        if report_path.is_file():
            try:
                if report_path.stat().st_size > 8 * 1024 * 1024:
                    raise RuntimeError("unit report exceeds its explicit eight-MiB bound")
                child = json.loads(report_path.read_text())
                if type(child) is not dict:
                    raise RuntimeError("unit report must be a structured object")
            except BaseException as error:
                child = {}
                primary = primary or error
                result.update(error_record(error))
        owned.update(report_identities(supervisor, child))
        if live_owned(api, owned):
            result["additional_owned_cleanup"] = cleanup_owned(api, owned, cfg["unit_grace_s"])
            owned.update(report_identities(result["additional_owned_cleanup"]))
            primary = primary or RuntimeError("owned descendants needed additional cleanup")
        result["supervisor"] = supervisor
        result["observed_owned"] = [dict(pid=p, create_time=c) for p, c in sorted(owned)]
        result["remaining_owned_pids"] = [p.pid for p in live_owned(api, owned)]
        try:
            after = snapshot(api, cfg, unit_id + "-after", owned)
            private_json(root / "snapshots" / (unit_id + "-after.json"), after)
            assert_idle(after, cfg)
            if result["remaining_owned_pids"]:
                raise RuntimeError("observed-owned process exit is not confirmed")
            result["resource_exit_confirmed"] = True
        except BaseException as error:
            result.update(status="unknown", resource_exit_confirmed=False, **error_record(error))
            primary = primary or error
    result["child_status"] = child.get("status") if isinstance(child, dict) else None
    actual = child.get("actual_model_calls") if isinstance(child, dict) else None
    result["actual_model_calls"] = actual
    if (primary is None and supervisor.get("status") == "passed"
            and child.get("status") == "completed" and child.get("unit_id") == unit_id
            and child.get("claimed") is True and child.get("reserved_cap") == 8
            and type(actual) is int and actual == unit["nominal_calls"]
            and type(child.get("engine_lifetimes")) is int and child["engine_lifetimes"] == 1):
        result["status"] = "completed"
    elif result["status"] != "unknown":
        result.update(status="failed", **error_record(primary or RuntimeError(
            "child, engine lifetime, attempt count or supervisor qualification did not complete")))
    private_json(root / ("unit-" + unit_id + ".json"), result)
    return result


def run(config_path, expected_sha):
    config_path = Path(config_path)
    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha) or digest_file(config_path) != expected_sha:
        raise ValueError("input configuration does not match its externally frozen SHA256")
    if config_path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("input configuration exceeds two MiB")
    cfg = validate_config(json.loads(config_path.read_text()))
    provenance = verify_sources(cfg)
    api = production_api(Path(cfg["repository_root"]) / "code")
    if str(Path(sys.executable).absolute()) != cfg["driver_python"]:
        raise RuntimeError("controller is not running in the fixed driver interpreter")
    root = Path(cfg["artifact_root"])
    # The exclusive directory is also the permanent controller-start marker.
    # An interrupted controller can never reopen it to reset its budget.
    api.new_private_directory(root)
    for directory in ("snapshots", "supervision", "units"):
        (root / directory).mkdir(mode=0o700)
    cfg.update(input_config_sha256=expected_sha,
               budget_deadline_utc=time.time() + 3 * cfg["unit_timeout_s"] + 120)
    cfg.pop("config_sha256", None)
    cfg["config_sha256"] = canonical_digest(cfg)
    frozen_path = root / "frozen-config.json"
    private_json(frozen_path, cfg)
    controller = dict(pid=os.getpid(), create_time=api.psutil.Process().create_time())
    private_json(root / "controller-start.json", dict(controller, config_sha256=cfg["config_sha256"]))
    report = dict(schema=SCHEMA, status="failed", controller=controller,
                  config_sha256=cfg["config_sha256"], provenance=provenance,
                  model_call_hard_cap=32, permanent_reserved_calls=0,
                  automatic_retries=0, units=[], lease="not-acquired")
    lease, ledger, owned = None, None, set()
    old_sigterm = signal.getsignal(signal.SIGTERM)
    def cancelled(_signum, _frame):
        raise InterruptedError("qualification controller cancellation requested")
    signal.signal(signal.SIGTERM, cancelled)
    def update(phase, unit_id=None):
        private_json(root / "status.json", dict(
            schema=SCHEMA, phase=phase, unit_id=unit_id, controller=controller,
            config_sha256=cfg["config_sha256"], completed_units=sum(
                item["status"] == "completed" for item in report["units"]),
            lease=report["lease"], updated_epoch_s=time.time(),
        ), replace=True)
    try:
        update("acquiring-lease")
        lease = api.acquire_runner_lease(
            Path(cfg["lease_scope"]), config_fingerprint=api.HOST_SCOPE_FINGERPRINT,
            repository_commit=cfg["repository_commit"], recover_stale=False,
        )
        report["lease"] = "owned"
        ledger = reserve_all(api, cfg)
        report["permanent_reserved_calls"] = 24
        private_json(root / "budget-initial.json", ledger.snapshot())
        os.environ.update({"PYTHONPATH": str(Path(cfg["repository_root"]) / "code"),
                           "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                           "CUDA_VISIBLE_DEVICES": "0", "OMP_NUM_THREADS": "1",
                           "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
                           "TOKENIZERS_PARALLELISM": "false"})
        for unit in cfg["units"]:
            result = run_unit(api, cfg, unit, frozen_path, lease, owned, update)
            state = ledger.snapshot()
            selected = next(row for row in state["units"] if row["unit_id"] == unit["unit_id"])
            if result["status"] == "completed" and selected["claimed"] != 1:
                result.update(status="failed", error="child completion lacks a durable unit claim")
            report["units"].append(result)
            private_json(root / "controller-report.json", report, replace=True)
            if result["status"] != "completed":
                raise RuntimeError("qualification stopped after its first failed or uncertain unit")
        report["status"] = "completed"
    except BaseException as error:
        report.update(error_record(error))
    finally:
        if ledger is not None:
            try:
                report["budget"] = ledger.snapshot()
            except BaseException as error:
                report.update(status="failed", budget_error=error_record(error))
        if lease is not None:
            try:
                if live_owned(api, owned):
                    report["final_owned_cleanup"] = cleanup_owned(api, owned, cfg["unit_grace_s"])
                    owned.update(report_identities(report["final_owned_cleanup"]))
                    report["status"] = "failed"
                final = snapshot(api, cfg, "controller-final", owned)
                private_json(root / "snapshots" / "controller-final.json", final)
                assert_idle(final, cfg)
                if live_owned(api, owned):
                    raise RuntimeError("owned process resources remain unconfirmed")
                check_lease(lease)
                lease.release()
                report["lease"] = "released-owned-only"
                report["resource_exit_confirmed"] = True
            except BaseException as error:
                report.update(status="unknown", lease="held-unresolved", resource_exit_confirmed=False,
                              cleanup_error=error_record(error))
        report["observed_owned"] = [dict(pid=p, create_time=c) for p, c in sorted(owned)]
        report["ended_epoch_s"] = time.time()
        private_json(root / "controller-report.json", report, replace=True)
        update(report["status"])
        signal.signal(signal.SIGTERM, old_sigterm)
    return 0 if report["status"] == "completed" else 1


def self_test(code_root):
    """Actual production budget APIs plus pure safety-gate fixtures, no GPU calls."""
    import tempfile
    import unittest
    from unittest.mock import Mock, patch
    api = production_api(Path(code_root))
    class Checks(unittest.TestCase):
        def test_permanent_24_reservations_and_no_reclaim_or_recreate(self):
            from src.experiments.attempt_ledger import BudgetError, BudgetExhausted
            with tempfile.TemporaryDirectory() as directory:
                cfg = dict(budget_id="qualification-cpu-fixture", ledger_path=str(Path(directory) / "budget.sqlite"),
                           budget_deadline_utc=time.time() + 60,
                           units=[dict(unit_id=unit_id) for unit_id, _, _ in UNITS])
                ledger = reserve_all(api, cfg)
                self.assertEqual(ledger.snapshot()["allocated_requests"], 24)
                with self.assertRaises(BudgetExhausted):
                    ledger.reserve_unit("over-global-cap", 9)
                selected = ledger.claim_unit("engine-native")
                for _ in range(8):
                    selected.reserve("0" * 64)
                with self.assertRaises(BudgetExhausted):
                    selected.reserve("0" * 64)
                with self.assertRaises(BudgetError):
                    ledger.claim_unit("engine-native")
                with self.assertRaises(FileExistsError):
                    reserve_all(api, cfg)
                self.assertEqual(ledger.snapshot()["allocated_requests"], 24)
        def test_idle_gate_never_accepts_foreign_or_unknown_inventory(self):
            import copy
            baseline = dict(inventory_complete=True, idle_allowlist_unverified=[], foreign_work=[],
                            gpu=dict(compute_inventory_complete=True, compute=[], used_mib=1))
            assert_idle(baseline, dict(gpu_idle_max_mib=1))
            for key, value in (("inventory_complete", False), ("foreign_work", [dict(pid=123)]),
                               ("idle_allowlist_unverified", [dict(pid=456)])):
                with self.subTest(key=key), self.assertRaises(RuntimeError):
                    assert_idle(dict(baseline, **{key: value}), dict(gpu_idle_max_mib=1))
            for field, value in (("compute", [dict(pid=789)]), ("used_mib", 2),
                                 ("compute_inventory_complete", False)):
                changed = copy.deepcopy(baseline)
                changed["gpu"][field] = value
                with self.subTest(field=field), self.assertRaises(RuntimeError):
                    assert_idle(changed, dict(gpu_idle_max_mib=1))
        def test_pid_reuse_is_never_signalled(self):
            process = Mock()
            process.create_time.return_value = 12.0
            fake = SimpleNamespace(Process=Mock(return_value=process),
                                   NoSuchProcess=api.psutil.NoSuchProcess,
                                   STATUS_ZOMBIE=api.psutil.STATUS_ZOMBIE, STATUS_DEAD=api.psutil.STATUS_DEAD)
            report = cleanup_owned(SimpleNamespace(psutil=fake), {(42, 11.0)}, 0.01)
            self.assertEqual(report["remaining_owned_pids"], [])
            process.send_signal.assert_not_called()
        def test_private_reports_are_redacted_before_writing(self):
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "report.json"
                private_json(path, {"message": "password=***, "auth_token": "***"})
                self.assertNotIn("fixture-value", path.read_text())
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
        def test_production_supervisor_and_strict_lease_signatures(self):
            self.assertIn("timeout_s", inspect.signature(api.supervise).parameters)
            self.assertIs(inspect.signature(api.acquire_runner_lease).parameters["recover_stale"].default, False)
        def test_snapshot_locks_idle_services_to_full_argv_digest(self):
            argv = ["tensorboard", "fixture-sensitive-argument"]
            info = dict(pid=729, create_time=100.0, name="tensorboard", cmdline=argv, status="sleeping")
            fake = SimpleNamespace(
                Process=lambda pid: SimpleNamespace(pid=pid, create_time=lambda: 200.0, parents=lambda: []),
                process_iter=lambda fields: [SimpleNamespace(info=info)],
                NoSuchProcess=api.psutil.NoSuchProcess, STATUS_ZOMBIE=api.psutil.STATUS_ZOMBIE,
                STATUS_DEAD=api.psutil.STATUS_DEAD,
            )
            cfg = dict(allowed_idle_processes=[dict(pid=729, create_time=100.0,
                       cmdline_sha256=hashlib.sha256(" ".join(argv).encode()).hexdigest())], gpu_idle_max_mib=1)
            gpu = dict(compute_inventory_complete=True, compute=[], used_mib=1)
            with patch.dict(globals(), gpu_snapshot=lambda cfg: gpu):
                observed = snapshot(SimpleNamespace(psutil=fake), cfg, "cpu-fixture")
                assert_idle(observed, cfg)
                self.assertNotIn("fixture-sensitive-argument", json.dumps(observed))
                info["cmdline"] = ["tensorboard", "changed"]
                changed = snapshot(SimpleNamespace(psutil=fake), cfg, "cpu-fixture")
                with self.assertRaises(RuntimeError):
                    assert_idle(changed, cfg)
        def controller_fixture(self, directory, fail_first, unknown_after_first=False):
            base = Path(directory)
            root = base / "artifacts"
            cfg = dict(
                schema=SCHEMA, repository_root=str(base / "source"), repository_commit="0" * 40,
                artifact_root=str(root), driver_python=str(Path(sys.executable).absolute()),
                unit_script=str(base / "qualification_unit.py"), controller_script=str(Path(__file__).absolute()),
                ledger_path=str(root / "budget.sqlite"), source_manifest=str(base / "manifest.json"),
                sembench_checkout=str(base / "sembench"), ray_temp_root=str(base / "ray"),
                source_archive_path=str(base / "source.tar"), budget_id="controller-cpu-fixture",
                budget_limit=32, automatic_retries=0, model_downloads=False, lease_scope=LEASE_SCOPE,
                unit_timeout_s=600, unit_grace_s=15, gpu_count=1, gpu_expected_name="NVIDIA GeForce RTX 4090",
                gpu_expected_total_mib=24564, gpu_idle_max_mib=1,
                engine=dict(max_model_calls=8, driver_python=str(Path(sys.executable).absolute())),
                units=[dict(id=unit_id, expected_calls=nominal, max_model_calls=8, ray_temp_suffix=suffix)
                       for unit_id, nominal, suffix in UNITS],
            )
            config = base / "config.json"
            config.write_text(json.dumps(cfg))
            events = []
            lease_path = base / "lease.json"
            def acquire(path, **kwargs):
                self.assertEqual(str(path), LEASE_SCOPE)
                self.assertIs(kwargs["recover_stale"], False)
                self.assertEqual(kwargs["config_fingerprint"], api.HOST_SCOPE_FINGERPRINT)
                private_json(lease_path, dict(owner_token="fixture-owner", pid=os.getpid()))
                def release():
                    events.append("lease-released")
                    lease_path.unlink()
                return SimpleNamespace(path=lease_path, owner=SimpleNamespace(owner_token="fixture-owner"),
                                       release=release)
            def supervise(command, output, **kwargs):
                frozen = json.loads(Path(command[command.index("--config") + 1]).read_text())
                stored_hash = frozen.pop("config_sha256")
                self.assertEqual(canonical_digest(frozen), stored_hash)
                unit_id = command[command.index("--unit-id") + 1]
                ledger = api.CellBudgetLedger(Path(cfg["ledger_path"]), api.AttemptBudget(cfg["budget_id"], 32))
                self.assertEqual(ledger.snapshot()["allocated_requests"], 24)
                self.assertEqual(len(ledger.snapshot()["units"]), 3)
                claim = ledger.claim_unit(unit_id)
                unit = next(item for item in frozen["units"] if item["unit_id"] == unit_id)
                for _ in range(unit["nominal_calls"]):
                    claim.reserve("0" * 64)
                events.append("spawn-" + unit_id)
                self.assertTrue(Path(unit["output_dir"]).is_dir())
                self.assertEqual(stat.S_IMODE(Path(unit["output_dir"]).stat().st_mode), 0o700)
                private_json(Path(unit["output_dir"]) / "unit_report.json", dict(
                    status="failed" if fail_first else "completed", unit_id=unit_id,
                    claimed=True, reserved_cap=8, actual_model_calls=unit["nominal_calls"], engine_lifetimes=1,
                ))
                report = dict(status="failed" if fail_first else "passed", observed_owned=[], worker_exit=0)
                if fail_first:
                    error = RuntimeError("synthetic child failure password=***
                    error.report = report
                    raise error
                return report
            fake = SimpleNamespace(**vars(api))
            fake.acquire_runner_lease, fake.supervise = acquire, supervise
            fake.psutil = SimpleNamespace(Process=lambda *args: SimpleNamespace(create_time=lambda: 1.0))
            idle = dict(inventory_complete=True, idle_allowlist_unverified=[], foreign_work=[],
                        gpu=dict(compute_inventory_complete=True, compute=[], used_mib=1))
            snapshot_calls = []
            def observe(*args, **kwargs):
                snapshot_calls.append(1)
                if unknown_after_first and len(snapshot_calls) > 1:
                    return dict(idle, gpu=dict(compute_inventory_complete=True, compute=[dict(pid=789)], used_mib=8))
                return idle
            with patch.dict(globals(), dict(
                verify_sources=lambda cfg: {"source_mode": "synthetic_cpu_fixture"},
                production_api=lambda code: fake, snapshot=observe,
                live_owned=lambda *args: [],
            )):
                result = run(config, digest_file(config))
                self.assertEqual(result, 1 if fail_first or unknown_after_first else 0)
                ledger_before = Path(cfg["ledger_path"]).read_bytes()
                spawns_before_restart = len([item for item in events if item.startswith("spawn-")])
                with self.assertRaises(FileExistsError):
                    run(config, digest_file(config))
                self.assertEqual(Path(cfg["ledger_path"]).read_bytes(), ledger_before)
                self.assertEqual(len([item for item in events if item.startswith("spawn-")]),
                                 spawns_before_restart)
            if unknown_after_first:
                self.assertNotIn("lease-released", events)
                self.assertTrue(lease_path.is_file())
                self.assertEqual(json.loads((root / "controller-report.json").read_text())["status"], "unknown")
            else:
                self.assertEqual(events[-1], "lease-released")
            self.assertEqual([item for item in events if item.startswith("spawn-")],
                             ["spawn-engine-native"] if fail_first or unknown_after_first else
                             ["spawn-engine-native", "spawn-ray-data", "spawn-static"])
            self.assertNotIn("fixture-value", (root / "controller-report.json").read_text())
            self.assertEqual(json.loads((root / "budget-initial.json").read_text())["allocated_requests"], 24)
        def test_controller_reserves_all_before_children_and_rejects_restart(self):
            with tempfile.TemporaryDirectory() as directory:
                self.controller_fixture(directory, False)
        def test_controller_stops_after_first_failure_without_retries(self):
            with tempfile.TemporaryDirectory() as directory:
                self.controller_fixture(directory, True)
        def test_unconfirmed_foreign_gpu_holds_lease_and_stops_without_signalling_it(self):
            with tempfile.TemporaryDirectory() as directory:
                self.controller_fixture(directory, False, unknown_after_first=True)
        def test_existing_unit_directory_is_rejected_before_any_child(self):
            with tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                (root / "snapshots").mkdir(mode=0o700)
                unit_root = root / "units" / "engine-native"
                unit_root.mkdir(mode=0o700, parents=True)
                existing_report = unit_root / "unit_report.json"
                existing_report.write_text("preserve previous unit evidence")
                lease_path = root / "lease.json"
                private_json(lease_path, dict(owner_token="fixture-owner", pid=os.getpid()))
                lease = SimpleNamespace(path=lease_path, owner=SimpleNamespace(owner_token="fixture-owner"))
                fake = SimpleNamespace(supervise=Mock())
                idle = dict(inventory_complete=True, idle_allowlist_unverified=[], foreign_work=[],
                            gpu=dict(compute_inventory_complete=True, compute=[], used_mib=1))
                cfg = dict(artifact_root=str(root), gpu_idle_max_mib=1)
                unit = dict(unit_id="engine-native", nominal_calls=4, output_dir=str(unit_root))
                with patch.dict(globals(), dict(verify_sources=lambda cfg: {},
                                                snapshot=lambda *a, **kw: idle,
                                                live_owned=lambda *args: [])):
                    with self.assertRaises(FileExistsError):
                        run_unit(fake, cfg, unit, root / "frozen-config.json", lease, set(), Mock())
                fake.supervise.assert_not_called()
                self.assertEqual(existing_report.read_text(), "preserve previous unit evidence")
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
    return 0 if result.wasSuccessful() else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config")
    parser.add_argument("--config-sha256")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--code-root")
    args = parser.parse_args()
    if args.self_test:
        if not args.code_root or args.config:
            parser.error("--self-test requires --code-root and forbids --config")
        return self_test(args.code_root)
    if not args.config or not args.config_sha256:
        parser.error("normal execution requires --config and --config-sha256")
    try:
        return run(args.config, args.config_sha256)
    except BaseException as error:
        # An existing artifact root is never modified to report a rejected rerun.
        path = Path(__file__).parent / ("controller-bootstrap-error-" + uuid.uuid4().hex + ".json")
        private_json(path, dict(status="failed-before-controller-completion", **error_record(error)))
        print(json.dumps(dict(status="failed", bootstrap_error_path=str(path))), flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
