from pathlib import Path
from copy import deepcopy
import os,sys,json,time,subprocess,hashlib,shutil
root=Path('<data-root>/semloom-stage-revalidation-20261111');source=root/'source'
sys.path.insert(0,str(source/'code'));sys.path.insert(0,str(source/'code/scripts/profiling/record_observation'))
from src.infrastructure.private_artifacts import write_private_json,file_identity
from src.infrastructure.redact import redact_text,redact_json_values
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.lotus_records_supervisor import supervise
import workflow
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip()
templates=json.loads((root/'pr98-templates.json').read_text());base=templates['fifo'];driver=base['engine']['driver_python'];model=base['engine']['model_python']
env=dict(os.environ);env.update(base['environment']);env.update(AI_OPERATOR_ENV_FILE=str(root/'runtime.env'),PYTHONPATH=str(source/'code'),LITELLM_LOCAL_MODEL_COST_MAP='True')
os.environ.clear();os.environ.update(env);os.chdir(source);os.sched_setaffinity(0,set(base['cpu_affinity']))
ledger=CellBudgetLedger(root/'budget.sqlite',AttemptBudget('native-stage-revalidation-20261111',500000))
write_private_json(root/'pr98-campaign-source.json',dict(head=head,tree=tree,files={n:file_identity(root/n)for n in ['pr98_campaign.py','pr98_cell.py','pr98_cpu_replay.py','pr98-templates.json','pr98-old-calls.json','pr98_model_inventory.py']},budget=ledger.snapshot()))
with acquire_host_runner_lease(Path('<data-root>/experiment-artifacts'),repository_commit=head):
 for name,suffix in [('host_helpers','.py'),('host_config','.json')]:
  original=Path(base[name]['path']);assert file_identity(original)['sha256']==base[name]['sha256'];(root/('pr98-original-'+name+suffix)).write_bytes(original.read_bytes())
 for python,groups,label in [(driver,'core,text,text-qwen7b','driver'),(model,'text,text-qwen7b','model')]:
  p=subprocess.run([python,'code/scripts/environment/manage_environment.py','check','--groups',groups,'--json-out',str(root/('pr98-'+label+'-preflight.json'))],env=env,capture_output=True,text=True,timeout=90)
  (root/('pr98-'+label+'-preflight.log')).write_text(redact_text(p.stdout+p.stderr));assert p.returncode==0
 p=subprocess.run([driver,'-B',str(root/'pr98_model_inventory.py')],env=env,capture_output=True,text=True,timeout=120)
 (root/'pr98-model-identity.log').write_text(redact_text(p.stdout+p.stderr));assert p.returncode==0
 for arm,template in templates.items():
  c=deepcopy(template)
  for key in ('tool_source','observer_sha256','base_config','cpu_check'):c.pop(key,None)
  base_id='pr98-invariant-base-'+arm
  c.update(source_root=str(source),expected_source=dict(head=head,tree=tree),artifact_root=str(root/(base_id+'-cell')),run_id=base_id,cell_id=base_id,trace_name=base_id,execution_enabled=False,units={base_id:48})
  c['environment'].update(VLLM_BATCH_INVARIANT='1',RAY_TMPDIR='/tmp/sem-bi-1111-'+arm)
  c['ray_options'].update(_temp_dir='/tmp/sem-bi-1111-'+arm,_plasma_directory=str(root/('pr98-plasma-'+arm)))
  c['nsys_tmp']=str(root/('pr98-nsys-'+arm));c['observation'].update(mode='on',profile='full')
  path=root/('pr98-base-'+arm+'.json');write_private_json(path,c)
  ready=root/('pr98-cpu-'+arm);print('CPU QUALIFY',arm,flush=True)
  result=workflow.qualify(path,ready,head);print('CPU READY',arm,result['status'],flush=True)
  workflow.prepare(path,ready/'CPU-READY.json',root/('pr98-'+arm),'pr98-invariant-'+arm,'on','full')
 # Current-source order regressions and exact old-answer request reconstruction precede new model calls.
 command=[driver,'-B','-m','unittest','tests.experiments.test_prepared_order_replay','tests.execution_provider.test_prepared_order_candidates']
 p=subprocess.run(command,cwd=source,env=dict(env,CUDA_VISIBLE_DEVICES=''),capture_output=True,text=True,timeout=180)
 (root/'pr98-request-replay-cpu.log').write_text(redact_text(p.stdout+p.stderr));assert p.returncode==0
 p=subprocess.run([driver,'-B',str(root/'pr98_cpu_replay.py')],env=dict(env,CUDA_VISIBLE_DEVICES=''),capture_output=True,text=True,timeout=120)
 (root/'pr98-current-request-replay.log').write_text(redact_text(p.stdout+p.stderr));print(p.stdout[-500:],flush=True);assert p.returncode==0
for arm in templates:
 if ledger.snapshot()['deadline_utc']-time.time()<1000:raise RuntimeError('insufficient remaining allowance for PR98 cell')
 unit='pr98-invariant-'+arm;ledger.reserve_unit(unit,48);ledger.claim_unit(unit).bind_execution()
 cell=root/('pr98-'+arm)
 write_private_json(cell/'GLOBAL-RESERVATION.json',dict(unit_id=unit,calls=48,budget=ledger.snapshot(),hierarchy='campaign precharge plus per-cell native cap; do not add the same attempts twice'))
 print('START',unit,flush=True)
 sup=supervise([driver,'-B',str(root/'pr98_cell.py'),str(cell)],cell/'outer-supervision',timeout_s=1100,grace_s=90,natural_exit_grace_s=3)
 result=json.loads((cell/'RESULT.json').read_text());print(json.dumps(result),flush=True)
 assert result['status']=='completed'and result['actual_call_count_complete']and result['physical_cleanup_confirmed']and result['lease_released']
print('DONE pr98',flush=True)
