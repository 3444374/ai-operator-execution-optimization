"""Export exact GPU interval evidence inside explicit NVTX request-round windows."""
import argparse, hashlib, json, sqlite3
from pathlib import Path

def duration_union(intervals):
    end=None;total=0
    for a,b in sorted(intervals):
        total+=max(0,b-max(a,end if end is not None else a));end=max(b,end if end is not None else b)
    return total

def analyze(path):
    db=sqlite3.connect(path);db.row_factory=sqlite3.Row
    tables={r[0] for r in db.execute("select name from sqlite_master where type='table'")}
    strings=dict(db.execute('select id,value from StringIds'))
    nvtx=[dict(r) for r in db.execute('select * from NVTX_EVENTS')]
    windows=[]
    for event in nvtx:
        text=event.get('text') or strings.get(event.get('textId'),'')
        if text.startswith('diagnosis-round-'):
            assert event['end'] is not None
            windows.append(dict(round=int(text.removeprefix('diagnosis-round-')),start=event['start'],end=event['end']))
    assert len(windows)==4, ('missing or duplicate NVTX rounds',len(windows))
    windows.sort(key=lambda x:x['round'])
    output=[]
    for w in windows:
        start,end=w['start'],w['end'];gpu=[];api=[]
        for table,kind in [('CUPTI_ACTIVITY_KIND_KERNEL','kernel'),('CUPTI_ACTIVITY_KIND_MEMCPY','memcpy'),('CUPTI_ACTIVITY_KIND_MEMSET','memset')]:
            if table not in tables:continue
            for r in db.execute(f'SELECT * FROM {table} WHERE start < ? AND end > ?',(end,start)):
                row=dict(r);event=dict(kind=kind,start_ns=max(row['start'],start)-start,end_ns=min(row['end'],end)-start,
                    global_pid=row.get('globalPid'),device_id=row.get('deviceId'),context_id=row.get('contextId'),stream_id=row.get('streamId'))
                if kind=='kernel':event['name']=strings.get(row.get('shortName') or row.get('demangledName'),'unknown')
                else:event.update(bytes=row.get('bytes'),copy_kind=row.get('copyKind'),src_kind=row.get('srcKind'),dst_kind=row.get('dstKind'))
                gpu.append(event)
        for table in ('CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER'):
            if table not in tables:continue
            for r in db.execute(f'SELECT * FROM {table} WHERE start < ? AND end > ?',(end,start)):
                row=dict(r);name=strings.get(row.get('nameId'),'unknown')
                if any(s in name.lower() for s in ('memcpy','synchronize','memset')):
                    api.append(dict(kind=table,name=name,global_tid=row.get('globalTid'),start_ns=max(row['start'],start)-start,end_ns=min(row['end'],end)-start))
        def union(rows):return duration_union([(r['start_ns'],r['end_ns']) for r in rows])/1e9
        copies=[x for x in gpu if x['kind']=='memcpy'];kernels=[x for x in gpu if x['kind']=='kernel']
        groups=[]
        for key in sorted({str(x['copy_kind']) for x in copies}):
            rows=[x for x in copies if str(x['copy_kind'])==key]
            groups.append(dict(copy_kind=key,count=len(rows),bytes=sum(x['bytes'] for x in rows),union_s=union(rows),sum_s=sum(x['end_ns']-x['start_ns'] for x in rows)/1e9))
        output.append(dict(round=w['round'],warmup=w['round']==0,wall_s=(end-start)/1e9,gpu_union_s=union(gpu),
            kernel_union_s=union(kernels),memcpy_union_s=union(copies),no_traced_gpu_activity_s=(end-start)/1e9-union(gpu),
            copy_groups=groups,gpu_pids=sorted({x['global_pid'] for x in gpu}),
            memcpy_api_union_s=union([x for x in api if 'memcpy' in x['name'].lower()]),
            gpu_intervals=gpu,selected_cuda_api_intervals=api))
    metadata={}
    for name in sorted(tables):
        if name.startswith('ENUM_CUDA_MEM') or name=='TARGET_INFO_GPU' or name.startswith('DIAGNOSTIC'):
            metadata[name]=[dict(x) for x in db.execute(f'SELECT * FROM {name}')]
    return dict(schema='semloom.stage_cost_cuda_intervals.v1',sqlite_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                windows=windows,rounds=output,metadata=metadata,
                interpretation='Intervals overlap; GPU inactivity is not uniquely CPU time. Memcpy union is not end-to-end handoff time.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('sqlite',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    out=analyze(a.sqlite);a.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(json.dumps([{k:v for k,v in row.items() if k not in ('gpu_intervals','selected_cuda_api_intervals')} for row in out['rounds']]))
