"""Recompute the observed fragment contrast; timings are diagnostic, not speedup."""
import argparse,ast,collections,json,re
from pathlib import Path
from analyze_trace import duration_union

def summarize(root, baseline):
    runs={}
    for name,cell in [('protocol','protocol01-q8-pipeline'),('tcp-fragment','tcp64-trace01-q8-pipeline')]:
        folder=root/('semloom-kv-'+name+'-20261112');p=folder/cell
        report=json.loads((p/'worker/report.json').read_text())
        source=json.loads((p/'source.json').read_text())
        inventory=json.loads((folder/'final-inventory.json').read_text())
        resources=json.loads((p/'resources.json').read_text())
        after=json.loads((p/'gpu-after.json').read_text())
        prompt=json.loads((p/'captured-prompt-parity.json').read_text())
        assert report['status']=='passed' and resources['passed'] and after['empty'] and prompt['complete']
        assert inventory['matches_previous_model_weights'] and inventory['matches_previous_native_files'] and inventory['source_clean']
        lanes={}
        for stage in ('prefill','decode'):
            text=(p/('worker/control/'+stage+'.log')).read_text()
            lanes[stage]=sorted({line[line.index('ucp_context_'):] for line in text.splitlines() if 'rma_am(' in line and 'ucp_context_' in line})
            assert lanes[stage] and all('rma_am(tcp/eth0)' in x for x in lanes[stage])
        runs[name]=dict(run_id=cell,source_head=source['head'],environment=source.get('transport_environment'),
            reserved_physical_calls=report['reserved_physical_calls'],strict_result_sha256=report['result_sha256'],prompt_parity=prompt,
            resource_check_passed=resources['passed'],gpu_empty_at_cell_end=after['empty'],lanes=lanes,
            close_status=report['close']['status'],native_transfer=report['close']['stages']['decode']['engine_api']['native_kv_transfer_final'])
    assert runs['protocol']['strict_result_sha256']==runs['tcp-fragment']['strict_result_sha256']
    text=(root/'semloom-kv-protocol-20261112/protocol01-q8-pipeline/worker/control/decode.log').read_text()
    # Native start_load_kv's len(block_ids) counts cache groups, not blocks.
    groups=[tuple(map(int,m)) for m in re.findall(r'start_load_kv for request [^\s:]+:(\d+)-.*?Num local_block_ids: (\d+)\. Num remote_block_ids: (\d+)\.',text)]
    assert len(groups)==240 and all(row[1:]==(1,1) for row in groups)
    rows=[]
    for count,parameters in re.findall(r'update_state_after_alloc: num_external_tokens=(\d+), kv_transfer_params=(\{[^\n]+\})',text):
        params=ast.literal_eval(parameters)
        if not params.get('do_remote_prefill') or int(count)==0:continue
        sequence=int(params['remote_request_id'].split(':')[1].split('-')[0])
        rows.append((sequence,int(count)))
    assert len(rows)==240 and sorted(row[0] for row in rows)==list(range(240))
    measured=[row for row in rows if row[0]>=120]
    assert len(measured)==120 and all(1<=row[1]<=16 for row in measured)
    block_counts=dict(measured_requests=len(measured),block_tokens=16,
        external_token_histogram=dict(sorted(collections.Counter(row[1] for row in measured).items())),
        measured_blocks_inferred_from_external_tokens=sum((row[1]+15)//16 for row in measured),
        warmup_blocks_inferred_from_external_tokens=sum((row[1]+15)//16 for row in rows if row[0]<120),
        native_start_load_log_cache_groups=1,
        interpretation='Positive external-token allocations identified by remote request sequence. ceil(tokens/16) gives block count and agrees with measured copy bytes. Native start_load_kv len(block_ids)=1 is outer cache-group count, not a block observation.')
    d=json.loads((root/'semloom-kv-tcp-fragment-20261112/tcp64-trace01-q8-pipeline/trace-intervals.json').read_text())
    rounds=[]
    for w in d['rounds']:
        if w['warmup']:continue
        gpu=w['gpu_intervals'];api=w['selected_cuda_api_intervals']
        shapes=collections.Counter((v['copy_kind'],v['bytes']) for v in gpu if v['kind']=='memcpy')
        copy_count=sum(v['name']=='cuMemcpyAsync' for v in api);sync_count=sum(v['name']=='cuStreamSynchronize' for v in api)
        assert shapes[(1,16384)]==shapes[(2,16384)]==3360
        assert copy_count==sync_count==6720
        selected=[v for v in api if v['name'] in ('cuMemcpyAsync','cuStreamSynchronize')]
        union=duration_union([(v['start_ns'],v['end_ns']) for v in selected])/1e9
        rounds.append(dict(round=w['round'],wall_s=w['wall_s'],kernel_union_s=w['kernel_union_s'],memcpy_union_s=w['memcpy_union_s'],
            copy_and_sync_api_union_s=union,copy_api_count=copy_count,stream_sync_count=sync_count,
            kv_copy_bytes_per_direction=3360*16384,copy_shapes=[dict(kind=k,bytes=b,count=n)for(k,b),n in sorted(shapes.items())]))
    refs=json.loads(baseline.read_text())
    return dict(schema='semloom.kv_tcp_fragment_followup.v1',runs=runs,protocol_blocks=block_counts,reference=refs,new_rounds=rounds,
        physical_copy_count_ratio=6720/20160,physical_calls_new_protocol=480,physical_calls_new_fragment_probe=960,
        interpretation='Counts are both host-staging directions combined. Same bytes and strict output, changed physical fragmentation. Separate sessions, INFO logging and Nsight perturbation preclude stable or whole-query speedup claims. No default tuning or backend patch.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('baseline',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    out=summarize(a.root,a.baseline);a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(blocks=out['protocol_blocks'],rounds=[{k:v for k,v in w.items() if k!='copy_shapes'}for w in out['new_rounds']]),ensure_ascii=False))
