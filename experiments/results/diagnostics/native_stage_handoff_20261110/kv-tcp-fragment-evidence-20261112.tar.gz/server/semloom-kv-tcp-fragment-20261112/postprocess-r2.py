from pathlib import Path
import subprocess,sys,os,json,hashlib,tarfile,time
r=Path('<data-root>/semloom-kv-tcp-fragment-20261112');source=Path('<data-root>/semloom-stage-revalidation-20261111/source')
sys.path.insert(0,str(source/'code'))
from src.infrastructure.runner_lease import acquire_host_runner_lease
os.sched_setaffinity(0,set(sorted(os.sched_getaffinity(0))[:8]))
deadline=time.monotonic()+600
while True:
 try:
  lease=acquire_host_runner_lease(Path('<data-root>/experiment-artifacts'),repository_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip())
  break
 except RuntimeError:
  if time.monotonic()>=deadline:raise
  time.sleep(2)
with lease:
 c=r/'tcp64-trace01-q8-pipeline'
 p=subprocess.run(['nsys','export','--type=sqlite','--output='+str(c/'trace.sqlite'),str(c/'trace.nsys-rep')],capture_output=True,text=True,timeout=120)
 (r/'trace-export.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 p=subprocess.run([sys.executable,str(r/'analyze_trace.py'),str(c/'trace.sqlite'),str(c/'trace-intervals.json')],capture_output=True,text=True,timeout=90)
 (r/'trace-analysis.log').write_text(p.stdout+p.stderr);assert p.returncode==0
 for name in ['protocol','tcp-fragment']:
  p=subprocess.run([sys.executable,str(r/('inventory-'+name+'.py'))],capture_output=True,text=True,timeout=90)
  (r/('inventory-'+name+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0
print('POSTPROCESS DONE',flush=True)
