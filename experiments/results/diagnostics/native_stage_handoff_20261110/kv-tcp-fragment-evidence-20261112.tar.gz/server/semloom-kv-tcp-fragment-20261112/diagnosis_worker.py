"""Temporary attribution harness over unchanged native owners; not a new backend."""
import argparse
import ctypes
import json
import time
from pathlib import Path
from src.experiments import native_stage_pipeline as replay
from src.infrastructure.private_artifacts import write_private_json
from src.infrastructure.redact import redact_json_values
from src.serving.backends.async_engine_process import AsyncEngineProcess
from src.serving.backends.vllm_protocol import AsyncEngineLimits
from src.serving.backends.vllm_sync_process import _publish

parser=argparse.ArgumentParser()
parser.add_argument('--config',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
config=json.loads(args.config.read_text())

class SingleAsync:
    def __init__(self,engine,generation,control,deadline,startup_timeout_s,**unused):
        self.control,self.deadline=control,deadline
        self.limits=AsyncEngineLimits(**config['limits'])
        self.owner=AsyncEngineProcess(engine,generation,limits=self.limits,
            startup_timeout_s=startup_timeout_s,startup_deadline=deadline,
            worker_log=control/'native.log')
        self.ready_report=self.owner.ready_report
        self.record=dict(model_pid=self.owner.process.pid,process_created=self.owner.process_created,
                         status='ready',process_exit_confirmed=False,cleanup_errors=[])
        _publish(control/'engine-async.json',self.record)
    def run_prepared(self,rows,*,generation):
        outcome=self.owner.submit_batch(rows,generation=generation,deadline_monotonic=self.deadline)
        if outcome.status!='queued':raise RuntimeError('single async batch not accepted: '+outcome.status)
        pending=set(outcome.request_ids); results={}
        while pending:
            for event in self.owner.poll(self.limits.result_slots):
                if event.request_id not in pending or not event.engine_terminal_confirmed:
                    raise RuntimeError('single async result unconfirmed or unexpected')
                results[event.request_id]=event.result;pending.remove(event.request_id)
            if pending:
                remaining=self.deadline-time.monotonic()
                if remaining<=0:raise TimeoutError('single async result deadline')
                self.owner.wait(timeout=remaining)
        return [results[key] for key in outcome.request_ids]
    def close(self,timeout):
        report=self.owner.close(timeout=timeout)
        _publish(self.control/'engine-async.json',dict(self.record,**report))
        return report

if config['diagnostic_arm']=='async':replay.ReferenceChainEngineProcess=SingleAsync

# NVTX is a tiny header-only host marker; it performs no CUDA synchronization.
nvtx=ctypes.CDLL(config['nvtx_library']) if config.get('profile') else None
if nvtx:
    nvtx.push.argtypes=[ctypes.c_char_p]
    nvtx.pop.argtypes=[]
counter=[0]
for cls in (replay.ReferenceChainEngineProcess,replay.PipelinedPrefillDecodeProcess):
    original=cls.run_prepared
    def timed(self,rows,*,generation,_original=original):
        number=counter[0];counter[0]+=1
        if nvtx:nvtx.push(('diagnosis-round-'+str(number)).encode())
        start=time.monotonic()
        try:return _original(self,rows,generation=generation)
        finally:
            end=time.monotonic()
            if nvtx:nvtx.pop()
            windows.append(dict(round=number,start_monotonic=start,end_monotonic=end))
    cls.run_prepared=timed
windows=[]
original_identity=replay.result_identity
def identity(results,expected):
    digest=original_identity(results,expected)
    # This runs outside the timed request window. Keep only attribution fields.
    keys=('call_id','engine_request_id','engine_uid','model_start_monotonic','model_end_monotonic',
          'model_elapsed_s','native_num_cached_tokens','prompt_tokens','completion_tokens','status')
    records=[]
    for result in results:
        item={k:result.get(k) for k in keys}
        if 'stage_receipts' in result:
            item['stage_receipts']={s:[{k:r.get(k) for k in keys} for r in rs]
                                    for s,rs in result['stage_receipts'].items()}
        records.append(item)
    write_private_json(args.output/('receipts-'+str(counter[0]-1)+'.json'),redact_json_values(records))
    return digest
replay.result_identity=identity
try:replay.run(config,args.output)
finally:
    if args.output.exists():write_private_json(args.output/'round-windows.json',windows)
