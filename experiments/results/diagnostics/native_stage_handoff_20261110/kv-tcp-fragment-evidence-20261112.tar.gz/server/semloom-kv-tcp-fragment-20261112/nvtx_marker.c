#include <nvtx3/nvToolsExt.h>
void push(const char *s) { nvtxRangePushA(s); }
void pop(void) { nvtxRangePop(); }
