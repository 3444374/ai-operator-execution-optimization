# Native KV protocol inspection 2026-11-12
Purpose: verify current actual NIXL/UCX READ transport and message fragmentation, not performance tuning.
Unchanged source14c6c5e03; same Qwen2.5-1.5B, RTX4090, 8CPU slots, BF16/eager, totalGPUfraction.6 and totalbatchtokens4096, C128/P64/B64.
Original complete120Q8 requests/generation; one warmup + one measured replay; 480physicalP/D calls total. Strict original result digest, NIXL completion/failure, observed-process/SHM/GPU exit required.
Only UCX_PROTO_INFO=used, UCX_LOG_LEVEL=info, VLLM_LOGGING_LEVEL=DEBUG logging added. No model/source/config optimization, no Nsight, no time-benefit claim. Retain full requests/first results and native logs; logging overhead means timings are diagnostic only.
Fresh480callledger,600seconds from controller startup, sharedhostlease, currentdriver/modelread-onlypreflight. 32GiBRSS/8GiBSHM/8GiBartifacts/free10GiB sameguards. Stoponunexpectedoutput/lifecyclefailure, no modelretry/budgetreset; no downloads/installs.
