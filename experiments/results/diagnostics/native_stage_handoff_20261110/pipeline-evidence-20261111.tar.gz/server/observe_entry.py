"""Explicit, bounded probe using the repository's existing native observer."""
import argparse
import os
from pathlib import Path

from src.infrastructure.private_artifacts import read_json
from src.experiments.native_stage_pipeline import run
from src.serving.backends.async_engine_process import AsyncEngineProcess

parser=argparse.ArgumentParser()
parser.add_argument('--config',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
config=read_json(args.config)
observer=Path(config['observer_source'])
os.environ.update(SEM_RECORD_OBSERVATION='on',SEM_RECORD_OBSERVER_ROOT=str(args.config.parent),
                  SEM_RECORD_OBSERVER_CODE=str(observer.parents[2]),
                  SEM_RECORD_RUN_ID=args.config.parent.name,SEM_RECORD_SESSION_ID=args.config.parent.name)
AsyncEngineProcess._command=staticmethod(lambda spec,fds:[spec.model_python,
    str(observer/'record_model_bootstrap.py'),*map(str,fds)])
run(config,args.output)
