from pathlib import Path
import json,math,statistics,sqlite3,time,hashlib,sys
root=Path('<data-root>/semloom-stage-pipeline-20261111')
sys.path.insert(0,str(root/'source/code'))
from src.infrastructure.private_artifacts import write_private_json
choices=json.loads((root/'capacity-selection.json').read_text())
frozen={};total=0
for name,choice in choices.items():
 capacity=choice['capacity']
 half=json.loads((root/('calibrate02-'+name+'-pipeline-c'+str(capacity))/'worker/report.json').read_text())
 full=json.loads((root/('window01-'+name+'-pipeline-full')/'worker/report.json').read_text())
 assert half['status']==full['status']=='passed'
 assert half['result_sha256']==full['result_sha256']==choice['result_sha256']
 mean=lambda report:statistics.mean(x['elapsed_s'] for x in report['rounds'] if not x['warmup'])
 window=capacity if mean(full)<mean(half) else capacity//2
 pipeline=min(mean(full),mean(half))
 native=choice['calibration_mean_s'][str(capacity)]['colocated']
 rounds=math.ceil(75/min(native,pipeline))
 rows=120 if name=='q8' else 64
 physical=3*3*rows*(rounds+1)
 total+=physical
 frozen[name]=dict(capacity=capacity,prefill_window=window,batch_size=window,rounds=rounds,
  result_sha256=choice['result_sha256'],source_head=choice['source_head'],
  selected_calibration_mean_s=dict(colocated=native,pipeline=pipeline),
  half_window_mean_s=mean(half),full_window_mean_s=mean(full),
  expected_physical_calls_three_repetitions=physical,
  predicted_measured_s=dict(colocated=native*rounds,pipeline=pipeline*rounds),
  lifecycle='three interleaved resident sessions per arm; one warmup each; same fixed measured rounds',
  scope='request replay; eager; same one GPU and declared total memory/CPU capacity; not full query or global optimum')
with sqlite3.connect(root/'budget.sqlite') as connection:
 allocated,limit,deadline=connection.execute('SELECT allocated,limit_count,deadline FROM budget').fetchone()
assert allocated+total+480<=limit,(allocated,total,limit)
estimated_s=sum(sum(x['predicted_measured_s'].values())*3+3*(75+150) for x in frozen.values())+300
assert estimated_s<deadline-time.time(),(estimated_s,deadline-time.time())
write_private_json(root/'frozen.json',frozen)
write_private_json(root/'freeze-audit.json',dict(allocated_before=allocated,planned_repetition_calls=total,
 observed_probe_reservation=480,hard_limit=limit,remaining_wall_s=deadline-time.time(),
 projected_wall_s=estimated_s,controller_sha256=hashlib.sha256((root/'campaign.py').read_bytes()).hexdigest(),
 freeze_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 plan_amendment_commit='62df69c0f',source_head=next(iter(frozen.values()))['source_head']))
print(json.dumps(frozen,indent=2));print('planned_calls',total,'already_allocated',allocated)
