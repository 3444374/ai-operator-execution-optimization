from pathlib import Path
import os,sys,json,subprocess,time,math,statistics,shutil
ROOT=Path('<data-root>/semloom-stage-pipeline-20261111');SOURCE=ROOT/'source'
sys.path.insert(0,str(SOURCE/'code'))
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.infrastructure.private_artifacts import write_private_json,content_digest
from src.infrastructure.redact import redact_json_values,redact_text
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.lotus_records_supervisor import supervise
from src.observability.process_resources.supervised import ResourceMonitor
from src.semantic_methods.lotus.records import identity

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True).strip()
base=json.loads(Path('<data-root>/semloom-execution-candidates-20261110/base-original.json').read_text())
driver,model=base['engine']['driver_python'],base['engine']['model_python']
env_text=Path('<data-root>/semloom-native-stage-handoff-20261110/runtime.env').read_text()
for key,value in [('PROJECT_ROOT',str(SOURCE)),('ARTIFACT_ROOT',str(ROOT))]:
 env_text='\n'.join(key+'='+value if line.removeprefix('export ').startswith(key+'=') else line for line in env_text.splitlines())+'\n'
env_path=ROOT/'runtime.env';env_path.write_text(env_text);env_path.chmod(0o600)
env=dict(os.environ,**base['environment']);env.update(PYTHONPATH=str(SOURCE/'code'),AI_OPERATOR_ENV_FILE=str(env_path),OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8',TOKENIZERS_PARALLELISM='false',CUDA_VISIBLE_DEVICES='0',VLLM_LOGGING_LEVEL='INFO')
os.environ.clear();os.environ.update(env);os.chdir(SOURCE)
slots=sorted(os.sched_getaffinity(0))[:8];assert len(slots)==8;os.sched_setaffinity(0,set(slots))
budget=AttemptBudget('native-stage-pipeline-20261111',500000)
ledger_path=ROOT/'budget.sqlite'
ledger=CellBudgetLedger(ledger_path,budget) if ledger_path.exists() else CellBudgetLedger.create(ledger_path,budget,deadline_utc=time.time()+7200)

def gpu():
 return dict(gpu=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True),compute=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],text=True))

def workload(name):
 if name=='q8':
  packet=json.loads(Path('<data-root>/semloom-execution-candidates-20261110/original.requests.json').read_text())
  return packet['requests'],base['generation']
 if name=='smoke':
  text=['What is two plus three?','Name the capital of France.','Write the next number: 1, 2, 3.','Give the opposite of cold.']
 else:
  text=['Copy the following numbered sequence exactly. Do not add an explanation.\n'+ ' '.join(str((i+j)%100) for j in range(80)) for i in range(64)]
 rows=[]
 for i,prompt in enumerate(text):
  messages=[dict(role='system',content='Follow the user instruction.'),dict(role='user',content=prompt)]
  rows.append(dict(identity('stage-'+name,'row-'+str(i),i),messages_json=json.dumps(messages)))
 return rows,dict(max_tokens=16 if name=='smoke' else 128,temperature=0,seed=0,stop=[])

def run_cell(run_id,name,arm,capacity,rounds):
 cell=ROOT/run_id;cell.mkdir(mode=0o700)
 before=gpu();write_private_json(cell/'gpu-before.json',before)
 if before['compute'].strip():raise RuntimeError('unrelated GPU work prevents exclusive run')
 rows,generation=workload(name);calls=len(rows)*(rounds+1)*(2 if arm=='pipeline' else 1)
 reservation=ledger.reserve_unit(run_id,calls);claim=ledger.claim_unit(run_id);claim.bind_execution()
 remaining=ledger.snapshot()['deadline_utc']-time.time()
 if remaining<600:raise RuntimeError('insufficient remaining experiment wall allowance')
 config=dict(arm=arm,rows=rows,generation=generation,warmup_rounds=1,rounds=rounds,reserved_physical_calls=calls,
  engine=dict(model_path='<data-root>/models/Qwen2.5-1.5B-Instruct',model_python=model,driver_python=driver,dtype='bfloat16',max_model_len=16384,max_num_seqs=capacity,max_num_batched_tokens=4096 if arm=='colocated' else 2048,gpu_memory_utilization=.6 if arm=='colocated' else .3,seed=0,enable_prefix_caching=True,enforce_eager=True),
  worker_timeout_s=min(1680,remaining-90),startup_timeout_s=240,close_timeout_s=30,
  prefill=dict(cuda_visible_devices='0',side_channel_port=15700),decode=dict(cuda_visible_devices='0',side_channel_port=15701),
  limits=dict(max_inflight=capacity,item_input_bytes=256*1024,item_result_bytes=256*1024),
  batch_size=capacity//2,prefill_window=capacity//2)
 write_private_json(cell/'config.json',config)
 write_private_json(cell/'source.json',dict(head=head,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=SOURCE,text=True).strip(),config_digest=content_digest(config),input_digest=content_digest(rows),cpu_affinity=slots,precharged_physical_calls=calls,budget=ledger.snapshot()))
 samples=[];previous=[0.0]
 resources=ResourceMonitor(dict(cpu_affinity_slots=slots,max_sampled_owned_rss_bytes=32*1024**3,max_owned_shm_bytes=8*1024**3),sample_seconds=.5)
 def monitor(owned):
  resources(owned)
  if time.monotonic()-previous[0]>=1:
   samples.append(dict(monotonic=time.monotonic(),**gpu()));previous[0]=time.monotonic()
   if shutil.disk_usage(ROOT).free<10*1024**3:raise RuntimeError('disk reserve reached')
   if sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file() and 'source' not in p.parts)>8*1024**3:raise RuntimeError('artifact size limit')
 print('START',run_id,'calls',calls,flush=True)
 try:
  sup=supervise([driver,'-B','-m','src.experiments.native_stage_pipeline','--config',str(cell/'config.json'),'--output',str(cell/'worker')],cell/'supervision',timeout_s=min(1770,remaining-5),grace_s=60,natural_exit_grace_s=2,monitor=monitor)
 finally:
  write_private_json(cell/'resources.json',redact_json_values(resources.finish()))
  write_private_json(cell/'gpu-samples.json',redact_json_values(samples))
  after=gpu();after['empty']=not after['compute'].strip();write_private_json(cell/'gpu-after.json',after)
 report=json.loads((cell/'worker/report.json').read_text())
 resource_report=json.loads((cell/'resources.json').read_text())
 result=dict(run_id=run_id,status=report['status'],error=report.get('error'),measured_s=report.get('measured_s'),digest=report.get('result_sha256'),resources=resource_report['passed'],gpu_empty=after['empty'],worker_exit=sup['worker_exit'])
 print(json.dumps(result),flush=True)
 if report['status']!='passed' or not resource_report['passed'] or not after['empty'] or sup['worker_exit']!=0:raise RuntimeError('cell did not pass all gates')
 return report

mode=sys.argv[1]
with acquire_host_runner_lease(Path('<data-root>/experiment-artifacts'),repository_commit=head):
 for python,groups,label in [(driver,'core,text,text-qwen15b','driver'),(model,'native-kv-transfer','model')]:
  output=ROOT/(mode+'-'+label+'-preflight.json')
  if output.exists():raise RuntimeError('run mode identity already exists')
  p=subprocess.run([python,'code/scripts/environment/manage_environment.py','check','--groups',groups,'--json-out',str(output)],cwd=SOURCE,env=env,capture_output=True,text=True,timeout=90)
  (ROOT/(mode+'-'+label+'-preflight.log')).write_text(redact_text(p.stdout+p.stderr));print(label,'preflight',p.returncode,flush=True);assert p.returncode==0
 if mode.startswith('smoke'):
  a=run_cell(mode+'-colocated','smoke','colocated',4,1)
  b=run_cell(mode+'-pipeline','smoke','pipeline',4,1)
  assert a['result_sha256']==b['result_sha256'],'cross-arm exact output mismatch'
 elif mode.startswith('calibrate'):
  for name in ('q8','copy'):
   digests=[]
   for capacity in (8,32,64):
    for arm in ('colocated','pipeline'):
     result=run_cell(mode+'-'+name+'-'+arm+'-c'+str(capacity),name,arm,capacity,2);digests.append(result['result_sha256'])
     if len(set(digests))!=1:raise RuntimeError('cross-arm/capacity exact output mismatch')
 elif mode.startswith('formal'):
  frozen=json.loads((ROOT/'frozen.json').read_text())
  for name,choice in frozen.items():
   for repeat in range(3):
    arms=('colocated','pipeline') if repeat%2==0 else ('pipeline','colocated')
    for arm in arms:
     result=run_cell(mode+'-'+name+'-'+arm+'-r'+str(repeat),name,arm,choice['capacity'],choice['rounds'])
     if result['result_sha256']!=choice['result_sha256']:raise RuntimeError('formal output mismatch')
 else:raise ValueError('unknown mode')
 print('DONE',mode,json.dumps(ledger.snapshot()),flush=True)
