"""Restore byte-identical public round receipts from an unpacked evidence archive."""
from pathlib import Path
import argparse,hashlib,json,os

parser=argparse.ArgumentParser()
parser.add_argument('directory',type=Path)
args=parser.parse_args();root=args.directory.resolve()
index=json.loads((root/'round-receipt-recovery.json').read_text());cache={}
for item in index['files']:
    source=(root/item['report']).resolve();target=(root/item['member']).resolve()
    if not source.is_relative_to(root) or not target.is_relative_to(root):raise ValueError('unsafe recovery path')
    if source not in cache:cache[source]={r['round']:r for r in json.loads(source.read_text())['rounds']}
    body=(json.dumps(cache[source][item['round']],ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    assert len(body)==item['public_bytes'] and hashlib.sha256(body).hexdigest()==item['public_sha256']
    if target.exists():assert target.read_bytes()==body
    else:
        target.parent.mkdir(parents=True,exist_ok=True)
        with os.fdopen(os.open(target,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600),'wb') as stream:stream.write(body)
print(json.dumps(dict(restored_or_verified=len(index['files']))))
