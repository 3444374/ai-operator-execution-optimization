from pathlib import Path
from collections import Counter,defaultdict
import json,sys
root=Path('<data-root>/semloom-stage-pipeline-20261111');cell=root/'observe01-q8-pipeline';sys.path.insert(0,str(root/'source/code'))
from src.infrastructure.private_artifacts import write_private_json
report=json.loads((cell/'worker/report.json').read_text());roles={v['engine_uid']:k for k,v in report['ready']['stages'].items()}
events=[json.loads(line)for p in sorted((cell/'events').glob('events-*.jsonl'))for line in p.read_text().splitlines()]
opens={(e['pid'],e['request_id']):roles[e['engine_uid']]for e in events if e['event']=='native_open'}
start=min(e['monotonic_ns']for e in events if e['event']=='native_open')
aliases={};unknown_adds=[]
for e in events:
 if e['event']=='native_api_native_add_return':
  stage=opens.get((e['pid'],e['request_id']));native=(e.get('native_identity')or{}).get('mapped_internal_ids',[])
  if not stage or not native:unknown_adds.append((e['pid'],e['request_id']))
  for key in native:
   assert key not in aliases;aliases[key]=stage
hist={name:Counter()for name in roles.values()};covered=set();unmatched=[];initial=[];iterations=[]
for e in events:
 if e['event']!='native_graph_decision':continue
 members=e.get('scheduled_tokens')or{};assigned={aliases.get(key)for key in members}
 if members and None not in assigned and len(assigned)==1:
  stage=assigned.pop();hist[stage][len(members)]+=1;covered.update(members)
  iterations.append(dict(pid=e['pid'],iteration=e['observer_execute_id'],stage=stage,requests=len(members),tokens=sum(members.values()),mode=e['cudagraph_mode']))
 elif e.get('observation_ns',e['monotonic_ns'])<start:initial.append((e['pid'],e['observer_execute_id']))
 else:unmatched.append((e['pid'],e['observer_execute_id'],list(members)))
summary=dict(native_alias_counts=dict(Counter(aliases.values())),batch_histograms={k:dict(v)for k,v in hist.items()},max_batch={k:max(v,default=0)for k,v in hist.items()},missing_business_native_ids=sorted(set(aliases)-covered),unknown_adds=unknown_adds,unmatched_after_business=unmatched,unassociated_before_business=initial,iterations=iterations,scope='actual native graph/input-preparation decision members, linked through native returned aliases; no kernel duration or simultaneous-kernel claim')
summary['passed']=not summary['missing_business_native_ids'] and not unknown_adds and not unmatched and all(n>1 for n in summary['max_batch'].values())
write_private_json(cell/'business-batches.json',summary)
print(json.dumps({k:v for k,v in summary.items()if k!='iterations'}))
