"""Independent CPU verification of revised per-round and final transfer gates."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from unittest.mock import patch

from src.infrastructure.redact import redact_json_values
from src.semantic_methods.lotus.records import identity


root = Path(__file__).parent
source = root / 'stage-pipeline-worker-fixed.py'
spec = importlib.util.spec_from_file_location('fixed_stage_replay', source)
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
row = dict(identity('fixture', 'a', 0), messages_json=json.dumps([dict(role='user', content='hello')]))
expected = replay._prepared([row])[0][0]
config = dict(engine=dict(model_path='/unused', model_python='/model/python', driver_python='/driver/python'),
    generation=dict(max_tokens=1), rows=[row], arm='pipeline', warmup_rounds=1, rounds=2,
    reserved_physical_calls=6, worker_timeout_s=10, startup_timeout_s=1, close_timeout_s=1,
    prefill=dict(cuda_visible_devices='0', side_channel_port=15600),
    decode=dict(cuda_visible_devices='0', side_channel_port=15601),
    limits=dict(max_inflight=2), batch_size=1, prefill_window=1)
output = root / 'stage-worker-gate-fixed-evidence'
output.mkdir(exist_ok=True)
observations = []
for scenario in ('failed_pipeline', 'missing_transfer_observation', 'expired_handoff',
                 'prefill_expired_handoff', 'valid_no_prefill_transfer_update'):
    class Owner:
        def __init__(self, *args, **kwargs):
            self.calls = 0
            self.last_run_report = None

        def ready(self):
            return dict(engine_uid='fixture')

        def run_prepared(self, rows, **kwargs):
            self.calls += 1
            self.last_run_report = dict(status='failed' if scenario == 'failed_pipeline' else 'passed',
                error_type='UnexpectedStageReceipt' if scenario == 'failed_pipeline' else None)
            return [dict(expected, status='succeeded', prompt_token_ids_json='[1]',
                output_token_ids_json='[2]', text='ok', finish_reason='stop',
                prompt_tokens=1, completion_tokens=1)]

        def close(self, **kwargs):
            decode = dict(status='observed', transfers=3, bytes=128, failed_transfers=0,
                failed_notifications=0, expired_requests=int(scenario == 'expired_handoff'))
            prefill = dict(status='no_transfer_update', transfers=0, bytes=0, failed_transfers=0,
                failed_notifications=0, expired_requests=0)
            if scenario == 'missing_transfer_observation':
                decode = dict(status='unavailable', error='unsupported_native_nixl_stats')
            if scenario == 'prefill_expired_handoff':
                prefill.update(status='observed', expired_requests=1)
            return dict(status='closed', stages={name:dict(status='closed',
                engine_api=dict(native_kv_transfer_final=metrics))
                for name, metrics in (('prefill', prefill), ('decode', decode))})

    directory = output / scenario
    caught = None
    with patch.object(replay.EngineSpec, 'validate_driver_environment'), \
            patch.object(replay, 'PipelinedPrefillDecodeProcess', Owner), \
            patch.object(replay.StageEngineCleanup, 'stop', return_value=dict(process_exit_confirmed=True)):
        try:
            replay.run(config, directory)
        except RuntimeError as error:
            caught = str(error)
    report = json.loads((directory/'report.json').read_text())
    valid = scenario == 'valid_no_prefill_transfer_update'
    assert report['status'] == ('passed' if valid else 'failed')
    assert (caught is None) is valid
    assert (directory/'first-results.json').exists()
    if scenario == 'failed_pipeline':
        assert len(report['rounds']) == 1
        assert (directory/'failed-results-0.json').exists()
    observations.append(dict(scenario=scenario, worker_status=report['status'],
        rounds_executed=len(report['rounds']), raised=caught,
        native_transfer_observed=report.get('native_transfer_observed'),
        first_receipt_retained=True))
print(json.dumps(redact_json_values(dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    model_calls=0, gpu=False, observations=observations)), indent=2))
