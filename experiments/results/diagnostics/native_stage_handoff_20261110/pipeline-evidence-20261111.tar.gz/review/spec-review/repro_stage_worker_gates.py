"""CPU fixture: successful outputs must not override failed pipeline/transfer evidence."""
import json
from pathlib import Path
from unittest.mock import patch

from src.experiments import native_stage_pipeline as replay
from src.infrastructure.redact import redact_json_values
from src.semantic_methods.lotus.records import identity


row = dict(identity('fixture', 'a', 0), messages_json=json.dumps([dict(role='user', content='hello')]))
expected = replay._prepared([row])[0][0]
config = dict(engine=dict(model_path='/unused', model_python='/model/python', driver_python='/driver/python'),
    generation=dict(max_tokens=1), rows=[row], arm='pipeline', warmup_rounds=1, rounds=2,
    reserved_physical_calls=6, worker_timeout_s=10, startup_timeout_s=1, close_timeout_s=1,
    prefill=dict(cuda_visible_devices='0', side_channel_port=15600),
    decode=dict(cuda_visible_devices='0', side_channel_port=15601),
    limits=dict(max_inflight=2), batch_size=1, prefill_window=1)
root = Path(__file__).parent / 'stage-worker-gate-evidence'
root.mkdir(exist_ok=True)
observations = []
for scenario in ('failed_pipeline', 'missing_transfer_observation', 'expired_handoff'):
    class Owner:
        def __init__(self, *args, **kwargs):
            self.calls = 0
            self.last_run_report = None

        def ready(self):
            return dict(engine_uid='fixture')

        def run_prepared(self, rows, **kwargs):
            self.calls += 1
            self.last_run_report = dict(status='failed' if scenario == 'failed_pipeline' else 'passed',
                error_type='UnexpectedStageReceipt' if scenario == 'failed_pipeline' else None)
            return [dict(expected, status='succeeded', prompt_token_ids_json='[1]',
                output_token_ids_json='[2]', text='ok', finish_reason='stop',
                prompt_tokens=1, completion_tokens=1)]

        def close(self, **kwargs):
            metrics = dict(status='observed', transfers=3, bytes=128, failed_transfers=0,
                failed_notifications=0, expired_requests=int(scenario == 'expired_handoff'))
            if scenario == 'missing_transfer_observation':
                metrics = dict(status='unavailable', error='unsupported_native_nixl_stats')
            return dict(status='closed', stages={name:dict(status='closed',
                engine_api=dict(native_kv_transfer_final=metrics)) for name in ('prefill', 'decode')})

    with patch.object(replay.EngineSpec, 'validate_driver_environment'), \
            patch.object(replay, 'PipelinedPrefillDecodeProcess', Owner), \
            patch.object(replay.StageEngineCleanup, 'stop', return_value=dict(process_exit_confirmed=True)):
        report = replay.run(config, root / scenario)
    observations.append(dict(scenario=scenario, worker_status=report['status'],
        rounds_executed=len(report['rounds']),
        owner_statuses=[item['pipeline']['status'] for item in report['rounds']],
        native_transfer=report['close']['stages']['decode']['engine_api']['native_kv_transfer_final']))
print(json.dumps(redact_json_values(dict(source='3add1cbc3', model_calls=0, gpu=False,
    scope='worker qualification control flow with fixture receipts, no transfer or performance evidence',
    observations=observations)), indent=2))
