from concurrent.futures import ThreadPoolExecutor
import json,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).parent/"e564703a1b/code"))
from src.serving.backends import pipelined_prefill_decode as pipeline
from src.serving.backends.vllm_protocol import AsyncEngineLimits,EngineSpec,GenerationSpec
from tests.serving.test_pipelined_prefill_decode import CPUProcess
from tests.serving.test_async_engine_process import row
from src.infrastructure.redact import redact_json_values
runs=[]
for repeat in range(5):
 with tempfile.TemporaryDirectory(prefix="stage-command-wakeup-") as directory, \
      patch.object(EngineSpec,"validate_driver_environment",return_value={}), \
      patch.object(pipeline,"AsyncEngineProcess",CPUProcess):
  owner=pipeline.PipelinedPrefillDecodeProcess(
    EngineSpec("/tmp/CPU-phase-model",sys.executable,"/tmp/CPU-driver",max_model_len=2048),
    GenerationSpec(max_tokens=12,stop=()),directory,time.monotonic()+5,2,
    prefill=pipeline.NixlPlacement("0",15600),decode=pipeline.NixlPlacement("1",15601),
    limits=AsyncEngineLimits(max_inflight=4,command_slots=1,item_input_bytes=4096,item_result_bytes=8192),
    batch_size=1,prefill_window=4,close_timeout_s=2)
  try:
   with ThreadPoolExecutor(max_workers=1) as executor:
    future=executor.submit(owner.run_prepared,[row(i,"hold") for i in range(4)])
    deadline=time.monotonic()+1
    while owner.stages["prefill"].snapshot()["accepted_requests"]<1:
     if time.monotonic()>=deadline:raise TimeoutError("CPU fixture never accepted first prefill")
     owner.stages["prefill"].wait(.005)
    time.sleep(.1)
    snapshot=owner.stages["prefill"].snapshot()
    runs.append(dict(repeat=repeat,logical_capacity=4,prefill_window=4,batch_size=1,command_slots=1,
                     before_cancel=snapshot,coordinator_pending=not future.done()))
    owner.cancel()
    results=future.result(timeout=4)
    runs[-1].update(submitted=owner.last_run_report["submitted_logical_requests"],
                    close_status=owner.last_close_report["status"],
                    children_exited=all(stage.process.poll() is not None for stage in owner.stages.values()))
  finally:
   owner.cancel();owner.close(timeout=2)
report=dict(source="e564703a1b7f89f1196d4c48be3624980b94213b",case="command_queue_capacity_relief_does_not_wake_pipeline",model_calls=0,gpu=False,runs=runs)
Path(__file__).with_suffix(".json").write_text(json.dumps(redact_json_values(report),indent=2)+"\n")
print(json.dumps([{k:v for k,v in run.items() if k!="before_cancel"}|{"accepted":run["before_cancel"]["accepted_requests"],"queued_commands":run["before_cancel"]["queued_commands"],"ready_results":run["before_cancel"]["ready_results"]} for run in runs],indent=2))
