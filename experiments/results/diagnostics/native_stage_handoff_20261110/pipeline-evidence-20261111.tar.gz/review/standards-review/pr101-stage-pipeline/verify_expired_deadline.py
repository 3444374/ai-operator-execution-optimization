import json, sys, tempfile, time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).parent/"fix-snapshot/code"))
from src.serving.backends import pipelined_prefill_decode as pipeline
from src.serving.backends.vllm_protocol import AsyncEngineLimits, EngineSpec, GenerationSpec
from tests.serving.test_pipelined_prefill_decode import CPUProcess
from src.infrastructure.redact import redact_json_values

report=dict(source="afab13620df41a194363215b17dd131b2dcaa979+working-tree-fixes",case="already_expired_overall_deadline",model_calls=0,gpu=False)
owner=None
with tempfile.TemporaryDirectory(prefix="stage-expired-deadline-") as directory, \
        patch.object(EngineSpec,"validate_driver_environment",return_value={}), \
        patch.object(pipeline,"AsyncEngineProcess",CPUProcess):
    deadline=time.monotonic()-1
    started=time.monotonic()
    try:
        owner=pipeline.PipelinedPrefillDecodeProcess(
            EngineSpec("/tmp/CPU-phase-model",sys.executable,"/tmp/CPU-driver",max_model_len=2048),
            GenerationSpec(max_tokens=12,stop=()),directory,deadline,5,
            prefill=pipeline.NixlPlacement("0",15600),decode=pipeline.NixlPlacement("1",15601),
            limits=AsyncEngineLimits(max_inflight=2,item_input_bytes=4096,item_result_bytes=8192),
            batch_size=2,prefill_window=2,close_timeout_s=3)
        report.update(outcome="constructor_returned_ready",elapsed_s=time.monotonic()-started,
                      stages_started=len(owner.stages),
                      live_stages_after_expired_deadline={name:stage.process.poll() is None for name,stage in owner.stages.items()})
    except Exception as error:
        report.update(outcome=type(error).__name__,elapsed_s=time.monotonic()-started)
        if not isinstance(error, TimeoutError):
            raise
        report["stages_started"] = len(list(Path(directory).glob("engine-*.json")))
    finally:
        if owner is not None:
            report["close"]=owner.close(timeout=3)
            report["children_exited"]={name:stage.process.poll() is not None for name,stage in owner.stages.items()}
Path(__file__).with_suffix(".json").write_text(json.dumps(redact_json_values(report),indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k!="close"},indent=2))
