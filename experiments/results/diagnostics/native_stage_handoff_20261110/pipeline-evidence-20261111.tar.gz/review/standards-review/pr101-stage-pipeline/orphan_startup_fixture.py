import asyncio,json,os,subprocess,sys,time
from pathlib import Path
import psutil
from src.serving.backends.async_engine_worker import serve

class Engine:
    def __init__(self,spec,generation,*,limits):
        child=subprocess.Popen([sys.executable,"-c","import time; time.sleep(30)"],
            stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,close_fds=True)
        identity=dict(parent_pid=os.getpid(),parent_created=psutil.Process().create_time(),
            child_pid=child.pid,child_created=psutil.Process(child.pid).create_time(),child_pgid=os.getpgid(child.pid))
        Path(os.environ["SEML_TEST_CHILD_ID"]).write_text(json.dumps(identity))
        # Simulate an EngineCore already forked while model initialization has not returned READY.
        time.sleep(30)

if __name__=="__main__":
    asyncio.run(serve(*map(int,sys.argv[1:]),engine_factory=Engine))
