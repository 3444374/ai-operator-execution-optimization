import json,os,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch
import psutil
root=Path(__file__).parent
sys.path.insert(0,str(root/"cleanup-fix-snapshot/code"))
from src.serving.backends import pipelined_prefill_decode as pipeline
from src.serving.backends.async_engine_process import AsyncEngineProcess
from src.serving.backends.stage_process_cleanup import StageEngineCleanup
from src.serving.backends.vllm_protocol import AsyncEngineLimits,EngineSpec,GenerationSpec
from src.infrastructure.owned_processes import _live
from src.infrastructure.redact import redact_json_values

class CPUProcess(AsyncEngineProcess):
    @staticmethod
    def _command(spec,descriptors):
        return [sys.executable,str(root/"orphan_startup_fixture.py"),*map(str,descriptors)]

control=Path(tempfile.mkdtemp(prefix="orphan-startup-",dir=root))
marker=control/"spawned-child.json"
report=dict(source_snapshot="cleanup-fix-snapshot.json",case="startup_timeout_with_spawned_enginecore_fixture",model_calls=0,gpu=False,control_directory=str(control))
owner=None
identity=None
started=time.monotonic()
try:
    with patch.object(EngineSpec,"validate_driver_environment",return_value={}), \
         patch.object(pipeline,"AsyncEngineProcess",CPUProcess), \
         patch.dict(os.environ,SEML_TEST_CHILD_ID=str(marker)):
        try:
            owner=pipeline.PipelinedPrefillDecodeProcess(
                EngineSpec("/tmp/CPU-phase-model",sys.executable,"/tmp/CPU-driver",max_model_len=2048),
                GenerationSpec(max_tokens=12,stop=()),control,time.monotonic()+.5,5,
                prefill=pipeline.NixlPlacement("0",15600),decode=pipeline.NixlPlacement("1",15601),
                limits=AsyncEngineLimits(max_inflight=2,item_input_bytes=4096,item_result_bytes=8192),
                batch_size=2,prefill_window=2,close_timeout_s=2)
            report["constructor_outcome"]="unexpected_ready"
        except Exception as error:
            report["constructor_outcome"]=type(error).__name__
            report["constructor_elapsed_s"]=time.monotonic()-started
            report["direct_child_close"]=getattr(error,"async_close_report",None)
            report["pipeline_close"]=getattr(error,"pipeline_close_report",None)
    identity=json.loads(marker.read_text())
    record=json.loads((control/"engine-prefill.json").read_text())
    automatic=json.loads((control/"driver-cleanup.json").read_text())
    child={(identity["child_pid"],identity["child_created"])}
    report.update(fixture_identity=identity,registered_report=record,automatic_cleanup=automatic,
                  descendant_alive_after_automatic_cleanup=bool(_live(child)))
    outer_started=time.monotonic()
    report["outer_cleanup"]=StageEngineCleanup(control).stop(grace_s=.4,started=True)
    report["outer_cleanup_elapsed_s"]=time.monotonic()-outer_started
    assert report["pipeline_close"]["status"]=="unknown"
    assert report["pipeline_close"]["registered_process_cleanup"]["process_exit_confirmed"] is True
    assert not report["descendant_alive_after_automatic_cleanup"]
    assert report["outer_cleanup_elapsed_s"] < .3
    # Apply the existing birth-matched group observer/stopper to this exact owned fixture.
    recovered=StageEngineCleanup._stop_registered(record)
    report.update(existing_registered_fallback=recovered,
                  descendant_alive_after_existing_fallback=bool(_live(child)))
finally:
    if owner is not None:
        owner.close(timeout=2)
    if identity is None and marker.exists():identity=json.loads(marker.read_text())
    if identity is not None:
        live=_live({(identity["child_pid"],identity["child_created"])})
        for process in live:process.kill()
        if live:psutil.wait_procs(live,timeout=1)
        report["fixture_cleanup_confirmed"]=not _live({(identity["child_pid"],identity["child_created"])})
    (root/"verify_orphan_startup_cleanup.json").write_text(json.dumps(redact_json_values(report),indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k in ("constructor_outcome","constructor_elapsed_s","descendant_alive_after_automatic_cleanup","descendant_alive_after_existing_fallback","fixture_cleanup_confirmed","outer_cleanup_elapsed_s")},indent=2))
