from pathlib import Path
import os,sys,json,subprocess,time,math,statistics,shutil,hashlib
ROOT=Path('<data-root>/semloom-stage-cost-diagnosis-20261112');SOURCE=Path('<data-root>/semloom-stage-revalidation-20261111/source')
sys.path.insert(0,str(SOURCE/'code'))
CONTROLLER_BYTES=Path(__file__).read_bytes()
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.infrastructure.private_artifacts import write_private_json,content_digest
from src.infrastructure.redact import redact_json_values,redact_text
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.lotus_records_supervisor import supervise
from src.observability.process_resources.supervised import ResourceMonitor
from src.semantic_methods.lotus.records import identity

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True).strip()
base=json.loads(Path('<data-root>/semloom-execution-candidates-20261110/base-original.json').read_text())
driver,model=base['engine']['driver_python'],base['engine']['model_python']
env_text=Path('<data-root>/semloom-native-stage-handoff-20261110/runtime.env').read_text()
for key,value in [('PROJECT_ROOT',str(SOURCE)),('ARTIFACT_ROOT',str(ROOT))]:
 env_text='\n'.join(key+'='+value if line.removeprefix('export ').startswith(key+'=') else line for line in env_text.splitlines())+'\n'
env_path=ROOT/'runtime.env';env_path.write_text(env_text);env_path.chmod(0o600)
env=dict(os.environ,**base['environment']);env.update(PYTHONPATH=str(SOURCE/'code'),AI_OPERATOR_ENV_FILE=str(env_path),OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8',TOKENIZERS_PARALLELISM='false',CUDA_VISIBLE_DEVICES='0',VLLM_LOGGING_LEVEL='INFO',LITELLM_LOCAL_MODEL_COST_MAP='True',UCX_SEG_SIZE='65536')
os.environ.clear();os.environ.update(env);os.chdir(SOURCE)
slots=sorted(os.sched_getaffinity(0))[:8];assert len(slots)==8;os.sched_setaffinity(0,set(slots))
budget=AttemptBudget('native-stage-cost-diagnosis-20261112',20000)
ledger_path=ROOT/'budget.sqlite'
ledger=CellBudgetLedger(ledger_path,budget) if ledger_path.exists() else CellBudgetLedger.create(ledger_path,budget,deadline_utc=time.time()+2700)

def gpu():
 return dict(gpu=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True),compute=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],text=True))

def workload(name):
 if name=='q8':
  packet=json.loads(Path('<data-root>/semloom-execution-candidates-20261110/original.requests.json').read_text())
  requests=packet['requests'];generation=requests[0]['generation']
  assert all(row['generation']==generation for row in requests)
  return [row['row'] for row in requests],generation
 if name=='narrow':
  text=['Return only the word OK. Here is irrelevant data:\n'+'alpha '*800+str(i)for i in range(2)]
 elif name=='smoke':
  text=['What is two plus three?','Name the capital of France.','Write the next number: 1, 2, 3.','Give the opposite of cold.']
 else:
  text=['Copy the following numbered sequence exactly. Do not add an explanation.\n'+ ' '.join(str((i+j)%100) for j in range(80)) for i in range(64)]
 rows=[]
 for i,prompt in enumerate(text):
  messages=[dict(role='system',content='Follow the user instruction.'),dict(role='user',content=prompt)]
  rows.append(dict(identity('stage-'+name,'row-'+str(i),i),messages_json=json.dumps(messages)))
 return rows,dict(max_tokens=16 if name in ('smoke','narrow') else 128,temperature=0,seed=0,stop=[])

def run_cell(run_id,name,arm,capacity,rounds,observed=False,prefill_window=None,batch_size=None):
 cell=ROOT/run_id;cell.mkdir(mode=0o700)
 before=gpu();write_private_json(cell/'gpu-before.json',before)
 if before['compute'].strip():raise RuntimeError('unrelated GPU work prevents exclusive run')
 rows,generation=workload(name);calls=len(rows)*(rounds+1)*(2 if arm=='pipeline' else 1)
 reservation=ledger.reserve_unit(run_id,calls);claim=ledger.claim_unit(run_id);claim.bind_execution()
 remaining=ledger.snapshot()['deadline_utc']-time.time()
 if remaining<180:raise RuntimeError('insufficient remaining experiment wall allowance')
 config=dict(arm='colocated' if arm=='async' else arm,diagnostic_arm=arm,profile=observed,nvtx_library=str(ROOT/'nvtx_marker.so'),rows=rows,generation=generation,warmup_rounds=1,rounds=rounds,reserved_physical_calls=calls,
  engine=dict(model_path='<data-root>/models/Qwen2.5-1.5B-Instruct',model_python=model,driver_python=driver,dtype='bfloat16',max_model_len=16384,max_num_seqs=capacity,max_num_batched_tokens=4096 if arm!='pipeline' else 2048,gpu_memory_utilization=.6 if arm!='pipeline' else .3,seed=0,enable_prefix_caching=True,enforce_eager=True),
  worker_timeout_s=min(1200,remaining-90),startup_timeout_s=240,close_timeout_s=30,
  prefill=dict(cuda_visible_devices='0',side_channel_port=15700),decode=dict(cuda_visible_devices='0',side_channel_port=15701),
  limits=dict(max_inflight=capacity,item_input_bytes=256*1024,item_result_bytes=256*1024),
  batch_size=capacity//2 if batch_size is None else batch_size,
  prefill_window=capacity//2 if prefill_window is None else prefill_window)
 if name=='narrow':
  config['limits'].update(input_bytes=8192,item_input_bytes=8192)
 write_private_json(cell/'config.json',config)
 write_private_json(cell/'source.json',dict(head=head,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=SOURCE,text=True).strip(),controller_sha256=hashlib.sha256(CONTROLLER_BYTES).hexdigest(),worker_sha256=hashlib.sha256((ROOT/'diagnosis_worker.py').read_bytes()).hexdigest(),config_digest=content_digest(config),input_digest=content_digest(rows),cpu_affinity=slots,transport_environment={'UCX_SEG_SIZE':os.environ['UCX_SEG_SIZE']},precharged_physical_calls=calls,budget=ledger.snapshot()))
 samples=[];previous=[0.0]
 resources=ResourceMonitor(dict(cpu_affinity_slots=slots,max_sampled_owned_rss_bytes=32*1024**3,max_owned_shm_bytes=8*1024**3),sample_seconds=.5)
 def monitor(owned):
  resources(owned)
  if time.monotonic()-previous[0]>=1:
   samples.append(dict(monotonic=time.monotonic(),**gpu()));previous[0]=time.monotonic()
   if shutil.disk_usage(ROOT).free<10*1024**3:raise RuntimeError('disk reserve reached')
   if sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file() and 'source' not in p.parts)>8*1024**3:raise RuntimeError('artifact size limit')
 print('START',run_id,'calls',calls,flush=True)
 command=[driver,'-B',str(ROOT/'diagnosis_worker.py')]
 if observed:
  command=['nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','--cuda-memory-usage=false','--trace-fork-before-exec=true','--wait=all','--force-overwrite=false','--output='+str(cell/'trace'),*command]
 try:
  sup=supervise([*command,'--config',str(cell/'config.json'),'--output',str(cell/'worker')],cell/'supervision',timeout_s=min(1290,remaining-5),grace_s=60,natural_exit_grace_s=2,monitor=monitor)
 finally:
  write_private_json(cell/'resources.json',redact_json_values(resources.finish()))
  write_private_json(cell/'gpu-samples.json',redact_json_values(samples))
  after=gpu();after['empty']=not after['compute'].strip();write_private_json(cell/'gpu-after.json',after)
 report=json.loads((cell/'worker/report.json').read_text())
 resource_report=json.loads((cell/'resources.json').read_text())
 if name=='q8':
  captured=json.loads(Path('<data-root>/semloom-execution-candidates-20261110/original.requests.json').read_text())['requests']
  actual=json.loads((cell/'worker/first-results.json').read_text())
  same=all(json.loads(a['prompt_token_ids_json'])==b['token_ids'] for a,b in zip(actual,captured,strict=True))
  write_private_json(cell/'captured-prompt-parity.json',dict(complete=same,requests=len(actual)))
  if not same:raise RuntimeError('native prompt tokens differ from original Q8 capture')
 result=dict(run_id=run_id,status=report['status'],error=report.get('error'),measured_s=report.get('measured_s'),digest=report.get('result_sha256'),resources=resource_report['passed'],gpu_empty=after['empty'],worker_exit=sup['worker_exit'])
 print(json.dumps(result),flush=True)
 if report['status']!='passed' or not resource_report['passed'] or not after['empty'] or sup['worker_exit']!=0:raise RuntimeError('cell did not pass all gates')
 return report

with acquire_host_runner_lease(Path('<data-root>/experiment-artifacts'),repository_commit=head):
 a=run_cell('segment01-q8-pipeline','q8','pipeline',128,6,prefill_window=64,batch_size=64)
 expected=json.loads((ROOT/'probe01-q8-colocated/worker/report.json').read_text())['result_sha256']
 assert a['result_sha256']==expected
 b=run_cell('segment-trace01-q8-pipeline','q8','pipeline',128,3,observed=True,prefill_window=64,batch_size=64)
 assert b['result_sha256']==expected
 print('DONE segment',json.dumps(ledger.snapshot()),flush=True)
