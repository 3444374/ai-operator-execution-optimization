from pathlib import Path
import hashlib,json,os,platform,sqlite3,subprocess,sys,time
root=Path('<data-root>/semloom-stage-cost-diagnosis-20261112');source=Path('<data-root>/semloom-stage-revalidation-20261111/source')
sys.path.insert(0,str(source/'code'))
from src.infrastructure.private_artifacts import write_private_json
from src.infrastructure.redact import redact_json_values

def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024**2),b''):result.update(block)
    return dict(file=path.name,bytes=path.stat().st_size,sha256=result.hexdigest(),mtime_ns=path.stat().st_mtime_ns)

model=Path('<data-root>/models/Qwen2.5-1.5B-Instruct')
weights=[digest(path) for path in sorted(model.glob('*.safetensors'))]
metadata=[digest(path)for path in sorted(model.glob('*.json'))]
assert weights
snapshots=[dict(file=str(p.relative_to(model)),metadata=p.read_text().splitlines())for p in sorted((model/'.cache/huggingface/download').glob('*.metadata'))]
python='<data-root>/venvs/vllm-4090/bin/python'
probe="""import importlib.metadata as m,json,sys
packages={}
for name in ['vllm','torch','nixl','transformers','flashinfer-python']:
 try:packages[name]=m.version(name)
 except m.PackageNotFoundError:packages[name]=None
print(json.dumps({'python':sys.version,'packages':packages}))
"""
packages=json.loads(subprocess.check_output([python,'-c',probe],text=True))
vllm=Path('<data-root>/venvs/vllm-4090/lib/python3.12/site-packages/vllm')
names=['distributed/kv_transfer/kv_connector/v1/nixl/base_worker.py','distributed/kv_transfer/kv_connector/v1/nixl/pull_worker.py','v1/engine/async_llm.py','v1/metrics/stats.py','v1/metrics/loggers.py','entrypoints/llm.py',
       'distributed/kv_transfer/kv_connector/v1/nixl/stats.py',
       'distributed/kv_transfer/kv_connector/v1/nixl/pull_scheduler.py',
       'v1/worker/gpu_worker.py','v1/worker/gpu/model_runner.py','v1/core/sched/scheduler.py']
native=[dict(digest(vllm/name),file='vllm/'+name,upstream_url='https://raw.githubusercontent.com/vllm-project/vllm/v0.25.1/vllm/'+name)for name in names]
compute=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],text=True)
transport_libraries=[digest(p) for pattern in ['nixl_cu13.libs/libucp-*','.nixl_cu13.mesonpy.libs/plugins/libplugin_UCX.so','nixl_cu13.libs/ucx/libuct_cuda.so.0.0.0'] for p in vllm.parent.glob(pattern)]
artifact_tools=[digest(root/name) for name in ['campaign.py','segment_campaign.py','diagnosis_worker.py','nvtx_marker.c','nvtx_marker.so','analyze_trace.py']]
inventory=dict(artifact_tools=artifact_tools,transport_libraries=transport_libraries,collected_epoch_s=time.time(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),
 source_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip(),
 source_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip(),
 compute_apps=compute,gpu_empty=not compute.strip(),
 gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,memory.used,driver_version','--format=csv,noheader,nounits'],text=True),
 lease_absent=not Path('<data-root>/experiment-artifacts/.host-runner-scope/.runner-lease.json').exists(),
 filesystem=subprocess.check_output(['df','-hT','/','<system-home>/autodl-tmp'],text=True),
 os=platform.system(),kernel=platform.release(),model_weight_files=weights,model_json_files=metadata,
 snapshot_download_metadata=snapshots,model_environment=packages,native_source_files=native)
old=json.loads(Path('<data-root>/semloom-stage-revalidation-20261111/final-inventory.json').read_text())
inventory['matches_previous_model_weights']=[(x['file'],x['sha256']) for x in weights]==[(x['file'],x['sha256']) for x in old['model_weight_files']]
inventory['matches_previous_native_files']=all(any(x['file']==y['file'] and x['sha256']==y['sha256'] for x in native) for y in old['native_source_files'])
write_private_json(root/'final-inventory.json',redact_json_values(inventory))
with sqlite3.connect(root/'budget.sqlite') as connection:
 row=connection.execute('SELECT schema,budget_id,limit_count,allocated,deadline FROM budget').fetchone()
 units=connection.execute('SELECT unit_id,first_attempt,requests,claimed FROM units ORDER BY first_attempt').fetchall()
budget=dict(zip(('schema','budget_id','limit','allocated_requests','deadline_utc'),row),
 units=[dict(zip(('unit_id','first_attempt','requests','claimed'),r))for r in units])
write_private_json(root/'budget-snapshot.json',budget)
print(json.dumps(dict(gpu_empty=inventory['gpu_empty'],lease_absent=inventory['lease_absent'],
 source_clean=inventory['source_clean'],source_head=inventory['source_head'],
 allocated_requests=budget['allocated_requests'],weight_bytes=sum(x['bytes']for x in weights),native_files=len(native))))
