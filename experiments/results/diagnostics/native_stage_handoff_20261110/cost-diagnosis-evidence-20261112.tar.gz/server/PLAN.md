# Native P/D cost attribution, 2026-11-12

Question: does physical KV copying explain the measured single-4090 P/D slowdown?
Scope: a bounded mechanism diagnostic on fixed native code 14c6c5e03b849947621b714949532c2a95728790,
not formal throughput qualification, a complete LOTUS query, or a new scheduling mechanism.

Hypotheses, ranked before probes:
1. KV handoff dominates: device copy and transfer-related waits should occupy most of the extra critical path.
   Nsight CUDA activity distinguishes actual copying from NIXL cumulative request durations.
2. Two native engine processes on one GPU dominate: GPU/host gaps or duplicated work remain after copying is accounted for.
3. Async ingress/IPC dominates: a single AsyncEngineProcess without NIXL should reproduce much of the slowdown.

Controls: unchanged native LLM.chat (colocated), a single native AsyncEngineProcess (diagnostic_reference),
unchanged PipelinedPrefillDecodeProcess. Single async submits the full request set in one bounded frame;
native vLLM owns physical batching. Original Q8 120 complete requests and COPY 64 complete requests,
original prompts/generation/seed/strict output digest; all physical P calls count, including warmup.
Same 8 CPU slots, one RTX4090, BF16, eager, context16384, prefix caching, total GPU fraction .6,
total batch-token budget4096; P/D .3/2048 each. C128/P64/B64 for Q8, C64/P64/B64 for COPY.
One warmup then Q8 six measured rounds and COPY three per session, three independent sessions per arm,
order co/async/pipe; pipe/async/co; async/co/pipe. These short sessions establish mechanism signals,
not a replacement for previous >=60s formal comparisons or new saturation qualification.
Nsight probes: Q8 co and pipeline, COPY pipeline, each one warmup + three measured rounds.
Only CUDA/NVTX, no CPU sampling, host NVTX round ranges; no forced device synchronization.
Trace timings reported separately from unprofiled and compared for observer perturbation.
All round receipts are written after the timer; startup, warmup, hashing, serialization and close remain separate.

Limits: fresh durable 20,000 physical-call ledger, 45-minute deadline, single host runner lease,
32 GiB summed owned RSS, 8 GiB SHM delta, 8 GiB artifacts, >=10 GiB free data disk.
No installs/model downloads, no external services. Preflight driver core/text/text-qwen15b,
model text/native-kv-transfer/text-qwen15b. Bind source/config/input/weight/native-package identities.
Stop comparison on strict output mismatch, capacity exceedance, unknown completion or unconfirmed cleanup;
retain failures without refund. Existing old ledgers/results are immutable.
No causal percentage from summing concurrent stage or NIXL times. Device memcpy activity may overlap kernels;
use unions and round windows, label missing transport visibility. Counterfactual controls remain diagnostic.

## Conditional follow-up, declared after CUDA trace and before execution

The trace showed 8176-byte and 32-byte paired H2D/D2H fragments and matching cuMemcpyAsync/cuStreamSynchronize counts.
Current bundled UCX is 1.21.0. Its official ucp_context.c defaults SEG_SIZE=8192.
Within the same original 20k-call/45-minute budget, test exactly one transport variable: UCX_SEG_SIZE=65536.
Keep P/D, prompt, generation, capacities, CPU/GPU and semantics fixed. One session warmup1+6 measured,
then one Nsight session warmup1+3 measured, total2640 physical calls. Hypothesis: if fragmentation contributes,
the large block reduces copy/synchronization counts at unchanged KV payload and improves wall time.
This is a temporary diagnostic environment only, not a production default or formal optimization qualification.
Both output/resource gates unchanged; remaining total deadline caps worker and external supervisor, no extra budget.
