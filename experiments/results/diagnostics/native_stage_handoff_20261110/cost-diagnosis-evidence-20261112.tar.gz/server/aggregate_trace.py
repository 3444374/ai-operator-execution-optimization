"""Recompute nonoverlapping activity unions from exported raw intervals."""
import argparse,collections,json
from pathlib import Path
from analyze_trace import duration_union

def aggregate(root):
    output=[]
    for p in sorted(root.glob('*/trace-intervals.json')):
        data=json.loads(p.read_text())
        for row in data['rounds']:
            if row['warmup']:continue
            gpu=row['gpu_intervals'];api=row['selected_cuda_api_intervals']
            def union(values):return duration_union([(v['start_ns'],v['end_ns']) for v in values])/1e9
            copy=[v for v in gpu if v['kind']=='memcpy'];kernels=[v for v in gpu if v['kind']=='kernel']
            result=dict(run_id=p.parent.name,round=row['round'],wall_s=row['wall_s'],kernel_union_s=union(kernels),
                memcpy_union_s=union(copy),gpu_union_s=union(gpu),
                memcpy_api_union_s=union([v for v in api if 'memcpy' in v['name'].lower()]),
                copy_and_sync_api_union_s=union([v for v in api if v['name'] in ('cuMemcpyAsync','cuStreamSynchronize')]),
                copy_api_count=sum(v['name']=='cuMemcpyAsync' for v in api),
                stream_sync_count=sum(v['name']=='cuStreamSynchronize' for v in api),
                copy_shapes=[dict(copy_kind=k,bytes=b,count=c) for (k,b),c in sorted(collections.Counter((v['copy_kind'],v['bytes']) for v in copy).items())])
            for k in ('kernel_union_s','memcpy_union_s','gpu_union_s','memcpy_api_union_s'):
                assert abs(result[k]-row[k])<1e-12,(p,k)
            output.append(result)
    return dict(schema='semloom.stage_cost_trace_summary.v1',unit='seconds; intervals overlap, do not add',rounds=output)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    d=aggregate(a.root);a.output.write_text(json.dumps(d,indent=2)+'\n');print('verified',len(d['rounds']),'measured trace rounds')
