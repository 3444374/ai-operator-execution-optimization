"""Recompute resident diagnostic durations from complete raw reports/receipts."""
import argparse, hashlib, json, statistics
from pathlib import Path

def describe(values):
    return dict(min=min(values),median=statistics.median(values),mean=statistics.mean(values),max=max(values))

def union(intervals):
    end=None;total=0
    for a,b in sorted(intervals):
        total+=max(0,b-max(a,end if end is not None else a));end=max(b,end if end is not None else b)
    return total

def summarize(root):
    cells=[]
    for path in sorted(root.glob('*/worker/report.json')):
        folder=path.parent.parent
        c=json.loads((folder/'config.json').read_text());r=json.loads(path.read_text())
        measured=[x['elapsed_s'] for x in r['rounds'] if not x['warmup']]
        if not measured:continue
        source=json.loads((folder/'source.json').read_text())
        item=dict(run_id=folder.name,arm=c['diagnostic_arm'],profile=c['profile'],rows=len(c['rows']),
            transport_environment=source.get('transport_environment',{}),
            workload='q8' if '-q8-' in folder.name else 'copy',status=r['status'],
            measured_s=measured,measured=describe(measured),startup_s=r['startup_s'],
            warmup_s=[x['elapsed_s'] for x in r['rounds'] if x['warmup']],
            output_sha256=r['result_sha256'],source=source,
            resources_passed=json.loads((folder/'resources.json').read_text())['passed'],
            gpu_empty=json.loads((folder/'gpu-after.json').read_text())['empty'],round_attribution=[])
        windows=json.loads((path.parent/'round-windows.json').read_text())
        for w in windows:
            n=w['round']
            if n<c['warmup_rounds']:continue
            rows=json.loads((path.parent/f'receipts-{n}.json').read_text())
            if c['diagnostic_arm']=='pipeline':
                stages={s:[row['stage_receipts'][s][0] for row in rows] for s in ('prefill','decode')}
                gaps=[d['model_start_monotonic']-p['model_end_monotonic'] for p,d in zip(stages['prefill'],stages['decode'])]
            else:stages={'single':rows};gaps=[]
            intervals={s:[(x['model_start_monotonic'],x['model_end_monotonic']) for x in rs] for s,rs in stages.items()}
            item['round_attribution'].append(dict(round=n,wall_s=w['end_monotonic']-w['start_monotonic'],
                stage_request_api_union_s={s:union(v) for s,v in intervals.items()},
                stage_request_api_span_s={s:max(b for a,b in v)-min(a for a,b in v) for s,v in intervals.items()},
                first_api_start_from_round_s={s:min(a for a,b in v)-w['start_monotonic'] for s,v in intervals.items()},
                last_api_end_from_round_s={s:max(b for a,b in v)-w['start_monotonic'] for s,v in intervals.items()},
                handoff_gap_s=describe(gaps) if gaps else None,
                cached_prompt_tokens={s:(sum(x['native_num_cached_tokens'] for x in rs)
                    if all(x.get('native_num_cached_tokens') is not None for x in rs) else None) for s,rs in stages.items()},
                actual_output_tokens={s:sum(x['completion_tokens'] for x in rs) for s,rs in stages.items()}))
        item['nixl_final']={s:v.get('engine_api',{}).get('native_kv_transfer_final') for s,v in r.get('close',{}).get('stages',{}).items()}
        cells.append(item)
    aggregate=[]
    for workload in ('q8','copy'):
        for arm in ('colocated','async','pipeline'):
            group=[x for x in cells if x['workload']==workload and x['arm']==arm and not x['profile'] and not x['transport_environment']]
            if group:
                means=[x['measured']['mean'] for x in group]
                aggregate.append(dict(workload=workload,arm=arm,sessions=len(group),session_mean_s=means,
                    median_session_mean_s=statistics.median(means)))
    return dict(schema='semloom.native_stage_cost_diagnosis.v1',scope='short mechanism diagnostic; stage intervals overlap; first warmup excluded',cells=cells,aggregate=aggregate)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    out=summarize(a.root);a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['aggregate']))
