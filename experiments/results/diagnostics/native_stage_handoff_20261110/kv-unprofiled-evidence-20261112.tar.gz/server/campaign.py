from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,sys,time
ROOT=Path('<data-root>/semloom-kv-unprofiled-20261112')
SOURCE=Path('<data-root>/semloom-stage-revalidation-20261111/source')
EXPECTED_HEAD='14c6c5e03b849947621b714949532c2a95728790'
START=time.time();DEADLINE=START+4500
sys.path.insert(0,str(SOURCE/'code'))
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.infrastructure.private_artifacts import write_private_json,content_digest
from src.infrastructure.redact import redact_json_values,redact_text
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.lotus_records_supervisor import supervise
from src.observability.process_resources.supervised import ResourceMonitor

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
assert head==EXPECTED_HEAD and not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True).strip()
base=json.loads(Path('<data-root>/semloom-execution-candidates-20261110/base-original.json').read_text())
driver,model=base['engine']['driver_python'],base['engine']['model_python']
text=Path('<data-root>/semloom-native-stage-handoff-20261110/runtime.env').read_text()
for key,value in [('PROJECT_ROOT',str(SOURCE)),('ARTIFACT_ROOT',str(ROOT))]:
 text='\n'.join(key+'='+value if line.removeprefix('export ').startswith(key+'=') else line for line in text.splitlines())+'\n'
(ROOT/'runtime.env').write_text(text);(ROOT/'runtime.env').chmod(0o600)
env=dict(os.environ,**base['environment'])
for key in ('UCX_SEG_SIZE','UCX_TCP_TX_SEG_SIZE','UCX_LOG_LEVEL','UCX_PROTO_INFO','VLLM_BATCH_INVARIANT'):env.pop(key,None)
env.update(PYTHONPATH=str(SOURCE/'code'),AI_OPERATOR_ENV_FILE=str(ROOT/'runtime.env'),OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8',TOKENIZERS_PARALLELISM='false',CUDA_VISIBLE_DEVICES='0',VLLM_LOGGING_LEVEL='INFO',LITELLM_LOCAL_MODEL_COST_MAP='True')
os.environ.clear();os.environ.update(env);os.chdir(SOURCE)
slots=sorted(os.sched_getaffinity(0))[:8];assert len(slots)==8;os.sched_setaffinity(0,set(slots))
packet=json.loads(Path('<data-root>/semloom-execution-candidates-20261110/original.requests.json').read_text())['requests']
rows=[x['row'] for x in packet];generation=packet[0]['generation'];assert len(rows)==120 and all(x['generation']==generation for x in packet)
expected=json.loads(Path('<data-root>/semloom-stage-cost-diagnosis-20261112/probe01-q8-colocated/worker/report.json').read_text())['result_sha256']
ledger=CellBudgetLedger.create(ROOT/'budget.sqlite',AttemptBudget('kv-unprofiled-20261112',1000000),deadline_utc=DEADLINE)
controller_sha=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()

def identity():
 old=json.loads(Path('<data-root>/semloom-kv-tcp-fragment-20261112/final-inventory.json').read_text())
 site=Path('<data-root>/venvs/vllm-4090/lib/python3.12/site-packages');checks=[]
 for row in old['model_weight_files']+old['model_json_files']:
  path=Path('<data-root>/models/Qwen2.5-1.5B-Instruct')/row['file'];value=sha(path)
  checks.append(dict(kind='model',file=row['file'],sha256=value,matches=value==row['sha256']))
 for row in old['native_source_files']:
  path=site/row['file'];value=sha(path);checks.append(dict(kind='native',file=row['file'],sha256=value,matches=value==row['sha256']))
 for pattern in ('nixl_cu13.libs/libucp-*','.nixl_cu13.mesonpy.libs/plugins/libplugin_UCX.so','nixl_cu13.libs/ucx/libuct_cuda.so.0.0.0'):
  paths=list(site.glob(pattern));assert len(paths)==1
  p=paths[0];value=sha(p);checks.append(dict(kind='transport',file=str(p.relative_to(site)),sha256=value,matches=any(x['file']==p.name and x['sha256']==value for x in old['transport_libraries'])))
 write_private_json(ROOT/'identity.json',dict(source_head=head,source_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=SOURCE,text=True).strip(),checks=checks,controller_sha256=controller_sha,input_sha256=content_digest(rows)))
 assert all(x['matches'] for x in checks)

def gpu():
 return dict(gpu=subprocess.check_output(['nvidia-smi','--query-gpu=index,name,memory.total,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True),compute=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],text=True))

def run_cell(run_id,variant,capacity,rounds,phase):
 cell=ROOT/run_id;cell.mkdir(mode=0o700)
 remaining=DEADLINE-time.time()
 if remaining<400:raise RuntimeError('insufficient campaign wall allowance for another fixed session')
 before=gpu();write_private_json(cell/'gpu-before.json',before)
 if before['compute'].strip():raise RuntimeError('GPU already occupied')
 arm='colocated' if variant=='colocated' else 'pipeline';calls=120*(rounds+1)*(1 if arm=='colocated' else 2)
 ledger.reserve_unit(run_id,calls);claim=ledger.claim_unit(run_id);claim.bind_execution()
 for key in ('UCX_SEG_SIZE','UCX_TCP_TX_SEG_SIZE'):os.environ.pop(key,None)
 if variant=='tcp64':os.environ.update(UCX_SEG_SIZE='65536',UCX_TCP_TX_SEG_SIZE='65536')
 config=dict(arm=arm,rows=rows,generation=generation,warmup_rounds=1,rounds=rounds,reserved_physical_calls=calls,
  engine=dict(model_path='<data-root>/models/Qwen2.5-1.5B-Instruct',model_python=model,driver_python=driver,dtype='bfloat16',max_model_len=16384,max_num_seqs=capacity,max_num_batched_tokens=4096 if arm=='colocated' else 2048,gpu_memory_utilization=.6 if arm=='colocated' else .3,seed=0,enable_prefix_caching=True,enforce_eager=True),
  worker_timeout_s=min(900,remaining-90),startup_timeout_s=240,close_timeout_s=30,
  prefill=dict(cuda_visible_devices='0',side_channel_port=15700),decode=dict(cuda_visible_devices='0',side_channel_port=15701),
  limits=dict(max_inflight=capacity,item_input_bytes=256*1024,item_result_bytes=256*1024),batch_size=64,prefill_window=64)
 write_private_json(cell/'config.json',config)
 write_private_json(cell/'source.json',dict(source_head=head,phase=phase,variant=variant,capacity=capacity,config_sha256=content_digest(config),input_sha256=content_digest(rows),controller_sha256=controller_sha,worker_sha256=sha(SOURCE/'code/src/experiments/native_stage_pipeline.py'),cpu_affinity=slots,environment={k:os.environ.get(k) for k in ('UCX_SEG_SIZE','UCX_TCP_TX_SEG_SIZE','UCX_LOG_LEVEL','UCX_PROTO_INFO','VLLM_BATCH_INVARIANT','VLLM_LOGGING_LEVEL')},profile=False,budget=ledger.snapshot()))
 samples=[];last=[0.0];resources=ResourceMonitor(dict(cpu_affinity_slots=slots,max_sampled_owned_rss_bytes=32*1024**3,max_owned_shm_bytes=8*1024**3),sample_seconds=.5)
 def monitor(owned):
  resources(owned);now=time.monotonic()
  if now-last[0]>=1:
   samples.append(dict(monotonic=now,**gpu()));last[0]=now
  if shutil.disk_usage(ROOT).free<10*1024**3:raise RuntimeError('data disk reserve reached')
 print('START',run_id,variant,capacity,rounds,calls,flush=True)
 started=time.monotonic()
 try:
  sup=supervise([driver,'-B','-m','src.experiments.native_stage_pipeline','--config',str(cell/'config.json'),'--output',str(cell/'worker')],cell/'supervision',timeout_s=min(990,remaining-5),grace_s=60,natural_exit_grace_s=2,monitor=monitor)
 finally:
  write_private_json(cell/'resources.json',redact_json_values(resources.finish()))
  write_private_json(cell/'gpu-samples.json',redact_json_values(samples))
  after=gpu();after['empty']=not after['compute'].strip();write_private_json(cell/'gpu-after.json',after)
 report=json.loads((cell/'worker/report.json').read_text());resource=json.loads((cell/'resources.json').read_text())
 actual=json.loads((cell/'worker/first-results.json').read_text());same=all(json.loads(a['prompt_token_ids_json'])==b['token_ids'] for a,b in zip(actual,packet,strict=True))
 write_private_json(cell/'captured-prompt-parity.json',dict(complete=same,requests=len(actual)))
 elapsed=[x['elapsed_s']for x in report['rounds']if not x['warmup']]
 result=dict(run_id=run_id,variant=variant,capacity=capacity,phase=phase,status=report['status'],mean_s=statistics.mean(elapsed) if elapsed else None,measured_s=sum(elapsed),startup_s=report.get('startup_s'),controller_cell_s=time.monotonic()-started,physical_calls=calls,strict_output=report.get('result_sha256')==expected,prompt_parity=same,resources=resource['passed'],gpu_empty=after['empty'],worker_exit=sup['worker_exit'],scale_chunk_mean_s=[statistics.mean(elapsed[i:i+64])for i in range(0,len(elapsed),64)])
 write_private_json(cell/'summary.json',result);print('DONE',json.dumps(result),flush=True)
 if report['status']!='passed' or not all(result[k]for k in ('strict_output','prompt_parity','resources','gpu_empty')) or sup['worker_exit']!=0:raise RuntimeError('cell failed strict output or lifecycle gate')
 if sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())>8*1024**3:raise RuntimeError('artifact size ceiling reached')
 return result

with acquire_host_runner_lease(Path('<data-root>/experiment-artifacts'),repository_commit=head):
 identity()
 for name,python,groups in [('driver',driver,'core,text,text-qwen15b'),('model',model,'text,native-kv-transfer,text-qwen15b')]:
  p=subprocess.run([python,'code/scripts/environment/manage_environment.py','check','--groups',groups,'--json-out',str(ROOT/('preflight-'+name+'.json'))],cwd=SOURCE,env=os.environ,capture_output=True,text=True,timeout=60)
  (ROOT/('preflight-'+name+'.log')).write_text(redact_text(p.stdout+p.stderr));print('PREFLIGHT',name,p.returncode,flush=True);assert p.returncode==0
 calibration=[]
 for variant,c in [('default',64),('tcp64',64),('tcp64',128),('default',128),('default',256),('tcp64',256)]:
  calibration.append(run_cell('cal-'+variant+'-c'+str(c),variant,c,192,'calibration'))
 best={v:min(x['mean_s']for x in calibration if x['variant']==v)for v in ('default','tcp64')}
 eligible=[c for c in (64,128,256)if all(next(x['mean_s']for x in calibration if x['variant']==v and x['capacity']==c)<=1.03*best[v]for v in best)]
 capacity=min(eligible)if eligible else 128
 frozen=dict(capacity=capacity,eligible_common_capacities=eligible,best_mean_s=best,calibration=calibration,choice='smallest common near-best measured point'if eligible else 'predeclared C128 diagnostic fallback; common saturation unqualified',saturation_global_optimum_claim=False,rounds=385,order=[['default','tcp64','colocated'],['tcp64','colocated','default'],['colocated','default','tcp64']])
 write_private_json(ROOT/'frozen-comparison.json',frozen);print('FROZEN',json.dumps({k:v for k,v in frozen.items()if k!='calibration'}),flush=True)
 results=[]
 for cycle,order in enumerate(frozen['order'],1):
  for variant in order:results.append(run_cell('repeat-'+str(cycle)+'-'+variant,variant,capacity,385,'comparison'))
 write_private_json(ROOT/'comparison.json',dict(frozen=frozen,results=results,budget=ledger.snapshot()))
 print('CAMPAIGN DONE',json.dumps(dict(allocated=ledger.snapshot()['allocated_requests'] if 'allocated_requests'in ledger.snapshot()else ledger.snapshot(),sessions=len(results))),flush=True)
write_private_json(ROOT/'closure.json',dict(completed_epoch=time.time(),controller_pid=os.getpid(),gpu_empty=not gpu()['compute'].strip(),lease_released=True))
