"""Summarize independent fixed-resource request sessions, preserving all rounds."""
import argparse,hashlib,json,statistics
from pathlib import Path

def analyze(root):
    cells=[]
    for folder in sorted(root.iterdir()):
        if not folder.is_dir() or not (folder/'summary.json').exists():continue
        summary=json.loads((folder/'summary.json').read_text())
        config=json.loads((folder/'config.json').read_text())
        source=json.loads((folder/'source.json').read_text())
        report=json.loads((folder/'worker/report.json').read_text())
        values=[r['elapsed_s']for r in report['rounds']if not r['warmup']]
        assert len(values)==config['rounds']
        assert abs(statistics.mean(values)-summary['mean_s'])<1e-12
        assert report['result_sha256']==report['rounds'][0]['result_sha256'] and all(r['result_sha256']==report['result_sha256']for r in report['rounds'])
        assert summary['physical_calls']==len(config['rows'])*(config['rounds']+config['warmup_rounds'])*(2 if config['arm']=='pipeline'else 1)
        native={}
        if config['arm']=='pipeline':
            for stage in ('prefill','decode'):
                part=report['close']['stages'][stage];engine=part['engine_api'];stats=engine['native_kv_transfer_final']
                native[stage]=stats
                assert part['status']=='closed' and part['process_exit_confirmed'] and engine['uncertain_requests']==0
                assert engine['native_scheduler_final']['finished_total']==len(config['rows'])*(config['rounds']+1)
                assert all(stats[k]==0 for k in ('failed_transfers','failed_notifications','expired_requests'))
            assert native['decode']['transfers']==len(config['rows'])*(config['rounds']+1)
        item=dict(summary,source=source,engine=config['engine'],warmup_s=[r['elapsed_s']for r in report['rounds']if r['warmup']],all_measured_s=values,
            minimum_measurement_duration_met=sum(values)>=60,requests_per_s=len(config['rows'])/statistics.mean(values),native_transfer=native,
            effective_capacity=report['ready'].get('stages',report['ready']),round_count=len(values),result_sha256=report['result_sha256'])
        cells.append(item)
    comparison=[x for x in cells if x['phase']=='comparison'];groups=[]
    for variant in ('default','tcp64','colocated'):
        group=sorted((x for x in comparison if x['variant']==variant),key=lambda x:x['run_id'])
        if not group:continue
        vals=[x['mean_s']for x in group]
        groups.append(dict(variant=variant,independent_sessions=len(group),session_mean_s=vals,median_session_mean_s=statistics.median(vals),min_session_mean_s=min(vals),max_session_mean_s=max(vals),stdev_session_mean_s=statistics.stdev(vals)if len(vals)>1 else None,all_normal_gates_passed=all(x['status']=='passed'and x['strict_output']and x['prompt_parity']and x['resources']and x['gpu_empty']and x['worker_exit']==0 for x in group),all_sessions_at_least60s=all(x['minimum_measurement_duration_met']for x in group)))
    paired=[]
    for cycle in (1,2,3):
        rows={x['variant']:x for x in comparison if x['run_id'].startswith('repeat-'+str(cycle)+'-')}
        if set(rows)=={'default','tcp64','colocated'}:
            a,b,c=(rows[k]['mean_s']for k in ('default','tcp64','colocated'))
            paired.append(dict(cycle=cycle,default_s=a,tcp64_s=b,colocated_s=c,tcp64_vs_default_reduction_fraction=1-b/a,tcp64_vs_colocated_ratio=b/c))
    frozen=json.loads((root/'frozen-comparison.json').read_text())if(root/'frozen-comparison.json').exists()else None
    return dict(schema='semloom.kv_unprofiled_comparison.v1',scope='Prepared-request replay of120originalQ8requests; independent sessions, not completeLOTUSquery or globaloptimality.',frozen=frozen,cells=cells,groups=groups,paired_cycles=paired,physical_calls_precharged=sum(x['physical_calls']for x in cells),incomplete=not(root/'comparison.json').exists())

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    d=analyze(a.root);a.output.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(groups=d['groups'],pairs=d['paired_cycles'],physical_calls=d['physical_calls_precharged'],incomplete=d['incomplete']),ensure_ascii=False))
