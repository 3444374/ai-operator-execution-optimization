# Bounded engineering model qualification

Fixed production source `a50351051de0d960736c46914f4c56bde2fa5111`. 8 passed units and 4 failed/unknown units; 99 confirmed calls plus 10 unconfirmed call records. Attempted-unit caps of 159 remain charged.

Core, Ray Data and Daft each executed a nonempty Map→Filter→Extract (5 calls) and a complete Extract→Map relation (4 calls). Original LOTUS messages, parsing, known usage, final relation and parent identities matched. Native arms retained their production schedulers and lifecycles.

Each passed unit independently confirmed process/GPU/shared-memory/RPC/lease cleanup. Failed or unknown units keep their original evidence and charges; any later physical resolution is separate. All twelve historical ledger hashes stayed unchanged. Resource observations are sampled, not a cgroup limit.

The shared batch limit remains164 calls and130 minutes:134 base allowance and25 repair allowance permanently reserved;5 repair calls remain unallocated. Failed/unknown work and unused reserved unit allowance are never refunded. No formal SemBench or performance result is claimed.

The original Ray generic cascade remains unknown after a caller CPU declaration defect. Its10 unconfirmed records and25 cap are retained. Subsequent exact-owned cleanup resolved physical resources only. A fresh repair requires separate reviewed unit evidence.

| Unit | Original status | Confirmed calls | Unconfirmed records | Permanent cap | Elapsed seconds |
|---|---|---:|---:|---:|---:|
| core-mfe | passed | 5 | 0 | 6 | 55.032 |
| core-em | passed | 4 | 0 | 4 | 56.679 |
| ray-mfe | passed | 5 | 0 | 6 | 81.039 |
| ray-em | passed | 4 | 0 | 4 | 136.890 |
| daft-mfe | passed | 5 | 0 | 6 | 70.506 |
| daft-em | passed | 4 | 0 | 4 | 119.519 |
| core-cascade | passed | 17 | 0 | 25 | 181.611 |
| ray-cascade | unknown | 0 | 10 | 25 | 556.232 |
| daft-cascade | qualification_failed | 17 | 0 | 25 | 169.652 |
| imlane-ef | qualification_failed | 4 | 0 | 4 | 180.554 |
| imlane-cascade | passed | 17 | 0 | 25 | 258.179 |
| ray-cascade-repair1 | qualification_failed | 17 | 0 | 25 | 163.173 |

Daft completed17 confirmed calls across all three native cascade stages. The private harness then called an unsupported redundant backend.close and failed. A separate zero-inference audit passed original LOTUS messages, parsing, decisions, statistics, known usage and retained native stage cleanup. The original failed status and25-call allocation remain.

The fresh Ray caller-CPU repair completed17 confirmed calls, then failed on the same unsupported redundant backend.close. A separate zero-inference audit passed retained original LOTUS semantics and usage. All three native row-close status fields remain unknown; graph, engine API and observed process-exit fields plus independent physical exit are reported separately. The original repair failure and25-call allocation remain.

The public IMLane Extract→Filter CLI completed2 Extract and2 Filter calls. Extract produced CLOSED/OPEN; the original duplicate-index relation assignment yielded OPEN/OPEN. Both actual Filter replies were False. Independent zero-inference replay matched messages, generated-field consumption, parent IDs, generation, usage, parser and the exact typed empty result, including float64/uint64 and the named int64 index. The all-kept sentinel expected2 rows and got0; its failure remains.

Final independent physical/accounting checks passed at4480.615s within the original7800s window: GPU1MiB, no compute processes, no shared memory, no active RPC endpoints and no leases. All864 observed process identities were absent. All13 ledger hashes and absence of WAL/SHM sidecars were verified after archive download; the twelve historical ledgers are unchanged.

Complete private evidence archive: SHA256 `9eaa7bf7c32c298ecc4f9e7bb8cc3360281f1d288add1825c44fc2f22c8da4c5`, 6166755 bytes, 1535 regular members. Every member SHA256 was verified after download. No credentials, environment-file contents or model-weight payloads were included.
