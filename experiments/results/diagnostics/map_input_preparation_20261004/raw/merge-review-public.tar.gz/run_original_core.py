import importlib.util, sys, unittest
import src.scheduling.core.session
name='src.scheduling.core.session'
spec=importlib.util.spec_from_file_location(name,sys.argv[1])
module=importlib.util.module_from_spec(spec)
sys.modules[name]=module
spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromNames([
 'tests.scheduling.test_input_preparation.InputPreparationTests.test_cancel_notification_precedes_retained_input_retries',
 'tests.scheduling.test_input_preparation.InputPreparationTests.test_job_cancel_notifies_later_flow_before_earlier_input_retries',
 'tests.scheduling.test_input_preparation.InputPreparationTests.test_local_reap_reaches_later_input_when_earlier_release_is_unknown',
 'tests.scheduling.test_input_preparation.InputPreparationTests.test_retained_input_in_one_flow_does_not_hide_later_releasable_flow',
 'tests.execution_provider.test_map_preparation.MapPreparationCompositionTests.test_core_cancel_during_next_preparation_suppresses_guarded_rpc'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
