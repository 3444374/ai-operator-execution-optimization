"""One-shot receiver: own the existing host lease before accepting source bytes."""

import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import uuid
from unittest.mock import patch


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def own_lease_present(lease):
    return lease.path.exists() and json.loads(lease.path.read_text())["owner_token"] == lease.owner.owner_token


def main():
    candidate, archive_sha, lease_source_sha = sys.argv[1:]
    data = Path("<server-workspace>")
    project, artifacts = data / "ai-operator", data / "experiment-artifacts"
    lease_source = project / "code/src/infrastructure/runner_lease.py"
    if hashlib.sha256(lease_source.read_bytes()).hexdigest() != lease_source_sha:
        raise RuntimeError("deployed lease helper differs from the reviewed candidate")
    support = load_module("image_sdk_receive_lease", lease_source)
    try:
        lease = support.acquire_runner_lease(
            artifacts / support.HOST_SCOPE_DIR_NAME,
            config_fingerprint=support.HOST_SCOPE_FINGERPRINT,
            repository_commit=candidate, recover_stale=False,
        )
    except RuntimeError:
        print(json.dumps({"status": "shared_lease_unavailable", "payload_received": False}), flush=True)
        return 75
    entered_runner, preflight_child_unknown = False, False
    phase = "receive_payload"
    run_root = artifacts / ("image-sdk-" + candidate[:8] + "-" + uuid.uuid4().hex[:8])
    ray_root = data / ("is" + uuid.uuid4().hex[:8])
    try:
        run_root.mkdir()
        print(json.dumps({"status": "lease_acquired_ready_for_payload", "owner_pid": os.getpid(),
                          "candidate": candidate}), flush=True)
        raw = sys.stdin.buffer.read()
        if hashlib.sha256(raw).hexdigest() != archive_sha:
            raise ValueError("received archive SHA mismatch")
        (run_root / "source-bundle.tar.gz").write_bytes(raw)
        prefix = "fixed-" + candidate[:8]
        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
            for member in archive.getmembers():
                path = Path(member.name)
                if path.is_absolute() or ".." in path.parts or path.parts[0] != prefix:
                    raise ValueError("unsafe archive path")
                if not (member.isdir() or member.isfile()):
                    raise ValueError("archive links or special files are forbidden")
            archive.extractall(run_root, filter="data")
        bundle = run_root / prefix
        control = load_module("fixed_image_sdk_control", bundle / "run_image_sdk_checks.py")
        manifest = control.verify_bundle(bundle, candidate)
        if manifest["status"] != "fixed_candidate":
            raise ValueError("not the fixed candidate")
        redact = load_module("image_sdk_receive_redact", bundle / "code/src/baselines/common/redact.py")
        server_head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=project,
                                     text=True, capture_output=True, check=True).stdout.strip()
        env = dict(os.environ, CUDA_VISIBLE_DEVICES="", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                   OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
                   PYTHONDONTWRITEBYTECODE="1")
        phase, preflight_child_unknown = "environment_preflight", True
        preflight = subprocess.run([
            sys.executable, str(project / "code/scripts/environment/manage_environment.py"),
            "--env-file", str(data / "ai-operator-runtime.env"), "check", "--groups", "core,image",
        ], cwd=project, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        preflight_child_unknown = False
        safe_preflight = redact.redact_text(preflight.stdout)
        (run_root / "preflight.log").write_text(safe_preflight)
        if preflight.returncode != 0:
            print(json.dumps({"status": "preflight_failed", "exit_code": preflight.returncode,
                              "evidence_root": str(run_root), "sdk_tests_started": False}), flush=True)
            return 1
        (run_root / "preflight.json").write_text(json.dumps(json.loads(safe_preflight), indent=2) + "\n")
        sys.path.insert(0, str(bundle / "code"))
        import src.infrastructure.runner_lease as bundled_support

        def borrow_own_lease(path, **kwargs):
            nonlocal entered_runner, phase
            if Path(path).resolve() != lease.path.parent.resolve() or kwargs["repository_commit"] != candidate or not own_lease_present(lease):
                raise RuntimeError("receiver cannot transfer a different lease")
            entered_runner = True
            phase = "sdk_checks"
            return lease

        sys.argv = [str(bundle / "run_image_sdk_checks.py"), "--candidate", candidate,
                    "--artifact-root", str(artifacts), "--output", str(run_root / "checks"),
                    "--ray-temp-root", str(ray_root)]
        with patch.object(bundled_support, "acquire_runner_lease", side_effect=borrow_own_lease):
            result = control.main()
        after_head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=project,
                                    text=True, capture_output=True, check=True).stdout.strip()
        receipt = {"candidate": candidate, "archive_sha256": archive_sha,
                   "status": "checks_complete", "exit_code": result,
                   "evidence_root": str(run_root), "ray_temp_root": str(ray_root),
                   "own_lease_present": own_lease_present(lease),
                   "server_repository_before": server_head, "server_repository_after": after_head,
                   "server_repository_unchanged": server_head == after_head}
        (run_root / "receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
        print(json.dumps(receipt, sort_keys=True), flush=True)
        return result
    finally:
        # The reviewed entry owns release after SDK execution. It deliberately
        # retains this lease on uncertain child/Ray cleanup; never override that.
        if not entered_runner and not preflight_child_unknown:
            lease.release()
        if run_root.is_dir():
            (run_root / "receiver-scope.json").write_text(json.dumps({
                "candidate": candidate, "phase": phase, "receiver_pid": os.getpid(),
                "preflight_child_exit_unconfirmed": preflight_child_unknown,
                "sdk_entry_owns_cleanup": entered_runner,
                "own_lease_present": own_lease_present(lease),
            }, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())
