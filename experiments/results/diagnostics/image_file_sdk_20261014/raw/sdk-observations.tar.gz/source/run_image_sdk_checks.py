#!/usr/bin/env python3
"""Run exactly three existing CPU-only SDK checks from one exported commit."""

import argparse
import contextlib
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time
import unittest
from unittest.mock import patch


CHECKS = {
    "daft_reader": "tests.modalities.image.test_image_file_source.ImageFileSourceTest.test_real_daft_file_reader_without_model_or_ray",
    "ray_binary_reader": "tests.modalities.image.test_image_file_source.ImageFileSourceTest.test_real_ray_binary_reader_without_model_or_gpu",
    "ray_factory_exit": "tests.modalities.image.test_image_worker_startup.ImageWorkerStartupRealRayTest.test_real_ray_factory_failure_records_process_exit_before_client_shutdown",
}
FIXED_SDK = {"daft": "0.7.21", "ray": "2.56.1", "pyarrow": "24.0.0"}
OBJECT_STORE_BYTES = 128 * 1024 * 1024


def verify_bundle(root, candidate):
    manifest = json.loads((root / "candidate-manifest.json").read_text())
    if not re.fullmatch(r"[0-9a-f]{40}", candidate):
        raise ValueError("candidate must be the integration owner's full commit SHA")
    if manifest["repository_commit"] != candidate:
        raise ValueError("candidate differs from exported sources")
    for item in manifest["files"]:
        path = root / item["path"]
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError("bundle contains an unsafe path")
        if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
            raise ValueError("bundle file changed: " + item["path"])
    return manifest


def sdk_versions():
    observed = {}
    for name in (*FIXED_SDK, "numpy", "Pillow", "torch"):
        try:
            observed[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            observed[name] = None
    return observed


def one_check(name, temp_root):
    # Imported only in a child after fixed-version, candidate and lease checks.
    sys.path.insert(0, str(Path(__file__).resolve().parent / "code"))
    context = contextlib.nullcontext()
    if name != "daft_reader":
        import ray

        if ray.is_initialized():
            raise RuntimeError("preserve any existing Ray client")
        native_init = ray.init

        def private_init(*args, **kwargs):
            if args or kwargs.get("address") not in (None, "local"):
                raise ValueError("the fixture must create its own private Ray runtime")
            if kwargs.get("num_cpus") != 2 or kwargs.get("num_gpus") != 0:
                raise ValueError("fixture resource request changed")
            kwargs.update(address="local", _temp_dir=str(temp_root),
                          object_store_memory=OBJECT_STORE_BYTES)
            return native_init(**kwargs)

        context = patch.object(ray, "init", private_init)
    with context:
        suite = unittest.defaultTestLoader.loadTestsFromName(CHECKS[name])
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    summary = {"check": name, "tests_run": result.testsRun,
               "failures": len(result.failures), "errors": len(result.errors),
               "skipped": len(result.skipped)}
    print("SDK_CHECK_RESULT " + json.dumps(summary, sort_keys=True), flush=True)
    return 0 if result.wasSuccessful() and result.testsRun == 1 and not result.skipped else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate")
    parser.add_argument("--inspect", action="store_true", help="hash/version metadata only; no SDK imports or lease")
    parser.add_argument("--artifact-root", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--ray-temp-root", type=Path)
    parser.add_argument("--one", choices=CHECKS, help=argparse.SUPPRESS)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if not args.candidate:
        parser.error("--candidate is required")
    manifest = verify_bundle(root, args.candidate)
    versions = sdk_versions()
    if args.inspect:
        print(json.dumps({"candidate": args.candidate, "status": manifest["status"],
                          "files": len(manifest["files"]), "versions": versions,
                          "sdk_imports": False, "server_execution": False}, sort_keys=True))
        return 0
    if manifest["status"] != "fixed_candidate":
        parser.error("preparation snapshot cannot run; export the integration owner's fixed candidate")
    if platform.system() != "Linux" or not Path("/proc/self/stat").is_file():
        parser.error("Linux PID/start-tick evidence is required")
    if sys.version_info[:2] != (3, 12):
        parser.error("fixed driver requires Python 3.12")
    if any(versions[name] != version for name, version in FIXED_SDK.items()):
        parser.error("fixed SDK metadata differs: " + json.dumps(versions, sort_keys=True))
    if any(versions[name] is None for name in ("numpy", "Pillow", "torch")):
        parser.error("missing fixture dependency; no automatic installation")
    if args.one:
        if args.artifact_root is None or args.ray_temp_root is None:
            parser.error("child requires the parent's artifact and temporary roots")
        lease_path = args.artifact_root / ".host-runner-scope/.runner-lease.json"
        lease_record = json.loads(lease_path.read_text())
        if (lease_record["pid"] != os.getppid() or
                lease_record["owner_token"] != os.environ.get("SEMLOOM_SDK_PARENT_OWNER") or
                lease_record["repository_commit"] != args.candidate):
            parser.error("child requires its live parent's matching host lease")
        return one_check(args.one, args.ray_temp_root)
    if any(value is None for value in (args.artifact_root, args.output, args.ray_temp_root)):
        parser.error("--artifact-root, --output and --ray-temp-root are required")
    artifact_root, output, ray_temp_root = (value.resolve() for value in
                                           (args.artifact_root, args.output, args.ray_temp_root))
    if not output.is_relative_to(artifact_root):
        parser.error("evidence must be within the shared artifact root")
    if not ray_temp_root.is_relative_to(artifact_root.parent) or ray_temp_root == artifact_root.parent:
        parser.error("short Ray temp root must be below the artifact root's persistent parent")
    if output.exists() or ray_temp_root.exists():
        parser.error("use new evidence and Ray temp directories; preserve previous runs")
    sys.path.insert(0, str(root / "code"))
    from src.baselines.common.redact import redact_text
    from src.infrastructure.runner_lease import (
        HOST_SCOPE_DIR_NAME, HOST_SCOPE_FINGERPRINT, acquire_runner_lease,
    )
    # Do not recover, replace or delete another owner's current/stale lease.
    lease = acquire_runner_lease(artifact_root / HOST_SCOPE_DIR_NAME,
                                 config_fingerprint=HOST_SCOPE_FINGERPRINT,
                                 repository_commit=args.candidate, recover_stale=False)
    release_safe, report = True, None
    try:
        output.mkdir()
        ray_temp_root.mkdir()
        report = {"candidate": args.candidate, "versions": versions, "status": "incomplete",
                  "scope": "three_cpu_sdk_checks_no_model_no_gpu", "checks": [],
                  "ray_requested_cpus": 2, "ray_requested_gpus": 0,
                  "ray_object_store_bytes": OBJECT_STORE_BYTES,
                  "physical_cpu_quota": "not_enforced_by_ray_slots"}
        env = os.environ.copy()
        for key in ("RAY_ADDRESS", "RAY_JOB_CONFIG_JSON_ENV_VAR", "RAY_RUNTIME_ENV_HOOK"):
            env.pop(key, None)
        env.update(PYTHONPATH=str(root / "code"), PYTHONDONTWRITEBYTECODE="1",
                   CUDA_VISIBLE_DEVICES="", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
                   MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1", HF_HUB_OFFLINE="1",
                   TRANSFORMERS_OFFLINE="1", SEMLOOM_IMAGE_FILE_SDK_TESTS="1",
                   SEMLOOM_IMAGE_WORKER_SDK_TESTS="1", SEMLOOM_SDK_PARENT_OWNER=lease.owner.owner_token)
        try:
            for index, name in enumerate(CHECKS):
                temp = ray_temp_root / str(index)
                temp.mkdir()
                child_env = dict(env, TMPDIR=str(temp), RAY_TMPDIR=str(temp))
                start = time.monotonic()
                report["active_check"] = name
                release_safe = False
                child = subprocess.run([sys.executable, str(root / Path(__file__).name),
                                        "--candidate", args.candidate, "--one", name,
                                        "--artifact-root", str(artifact_root), "--ray-temp-root", str(temp)],
                                       cwd=root, env=child_env, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, errors="replace")
                if name == "daft_reader":
                    release_safe = True
                safe_log = redact_text(child.stdout)
                (output / f"{name}.log").write_text(safe_log)
                summaries = [json.loads(line.removeprefix("SDK_CHECK_RESULT "))
                             for line in safe_log.splitlines() if line.startswith("SDK_CHECK_RESULT ")]
                passed = (child.returncode == 0 and len(summaries) == 1 and
                          summaries[0] == {"check": name, "tests_run": 1,
                                           "failures": 0, "errors": 0, "skipped": 0})
                report["checks"].append({"check": name, "exit_code": child.returncode,
                                         "wall_s": time.monotonic() - start,
                                         "passed": passed, "summary": summaries,
                                         "log_sha256": hashlib.sha256(safe_log.encode()).hexdigest()})
                if not passed:
                    report["status"] = "stopped_at_first_failed_or_skipped_check"
                    return 1
                release_safe = True
            report["status"] = "three_sdk_checks_passed"
            report["active_check"] = None
            return 0
        except BaseException as error:
            report["status"] = "incomplete_or_interrupted"
            report["error_type"] = type(error).__name__
            report["error"] = redact_text(str(error))
            raise
        finally:
            (output / "summary.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    finally:
        if release_safe:
            lease.release()
        if report is not None:
            report["host_lease_released"] = release_safe
            report["unknown_child_cleanup_requires_owner_inspection"] = not release_safe
            report["unknown_ray_cleanup_requires_owner_inspection"] = (
                not release_safe and report.get("active_check") != "daft_reader")
            (output / "summary.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())
