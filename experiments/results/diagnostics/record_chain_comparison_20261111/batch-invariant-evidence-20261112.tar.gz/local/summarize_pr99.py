"""Recompute the bounded cold MMF comparison without subtracting startup."""
import argparse,hashlib,json,statistics
from pathlib import Path
FIELDS=['query_id','model_role','algorithm_stage','call_id','row_id','source_position','call_index','messages_sha256','prompt_token_ids_json','output_token_ids_json','text','finish_reason','prompt_tokens','completion_tokens','total_tokens','parent_call_ids','decision','status','submission_confirmed']

def analyze(root):
    final=json.loads((root/'host/FINAL.json').read_text());rows=[];pairs=[];reference=None;cross_pair_equal=True
    repair_path=root/'host/ARCHIVE-REPAIR.json'
    repair=json.loads(repair_path.read_text())if repair_path.exists()else None
    for pair in sorted(root.glob('pair-*')):
        if not pair.is_dir():continue
        outputs={}
        for name in ('one-action','default-actions'):
            path=pair/'artifacts/cases'/name/'case.json'
            if not path.exists():continue
            report=json.loads(path.read_text());profile=pair/('PROFILE-'+name+'.json')
            proof=json.loads(profile.read_text())if profile.exists()else None
            timing=report.get('timing',{});calls=report.get('calls',report.get('observed_calls',[]))
            normalized=sorted([{k:x.get(k)for k in FIELDS}for x in calls],key=lambda x:x['call_id'])
            if reference is None and report['status']=='completed':reference=normalized
            elif reference is not None and normalized!=reference:cross_pair_equal=False
            t=timing.get('caller_to_full_relation_ready_s')
            worker_t=(timing['full_relation_ready_ns']-report['process_start_ns'])/1e9 if timing.get('full_relation_ready_ns') else None
            row=dict(pair=pair.name,case=name,status=report['status'],model_calls=report.get('actual_calls'),confirmed_calls=len(calls),full_relation_s=t,worker_to_full_relation_s=worker_t,owner_including_close_s=timing.get('full_owner_call_s'),worker_wall_s=report.get('worker_wall_before_final_write_s'),ray=report.get('caller_runtime'),replay=report.get('replay'),native_profile=proof,outputs_sha256=hashlib.sha256(json.dumps(report.get('outputs'),sort_keys=True).encode()).hexdigest(),call_fields_sha256=hashlib.sha256(json.dumps(normalized,sort_keys=True).encode()).hexdigest(),source=report['public_git_commit'],generation=report.get('generation'),resources=report.get('resources'),step_actions=report.get('step_actions'))
            intervals=[(x.get('model_start_monotonic'),x.get('model_end_monotonic'))for x in calls]
            row['model_api_span_s']=(max(b for a,b in intervals)-min(a for a,b in intervals)if intervals and all(a is not None and b is not None for a,b in intervals)else None)
            rows.append(row);outputs[name]=row
        compare=pair/'COMPARISON.json'
        if compare.exists():
            c=json.loads(compare.read_text());a=outputs.get('one-action',{}).get('full_relation_s');b=outputs.get('default-actions',{}).get('full_relation_s')
            pairs.append(dict(pair=pair.name,strict=c['outputs_strictly_comparable'],comparison=c,one_action_s=a,default_actions_s=b,one_vs_default_reduction_fraction=1-a/b if a is not None and b else None))
    groups=[]
    for name in ('one-action','default-actions'):
        values=[x['full_relation_s']for x in rows if x['case']==name and x['status']=='completed']
        if values:groups.append(dict(case=name,independent_cold_sessions=len(values),all_full_relation_s=values,median_s=statistics.median(values),min_s=min(values),max_s=max(values)))
    return dict(schema='semloom.pr99_batch_invariant_followup.v1',scope='Cold project MMF; each session owns a fresh model and Ray. New common batch-invariant profile, not original R1 or native SemBench task. No startup subtraction.',final_status=final['status'],failure=final['failure'],lease_released=final['lease_released'],shm_unchanged=final['SHM_unchanged'],physical_gpu_final=final['GPU'],rows=rows,pairs=pairs,groups=groups,cross_pair_complete_call_fields_equal=cross_pair_equal,observed_model_calls=sum(x['model_calls']or x['confirmed_calls']for x in rows),global_budget=final['global_budget'],strict_success=len(pairs)==2 and all(x['strict']for x in pairs)and cross_pair_equal and final['lease_released'] and final['SHM_unchanged'] and all(r['native_profile'].get('batch_invariant_active')is True for r in rows),archive_repair_status=None if repair is None else repair['status'])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);a=p.parse_args();d=analyze(a.root);a.output.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:d[k]for k in ('final_status','groups','observed_model_calls','strict_success','failure')},ensure_ascii=False))
