"""PR99 independent workload with verified support-source host supervision."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,signal,sys,tempfile,time
R=Path('<data-root>/semloom-pr99-batch-invariant-20261112/readback-followup'); OLD=Path('<data-root>/semloom-pr99-step-actions-20261112-r1'); S=R/'source'; P=R/'packet'
SUP=OLD/'support'
COMMIT='4294f14bc412cbec2c067157605c50c63d2e4d26'; MODE='batch-invariant'
os.umask(0o077);os.sched_setaffinity(0,set(range(8)));sys.path.insert(0,str(SUP/'code'))
from src.baselines.image.ray_animals_q7.host_adapter import from_bound,load_host
template=json.loads(Path('<data-root>/ray-animals-q7-909-engine-1111-r2/RUN-BOUND.json').read_text())
bound=dict(source=str(SUP),source_commit='933157666e1db81d47872fe21422ac8315ea7be3',code_tree='e973cd44d8c971942bcc8bd1fc312f9906449906',root=str(R),host_adapter=template['host_adapter'],workload_source=str(S),workload_commit=COMMIT,model_calls=288)
bound['host_adapter']['host_helper']=dict(path='<data-root>/semloom-host-helper-argv0-20261111-r1/host_helpers.py',sha256='7c1d0d3f9f9ed9738559524516a547d8bc88a663d1fb2fae7ba7b19a4ad3e1da')
host=load_host('host',bound['host_adapter']['host_helper']);api=host.production_api(SUP/'code')
resources=json.loads(Path(bound['host_adapter']['resource_config']['path']).read_text())
O=R/'host';O.mkdir(mode=0o700,exist_ok=False)
import subprocess,threading,psutil
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
D='<data-root>/venvs/sembench-query-0910/bin/python'
entry=str(S/'code/scripts/experiments/validate_record_chain_options.py')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==COMMIT
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
before=host.snapshot(api,resources,'pr99-batch-invariant-before');host.private_json(O/'BEFORE.json',before);host.assert_idle(before,resources)
lease=api.acquire_runner_lease(Path('<data-root>/experiment-artifacts/.host-runner-scope'),config_fingerprint=api.HOST_SCOPE_FINGERPRINT,repository_commit=COMMIT,recover_stale=False)
before_shm={p.name:(p.stat().st_ino,p.stat().st_size)for p in Path('/dev/shm').iterdir()}
short=Path(tempfile.mkdtemp(prefix='p99bi-',dir='/tmp'))
owned=set();failure=None;receipts=[];pairs=[];started=time.monotonic_ns();deadline=json.loads((R.parent/'host/FINAL.json').read_text())['global_budget']['deadline_utc']
master=CellBudgetLedger(R.parent/'budget.sqlite',AttemptBudget('pr99-batch-invariant-20261112',288))
assert deadline-time.time()>300, 'insufficient original allocation; no reset'

def alarm(*_):raise TimeoutError('bounded PR99 batch-invariant allocation')
signal.signal(signal.SIGALRM,alarm);signal.alarm(max(1,int(deadline-time.time())))
os.environ.update(PYTHONPATH=str(S/'code'),CUDA_VISIBLE_DEVICES='0',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',LITELLM_LOCAL_MODEL_COST_MAP='True',TOKENIZERS_PARALLELISM='false',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',GIT_ALLOW_PROTOCOL='file',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',AI_OPERATOR_ENV_FILE=str(P/'runtime.env'),VLLM_BATCH_INVARIANT='1',VLLM_LOGGING_LEVEL='INFO')

def observe_native_environment(stop,samples):
 while not stop.is_set():
  try:
   p=subprocess.run(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=8)
   if p.returncode==0:
    for line in p.stdout.splitlines():
     pid=int(line.strip())
     try:
      born=psutil.Process(pid).create_time();raw=(Path('/proc')/str(pid)/'environ').read_bytes()
      env=dict(x.split(b'=',1)for x in raw.split(b'\0')if b'='in x)
      samples[(pid,born)]=dict(pid=pid,create_time=born,VLLM_BATCH_INVARIANT=env.get(b'VLLM_BATCH_INVARIANT',b'').decode() or None,CUDA_VISIBLE_DEVICES=env.get(b'CUDA_VISIBLE_DEVICES',b'').decode() or None,initial_env_key_count=len(env),read_scope='selected initial environment keys on actual NVIDIA compute PID; missing is unavailable, not false')
     except (OSError,psutil.Error):pass
  except (ValueError,subprocess.TimeoutExpired):pass
  stop.wait(1)

stage_number=0
try:
 host.private_json(O/'STARTED.json',dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),source=COMMIT,supervisor_source=bound['source_commit'],short=str(short),affinity=sorted(os.sched_getaffinity(0)),environment_profile='VLLM_BATCH_INVARIANT=1 both arms; not original R1 profile'))
 for name,python,groups in [('driver',D,'core,text,text-qwen7b'),('model',json.loads((P/'config-template.json').read_text())['engine']['model_python'],'text,text-qwen7b')]:
  with (O/('preflight-'+name+'.log')).open('w') as log:
   subprocess.run([python,str(S/'code/scripts/environment/manage_environment.py'),'check','--groups',groups,'--json-out',str(O/('preflight-'+name+'.json'))],cwd=S,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
  print('PREFLIGHT',name,'passed',flush=True)
 for cycle,order in enumerate([['default-actions','one-action'],['one-action','default-actions']],2):
  master.claim_unit('pair-'+str(cycle)).bind_execution()
  cell=R/('pair-'+str(cycle));cell.mkdir(mode=0o700)
  c=json.loads((P/'config-template.json').read_text());c.update(run_id='pr99-batch-invariant-pair-'+str(cycle),target_root=str(cell),public_git_commit=COMMIT,execution_enabled=True,artifact_root=str(cell/'artifacts'),external_owner=dict(artifact_root='<data-root>/experiment-artifacts',lease_sha256=hashlib.sha256(Path('<data-root>/experiment-artifacts/.host-runner-scope/.runner-lease.json').read_bytes()).hexdigest()))
  c['ray_roots']={m:str(short/('r'+str(cycle)+'-'+m))for m in ('one-action','default-actions')}
  config=cell/'CONFIG.json';ready=cell/'READY.json';host.private_json(config,c)
  host.private_json(cell/'environment.json',dict(VLLM_BATCH_INVARIANT='1',source=COMMIT,order=order,model_calls_limit=96))
  for action,extra in [('check',[]),('qualify',['--count-only','--output',str(ready)])]:
   with (cell/(action+'.log')).open('w') as log:subprocess.run([D,'-B',entry,action,'--config',str(config)]+extra,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
  Path(c['artifact_root']).mkdir(mode=0o700)
  ledger=CellBudgetLedger.create(Path(c['artifact_root'])/'budget.sqlite',AttemptBudget(c['run_id'],96),deadline_utc=min(deadline,time.time()+900))
  for name in order:ledger.reserve_unit(name,48)
  for name in order:
   host.check_lease(lease);bound['host_adapter']['stage_timeout_s']=min(460,deadline-time.time()-90)
   command=[D,'-B',entry,'case','--config',str(config),'--ready',str(ready),'--case',name,'--execute-model']
   host.private_json(cell/('COMMAND-'+name+'.json'),command);host.private_json(cell/('BOUND-'+name+'.json'),bound)
   stop=threading.Event();samples={};thread=threading.Thread(target=observe_native_environment,args=(stop,samples),daemon=True);thread.start()
   print('START',cycle,name,flush=True)
   try:receipt=from_bound(bound)(command,stage_number,short);stage_number+=1;receipts.append(receipt)
   finally:
    stop.set();thread.join(timeout=10)
    host.private_json(cell/('NATIVE-ENV-'+name+'.json'),dict(samples=list(samples.values()),sampler_stopped=not thread.is_alive()))
   assert receipt['worker_exit_zero'] and receipt['physical_idle'] and receipt['resource_passed']
   host.private_json(cell/('RESULT-'+name+'.json'),receipt)
   case=json.loads((cell/'artifacts/cases'/name/'case.json').read_text())
   evidence=case['close']['model_owner']['model_ready']['native_execution_profile']
   host.private_json(cell/('PROFILE-'+name+'.json'),evidence)
   assert (evidence['status']=='observed_worker_execution_profile' and
           evidence['batch_invariant_requested'] is True and evidence['batch_invariant_active'] is True), 'actual initialized native batch-invariance profile unconfirmed'
   print('DONE',json.dumps(dict(cycle=cycle,case=name,status=case['status'],actual_calls=case['actual_calls'],full_relation_s=case['timing']['caller_to_full_relation_ready_s'],worker_to_full_relation_s=(case['timing']['full_relation_ready_ns']-case['process_start_ns'])/1e9)),flush=True)
  command=[D,'-B',entry,'compare','--config',str(config),'--output',str(cell/'COMPARISON.json')]
  bound['host_adapter']['stage_timeout_s']=30
  receipt=from_bound(bound)(command,stage_number,short);stage_number+=1;receipts.append(receipt)
  comparison=json.loads((cell/'COMPARISON.json').read_text())
  host.private_json(cell/'BUDGET-final.json',ledger.snapshot());pairs.append(dict(cycle=cycle,order=order,strict=comparison['outputs_strictly_comparable']))
  print('PAIR',json.dumps(pairs[-1]),flush=True)
  assert receipt['worker_exit_zero'] and receipt['physical_idle'] and receipt['resource_passed'] and comparison['outputs_strictly_comparable']
except BaseException as error:failure=host.error_record(error)
finally:
 signal.alarm(0)
 for path in short.glob('stage-*-supervision/supervisor.json'):owned.update(host.report_identities(json.loads(path.read_text())))
 if host.live_owned(api,owned):host.cleanup_owned(api,owned,20)
 live=host.live_owned(api,owned);after=host.snapshot(api,resources,'pr99-batch-invariant-after',owned);gpu=host.gpu_snapshot(resources)
 shm={p.name:(p.stat().st_ino,p.stat().st_size)for p in Path('/dev/shm').iterdir()};clean=not live and not gpu['compute'] and gpu['used_mib']==1 and shm==before_shm
 try:host.assert_idle(after,resources)
 except BaseException as error:failure=failure or host.error_record(error);clean=False
 try:shutil.copytree(short,O/'RUNS')
 except BaseException as error:failure=failure or host.error_record(error);host.private_json(O/'ARCHIVE-ERROR.json',host.error_record(error))
 host.private_json(O/'AFTER.json',after)
 if clean:host.check_lease(lease);lease.release()
 final=dict(status='passed'if failure is None and clean else'failed',failure=failure,source=COMMIT,start_ns=started,end_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),pairs=pairs,receipts=receipts,remaining_owned=sorted(live),GPU=gpu,SHM_unchanged=shm==before_shm,lease_released=clean,short=str(short),global_budget=master.snapshot())
 host.private_json(O/'FINAL.json',final)
print('PR99 DONE',json.dumps(dict(status=final['status'],pairs=pairs,lease_released=clean,failure=failure)),flush=True)
raise SystemExit(0 if final['status']=='passed'else 1)
