"""Retain redacted local test output before writing an evidence file."""

import subprocess
import sys
from pathlib import Path

from src.baselines.common.redact import redact_text


completed = subprocess.run([sys.executable, "-m", "unittest", "-v", *sys.argv[2:]],
                           text=True, capture_output=True)
output = redact_text(completed.stdout + completed.stderr).replace(str(Path.cwd()), "<repo>")
Path(sys.argv[1]).write_text(output, encoding="utf-8")
print(output)
raise SystemExit(completed.returncode)
