"""Run the full HSE function with a suspended source and retained traceback."""

import gc
import inspect
import json
import weakref

from src.baselines.common.redact import redact_text
from src.modalities.image.execution import ProjectRayWorkerPool
from tests.modalities.image import test_hse_static_lifecycle as lifecycle
from tests.modalities.image import test_staged_image_execution as fixture


error = ValueError("fixture row materialization failed")
events = []


class FailedScalar:
    def as_py(self):
        raise error


class Source(fixture._Source):
    def to_arrow_iter(self, *, results_buffer_size):
        assert results_buffer_size == 2

        def generate():
            try:
                yield from self._batches
            finally:
                events.append("source_finalized")

        iterator = generate()
        self.iterator_ref = weakref.ref(iterator)
        return iterator


source = Source([fixture._RecordBatch(doc_id=[FailedScalar()], image=[fixture._Scalar(b"a")])])
pool = ProjectRayWorkerPool((lifecycle.FenceCpu(events),), (lifecycle.FenceGpu(events),))
retained = None
with fixture._fake_ray_module(lifecycle.AbortRay()):
    try:
        lifecycle.run(source, pool, rows=("a",), active=1)
    except BaseException as caught:
        retained = caught
gc.collect()
iterator = source.iterator_ref()
observation = {
    "exception_identity_preserved": retained is error,
    "traceback_retained": retained.__traceback__ is not None,
    "events_after_gc": list(events),
    "iterator_alive_after_gc": iterator is not None,
    "generator_state_after_gc": inspect.getgeneratorstate(iterator) if iterator else "collected",
}
if iterator is not None:
    iterator.close()
observation["events_after_explicit_close"] = list(events)
print(redact_text(json.dumps(observation, sort_keys=True)))
