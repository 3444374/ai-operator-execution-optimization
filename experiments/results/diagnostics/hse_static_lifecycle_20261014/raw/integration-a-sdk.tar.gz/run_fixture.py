"""Private observation wrapper for the unchanged five audited Ray test cases."""
import dataclasses
import json
import os
from pathlib import Path
import shutil
import sys
import time
import unittest

from tests.modalities.image import test_hse_static_ray as fixture

root = Path(sys.argv[1])
cases, identities, diagnostic_errors = [], [], []


def write(name, value):
    path = root / name
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def operation(name):
    write("operation.json", {"name": name, "started_epoch_s": time.time()})


original_temp = fixture.tempfile.mkdtemp


def data_disk_temp(*args, **kwargs):
    path = original_temp(*args, **kwargs)
    if kwargs.get("prefix") == "hs" and kwargs.get("dir") == "/tmp":
        physical = root / "ray-runtime"
        shutil.move(path, physical)
        os.symlink(physical, path)
        write("ray_log_location.json", {"short_path": path, "physical_path": str(physical)})
    return path


fixture.tempfile.mkdtemp = data_disk_temp
cls = fixture.HSEStaticActualRayTests
original_setup, original_shutdown = cls.setUpClass, cls.tearDownClass
original_pool, original_teardown = cls.pool, cls.tearDown


def setup(_cls):
    import numpy, pyarrow, psutil, ray
    versions = {"python": sys.version.split()[0], "numpy": numpy.__version__,
                "pyarrow": pyarrow.__version__, "psutil": psutil.__version__, "ray": ray.__version__,
                "module_files": {item.__name__: item.__file__ for item in (numpy, pyarrow, psutil, ray)}}
    write("versions.json", versions)
    assert pyarrow.__version__ == "16.1.0" and ray.__version__ == "2.56.1"
    assert psutil.__version__ == "7.0.0"
    version = tuple(int(item) for item in numpy.__version__.split(".")[:2])
    assert (1, 25) <= version < (2, 0)
    operation("ray_initialization")
    original_setup()
    operation("test_cases")
    versions["cluster_resources"] = ray.cluster_resources()
    write("versions.json", versions)


def shutdown(_cls):
    operation("ray_shutdown")
    original_shutdown()
    operation("finished")


def pool(self, *args, **kwargs):
    try:
        return original_pool(self, *args, **kwargs)
    finally:
        identities.extend(dict(item, case=self.id()) for item in self.identities)
        write("actor_identities.json", identities)


def teardown(self):
    record = {"case": self.id()}
    try:
        record.update(events=list(self.events), driver_get_types=list(self.observed_ray.get_types),
                      broker_snapshots=[dataclasses.asdict(item.snapshot()) for item in self.brokers],
                      created_handles=len(self.actors), known_identities=len(self.identities))
    except BaseException as error:
        diagnostic_errors.append({"case": self.id(), "error_type": type(error).__name__})
    try:
        return original_teardown(self)
    finally:
        try:
            record["actor_exit_confirmed"] = not type(self).cleanup_unconfirmed
            cases.append(record)
            write("case_observations.json", cases)
        except BaseException as error:
            diagnostic_errors.append({"case": self.id(), "error_type": type(error).__name__})


cls.setUpClass, cls.tearDownClass = classmethod(setup), classmethod(shutdown)
cls.pool, cls.tearDown = pool, teardown
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
write("test_result.json", {"tests_run": result.testsRun,
      "passed": max(0, result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped)),
      "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
      "successful": result.wasSuccessful(), "cleanup_unconfirmed": getattr(cls, "cleanup_unconfirmed", True),
      "cleanup_incidents": getattr(cls, "cleanup_incidents", []), "diagnostic_errors": diagnostic_errors})
raise SystemExit(0 if result.wasSuccessful() and not result.skipped and not diagnostic_errors and result.testsRun == 5 else 1)
