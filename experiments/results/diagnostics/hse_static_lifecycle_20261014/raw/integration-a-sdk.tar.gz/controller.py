"""Own one host lease, execute the fixed CPU fixture, and prove process exit."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import psutil

COMMIT = "45da0a5451bfcf785d98b9ab5336054bdbaf199f"
LEASE_SHA = "637738aea07ffd1b8377ceb03ae9dd871769927e3f378c9d091d8b8af306d959"
root, driver, repo = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
root.mkdir(mode=0o700, parents=True, exist_ok=False)
lease, child, tracked = None, None, {}
status = {"state": "starting", "repository_commit": COMMIT,
          "controller_pid": os.getpid(), "cpu_slots": 4, "gpu_slots": 0,
          "overall_wall_deadline_s": None}


def persist():
    path = root / "status.json"
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(status, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def remember(process):
    try:
        identity = {"pid": process.pid, "birth": process.create_time(), "name": process.name()}
        tracked[(identity["pid"], identity["birth"])] = identity
    except psutil.NoSuchProcess:
        pass


def living():
    result = []
    for identity in tracked.values():
        try:
            process = psutil.Process(identity["pid"])
            if (process.create_time() == identity["birth"] and process.is_running()
                    and process.status() != psutil.STATUS_ZOMBIE):
                result.append(process)
        except psutil.NoSuchProcess:
            pass
    return result


def collect_descendants():
    for parent in living():
        try:
            for process in parent.children(recursive=True):
                remember(process)
        except psutil.NoSuchProcess:
            pass


persist()
try:
    lease_path = repo / "code/src/infrastructure/runner_lease.py"
    assert hashlib.sha256(lease_path.read_bytes()).hexdigest() == LEASE_SHA, "runner lease source differs"
    spec = importlib.util.spec_from_file_location("hse_owned_runner_lease", lease_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    lease = module.acquire_host_runner_lease(Path("<data-root>/experiment-artifacts"), repository_commit=COMMIT)
    status["state"] = "lease_acquired"
    persist()

    # Recheck resources after the atomic lease so another owner cannot race admission.
    foreign = []
    for process in psutil.process_iter(["pid", "name"]):
        name = process.info["name"] or ""
        if name in ("gcs_server", "raylet"):
            foreign.append(process.pid)
    assert not foreign, "other Ray/model owner processes remain"

    package = root.parent / "package"
    receipt = json.loads((package / "ray_package_manifest.json").read_text())
    for item in receipt["members"]:
        data = (package / item["path"]).read_bytes()
        assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"], item["path"]
    status["source_members_verified"] = len(receipt["members"])
    env = dict(os.environ, PYTHONPATH=str(repo / "code"), CUDA_VISIBLE_DEVICES="",
               OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
               AI_OPERATOR_ENV_FILE="<runtime-env>")
    status["private_driver_reused_without_install"] = True
    with (root / "preflight.stdout.json").open("w") as stdout, (root / "preflight.stderr.log").open("w") as stderr:
        child = subprocess.Popen([str(driver), str(repo / "code/scripts/environment/manage_environment.py"),
                                  "--assets-manifest", str(repo / "deploy/runtime/assets.json"),
                                  "check", "--groups", "imlane-runtime", "--json-out", str(root / "preflight.json")],
                                 env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        remember(psutil.Process(child.pid))
        status["state"] = "preflight_running"
        persist()
        started = time.monotonic()
        while child.poll() is None:
            collect_descendants()
            if time.monotonic() - started > 60:
                raise TimeoutError("environment preflight produced no completion")
            time.sleep(0.05)
    assert child.returncode == 0, "imlane-runtime preflight failed"
    status["state"] = "running"
    status["started_epoch_s"] = time.time()
    persist()
    env.update(PYTHONPATH=str(package / "code"), SEMLOOM_RUN_HSE_RAY="1")
    with (root / "tests.stdout.log").open("w") as stdout, (root / "tests.stderr.log").open("w") as stderr:
        child = subprocess.Popen([str(driver), str(root.parent / "run_fixture.py"), str(root)],
                                 cwd=package, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        remember(psutil.Process(child.pid))
        while child.poll() is None:
            try:
                for process in psutil.Process(child.pid).children(recursive=True):
                    remember(process)
            except psutil.NoSuchProcess:
                pass
            operation = root / "operation.json"
            if operation.exists():
                current = json.loads(operation.read_text())
                timeout = {"ray_initialization": 60, "ray_shutdown": 30}.get(current["name"])
                if timeout is not None and time.time() - current["started_epoch_s"] > timeout:
                    raise TimeoutError(current["name"] + " produced no completion")
            time.sleep(0.05)
    status["test_exit_code"] = child.returncode
    status["result"] = json.loads((root / "test_result.json").read_text())
    if child.returncode == 0:
        result = status["result"]
        assert result["tests_run"] == result["passed"] == 5
        assert not any(result[k] for k in ("failures", "errors", "skipped", "cleanup_unconfirmed", "cleanup_incidents", "diagnostic_errors"))
        status["state"] = "shared_data_preparation"
        persist()
        with (root / "shared.stdout.log").open("w") as stdout, (root / "shared.stderr.log").open("w") as stderr:
            child = subprocess.Popen([
                "<shared-data-driver>/bin/python",
                str(root.parent / "run_shared_preparation.py"), str(root), str(repo)],
                cwd=repo, env=env, stdout=stdout, stderr=stderr)
            while child.poll() is None:
                collect_descendants()
                time.sleep(0.1)
        status["shared_exit_code"] = child.returncode
        status["shared_result"] = json.loads((root / "shared_result.json").read_text())
    status["state"] = "passed" if child.returncode == 0 else "failed"
except BaseException as error:
    status.update(state="blocked" if lease is None else "failed", error_type=type(error).__name__, error=str(error))
finally:
    try:
        actor_file = root / "actor_identities.json"
        if actor_file.exists():
            for identity in json.loads(actor_file.read_text()):
                tracked[(identity["pid"], identity["birth"])] = identity
        collect_descendants()
        if child is not None and child.poll() is None:
            child.terminate()
        deadline = time.monotonic() + 30
        while living() and time.monotonic() < deadline:
            collect_descendants()
            time.sleep(0.05)
        remaining = living()
        if remaining:
            status["cleanup_forced"] = True
            status["state"] = "failed"
            for process in remaining:
                try:
                    process.terminate()
                except psutil.NoSuchProcess:
                    pass
            _, remaining = psutil.wait_procs(remaining, timeout=10)
            for process in remaining:
                try:
                    if any(item["pid"] == process.pid and item["birth"] == process.create_time() for item in tracked.values()):
                        process.kill()
                except psutil.NoSuchProcess:
                    pass
            psutil.wait_procs(remaining, timeout=10)
        if child is not None:
            child.wait(timeout=10)
        status["unconfirmed_processes"] = len(living())
        status["observed_processes"] = len(tracked)
        status["ray_processes_remaining"] = sum(
            process.info["name"] in ("gcs_server", "raylet")
            for process in psutil.process_iter(["name"]))
        (root / "owned_processes.json").write_text(json.dumps(list(tracked.values()), indent=2) + "\n")
        if status["unconfirmed_processes"] or (lease is not None and status["ray_processes_remaining"]):
            status["state"] = "cleanup_unconfirmed"
        elif lease is not None:
            lease.release()
            status["lease_released"] = True
    except BaseException as error:
        status.update(state="cleanup_unconfirmed", cleanup_error_type=type(error).__name__)
    try:
        status["finished_epoch_s"] = time.time()
        persist()
    except BaseException as error:
        status.update(state="cleanup_unconfirmed", persistence_error_type=type(error).__name__)

# A JSON file with a dead PID is automatically recovered by the shared API.
# Keep this owner alive while cleanup cannot be proved; do not release or exit.
while lease is not None and not status.get("lease_released"):
    try:
        # Persistence is diagnostic; its failure must not prevent process proof.
        try:
            persist()
        except BaseException:
            pass
        collect_descendants()
        remaining = living()
        ray_remaining = sum(process.info["name"] in ("gcs_server", "raylet")
                            for process in psutil.process_iter(["name"]))
        if not remaining and not ray_remaining:
            lease.release()
            status.update(state="failed", lease_released=True, unconfirmed_processes=0,
                          ray_processes_remaining=0, finished_epoch_s=time.time())
            persist()
            break
        time.sleep(1)
    except BaseException:
        try:
            time.sleep(1)
        except BaseException:
            pass

raise SystemExit(0 if status["state"] == "passed" and status.get("lease_released") else 1)
