import importlib.metadata as metadata
import json
from pathlib import Path
import subprocess
import sys
import unittest

root, repo = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(repo / 'code'))
versions = {name: metadata.version(name) for name in ('numpy', 'pyarrow', 'daft', 'ray', 'psutil')}
assert versions['pyarrow'] == '24.0.0' and versions['daft'] == '0.7.21' and versions['ray'] == '2.56.1'
preflight = subprocess.run([sys.executable, str(repo / 'code/scripts/environment/manage_environment.py'),
    'check', '--groups', 'core', '--json-out', str(root / 'shared_preflight.json')],
    cwd=repo, capture_output=True, text=True)
(root / 'shared_preflight.stdout.log').write_text(preflight.stdout)
(root / 'shared_preflight.stderr.log').write_text(preflight.stderr)
assert preflight.returncode == 0, 'shared data driver preflight failed'
name = 'tests.execution_provider.test_map_preparation.MapPreparationTests.test_actual_batch_adapters_keep_merged_row_identity_and_buffers'
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName(name))
record = {'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'skipped': len(result.skipped), 'successful': result.wasSuccessful(), 'versions': versions,
    'scope': 'real Daft/Arrow tables with fake Ray transport; no HTTP/model/GPU'}
(root / 'shared_result.json').write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(0 if result.wasSuccessful() and result.testsRun == 1 and not result.skipped else 1)
