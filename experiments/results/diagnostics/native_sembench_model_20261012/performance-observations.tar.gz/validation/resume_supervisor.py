"""Published original Q2 model plan; fresh services and finite, separate phases."""
from collections import Counter
import hashlib,json,os,signal,socket,sqlite3,subprocess,sys,threading,time,urllib.request,uuid
from pathlib import Path
import psutil
from support import ROOT,STATE,SOURCE,ARMS,Registry,base_env,cli,save,source_identity,author_identity,gpu
from src.baselines.common.redact import redact_text
from pre_send_ledger import activate,counts,install
from src.experiments.fixed_request_routes import FixedRequestRoutes,request_values_sha256
from src.observability.request_gateway import GatewayRoute,ObservationGateway
from src.infrastructure.runner_lease import acquire_host_runner_lease
from src.experiments.postgresql.sembench_queries import MovieDataset

os.sched_setaffinity(0,set(STATE['driver_cpus']))
FIRST_CLOCK_BYTES=(ROOT/'model-start.json').read_bytes()
if hashlib.sha256(FIRST_CLOCK_BYTES).hexdigest()!='837b0b4947a228d1d3128ac287faa36dbc8d11cda3ebe93d34b1bf023bd65ee7':raise RuntimeError('original first API clock differs; do not resume')
PRIOR=json.loads((ROOT/'model/result.json').read_text());PARENT=json.loads((ROOT/'quality-parent-continuation.json').read_text());GOLD=json.loads((ROOT/'quality-gold-identity.json').read_text())
if not PRIOR['phases']['quality']['passed'] or PRIOR['model_calls']!=720 or PRIOR['model_transmission_posts']!=2160 or PRIOR['error']!='parent quality decision not received within original quality/overall time allowance; no measurement started':raise RuntimeError('completed quality and preserved timeout do not match')
if PRIOR['cleanup']['owned_survivors'] or PRIOR['gpu_after'] or counts('single')['total'] or counts('dual')['total']:raise RuntimeError('continuation requires unused performance counts and settled old resources')
if PARENT.get('issuer')!='parent' or PARENT.get('continue') is not True or PARENT.get('source_head')!=STATE['source_head'] or PARENT.get('quality_checkpoint_sha256')!=PRIOR['quality_review_checkpoint_sha256'] or PARENT.get('allowed_phases')!=['single','dual'] or PARENT.get('first_clock_sha256')!=hashlib.sha256(FIRST_CLOCK_BYTES).hexdigest():raise RuntimeError('parent continuation identity differs')
if not GOLD['gold_and_evaluator_source_verified'] or GOLD['positive_occurrences']!=14 or GOLD['source_head']!=STATE['source_head']:raise RuntimeError('original gold identity is not verified')
if time.monotonic_ns()>=json.loads(FIRST_CLOCK_BYTES)['deadline_monotonic_ns']-120_000_000_000:raise TimeoutError('original global cleanup reserve reached; no continuation')
ROOT_MODEL=ROOT/'model-resume';ROOT_MODEL.mkdir(exist_ok=False)
PREP=json.loads((ROOT/'model-preparation/result.json').read_text());MANIFEST=json.loads((ROOT/'model-preparation/route-manifest.json').read_text())
if not PREP['passed'] or PREP['request_occurrences']!=120:raise RuntimeError('real tokenizer and original request manifest not qualified')
MODEL_SCOPE=os.environ['MODELRUN_SCOPE'];ALL_CPUS=set(STATE['driver_cpus'])|set(sum(STATE['service_cpus'],[]))
ANCESTOR_IDENTITIES={(p.pid,p.create_time()) for p in psutil.Process().parents()}
class OwnedRegistry(Registry):
 def observe(self):
  super().observe()
  for p in psutil.process_iter():
   if p.pid==os.getpid():continue
   try:
    if (p.pid,p.create_time()) in ANCESTOR_IDENTITIES:continue
    if p.environ().get('MODELRUN_SCOPE')!=self.token:continue
    row=dict(pid=p.pid,born=p.create_time(),name=p.name(),affinity=p.cpu_affinity())
    with self.lock:self.known[(p.pid,p.create_time())]=row
    if not set(row['affinity'])<=self.cpus:self.violations.append(row)
   except psutil.Error:pass
registry=OwnedRegistry(MODEL_SCOPE,ALL_CPUS);result=dict(passed=False,source_head=STATE['source_head'],phases={},services=[],planned_logical_calls=9360,max_logical_calls=9984,max_transmission_posts=29952,max_seconds=5100,startup_seconds_limit=900,startup_seconds_used=0,model_calls=0,cleanup_actions=[],forced_service_cleanup=False)
result.update(startup_seconds_used=PRIOR['startup_seconds_used'],original_quality_result_sha256=hashlib.sha256((ROOT/'model/result.json').read_bytes()).hexdigest(),original_quality_wait_timeout_preserved=True,original_first_clock_sha256=hashlib.sha256(FIRST_CLOCK_BYTES).hexdigest(),parent_continuation=PARENT,original_supervisor_passed=False)
services=[];writers=[];router=None;lease=None;sampler_stop=threading.Event();sampler=None
ORDERS=[[0,1,2,3,4,5],[5,4,3,2,1,0],[2,3,4,5,0,1]]
dataset=MovieDataset(Path(STATE['data']['checkout']),Path(STATE['data']['manifest']),Path(STATE['data']['csv']))
ELIGIBLE_IDS={r['row_id'] for r in dataset.load_rows() if r['movie_id']=='taken_3'}
if len(ELIGIBLE_IDS)!=120:raise RuntimeError('original Q2 eligible identity set differs')
def write():
 result['model_calls']=sum(counts(p)['gateway'] for p in ('quality','single','dual'));result['model_transmission_posts']=sum(counts(p)['total'] for p in ('quality','single','dual'));save(ROOT_MODEL/'result.json',result)
def control(phase,start_ns,seconds,reserve):
 save(ROOT/'model-resume-phase-control.json',dict(phase=phase,started_monotonic_ns=start_ns,deadline_monotonic_ns=start_ns+int(seconds*1e9),cleanup_reserve_seconds=reserve))
def port():
 with socket.socket() as probe:probe.bind(('127.0.0.1',0));return probe.getsockname()[1]
def api_get(endpoint,path,timeout=3):
 request=urllib.request.Request(endpoint.rsplit('/v1/chat/completions',1)[0]+path,headers={'Authorization':'Bearer ***'})
 with urllib.request.urlopen(request,timeout=timeout) as response:return response.read()
def resource_preflight():
 occupied=[]
 for process in psutil.process_iter():
  if process.pid==os.getpid():continue
  try:
   if process.status()==psutil.STATUS_ZOMBIE or (process.pid,process.create_time()) in ANCESTOR_IDENTITIES or process.environ().get('MODELRUN_SCOPE')==MODEL_SCOPE:continue
   mask=set(process.cpu_affinity())
   if len(mask)<=24 and mask&ALL_CPUS:occupied.append(dict(pid=process.pid,born=process.create_time(),affinity=sorted(mask),name=process.name()))
  except psutil.Error:pass
 if occupied:raise RuntimeError('requested CPU group has other dedicated processes; leave other owners running')
 if gpu():raise RuntimeError('GPU compute is already occupied; leave other owners running')
 save(ROOT_MODEL/'resource-preflight.json',dict(at_monotonic_ns=time.monotonic_ns(),dedicated_other_processes=occupied,gpu_compute=[],driver_cpus=STATE['driver_cpus'],service_cpus=STATE['service_cpus'],source_head=STATE['source_head'],host_background_load_role='host CPU background outside visible process scope can remain; report separately'))
def sample_gpu():
 with (ROOT_MODEL/'gpu-timeseries.jsonl').open('w') as output:
  while not sampler_stop.is_set():
   at=time.monotonic_ns()
   try:
    query=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,utilization.gpu,utilization.memory,memory.used,power.draw','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=4)
    value=dict(started_ns=at,ended_ns=time.monotonic_ns(),returncode=query.returncode,rows=query.stdout.splitlines())
   except Exception as error:value=dict(started_ns=at,error_type=type(error).__name__)
   output.write(json.dumps(value)+'\n');output.flush();sampler_stop.wait(.25)
def start_services(phase,endpoints):
 global sampler
 resource_preflight()
 started=time.monotonic();remaining=900-result['startup_seconds_used'];overall=ROOT/'model-start.json'
 if remaining<=60:raise TimeoutError('cumulative startup allowance cannot preserve its cleanup reserve; no new service started')
 if overall.read_bytes()!=FIRST_CLOCK_BYTES:raise RuntimeError('original first model clock changed')
 if sampler is None:
  sampler=threading.Thread(target=sample_gpu,daemon=True);sampler.start()
 global_deadline=json.loads(overall.read_text())['deadline_monotonic_ns']/1e9
 until=min(started+remaining,global_deadline-120);control('startup-'+phase,int(started*1e9),max(0,until-started),60);work_until=until-60
 records=[]
 try:
  for index,endpoint in enumerate(endpoints):
   root=ROOT_MODEL/phase/('service-'+str(index));root.mkdir(parents=True)
   cpu=STATE['service_cpus'][index];number=int(endpoint.split(':')[2].split('/')[0]);tmp=root/'tmp';tmp.mkdir()
   options=['--host','127.0.0.1','--port',str(number),'--model',STATE['model_path'],'--served-model-name',STATE['model_id'],'--dtype','bfloat16','--max-model-len','4096','--max-num-seqs','16','--max-num-batched-tokens','2048','--gpu-memory-utilization','0.80','--tensor-parallel-size','1','--pipeline-parallel-size','1','--enforce-eager','--no-enable-prefix-caching','--api-key','***']
   command=['taskset','-c',','.join(map(str,cpu)),STATE['service_python'],'-B',str(SOURCE/'code/scripts/services/launch_vllm_with_identity.py'),'--identity-output',str(root/'identity.json'),'--port',str(number),'--',*options]
   env=base_env();env.update(MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0',CUDA_VISIBLE_DEVICES=str(index),VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',HF_HUB_DISABLE_TELEMETRY='1',HF_HOME=str(root/'cache'),VLLM_CACHE_ROOT=str(root/'cache/vllm'),TMPDIR=str(tmp));writer=(root/'vllm.log').open('w');writers.append(writer)
   if time.monotonic()>=work_until:raise TimeoutError('startup or overall work deadline reached before API launch; no new service started')
   at=time.monotonic_ns()
   if not (ROOT/'model-resume-first-api.json').exists():save(ROOT/'model-resume-first-api.json',dict(first_pending_api_ns=at,original_first_clock_sha256=hashlib.sha256(FIRST_CLOCK_BYTES).hexdigest()))
   child=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=writer,stderr=subprocess.STDOUT,start_new_session=True);services.append(child);registry.add(child)
   row=dict(phase=phase,replica='gpu'+str(index),api_pid=child.pid,api_start_ticks=int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19]),endpoint=endpoint,cpu_affinity=cpu,started_ns=at,argv=command,service_history_before=0);records.append(row);result['services'].append(row);write()
  for row,child in zip(records,services[-len(records):]):
   while True:
    if child.poll() is not None:raise RuntimeError('fresh owned model service exited before ready')
    if time.monotonic()>=work_until:raise TimeoutError('cumulative startup or global cleanup reserve reached')
    try:
     models=json.loads(api_get(row['endpoint'],'/v1/models',2))
     if [v['id'] for v in models['data']]==[STATE['model_id']]:break
    except (OSError,ValueError):pass
    time.sleep(.5)
   row['ready_ns']=time.monotonic_ns();row['readiness_seconds']=(row['ready_ns']-row['started_ns'])/1e9
   row['actual_api_affinity']=psutil.Process(child.pid).cpu_affinity()
   if set(row['actual_api_affinity'])!=set(row['cpu_affinity']):raise RuntimeError('model API CPU assignment changed')
  registry.observe();compute=gpu();expected=['GPU-b7729a10-0f62-16ed-e91b-65801dfa5ee9','GPU-026e4b6e-0b94-4bb1-706b-62975cf71531'][:len(records)]
  if len(compute)!=len(records) or {r.split(',')[1].strip() for r in compute}!=set(expected):raise RuntimeError('actual GPU engine identities do not match planned replicas')
  for row,gpu_uuid in zip(records,expected):
   pid=int(next(line.split(',')[0] for line in compute if gpu_uuid in line));process=psutil.Process(pid)
   if (pid,process.create_time()) not in registry.known:raise RuntimeError('model engine is not an owned API descendant')
   row.update(gpu_uuid=gpu_uuid,engine_pid=pid,engine_start_ticks=int(Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()[19]),engine_affinity=process.cpu_affinity())
   if set(row['engine_affinity'])!=set(row['cpu_affinity']):raise RuntimeError('model engine CPU assignment changed')
   (ROOT_MODEL/phase/('service-'+row['replica'][-1])/'ready-metrics.txt').write_bytes(api_get(row['endpoint'],'/metrics'))
  return records
 finally:
  result['startup_seconds_used']+=time.monotonic()-started;write()
def stop_services(records):
 for row in records:
  for child in services:
   if child.pid==row['api_pid'] and child.poll() is None and int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19])==row['api_start_ticks']:
    result['cleanup_actions'].append(dict(pid=child.pid,start_ticks=row['api_start_ticks'],signal='TERM',planned=True,at_ns=time.monotonic_ns()));child.terminate()
 until=time.monotonic()+35
 while any(child.poll() is None for child in services) and time.monotonic()<until:time.sleep(.2)
 for child in services:
  if child.poll() is None:
   row=next(r for r in result['services'] if r['api_pid']==child.pid)
   if int(Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19])==row['api_start_ticks']:
    result['forced_service_cleanup']=True;result['cleanup_actions'].append(dict(pid=child.pid,start_ticks=row['api_start_ticks'],signal='KILL',planned=False,at_ns=time.monotonic_ns()));child.kill();child.wait(timeout=5)
 registry.observe()
 # API termination must also settle its separately recorded engine process.
 for row in records:
  if 'engine_pid' in row:
   try:
    process=psutil.Process(row['engine_pid'])
    if int(Path('/proc',str(process.pid),'stat').read_text().rsplit(')',1)[1].split()[19])==row['engine_start_ticks'] and process.status()!=psutil.STATUS_ZOMBIE:
     result['forced_service_cleanup']=True;result['cleanup_actions'].append(dict(pid=process.pid,start_ticks=row['engine_start_ticks'],signal='TERM',planned=False,at_ns=time.monotonic_ns()));process.terminate();process.wait(timeout=10)
   except psutil.NoSuchProcess:pass
 if gpu():raise RuntimeError('GPU compute remains after owned service cleanup; stop next phase')
 if result['forced_service_cleanup']:raise RuntimeError('unplanned service cleanup used; preserve diagnostic and stop next phase')
 for row in records:row['api_exit']=next(c.returncode for c in services if c.pid==row['api_pid'])
def stop_signal(_signum,_frame):raise TimeoutError('outer model watchdog requested cleanup')
signal.signal(signal.SIGTERM,stop_signal)
try:
 resource_preflight()
 source_check=source_identity();author_check=author_identity();lease=acquire_host_runner_lease(Path(PREP['artifact_root']),repository_commit=STATE['source_head'])
 assets=json.loads((ROOT/'asset-check.json').read_text())
 if not assets['passed'] or assets['model_files_fingerprint']!=STATE['model_files_fingerprint']:raise RuntimeError('qualified model assets or versions differ')
 hardware=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,name,memory.total,driver_version','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
 if hardware.returncode:raise RuntimeError('actual GPU and driver identity could not be read')
 signature=dict(schema='semloom.sembench_original_q2_model_run_signature.v1',source_head=STATE['source_head'],actual_source_check=source_check,state=STATE,asset_preflight=assets,author_identity=author_check,model_preparation=PREP,model_harness_identity=json.loads((ROOT/'model-resume-harness-identity.json').read_text()),parent_continuation=PARENT,original_first_model_start=json.loads(FIRST_CLOCK_BYTES),gpu_driver_identity_rows=hardware.stdout.splitlines(),native_control_scope='unchanged public config from software qualification; no online tuning',logical_routing='one fixed full-values router for single and dual; caller-owner-router-model three sends',generation='actual original Q2 SDK values from fixed route manifest; temperature0/top_p1/max_completion_tokens8/stop newline/nonstream/cachefalse/retry0',single_orders=ORDERS,dual_orders=[list(reversed(v)) for v in ORDERS],services='fresh independent single-parallel replicas; BF16/context4096/max-seqs16/batched-token2048/memory0.8/eager/prefix-cache-off',recorded_before_continued_model_start_ns=time.monotonic_ns())
 save(ROOT_MODEL/'run-signature.json',signature)
 declarations=PRIOR['declarations']
 old_router_port=int(PRIOR['logical_router_endpoint'].split(':')[2].split('/')[0])
 os.environ['MODELRUN_MODEL_ENDPOINTS']=json.dumps(sum(declarations.values(),[]));os.environ.pop('MODELRUN_FIXTURE_URL',None);install()
 selected={'routes':None}
 def choose(route,body):
  if selected['routes'] is None:raise RuntimeError('no phase routing declaration active')
  return selected['routes'](route,body)
 def query_tag():
  with sqlite3.connect(ROOT/'sends.sqlite',timeout=10) as db:
   row=db.execute('SELECT phase,slot,unit FROM control WHERE id=1').fetchone()
  return None if row is None else '/'.join(row)
 router=ObservationGateway(bind_port=old_router_port,query_identity=query_tag,routes=(GatewayRoute('model-plan','model',declarations['quality'][0]),),trace_path=ROOT_MODEL/'router-http-trace.jsonl',request_timeout_s=30,preserve_http=True,select_upstream=choose)
 router.start();router_url=router.endpoint_url('model-plan','model');os.environ['MODELRUN_ROUTER_URL']=router_url;result['logical_router_endpoint']=router_url;result['declarations']=declarations;write()
 for phase in ('single','dual'):
  records=start_services(phase,declarations[phase]);seconds=STATE['matrix']['stages'][phase][2];started_ns=time.monotonic_ns();control(phase,started_ns,seconds,120);activate(phase,'phase-ready',time.time(),seconds,120)
  selected['routes']=FixedRequestRoutes({r['replica']:r['endpoint'] for r in records},MANIFEST['dual_assignments'] if phase=='dual' else MANIFEST['single_assignments']);router.reset_upstream_connections()
  root=ROOT_MODEL/phase;save(root/'model.json',dict(endpoint_url=router_url,model_id=STATE['model_id'],timeout_ms=30000,bearer_token_env='SEMBENCH_LOCAL_TOKEN'));env=base_env();env['SEMBENCH_MODEL_CONFIG']=str(root/'model.json');env['MODELRUN_ROUTER_URL']=router_url;env['MODELRUN_MODEL_ENDPOINTS']=json.dumps(declarations[phase])
  phase_result=dict(cases=[],started_ns=started_ns,seconds_limit=seconds,planned_logical=720 if phase=='quality' else 4320,hard_limits=STATE['matrix']['stages'][phase],route_manifest_sha256=selected['routes'].manifest_sha256,service_history_before=0);result['phases'][phase]=phase_result;write()
  orders=[list(range(6))] if phase=='quality' else [list(reversed(order)) if phase=='dual' else order for order in ORDERS]
  deadline=min(started_ns/1e9+seconds-120,json.loads((ROOT/'model-start.json').read_text())['deadline_monotonic_ns']/1e9-120)
  for round_index,order in enumerate(orders):
   for position,arm_index in enumerate(order):
    case=root/('round-'+str(round_index)+'-position-'+str(position)+'-'+ARMS[arm_index]);value=cli(ARMS[arm_index],0 if phase=='quality' else 1,'qualification' if phase=='quality' else 'performance',case,env,deadline,registry);phase_result['cases'].append(dict(round=round_index,position=position,**value));write()
    for cell in value['matrix']['cells']:
     unit=case/'output'/cell['unit_id'];protocols=[json.loads(line) for line in (unit/'protocols.jsonl').read_text().splitlines()]
     if Counter(request_values_sha256(p['request']) for p in protocols)!=Counter(MANIFEST['request_weights']):raise ValueError('original full request values multiset changed')
     summary=json.loads((unit/'summary.json').read_text())
     if summary['quality']['classification_audit']['invalid'] or summary['quality']['classification_audit']['missing_rows']:raise ValueError('original parser produced invalid or missing classifications')
     calls=json.loads((unit/'calls.json').read_text());decisions=json.loads((unit/'filter-decisions.json').read_text())
     if (not summary['identity']['original_method_preserved'] or summary['identity']['original_query']['commit']!='c814e3807e72d4cf876b852b17e77f3cc94575c2' or summary['identity']['original_query']['query_id']!=2):raise ValueError('original query or method identity changed')
     if (len(calls)!=120 or len({(c['row_id'],c['stage_id'],c['stage_ordinal'],c['call_id']) for c in calls})!=120 or {c['row_id'] for c in calls}!=ELIGIBLE_IDS or len(decisions)!=120 or {d[0] for d in decisions}!=ELIGIBLE_IDS):raise ValueError('original method occurrence or decision association differs')
     if phase=='quality' and summary['method_http_values_audit']['status']!='passed':raise ValueError('original method full request differential did not pass')
     if summary['native_http_audit']['readable_json_responses']!=120:raise ValueError('original SDK/parser did not receive every full response')
     save(unit/'model-method-check.json',dict(passed=True,original_method_preserved=True,original_query_preserved=True,original_occurrence_ids_checked=120,original_full_values_checked=True,original_sdk_parser_evaluator='actual public query path, no replacement parsing',method_http_values_audit=summary['method_http_values_audit'],quality=summary['quality']))
  actual=counts(phase);expected=phase_result['planned_logical']
  if actual!=dict(total=expected*3,gateway=expected,router=expected,model=expected,fixture=0):raise ValueError('actual three-hop phase accounting changed')
  phase_result.update(counts=actual,queries=len(phase_result['cases'])*(1 if phase=='quality' else 2),ended_ns=time.monotonic_ns())
  for record in records:(root/('service-'+record['replica'][-1])/'final-metrics.txt').write_bytes(api_get(record['endpoint'],'/metrics'))
  stop_services(records);selected['routes']=None;phase_result['cleanup_ended_ns']=time.monotonic_ns();phase_result['elapsed_seconds']=(phase_result['cleanup_ended_ns']-started_ns)/1e9
  if phase_result['elapsed_seconds']>seconds:raise TimeoutError('phase cleanup exceeded original phase deadline')
  phase_result['passed']=True;write()
 result['passed']=True
except BaseException as error:result.update(error_type=type(error).__name__,error=redact_text(str(error)));write()
finally:
 control('final-cleanup',time.monotonic_ns(),90,0)
 try:
  if router is not None:router.stop()
 except Exception as error:result['router_cleanup_error_type']=type(error).__name__
 registry.observe();result['fallback_processes_before_final_cleanup']=registry.live()
 if result['fallback_processes_before_final_cleanup']:registry.terminate()
 sampler_stop.set()
 if sampler is not None:sampler.join(5)
 result['cleanup']=registry.finish();result['gpu_after']=gpu();result['all_recorded_counts_including_software']=counts();result['per_phase_counts']={p:counts(p) for p in ('quality','single','dual')}
 if lease is not None:lease.release()
 for writer in writers:writer.close()
 started=ROOT/'model-start.json';result['elapsed_seconds']=None if not started.exists() else (time.monotonic_ns()-json.loads(started.read_text())['started_monotonic_ns'])/1e9
 result['original_first_clock_unchanged']=(ROOT/'model-start.json').read_bytes()==FIRST_CLOCK_BYTES
 result['passed']=result['passed'] and result['original_first_clock_unchanged'] and not result['fallback_processes_before_final_cleanup'] and not result['forced_service_cleanup'] and not result['cleanup']['owned_survivors'] and not result['cleanup']['affinity_violations'] and not result['gpu_after'] and not result.get('router_cleanup_error_type') and result['elapsed_seconds'] is not None and result['elapsed_seconds']<=5100 and result['startup_seconds_used']<=900
 write()
raise SystemExit(not result['passed'])
