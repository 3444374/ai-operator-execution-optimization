"""Outer 300-second watchdog including startup, fixture threads and cleanup."""
import json,os,signal,subprocess,time,uuid
from support import ROOT,STATE,Registry,save

os.sched_setaffinity(0,set(STATE['software_cpus']))
if (ROOT/'software').exists():raise RuntimeError('software window already has evidence; no automatic repeat')
started=time.monotonic();epoch=time.time();maximum=STATE['minimal_sync_public_cli_software']['max_seconds'];token='software-'+uuid.uuid4().hex
registry=Registry(token,set(STATE['software_cpus']));env=dict(os.environ,MODELRUN_SCOPE=token,MODELRUN_SOFTWARE_STARTED_MONOTONIC=str(started),MODELRUN_SOFTWARE_STARTED_EPOCH=str(epoch),MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0')
command=[STATE['driver_python'],'-B',str(ROOT/'validation/software.py')]
with (ROOT/'software.stdout.log').open('wb') as out,(ROOT/'software.stderr.log').open('wb') as err:
 child=subprocess.Popen(command,cwd=ROOT/'source',env=env,stdout=out,stderr=err,start_new_session=True);registry.add(child)
 save(ROOT/'software-launch.json',dict(argv=command,pid=child.pid,started_epoch=epoch,started_monotonic=started,limit_seconds=maximum,cleanup_signal_seconds=maximum-60,force_cleanup_seconds=maximum-20,scope=token))
 interrupted=False;forced=False
 while child.poll() is None:
  elapsed=time.monotonic()-started
  if elapsed>=maximum-60 and not interrupted:
   child.send_signal(signal.SIGTERM);interrupted=True
  if elapsed>=maximum-20:
   registry.terminate();forced=True;break
  time.sleep(.1)
 if registry.live():registry.terminate()
cleanup=registry.finish();elapsed=time.monotonic()-started
result=dict(returncode=child.poll(),elapsed_seconds=elapsed,limit_seconds=maximum,work_stop_sent=interrupted,forced_cleanup=forced,cleanup=cleanup,model_requests=0,gpu=0)
result['passed']=child.poll()==0 and not interrupted and not forced and elapsed<=maximum and not cleanup['owned_survivors'] and not cleanup['affinity_violations']
save(ROOT/'software-watchdog.json',result);print(json.dumps(result));raise SystemExit(not result['passed'])
