"""Refuse startup if the requested accounting or observer cannot load."""
import os,sys
try:
 if os.environ.get('MODELRUN_ACCOUNT')=='1':
  # The author's Ray runtime retains its UDF-directory PYTHONPATH. An owned
  # sitecustomize symlink in that directory loads this same diagnostic helper.
  sys.path.insert(0,os.path.join(os.environ['MODELRUN_ROOT'],'validation'))
  sys.path.insert(1,os.path.join(os.environ['MODELRUN_ROOT'],'source','code'))
  from pre_send_ledger import install
  install()
 if os.environ.get('MODELRUN_QUERY_OBSERVER')=='1' and 'src.experiments.postgresql.sembench_query_cli' in sys.orig_argv:
  from query_observer import install
  install()
  if '--execute' in sys.orig_argv:
   from pre_send_ledger import await_cli_release
   await_cli_release()
except BaseException as error:
 # Python normally continues after a sitecustomize exception. This run cannot.
 try:os.write(2,('required run bootstrap failed: '+type(error).__name__+'\n').encode())
 finally:os._exit(78)
