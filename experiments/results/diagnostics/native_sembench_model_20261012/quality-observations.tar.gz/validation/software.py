"""Two synchronous original Q2 public CLI cells; independent software allowance."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib,json,os,signal,socket,threading,time,uuid
from pre_send_ledger import activate,counts,initialize,claim_fixture
from support import ROOT,STATE,ARMS,Registry,base_env,cli,save,author_identity,source_identity

os.sched_setaffinity(0,set(STATE['software_cpus']));initialize()
root=ROOT/'software';root.mkdir(exist_ok=False)
started=float(os.environ['MODELRUN_SOFTWARE_STARTED_MONOTONIC']);epoch=float(os.environ['MODELRUN_SOFTWARE_STARTED_EPOCH'])
maximum=STATE['minimal_sync_public_cli_software']['max_seconds'];activate('software','preflight',epoch,maximum,60)
save(root/'started.json',dict(started_epoch=epoch,deadline_epoch=epoch+maximum,started_monotonic=started,seconds_limit=maximum,logical_limit=256,post_limit=512,source_head=STATE['source_head'],timer_scope='outer supervisor launch before author startup and public CLI readonly preflights; includes cleanup'))
receipts=[];lock=threading.Lock();fixture_errors=[]
class Handler(BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def do_POST(self):
  value=None
  try:
   raw=self.rfile.read(int(self.headers['Content-Length']));sequence=claim_fixture(raw);body=json.loads(raw)
   signature=hashlib.sha256(json.dumps(body['messages'],sort_keys=True,ensure_ascii=False).encode()).hexdigest();answer='True' if int(signature[-2:],16)%2==0 else 'False'
   value=dict(reserved_sequence=sequence,start_ns=time.monotonic_ns(),body_sha256=hashlib.sha256(raw).hexdigest(),messages_sha256=signature,answer=answer,end_ns=None)
   with lock:receipts.append(value)
   result=json.dumps(dict(id='software-fixture',object='chat.completion',created=1,model=STATE['model_id'],choices=[dict(index=0,message=dict(role='assistant',content=answer),finish_reason='stop')],usage=dict(prompt_tokens=2,completion_tokens=1,total_tokens=3))).encode()
   self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(result)));self.end_headers();self.wfile.write(result)
  except Exception as error:
   with lock:fixture_errors.append(dict(error_type=type(error).__name__,at_ns=time.monotonic_ns()))
   self.close_connection=True
  finally:
   if value is not None:value['end_ns']=time.monotonic_ns()
 def log_message(self,*_args):pass
class TrackedServer(ThreadingHTTPServer):
 daemon_threads=False
 block_on_close=False
 def __init__(self,*args):
  self.connections={};self.request_threads={};self.activity_lock=threading.Lock();super().__init__(*args)
 def process_request_thread(self,request,client):
  request.settimeout(3);identity=threading.get_ident()
  with self.activity_lock:self.connections[identity]=request;self.request_threads[identity]=threading.current_thread()
  try:super().process_request_thread(request,client)
  finally:
   with self.activity_lock:self.connections.pop(identity,None)
 def finish_connections(self,deadline):
  self.shutdown();self.server_close()
  with self.activity_lock:connections=list(self.connections.values());threads=list(self.request_threads.values())
  for connection in connections:
   try:connection.shutdown(socket.SHUT_RDWR)
   except OSError:pass
   connection.close()
  for thread in threads:thread.join(max(0,min(3,deadline-time.monotonic())))
  with self.activity_lock:return dict(active_connections=len(self.connections),request_threads_alive=[t.name for t in self.request_threads.values() if t.is_alive()])
def stop_signal(_signum,_frame):raise TimeoutError('outer software watchdog requested cleanup')
signal.signal(signal.SIGTERM,stop_signal)
server=TrackedServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever);thread.start()
endpoint='http://127.0.0.1:'+str(server.server_port)+'/v1/chat/completions';os.environ['MODELRUN_FIXTURE_URL']=endpoint
registry=Registry('software-'+uuid.uuid4().hex,set(STATE['software_cpus']));report=dict(passed=False,cases=[],models=0,gpu=0,response_role='messages-only SHA-derived semantic fixture, no labels',data_role='original_movie_sf2000',source_head=STATE['source_head'])
try:
 report['actual_source_checked']=source_identity();report['author_identity_checked']=bool(author_identity())
 assets=json.loads((ROOT/'asset-check.json').read_text())
 if not assets['passed'] or assets['source_head']!=STATE['source_head']:raise RuntimeError('readonly asset/runtime preflight has not passed')
 env=base_env();env['MODELRUN_FIXTURE_URL']=endpoint;model=root/'model.json';save(model,dict(endpoint_url=endpoint,model_id=STATE['model_id'],timeout_ms=30000,bearer_token_env='SEMBENCH_LOCAL_TOKEN'));env['SEMBENCH_MODEL_CONFIG']=str(model)
 for arm in ARMS[4:]:
  item=cli(arm,0,'qualification',root/('cell-'+str(len(report['cases']))),env,started+maximum-60,registry);report['cases'].append(item)
  save(root/'progress.json',dict(cases=len(report['cases']),counts=counts('software'),elapsed=time.monotonic()-started))
 if counts('software')!=dict(total=480,gateway=240,router=0,model=0,fixture=240) or len(receipts)!=240 or any(r['end_ns'] is None for r in receipts) or fixture_errors:raise ValueError('complete software calls/two-hop accounting failed')
 report['passed']=True
except BaseException as error:
 report.update(error_type=type(error).__name__,error=str(error));registry.terminate()
finally:
 fixture_cleanup=server.finish_connections(started+maximum-10);thread.join(3)
 report.update(counts=counts('software'),elapsed_seconds=time.monotonic()-started,cleanup=registry.finish(),fixture_thread_alive=thread.is_alive(),fixture_receipts=receipts,fixture_errors=fixture_errors,fixture_cleanup=fixture_cleanup)
 report['passed']=report['passed'] and report['elapsed_seconds']<=maximum and not report['cleanup']['owned_survivors'] and not report['cleanup']['affinity_violations'] and not thread.is_alive() and not fixture_cleanup['active_connections'] and not fixture_cleanup['request_threads_alive']
 save(root/'result.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ('cases','fixture_receipts','cleanup')}))
raise SystemExit(not report['passed'])
