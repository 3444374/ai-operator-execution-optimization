"""Original request manifest and real cached tokenizer preflight; no model start."""
from collections import Counter
import hashlib,json,os,subprocess,time
from pathlib import Path
from support import ROOT,STATE,SOURCE,save,source_identity,author_identity
from src.experiments.fixed_request_routes import request_values_sha256
from src.infrastructure.environment import load_env_file
os.sched_setaffinity(0,set(STATE['driver_cpus']))
if not json.loads((ROOT/'software-watchdog.json').read_text())['passed']:raise RuntimeError('sync public-entry software has not passed')
root=ROOT/'model-preparation';root.mkdir(exist_ok=False);source_identity();author_identity()
values=[]
for ordinal in (0,1):
 matrix=json.loads((ROOT/'software'/('cell-'+str(ordinal))/'output/matrix.json').read_text());unit=matrix['cells'][0]['unit_id'];path=ROOT/'software'/('cell-'+str(ordinal))/'output'/unit/'protocols.jsonl'
 request=[json.loads(line)['request'] for line in path.read_text().splitlines()]
 if len(request)!=120:raise RuntimeError('original Q2 occurrence count changed')
 for value in request:
  if (value['model']!=STATE['model_id'] or value['temperature']!=0 or value['top_p']!=1 or value['max_completion_tokens']!=8 or value['stop']!=['\n']):raise ValueError('original Q2 generation values changed')
 values.append(request)
if Counter(request_values_sha256(v) for v in values[0])!=Counter(request_values_sha256(v) for v in values[1]):raise ValueError('two original author request value multisets differ')
weights=Counter(request_values_sha256(v) for v in values[0]);loads=[0,0];dual={}
for key,weight in sorted(weights.items(),key=lambda p:(-p[1],p[0])):
 replica=0 if loads[0]<=loads[1] else 1;dual[key]='gpu'+str(replica);loads[replica]+=weight
manifest=dict(source_head=STATE['source_head'],query_id=2,relation_rows=2000,eligible_occurrences=120,request_weights=dict(weights),single_assignments={key:'gpu0' for key in weights},dual_assignments=dual,dual_occurrence_loads=loads,selection='immutable full JSON value digest, duplicates stay together, unknown refused, no retry or failover')
save(root/'route-manifest.json',manifest);save(root/'original-requests-private.json',values[0])
program='''import json,os,sys
from pathlib import Path
from transformers import AutoTokenizer
model=Path(sys.argv[1]);values=json.loads(Path(sys.argv[2]).read_text());tokenizer=AutoTokenizer.from_pretrained(model,local_files_only=True);rows=[]
for index,value in enumerate(values):
 tokens=tokenizer.apply_chat_template(value['messages'],tokenize=True,add_generation_prompt=True,return_dict=False,truncation=False,padding=False)
 if not isinstance(tokens,list) or not all(type(t) is int for t in tokens):raise ValueError('actual tokenizer result has unsupported shape')
 count=len(tokens);maximum=value['max_completion_tokens']
 if count+maximum>4096:raise ValueError('complete original prompt plus generation exceeds 4096; no truncation allowed')
 rows.append(dict(occurrence=index,prompt_tokens=count,max_generation_tokens=maximum,total_capacity_tokens=count+maximum))
print(json.dumps(dict(passed=True,tokenizer_class=type(tokenizer).__name__,rows=rows,requests=0,models=0,gpu=0)))
'''
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',MODELRUN_ACCOUNT='0',MODELRUN_QUERY_OBSERVER='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
r=subprocess.run([STATE['service_python'],'-B','-c',program,STATE['model_path'],str(root/'original-requests-private.json')],capture_output=True,text=True,timeout=90,env=env)
(root/'tokenizer.stderr.log').write_text(r.stderr)
if r.returncode:raise RuntimeError('existing real tokenizer preflight failed')
tokens=json.loads(r.stdout);save(root/'real-tokenizer.json',tokens)
artifact_root=Path(load_env_file(Path(STATE['runtime_env']))['ARTIFACT_ROOT']).resolve()
report=dict(passed=True,source_head=STATE['source_head'],route_manifest_sha256=hashlib.sha256((root/'route-manifest.json').read_bytes()).hexdigest(),request_unique_values=len(weights),request_occurrences=sum(weights.values()),dual_occurrence_loads=loads,real_prompt_token_min=min(r['prompt_tokens'] for r in tokens['rows']),real_prompt_token_max=max(r['prompt_tokens'] for r in tokens['rows']),generation_max=8,context=4096,artifact_root=str(artifact_root),models_started=0,model_requests=0)
save(root/'result.json',report);print(json.dumps(report))
