"""GET-only metrics around each original public query; overhead retained."""
import json,os,sys,time,urllib.request
from pathlib import Path
from pre_send_ledger import unit
ROOT=Path(os.environ['MODELRUN_ROOT'])
def metrics():
 result=[]
 for endpoint in json.loads(os.environ.get('MODELRUN_MODEL_ENDPOINTS','[]')):
  base=endpoint.rsplit('/v1/chat/completions',1)[0]
  at=time.monotonic_ns()
  try:
   request=urllib.request.Request(base+'/metrics',headers={'Authorization':'Bearer ***'})
   with urllib.request.urlopen(request,timeout=3) as r:text=r.read().decode()
   result.append(dict(endpoint=base,started_ns=at,ended_ns=time.monotonic_ns(),text=text))
  except Exception as error:result.append(dict(endpoint=base,started_ns=at,error_type=type(error).__name__))
 return result
def install():
 from src.experiments.postgresql.persistent_native_adapter_query import PersistentAdapterGroup
 original=PersistentAdapterGroup.run
 def observed(self,*args,**kwargs):
  identity=kwargs['unit_id'];unit(identity);record=dict(unit_id=identity,phase=kwargs.get('phase'),slot=os.environ.get('MODELRUN_SLOT'),before=metrics(),started_ns=time.monotonic_ns())
  failure=None
  try:return original(self,*args,**kwargs)
  except BaseException as error:
   failure=error;record['query_error_type']=type(error).__name__;raise
  finally:
   try:
    record.update(ended_ns=time.monotonic_ns(),after=metrics())
    target=Path(os.environ['MODELRUN_OBSERVER_DIR']);target.mkdir(exist_ok=True)
    (target/(identity+'-metrics.json')).write_text(json.dumps(record,indent=2)+'\n')
   except Exception as error:
    if failure is not None:failure.add_note('Query observation save failed: '+type(error).__name__)
    try:os.write(2,('query observer save failed: '+type(error).__name__+'\n').encode())
    except OSError:pass
    if failure is None:raise
 PersistentAdapterGroup.run=observed
