"""Read existing assets, machine profile and code; no model/service startup."""
import hashlib,importlib.util,json,os,subprocess,time
from pathlib import Path
ROOT=Path(os.environ['MODELRUN_ROOT']);STATE=json.loads((ROOT/'state.json').read_text());SOURCE=ROOT/'source'
os.sched_setaffinity(0,set(STATE['driver_cpus']))
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
identity=json.loads((ROOT/'source-identity.json').read_text())
for n,d in identity['files'].items():
 if sha(SOURCE/n)!=d:raise ValueError('fixed source copy differs: '+n)
model=Path(STATE['model_path']);files={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(model.iterdir()) if p.is_file() and (p.suffix in ('.json','.safetensors') or p.name in ('merges.txt','vocab.json'))}
fingerprint=hashlib.sha256(json.dumps(files,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
if fingerprint!=STATE['model_files_fingerprint']:raise ValueError('existing cached model identity changed')
report=dict(source_head=STATE['source_head'],source_files_verified=len(identity['files']),model_file_sha256=files,model_files_fingerprint=fingerprint,models_started=0,model_requests=0,groups=['core','text','semantic-benchmarks'],cpu_affinity=sorted(os.sched_getaffinity(0)))
env=dict(os.environ,PYTHONPATH=str(SOURCE/'code'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',LITELLM_LOCAL_MODEL_COST_MAP='True')
command=[STATE['driver_python'],'-B',str(SOURCE/'code/scripts/environment/manage_environment.py'),'--env-file',STATE['runtime_env'],'check','--groups','core,text,semantic-benchmarks','--json-out',str(ROOT/'runtime-preflight.json')]
r=subprocess.run(command,cwd=SOURCE,env=env,capture_output=True,text=True,timeout=90)
(ROOT/'runtime-preflight.log').write_text(r.stdout+r.stderr);report['runtime_preflight_returncode']=r.returncode
if r.returncode:report['runtime_failure']=True
program="import importlib.metadata,importlib.util,json,pathlib,hashlib; names=['vllm','torch','transformers']; package=pathlib.Path(importlib.util.find_spec('vllm').origin).parent; files={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.rglob('*.py'))};print(json.dumps(dict(versions={n:importlib.metadata.version(n) for n in names},vllm_source_files=files)))"
r=subprocess.run([STATE['service_python'],'-B','-c',program],capture_output=True,text=True,env=env,timeout=30)
if r.returncode:raise RuntimeError('existing service software unavailable')
report['serving']=json.loads(r.stdout)
author=Path(STATE['author_root']);build=json.loads((author/'artifacts/build-patched/build-identity.json').read_text())
for n,d in {**build['original_sha256'],**build['patched_sha256']}.items():
 if sha(author/'source'/n)!=d:raise ValueError('original author source changed')
for n,d in build['binaries_sha256'].items():
 if sha(author/'prefix-patched'/n)!=d:raise ValueError('original author binary changed')
report['author_identity_verified']=True
bridge=Path(STATE['bridge_binary']);manifest=json.loads(bridge.with_suffix('.build.json').read_text())
if manifest['returncode'] or sha(bridge)!=manifest['binary_sha256'] or sha(SOURCE/'code/integrations/sema/imlane_http.cpp')!=manifest['source_sha256']:raise ValueError('existing original bridge changed')
report['bridge_sha256']=sha(bridge);report['passed']=report['runtime_preflight_returncode']==0
(ROOT/'asset-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('model_file_sha256','serving')}))
raise SystemExit(not report['passed'])
