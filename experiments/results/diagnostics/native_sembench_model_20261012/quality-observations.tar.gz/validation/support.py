"""Private lifecycle and public CLI orchestration; fixed source stays unchanged."""
from collections import Counter
from contextlib import contextmanager
from dataclasses import asdict
import hashlib,importlib.util,json,os,signal,socket,subprocess,sys,threading,time,uuid
from pathlib import Path
from types import SimpleNamespace
import psutil
from pre_send_ledger import counts,slot,start_ticks,harness_identity
ROOT=Path(os.environ['MODELRUN_ROOT']);STATE=json.loads((ROOT/'state.json').read_text());SOURCE=ROOT/'source';VALIDATION=ROOT/'validation'
sys.path.insert(0,str(SOURCE/'code'))
from src.baselines.common.redact import redact_text
from src.baselines.common.private_artifacts import write_private_json
ARMS=STATE['matrix']['arms']
def save(path,value):
 path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def source_identity():
 identity=json.loads((ROOT/'source-identity.json').read_text())
 if identity['source_head']!=STATE['source_head']:raise ValueError('source identity commit changed')
 for name,value in identity['files'].items():
  if digest(SOURCE/name)!=value:raise ValueError('actual source file changed: '+name)
 return dict(source_head=identity['source_head'],source_files_verified=len(identity['files']))
def bootstrap(pid,namespace=None,require_live=True):
 value=json.loads((ROOT/'bootstrap'/f'{pid}.json').read_text())
 if value['pid']!=pid or value['helper_identity']!=harness_identity() or not value['installed'] or 'aiohttp' not in value['hooks']:raise RuntimeError('required effective send bootstrap differs')
 if require_live and start_ticks(pid)!=value['start_ticks']:raise RuntimeError('bootstrap process identity changed')
 if namespace is not None and value.get('namespace')!=namespace:raise RuntimeError('author bootstrap namespace differs')
 return value
def release_cli(child,deadline):
 target=ROOT/'bootstrap'/f'{child.pid}.json'
 until=min(deadline,time.monotonic()+20)
 while True:
  if child.poll() is not None:raise RuntimeError('public CLI exited before bootstrap confirmation')
  if target.exists():
   value=bootstrap(child.pid)
   if value.get('cli_waiting'):break
  if time.monotonic()>=until:raise TimeoutError('public CLI send bootstrap confirmation timed out')
  time.sleep(.02)
 save(target.with_name(f'{child.pid}.release.json'),dict(pid=child.pid,start_ticks=value['start_ticks'],helper_identity=value['helper_identity']))
 return value
def gpu():
 r=subprocess.run(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_gpu_memory','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
 if r.returncode:raise RuntimeError('actual GPU compute query failed')
 return r.stdout.splitlines()
def base_env():
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(VALIDATION)+os.pathsep+str(SOURCE/'code'),CUDA_VISIBLE_DEVICES='',MODELRUN_ROOT=str(ROOT),MODELRUN_ACCOUNT='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',LITELLM_LOCAL_MODEL_COST_MAP='True',RAY_USAGE_STATS_ENABLED='0',RAY_DEDUP_LOGS='0',NO_PROXY='127.0.0.1,localhost,::1',LD_PRELOAD='/usr/lib/x86_64-linux-gnu/libstdc++.so.6')
 for n in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy','RAY_ADDRESS','PYTHONHOME'):env.pop(n,None)
 env.update(SEMBENCH_CHECKOUT=STATE['data']['checkout'],SEMBENCH_MOVIE_MANIFEST=STATE['data']['manifest'],SEMBENCH_MOVIE_CSV=STATE['data']['csv'],SEMBENCH_TOKENIZER=str(Path(STATE['model_path'])/'tokenizer.json'),SEMBENCH_RAY_PARENT=STATE['ray_parent'],SEMBENCH_LOCAL_TOKEN='local-fixture')
 return env
class Registry:
 def __init__(self,token,cpus):self.token=token;self.cpus=set(cpus);self.known={};self.roots={};self.violations=[];self.lock=threading.Lock();self.stop=threading.Event();self.thread=threading.Thread(target=self.watch,daemon=True);self.thread.start()
 def add(self,process):
  p=psutil.Process(process.pid)
  with self.lock:self.roots[p.pid]=p.create_time();self.known[(p.pid,p.create_time())]=dict(pid=p.pid,born=p.create_time(),name=p.name(),affinity=p.cpu_affinity())
 def observe(self):
  with self.lock:roots=dict(self.roots)
  family=[]
  for pid,born in roots.items():
   try:
    p=psutil.Process(pid)
    if p.create_time()==born:family.extend([p,*p.children(recursive=True)])
   except psutil.Error:pass
  for p in family:
   try:
    mask=p.cpu_affinity();row=dict(pid=p.pid,born=p.create_time(),name=p.name(),affinity=mask)
    with self.lock:self.known[(p.pid,p.create_time())]=row
    if not set(mask)<=self.cpus:self.violations.append(row)
   except psutil.Error:pass
 def watch(self):
  while not self.stop.wait(.15):self.observe()
 def bootstraps(self,namespace):
  values=[]
  for path in (ROOT/'bootstrap').glob('*.json'):
   if '.release.' in path.name:continue
   row=json.loads(path.read_text())
   if row.get('namespace')!=namespace:continue
   try:
    value=bootstrap(row['pid'],namespace)
    process=psutil.Process(row['pid'])
    if not process.is_running() or process.status()==psutil.STATUS_ZOMBIE:continue
    with self.lock:owned=(process.pid,process.create_time()) in self.known
    if owned:values.append(dict(**value,process_name=process.name(),command=process.cmdline()))
   except (psutil.Error,OSError):continue
  return values
 def live(self):
  values=[]
  with self.lock:known=dict(self.known)
  for (pid,born),row in known.items():
   try:
    p=psutil.Process(pid)
    if p.create_time()==born and p.is_running() and p.status()!=psutil.STATUS_ZOMBIE:values.append(row)
   except psutil.Error:pass
  return values
 def terminate(self):
  self.observe();live=[]
  for row in self.live():
   try:
    p=psutil.Process(row['pid'])
    if p.create_time()!=row['born']:continue
    p.terminate();live.append(p)
   except psutil.Error:pass
  _,alive=psutil.wait_procs(live,timeout=4)
  for p in alive:
   try:
    if any(p.pid==row['pid'] and p.create_time()==row['born'] for row in self.live()):p.kill()
   except psutil.Error:pass
  psutil.wait_procs(alive,timeout=3)
 def finish(self):self.observe();self.stop.set();self.thread.join(2);return dict(processes=list(self.known.values()),owned_survivors=self.live(),affinity_violations=self.violations)
def author_identity():
 author=Path(STATE['author_root']);identity=json.loads((author/'artifacts/build-patched/build-identity.json').read_text())
 if identity['upstream_commit']!='072f8257db80569e42c9f5727d839587df529652' or identity['mode']!='patched':raise ValueError('original author build identity changed')
 for n,h in {**identity['original_sha256'],**identity['patched_sha256']}.items():
  if digest(author/'source'/n)!=h:raise ValueError('author source changed: '+n)
 for n,h in identity['binaries_sha256'].items():
  if digest(author/'prefix-patched'/n)!=h:raise ValueError('author binary changed: '+n)
 helper_path=author/'harness/code/integrations/imlane/verify.py'
 if digest(helper_path)!=identity['owned_sha256']['verify.py']:raise ValueError('checked author lifecycle helper changed')
 bridge=Path(STATE['bridge_binary']);linked=json.loads(bridge.with_suffix('.build.json').read_text())
 if linked['returncode'] or linked['binary_sha256']!=digest(bridge) or linked['source_sha256']!=digest(SOURCE/'code/integrations/sema/imlane_http.cpp'):raise ValueError('original capacity bridge identity changed')
 return identity
@contextmanager
def author_mode(mode,out,env,registry):
 if mode is None:yield {};return
 path=SOURCE/'code/integrations/sema/verify_imlane_async_calls.py';spec=importlib.util.spec_from_file_location('checked_lifecycle',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 module.KERNEL=SOURCE/'code/integrations/sema/imlane_complete_call.py'
 helper_path=Path(STATE['author_root'])/'harness/code/integrations/imlane/verify.py';spec=importlib.util.spec_from_file_location('checked_author_helper',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
 class ObservedHelper:
  def __getattr__(self,name):return getattr(helper,name)
  def spawn(self,command,worker_env,*args,**kwargs):
   updated=dict(worker_env,PYTHONPATH=str(VALIDATION)+os.pathsep+worker_env['PYTHONPATH'])
   process,writer=helper.spawn(command,updated,*args,**kwargs);registry.add(process);return process,writer
 args=SimpleNamespace(author_root=Path(STATE['author_root']),bridge_binary=Path(STATE['bridge_binary']),output=out,scopes=[],stop_budget=module.StopBudget(threading.Event()))
 report=dict(cleanup=[],cleanup_errors=[]);previous=dict(os.environ)
 os.environ.update(env)
 try:
  with module.AuthorScope(args,mode,ObservedHelper(),report) as scope:
   if scope.meta!={'native_executors':4,'native_task_threads':6}:raise ValueError('declared original author thread settings changed')
   target=out/'call-config.json';write_private_json(target,asdict(scope.config));env['SEMBENCH_IMLANE_CONFIG']=str(target)
   until=time.monotonic()+15;identity=author_identity();worker_binaries=set(identity['binaries_sha256'].values())
   while True:
    registry.observe();bootstraps=registry.bootstraps(scope.namespace);workers=[]
    for value in bootstraps:
     process=psutil.Process(value['pid']);command=value['command']
     if mode=='cpython':
      if process.ppid()!=scope.service.pid or '--parent_pid' not in command or '--executor_id' not in command:continue
      if command[command.index('--parent_pid')+1]!=str(scope.service.pid) or digest(process.exe()) not in worker_binaries:continue
     elif not command or command[0]!='ray::ActorWrapper':continue
     workers.append(value)
    if len(workers)==2:break
    if time.monotonic()>=until:raise RuntimeError('two actual author executors/ActorWrapper PIDs have not confirmed effective send bootstrap')
    time.sleep(.05)
   save(out/'author-start.json',dict(runtime=mode,actual_meta=scope.meta,coordinator_pid=scope.service.pid,udf_path=str(module.KERNEL),udf_sha256=digest(module.KERNEL),declared_executors=2,declared_http_allowance=6,actual_worker_bootstraps=workers,registered_bootstraps=bootstraps,worker_identity_rule='original executable hash, Coordinator parent and executor argv' if mode=='cpython' else 'original synchronous Ray ActorWrapper process command'))
   yield {mode:'SEMBENCH_IMLANE_CONFIG'}
 finally:
  os.environ.clear();os.environ.update(previous);save(out/'author-cleanup.json',report)
 if not report['cleanup'] or not all(v['passed'] for v in report['cleanup']):raise RuntimeError('author mode cleanup failed')
def config(arm,warmups,mode,imlane):
 values=dict(schema='semloom.sembench_lotus_queries.v1',dataset=dict(checkout_env='SEMBENCH_CHECKOUT',manifest_env='SEMBENCH_MOVIE_MANIFEST',csv_env='SEMBENCH_MOVIE_CSV',manifest_content_digest=STATE['data']['manifest_content_digest']),arms=[arm],queries=[2],warmups=warmups,repeats=1,max_attempts=120*(warmups+1),model_config_env='SEMBENCH_MODEL_CONFIG',output_env='SEMBENCH_OUTPUT',native_options=dict(concurrency=6 if imlane else 4,num_threads=8,ray_actors=2,ray_async_batches_per_actor=2,ray_batch_rows=1,source_blocks=2),query_timeout_s=120,owner_timeout_s=480,tokenizer_env='SEMBENCH_TOKENIZER',lotus_observation_mode=mode)
 if imlane:values['imlane_config_envs']=imlane
 if arm in ('lotus-method-native-ray-data','lotus-method-semloom'):values['ray_temp_parent_env']='SEMBENCH_RAY_PARENT'
 if arm=='lotus-method-semloom':values.update(max_held_tasks=8,physical=dict(address='resolved',workers=2,batch_rows=2,window_bytes=2097152,object_bytes=8388608,payload_backend='daft'))
 return values
def cli(arm,warmups,observation,out,env,deadline,registry):
 out.mkdir(parents=True,exist_ok=False);case=out.name;slot(case);env=dict(env,MODELRUN_SLOT=case,MODELRUN_QUERY_OBSERVER='1',MODELRUN_OBSERVER_DIR=str(out/'query-metrics'),SEMBENCH_OUTPUT=str(out/'output'))
 mode='ray' if arm==ARMS[5] else 'cpython' if arm==ARMS[4] else None
 starts=time.monotonic_ns();before=counts()
 with author_mode(mode,out,env,registry) as imlane:
  args=config(arm,warmups,observation,imlane);write_private_json(out/'config.json',args)
  for action in ('--data-preflight','--preflight','--execute'):
   if time.monotonic()>=deadline:raise TimeoutError('remaining phase work time exhausted')
   argv=[STATE['driver_python'],'-B','-m','src.experiments.postgresql.sembench_query_cli','--config',str(out/'config.json'),action]
   with (out/(action[2:]+'.stdout.log')).open('w') as stdout,(out/(action[2:]+'.stderr.log')).open('w') as stderr:
    at=time.monotonic();child=subprocess.Popen(argv,cwd=SOURCE,env=env,stdout=stdout,stderr=stderr,start_new_session=True);registry.add(child)
    if action=='--execute':save(out/'driver-bootstrap.json',release_cli(child,deadline))
    while child.poll() is None:
     if time.monotonic()>=deadline:
      registry.terminate();raise TimeoutError('public CLI work deadline reached; owned resources stopped')
     time.sleep(.1)
   save(out/(action[2:]+'-command.json'),dict(argv=argv,returncode=child.returncode,seconds=time.monotonic()-at,source_head=STATE['source_head']))
   if child.returncode:raise RuntimeError('original public CLI '+action+' failed for '+arm)
  matrix=json.loads((out/'output/matrix.json').read_text())
  if matrix['status']!='passed' or len(matrix['cells'])!=warmups+1 or any(c['actual_posts']!=120 for c in matrix['cells']):raise ValueError('full original Q2 public query count/status failed')
 ended=time.monotonic_ns();facts=dict(arm=arm,warmups=warmups,observer_mode=observation,start_ns=starts,end_ns=ended,full_slot_seconds=(ended-starts)/1e9,matrix=matrix,count_before=before,count_after=counts())
 save(out/'slot-result.json',facts);return facts
