import json,unittest
from dataclasses import asdict
from src.execution_provider.multiplexed_gateway import MultiSessionMapGateway
from tests.execution_provider.test_multisession_gateway import MultiSessionGatewayTests
original=MultiSessionMapGateway.serve
def serve(self,*args,**kwargs):
 try:return original(self,*args,**kwargs)
 except Exception:
  print('DIAGNOSTIC',json.dumps({'error':self.engine.error,'records':[{**asdict(r),'task':{'sequence':r.task.sequence},'result':len(r.result),'result_metadata':len(r.result_metadata)} for r in self.engine.capacity.records.values()], 'sessions':[(s.session_id,str(s.state),s.error) for s in self.engine._sessions.values()], 'jobs':[(j.job_id,x.closing) for j,x in self.engine.jobs.jobs.items()]},default=str),flush=True)
  raise
MultiSessionMapGateway.serve=serve
for i in range(50):
 print('iteration',i,flush=True)
 result=unittest.TextTestRunner().run(unittest.TestSuite([MultiSessionGatewayTests('test_slow_send_retains_lease_while_other_job_runs')]))
 if not result.wasSuccessful():break
