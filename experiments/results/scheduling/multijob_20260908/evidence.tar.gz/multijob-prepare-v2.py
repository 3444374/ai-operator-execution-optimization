"""Prepare a fresh, bounded, private model-validation run without installing anything."""
import argparse,hashlib,json,os,pwd,shutil,subprocess,socket
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--check-root',type=Path,required=True)
p.add_argument('--real-root',type=Path,required=True)
p.add_argument('--manifest',required=True)
p.add_argument('--window',type=int,choices=(1,2),default=2)
p.add_argument('--driver',required=True)
p.add_argument('--budget',type=int,required=True)
p.add_argument('--fresh-port',action='store_true')
p.add_argument('--reference-profile',default='openai-compatible-fixed')
p.add_argument('--expected-extension-sha',required=True)
a=p.parse_args();old=Path('<data-root>/pga6/prepare')
a.real_root.mkdir();root=a.real_root/'prepare';root.mkdir()
s=json.loads((old/'settings.json').read_text());prior_config=s['config']
s.update(source=str(a.check_root/'source'),root=str(a.real_root/'run'),ledger=str(root/'ledger.jsonl'),
 budget_id=a.real_root.name,budget_limit=a.budget,source_commit='b6c341c9 plus multijob manifest',
 config=str(root/'model.json'),window=a.window,reference_profile=a.reference_profile)
s.pop('service_verification',None)
s['source_delta']=json.loads((a.check_root/a.manifest).read_text())
for n,d in s['source_delta'].items():assert hashlib.sha256((Path(s['source'])/n).read_bytes()).hexdigest()==d,n
s['extension_sha256']=hashlib.sha256((Path(s['prefix'])/'lib/postgresql/semloom_pg.so').read_bytes()).hexdigest()
assert s['extension_sha256']==a.expected_extension_sha
for name in ('launch.py','model-verification.json'):shutil.copyfile(old/name,root/name)
shutil.copyfile(a.check_root/a.driver,root/'real_check.py')
shutil.copyfile(prior_config,root/'model.json')
if a.fresh_port:
 with socket.socket() as probe:
  probe.bind(('127.0.0.1',0));s['model_port']=probe.getsockname()[1]
 s['service_args'][s['service_args'].index('--port')+1]=str(s['model_port'])
 config=json.loads((root/'model.json').read_text())
 config['endpoint_url']=f"http://127.0.0.1:{s['model_port']}/v1/chat/completions"
 (root/'model.json').write_text(json.dumps(config,indent=2)+'\n')
verified=json.loads((root/'model-verification.json').read_text())
for n,d in verified['files'].items():assert hashlib.sha256((Path(s['model_root'])/n).read_bytes()).hexdigest()==d,'model_mismatch'
(root/'settings.json').write_text(json.dumps(s,indent=2)+'\n')
user=pwd.getpwnam(s['pg_user'])
for path in [a.real_root,root,*root.iterdir()]:os.chown(path,user.pw_uid,user.pw_gid)
with (root/'preflight.log').open('w') as output:
 result=subprocess.run(['<data-root>/venvs/text-baselines/bin/python','code/scripts/environment/manage_environment.py','check',
  '--groups','core,text','--json-out',str(root/'preflight.json')],cwd=s['source'],
  env=dict(os.environ,AI_OPERATOR_ENV_FILE='<data-root>/ai-operator-runtime.env',PYTHONPATH='code'),stdout=output,stderr=subprocess.STDOUT)
assert result.returncode==0
print('verified source',len(s['source_delta']),'model files',len(verified['files']),'request budget',s['budget_limit'])
