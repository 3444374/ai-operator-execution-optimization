"""Ten real requests through two bounded method drivers; no PG or quality claim."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time

from src.baselines.common.redact import redact_text
from src.execution_provider.adapters.incremental_execution import build_fixed_model_execution
from src.execution_provider.adapters.model_config import load_fixed_model_config
from src.experiments.attempt_ledger import AttemptBudget, AttemptLedger, observe_async_http_posts
from src.semantic_methods.budget import MethodBudgetPool, MethodCapacity, row_reservation
from src.semantic_methods.continuation import Continue, Final, Request, MethodLimits
from src.semantic_methods.driver import MethodDriver, RowIdentity
from src.scheduling.core.session_contract import SessionSpec, TaskProfile


class CopyMethod:
    def __init__(self, model):
        self.model = model

    def request(self):
        payload = json.dumps(dict(model=self.model, temperature=0, max_tokens=16, messages=[
            {'role':'user','content':'Return only the input text exactly as received. Do not add or remove anything. Input: TRUE'}])).encode()
        return Request('model', payload, 1, 8192)

    def start(self, value):
        stages=int(value)
        return Continue(self.request(),str(stages).encode()) if stages else Final(b'TRUE')

    def resume(self, state, result):
        parsed=json.loads(result)
        assert parsed['model']==self.model
        choice,=parsed['choices']
        assert choice['finish_reason']=='stop'
        assert choice['message']['content']=='TRUE'
        assert parsed['usage']['completion_tokens']>0
        stages=int(state)-1
        return Continue(self.request(),str(stages).encode()) if stages else Final(b'TRUE')


def run(settings):
    root=Path(settings['root']);root.mkdir()
    source=Path(settings['source'])
    for name,sha in settings['source_delta'].items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest()==sha,name
    config=load_fixed_model_config(Path(settings['config']))
    ledger=AttemptLedger(Path(settings['ledger']),AttemptBudget(settings['budget_id'],12))
    assert ledger.attempts==0
    events=[]
    def observe(event):events.append(event)
    execution=build_fixed_model_execution(config,max_tasks=4,max_active_requests=2,max_jobs=2,observer=observe)
    limits=MethodLimits(input_bytes=4096,state_bytes=16,result_bytes=8192,stages=2)
    per_row=row_reservation(limits)
    pool=MethodBudgetPool(MethodCapacity(4,4*per_row))
    drivers=[];jobs=[];counts=[0,0];outputs=[{},{}]
    summary={'status':'incomplete','source_files':len(settings['source_delta']),'rows':8,'expected_posts':10}
    try:
        for i in range(2):
            job,session,_=execution.open_job(str(i),SessionSpec(str(i),'method','model',task_profiles=(TaskProfile('model','model'),)))
            jobs.append(job)
            drivers.append(MethodDriver(session,CopyMethod(config.model_id),limits,pool.allocate(MethodCapacity(2,2*per_row))))
        deadline=time.monotonic()+180
        iterations=0;peak_bytes=0;peak_runs=0
        with observe_async_http_posts(ledger,lambda attempt,payload:None):
            while not all(d.finished for d in drivers):
                assert time.monotonic()<deadline,'progress_timeout'
                for i,d in enumerate(drivers):
                    if counts[i]<4 and d.offer_row(RowIdentity(counts[i],f'call-{i}'),(b'0',b'1',b'2',b'2')[counts[i]]):
                        counts[i]+=1
                        if counts[i]==4:d.end_input()
                execution.engine.advance()
                for i,d in enumerate(drivers):
                    d.advance(2)
                    for result in d.results(2):
                        assert result.row.sequence not in outputs[i]
                        assert result.row.call_id==f'call-{i}' and result.value==b'TRUE'
                        outputs[i][result.row.sequence]=result.value.decode()
                        d.release_result(result.row)
                used_runs,used_bytes=pool.used
                peak_runs=max(peak_runs,used_runs);peak_bytes=max(peak_bytes,used_bytes)
                assert used_runs<=4 and used_bytes<=4*per_row
                iterations+=1
                time.sleep(.005)
        assert ledger.attempts==10 and counts==[4,4]
        assert all(len(o)==4 for o in outputs)
        assert pool.used==(0,0)
        assert execution.engine.capacity.usage().held_tasks==0
        summary.update(status='passed',requests=ledger.attempts,outputs=outputs,peak_runs=peak_runs,
            peak_reserved_bytes=peak_bytes,method_capacity_bytes=4*per_row,iterations=iterations)
    finally:
        for d in drivers:d.close()
        for j in jobs:execution.engine.close_job(j)
        until=time.monotonic()+130
        while execution.engine.capacity.usage().held_tasks and time.monotonic()<until:
            execution.engine.advance();time.sleep(.01)
        summary['backend_closed']=execution.close()
        summary['method_allocated']=pool.allocated
        summary['core_usage']=asdict(execution.engine.capacity.usage())
        summary['actual_posts']=ledger.attempts
        if not summary['backend_closed'] or pool.allocated!=(0,0) or summary['core_usage']['held_tasks']:
            summary['status']='incomplete'
        (root/'summary.json').write_text(redact_text(json.dumps(summary,indent=2))+'\n')
        (root/'events.jsonl').write_text(''.join(redact_text(json.dumps(e))+'\n' for e in events))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--settings',required=True)
    run(json.loads(Path(p.parse_args().settings).read_text()))
