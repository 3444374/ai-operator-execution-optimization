"""18-POST real PG diagnostic: shared Job engine, SQL association and cancellation isolation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pwd
import sys
import threading
import time
import psycopg
from psycopg import sql
from transformers import AutoTokenizer
from src.baselines.common.redact import redact_text
from src.experiments.attempt_ledger import AttemptBudget, AttemptLedger
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster, owned_child_process, wait_for_path
from src.execution_provider.semantic_map import SemanticMapPlan
from src.execution_provider.wire import v6

INSTRUCTION='Return only the input text exactly as received. Do not add or remove anything.'
def events(path):
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []
def until(predicate,label,seconds=30):
    deadline=time.monotonic()+seconds
    while not predicate():
        assert time.monotonic()<deadline,label
        time.sleep(.01)
def save(path,value):
    path.write_text(redact_text(json.dumps(value,indent=2,ensure_ascii=False))+'\n')

def run(settings):
    root=Path(settings['root']);root.mkdir();source=Path(settings['source'])
    for name,digest in settings['source_delta'].items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,'source_identity'
    assert hashlib.sha256((Path(settings['prefix'])/'lib/postgresql/semloom_pg.so').read_bytes()).hexdigest()==settings['extension_sha256']
    assert settings['budget_limit']==18
    config=json.loads(Path(settings['config']).read_text())
    ledger=AttemptLedger(Path(settings['ledger']),AttemptBudget(settings['budget_id'],18));assert ledger.attempts==0
    tokenizer=AutoTokenizer.from_pretrained(settings['model_root'],local_files_only=True)
    summary={'status':'incomplete','request_limit':18,'phases':{}}
    try:
        with isolated_pg18_cluster(Path(settings['prefix']),root,pwd.getpwuid(os.getuid()),port=settings['pg_port']) as conn:
            conn.execute('CREATE TABLE inputs(id integer,body text)')
            conn.execute('CREATE TABLE outputs(id integer,body text,generated text)')
            conn.execute('CREATE TABLE rejected(id integer CHECK(id<0),body text,generated text)')
            with conn.cursor() as cur:
                cur.executemany('INSERT INTO inputs VALUES(%s,%s)',[(1,'Hello, SemLoom.'),(2,'Blue sky.'),(3,None),(4,'Green garden.'),(5,'Quiet lake.')])
            parameters=dict(host=conn.info.host,port=conn.info.port,user=conn.info.user,dbname=conn.info.dbname,autocommit=True)
            options=json.dumps({'model':config['model_id'],'temperature':0,'max_tokens':128})
            expression=sql.SQL('ai_semantic.map(body,{},{}::jsonb)').format(sql.Literal(INSTRUCTION),sql.Literal(options))
            query=sql.SQL('SELECT id,body,{} FROM ONLY inputs').format(expression)
            queries={'A':query+sql.SQL(' WHERE id<3'),'B':query+sql.SQL(' WHERE id>3')}
            reference={}
            for mode in ('reference','incremental'):
                path=root/(mode+'-events.jsonl');sock=root/'socket'/(mode+'.sock')
                command=[sys.executable,'-m','src.experiments.choice_gateway_observer','--events',str(path),'--ledger',settings['ledger'],'--budget-id',settings['budget_id'],'--max-attempts','18','--','--socket',str(sock),'--fixed-model-config',settings['config'],'--max-active-requests','2']
                if mode=='incremental':command+=['--incremental-map','--max-active-jobs','2','--max-held-tasks','4','--max-connections','4']
                with owned_child_process(command,root,mode,dict(os.environ,PYTHONPATH=str(source/'code')),pwd.getpwuid(os.getuid())) as process:
                    wait_for_path(sock,process)
                    def configure(c):
                        c.execute("SELECT set_config('semloom_pg.gateway_socket',%s,false)",(str(sock),))
                        c.execute("SELECT set_config('semloom_pg.provider_execution_profile',%s,false)",('incremental-map' if mode=='incremental' else 'openai-compatible-fixed',))
                        c.execute('SET semloom_pg.provider_window_tasks=2')
                        c.execute("SET statement_timeout='120s'")
                    configure(conn)
                    before=ledger.attempts
                    assert conn.execute(query+sql.SQL(' LIMIT 0')).fetchall()==[]
                    assert conn.execute(query+sql.SQL(' WHERE id=3')).fetchall()==[(3,None,None)]
                    plan=conn.execute(sql.SQL('EXPLAIN(FORMAT JSON) ')+query).fetchone()[0]
                    assert ledger.attempts==before,'zero_controls'
                    if mode=='reference':
                        for name,q in queries.items():reference[name]=conn.execute(q).fetchall()
                        assert ledger.attempts==4
                        summary['phases']['reference']=reference
                        continue
                    assert 'semloom_incremental_map' in json.dumps(plan) and '"Semantic Input Window": 2' in json.dumps(plan)
                    def parallel(jobs):
                        barrier=threading.Barrier(len(jobs));results={};failures=[]
                        def work(name,q):
                            try:
                                with psycopg.connect(**parameters) as c:
                                    configure(c);barrier.wait(timeout=10)
                                    cursor=c.execute(q)
                                    results[name]=cursor.fetchall() if cursor.description else cursor.rowcount
                            except psycopg.Error as exc:results[name]={'sqlstate':exc.sqlstate}
                            except BaseException as exc:failures.append(type(exc).__name__)
                        workers=[threading.Thread(target=work,args=(name,q)) for name,q in jobs.items()]
                        for w in workers:w.start()
                        for w in workers:w.join(120)
                        assert not any(w.is_alive() for w in workers) and not failures,('parallel_workers',failures)
                        return results
                    rows=parallel(queries);assert rows==reference,'per_job_result_association'
                    assert ledger.attempts==8
                    summary['phases']['concurrent_select']=rows
                    # Hold A in a longer model request; cancellation must leave B usable.
                    cancelled=psycopg.connect(**parameters);configure(cancelled)
                    long_options=json.dumps({'model':config['model_id'],'temperature':0,'max_tokens':256})
                    long_query=sql.SQL('SELECT ai_semantic.map(body,{},{}::jsonb) FROM ONLY inputs WHERE id=1').format(sql.Literal('Write a detailed numbered list of one hundred facts about astronomy. Do not stop early.'),sql.Literal(long_options))
                    outcome=[]
                    def cancel_work():
                        try:cancelled.execute(long_query).fetchall();outcome.append('unexpected_success')
                        except psycopg.Error as exc:outcome.append(exc.sqlstate)
                    worker=threading.Thread(target=cancel_work);worker.start()
                    until(lambda:ledger.attempts==9,'A_request_started')
                    b_result=[];b_failure=[]
                    def b_work():
                        try:
                            with psycopg.connect(**parameters) as c:
                                configure(c);b_result.extend(c.execute(queries['B']).fetchall())
                        except BaseException as exc:b_failure.append(type(exc).__name__)
                    b_worker=threading.Thread(target=b_work);b_worker.start()
                    until(lambda:ledger.attempts>=10,'B_request_while_A_active')
                    assert worker.is_alive(),'cancel_before_A_completion'
                    cancelled.cancel();worker.join(30);b_worker.join(120);cancelled.close()
                    assert not worker.is_alive() and outcome==['57014'],'cancel_SQLSTATE'
                    assert not b_worker.is_alive() and not b_failure and b_result==reference['B'],'other_job_survives_cancel'
                    assert ledger.attempts==11
                    assert conn.execute(query+sql.SQL(' WHERE id=1 LIMIT 1')).fetchall()==reference['A'][:1]
                    assert ledger.attempts==12
                    summary['phases']['cancel_and_recovery']={'sqlstate':outcome[0],'B_rows':b_result,'limit_one':True}
                    inserts=parallel({name:sql.SQL('INSERT INTO outputs ')+q for name,q in queries.items()})
                    assert inserts=={'A':2,'B':2}
                    with psycopg.connect(**parameters) as audit:
                        assert audit.execute('SELECT * FROM outputs ORDER BY id').fetchall()==reference['A']+reference['B'],'independent_insert_audit'
                    assert ledger.attempts==16
                    rejected=parallel({'A':sql.SQL('INSERT INTO rejected ')+queries['A']+sql.SQL(' LIMIT 1'),'B':queries['B']+sql.SQL(' LIMIT 1')})
                    assert rejected=={'A':{'sqlstate':'23514'},'B':reference['B'][:1]}
                    assert conn.execute('SELECT count(*) FROM rejected').fetchone()[0]==0
                    assert ledger.attempts==18
                    until(lambda:len([e for e in events(path) if e['event']=='core_terminal'])==14,'all_authoritative_terminals')
                    until(lambda:len([e for e in events(path) if e['event']=='core_job_drained'])==9,'all_jobs_drained')
                    seen=events(path);active=set();peak=0;cross_job=False
                    mapping={e['engine_session_id']:e['job_id'] for e in seen if e['event']=='core_job_opened'}
                    for event in seen:
                        if event['event'] not in ('core_http_started','core_http_finished'):continue
                        key=(event['key']['session_id'],event['key']['sequence'])
                        if event['event']=='core_http_started':
                            assert key not in active;active.add(key);peak=max(peak,len(active))
                            cross_job |= len({mapping[k[0]] for k in active})==2
                            assert len(active)<=2
                        else:active.remove(key)
                    assert peak==2 and cross_job and not active,'real_cross_job_overlap'
                    submitted=[e for e in seen if e['event']=='core_submitted']
                    terminals=[e for e in seen if e['event']=='core_terminal']
                    def keys(items):return [(e['key']['session_id'],e['key']['sequence']) for e in items]
                    assert len(set(keys(submitted)))==14 and sorted(keys(submitted))==sorted(keys(terminals)),'exactly_once_task_terminal'
                    drained=[e for e in seen if e['event']=='core_job_drained']
                    assert all(not any(e['usage'].values()) for e in drained),'job_credits_zero'
                    requests=[e['body'] for e in seen if e['event']=='request']
                    for result in [e for e in seen if e['event']=='core_map_completion']:
                        matches=[]
                        for body in requests:
                            spec=SemanticMapPlan(body['messages'][0]['content'],body['model'],body['max_tokens'])
                            digest=v6.build_task_message(spec,sequence=0,input_value=body['messages'][1]['content'])['semantic_payload_digest']
                            if digest==result['payload_digest']:matches.append(body)
                        assert matches and result['response_model_id']==config['model_id']
                        body=matches[0]
                        assert result['prompt_tokens']==len(tokenizer.apply_chat_template(body['messages'],tokenize=True,add_generation_prompt=True,return_dict=False))
                        assert 0<result['output_tokens']<=body['max_tokens']
                    summary.update(http_peak=peak,cross_job_overlap=cross_job,incremental_tasks=14,drained_jobs=9,resources_zero=True)
                    summary['phases']['insert_and_error']={'inserted':4,'failed_insert_SQLSTATE':'23514','failed_rows':0,'other_job_rows':rejected['B']}
                closed=[e for e in events(path) if e['event']=='core_transport_closed']
                assert len(closed)==1 and closed[0]['closed'] and not any(closed[0]['usage'].values())
                assert not sock.exists()
        assert not (root/'data/postmaster.pid').exists()
        summary['status']='passed'
    finally:
        summary['model_requests']=ledger.attempts;save(root/'summary.json',summary)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--settings',type=Path,required=True)
    run(json.loads(parser.parse_args().settings.read_text()))
