"""Read back completed fixture/probe evidence and export sanitized immutable copies."""
from pathlib import Path
from dataclasses import fields
import gzip,hashlib,ipaddress,json,re,sqlite3,subprocess
from src.baselines.common.redact import redact_text
from src.experiments.postgresql.organization_evaluation import verify_organization
from src.experiments.postgresql.query_workloads import read_prepared
from src.execution_provider.adapters.map_organization import MapOrganizationConfig
root=Path('/root/autodl-tmp/sq-cwe');fixture=root/'integration/fixture';public=root/'public';public.mkdir(mode=0o700)
unit_results=[]
for unit in sorted(p for p in fixture.iterdir() if p.is_dir() and (p/'summary.json').exists()):
    summary=json.loads((unit/'summary.json').read_text());assert summary['status']=='passed'
    execution=json.loads((unit/'q0/execution.json').read_text());data=(unit/'q0/results.jsonl').read_bytes()
    assert execution['status']==execution['query_status']=='completed'
    assert hashlib.sha256(data).hexdigest()==execution['results_sha256']
    assert len(data)==execution['recorded_bytes'] and len(data.splitlines())==execution['recorded_rows']
    result=dict(unit=unit.name,rows=execution['recorded_rows'],actual_posts=summary['evaluation']['actual_posts'],
                recorded_results_sha256=execution['results_sha256'])
    if (unit/'organization.json').exists():
        config=MapOrganizationConfig.load(unit/'organization.json')
        events=[json.loads(l) for l in (unit/'events.jsonl').read_text().splitlines()]
        input_root=fixture/('workload' if 'empty' in unit.name else 'organization-workload')
        raw=list(read_prepared(input_root/'manifest.json','raw.jsonl'))
        movie=summary['config']['movie_id']
        selected=raw if movie is None else [r for r in raw if r[2]==movie]
        report=verify_organization(config,events,max_active_requests=summary['config']['concurrency'],
            expected_max_new_tokens=128,expected_task_count=len(selected))
        assert report==summary['evaluation']['organization']
        if not selected:
            assert not any(e['event'] in ('core_job_opened','core_submitted','request','core_job_drained') for e in events)
            assert not (unit/'sessions.jsonl').read_bytes()
        result.update(audit_readback_identical=True,independent_selected_rows=len(selected))
    unit_results.append(result)
with sqlite3.connect('file:'+str(fixture/'budget.sqlite')+'?mode=ro',uri=True) as connection:
    budget=dict(spent=connection.execute('SELECT count(*) FROM shared_requests').fetchone()[0],
                closed_units=[r[0] for r in connection.execute('SELECT unit_id FROM closed_shared_units ORDER BY unit_id')])
assert budget['spent']==228 and len(budget['closed_units'])==7
probe=root/'integration/buffer-probe-fixed'
summary=json.loads((probe/'summary.json').read_text());assert summary['status']=='completed_diagnostic'
for case in summary['cases']:
    rows=json.loads((probe/f"case-{case['index']}-rows.json").read_text());records=rows['records']
    assert len(records)==128
    assert [r['row'][0] for r in records]==[str(i) for i in range(128)]
    assert sum(7+sum(4+len(v.encode()) for v in r['row']) for r in records)==case['data_row_bytes']
readback=dict(units=unit_results,shared_fixture_budget=budget,probe_cases_checked=4,actual_model_posts=0,
    initial_probe_cases_with_raw_rows=len(list((root/'integration/buffer-probe').glob('case-*-rows.json'))))
(root/'readback-audit.json').write_text(json.dumps(readback,indent=2)+'\n')
identity={}
checkout=root/'checkout'
for name in subprocess.check_output(['git','-C',str(checkout),'ls-files','code','deploy'],text=True).splitlines():
    p=checkout/name
    if p.is_file() and p.suffix!='.md':identity[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'final-source-files.json').write_text(json.dumps(dict(commit=subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip(),files=identity),indent=2)+'\n')
cleanup=dict(gpu_compute_processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).splitlines(),
    pg_processes=subprocess.run(['pgrep','-x','postgres'],capture_output=True,text=True).stdout.splitlines())
assert not cleanup['gpu_compute_processes'] and not cleanup['pg_processes']
(root/'final-process-check.json').write_text(json.dumps(cleanup,indent=2)+'\n')
files=[root/name for name in ('preflight.json','preflight-checkout.json','source-identity.json','checkout-identity.json',
 'regressions.json','scheduling.log','execution_provider.log','postgres.log','experiments.log',
 'experiments-complete-checkout.log','experiments-complete-checkout.json','probe-writer-fixed.log',
 'pg-query-integration.log','pg-legacy-integration.log','pg-buffer-probe.log','pg-validation.json',
 'pg-buffer-probe-fixed.log','pg-probe-fixed-validation.json','readback-audit.json','final-source-files.json',
 'final-process-check.json')]
files += [root/'integration/fixture/fixture-summary.json',root/'integration/legacy/fixture-summary.json']
for parent in (root/'integration/buffer-probe',probe):files+=list(parent.glob('*.json'))
for unit in sorted(p for p in fixture.iterdir() if p.is_dir() and (p/'summary.json').exists()):
    files += [unit/name for name in ('summary.json','events.jsonl','sessions.jsonl','plan.json','q0-producer.log',
                                     'q0/execution.json','q0/evaluation.json','q0/results.jsonl') if (unit/name).exists()]
files+=[root/'run-pg-validation.py',root/'run-fixed-probe.py',root/'postcheck-export.py']
def clean_address(match):
    try:address=ipaddress.ip_address(match.group())
    except ValueError:return match.group()
    return match.group() if address.is_loopback or address.is_unspecified else 'PRIVATE_ADDRESS'
manifest={}
for path in files:
    text=redact_text(path.read_text())
    text=re.sub(r'(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])',clean_address,text)
    name='__'.join(path.relative_to(root).parts)+'.gz'
    encoded=gzip.compress(text.encode(),mtime=0);(public/name).write_bytes(encoded)
    manifest[name]=dict(bytes=len(encoded),sha256=hashlib.sha256(encoded).hexdigest())
(public/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(exported_files=len(manifest),code_identity_files=len(identity),units=len(unit_results),readback='passed')))
