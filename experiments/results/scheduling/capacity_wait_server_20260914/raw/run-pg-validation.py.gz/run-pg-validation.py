"""Owned model-free PG follow-up; preserve each failed run and exact ACL state."""
from pathlib import Path
import json,os,pwd,signal,socket,subprocess,time
import psutil
from src.baselines.common.redact import redact_text
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster

root=Path('/root/autodl-tmp/sq-cwe');checkout=root/'checkout'
python='/root/autodl-tmp/venvs/sembench-query-0910/bin/python'
user=pwd.getpwnam('postgres');pg=Path('/opt/semloom-pg18.3-total-budget')
assert json.loads((root/'preflight-checkout.json').read_text())['status']=='ok'
assert json.loads((root/'experiments-complete-checkout.json').read_text())['exit_code']==0
assert all(r['exit_code']==0 for r in json.loads((root/'regressions.json').read_text()) if r['suite']!='experiments')
started=time.monotonic();deadline=started+1200
report=dict(source_commit='cc0f54f6a36a4fb45c94052741643a0e59230060',actual_model_posts=0,stages=[])
owned_groups=[]
acl_paths=[Path('/root'),root]
acl_before={str(p):subprocess.check_output(['getfacl','-p',str(p)],text=True) for p in acl_paths}
(root/'acl-before.json').write_text(json.dumps(acl_before,indent=2)+'\n')

def run(name,args,env):
    remaining=min(240,deadline-time.monotonic())
    if remaining<=0:raise TimeoutError('PG validation deadline exceeded')
    command=['runuser','-u','postgres','--',python,*args]
    process=subprocess.Popen(command,cwd=checkout,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
    owned_groups.append(process.pid)
    try:
        output,_=process.communicate(timeout=remaining)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid,signal.SIGTERM)
        try:output,_=process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);output,_=process.communicate()
        (root/(name+'.log')).write_text(redact_text(output))
        raise TimeoutError('owned PG test exceeded deadline')
    (root/(name+'.log')).write_text(redact_text(output))
    report['stages'].append(dict(name=name,command=['python',*args],exit_code=process.returncode))
    (root/'pg-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,'exit',process.returncode,flush=True)
    if process.returncode:raise RuntimeError(name+' failed; no automatic retry')

try:
    for p in acl_paths:subprocess.run(['setfacl','-m','u:postgres:--x',str(p)],check=True)
    for name in ('pg','integration','tmp/pg-tests'):
        p=root/name;p.mkdir(mode=0o700);os.chown(p,user.pw_uid,user.pw_gid)
    env=dict(os.environ,PYTHONPATH=str(checkout/'code'),TMPDIR=str(root/'tmp/pg-tests'),
             OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',
             SEMLOOM_TEST_PG_DSN='host='+str(root/'pg/socket')+' port=57660 user=postgres dbname=postgres',
             SEMLOOM_TEST_PG_LOG=str(root/'pg/postgres.log'),
             SEMLOOM_TEST_SEMBENCH_ROOT='/root/autodl-tmp/sq-b/sembench-checkout',
             SEMLOOM_TEST_RAY_TMPDIR=str(root/'integration/ray-unused'))
    with isolated_pg18_cluster(pg,root/'pg',user,port=57660):
        env['SEMLOOM_TEST_ARTIFACT_ROOT']=str(root/'integration/fixture')
        base='tests.experiments.test_database_query_runner_integration.DatabaseQueryRunnerTests.'
        run('pg-query-integration',['-m','unittest','-v',
            base+'test_organization_controls_bind_tokens_groups_and_actual_pg_rows',
            base+'test_organized_empty_selection_keeps_provider_lazy_open',
            base+'test_total_budget_query_reports_independent_pg_memory'],env)
        env['SEMLOOM_TEST_ARTIFACT_ROOT']=str(root/'integration/legacy')
        run('pg-legacy-integration',['-m','unittest','-v',
            'tests.experiments.test_pg_query_execution_integration'],env)
        run('pg-buffer-probe',['code/scripts/experiments/pg_result_buffer_probe.py',
            '--output',str(root/'integration/buffer-probe')],env)
        fixture=json.loads((root/'integration/fixture/fixture-summary.json').read_text())
        legacy=json.loads((root/'integration/legacy/fixture-summary.json').read_text())
        report['fixture_posts']=fixture['fixture_posts']+legacy['fixture_http_posts']
        assert report['fixture_posts']<=2500
        assert fixture['actual_model_posts']==legacy['actual_model_requests']==0
        assert fixture['server_stopped'] and legacy['server_stopped'] and fixture['active_http']==0
        report['status']='passed'
except Exception as error:
    report.update(status='failed',error=redact_text(str(error)),error_type=type(error).__name__)
finally:
    # The PG context stops its cluster before this outer cleanup restores access.
    for p,acl in acl_before.items():subprocess.run(['setfacl','--restore=-'],input=acl,text=True,check=True)
    acl_after={p:subprocess.check_output(['getfacl','-p',p],text=True) for p in acl_before}
    own={os.getpid(),*(p.pid for p in psutil.Process().parents())};remaining=[]
    for proc in psutil.process_iter(['pid','cmdline','status']):
        try:
            if proc.pid not in own and proc.info['status']!=psutil.STATUS_ZOMBIE and any(str(root) in a for a in (proc.info['cmdline'] or [])):
                remaining.append(dict(pid=proc.pid,program=(proc.info['cmdline'] or [''])[0]))
        except (psutil.NoSuchProcess,psutil.AccessDenied):pass
    cleanup=dict(acl_restored=acl_before==acl_after,
        pg_pid_file_present=(root/'pg/data/postmaster.pid').exists(),
        pg_socket_present=(root/'pg/socket/.s.PGSQL.57660').exists(),remaining_task_processes=remaining,
        elapsed_s=time.monotonic()-started)
    report['cleanup']=cleanup
    if not cleanup['acl_restored'] or cleanup['pg_pid_file_present'] or cleanup['pg_socket_present'] or remaining:
        report['status']='failed_cleanup'
    (root/'pg-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],cleanup=cleanup)),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
