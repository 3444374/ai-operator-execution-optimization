"""Run only the repaired ordinary SQL probe in a new isolated PG cluster."""
from pathlib import Path
import hashlib,json,os,pwd,signal,subprocess,time
import psutil
from src.baselines.common.redact import redact_text
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster
root=Path('/root/autodl-tmp/sq-cwe');checkout=root/'checkout';user=pwd.getpwnam('postgres')
head=subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()
assert head.startswith('8d4786c9')
python='/root/autodl-tmp/venvs/sembench-query-0910/bin/python'
acl_before={str(p):subprocess.check_output(['getfacl','-p',str(p)],text=True) for p in (Path('/root'),root)}
started=time.monotonic();report=dict(source_commit=head,status='failed',actual_model_posts=0)
(root/'probe-fixed-acl-before.json').write_text(json.dumps(acl_before,indent=2)+'\n')
try:
    for p in acl_before:subprocess.run(['setfacl','-m','u:postgres:--x',p],check=True)
    pgroot=root/'pg-probe';pgroot.mkdir(mode=0o700);os.chown(pgroot,user.pw_uid,user.pw_gid)
    env=dict(os.environ,PYTHONPATH=str(checkout/'code'),TMPDIR=str(root/'tmp/pg-tests'),
        SEMLOOM_TEST_PG_DSN='host='+str(pgroot/'socket')+' port=57661 user=postgres dbname=postgres')
    with isolated_pg18_cluster(Path('/opt/semloom-pg18.3-total-budget'),pgroot,user,port=57661):
        command=['runuser','-u','postgres','--',python,'code/scripts/experiments/pg_result_buffer_probe.py',
                 '--output',str(root/'integration/buffer-probe-fixed')]
        process=subprocess.Popen(command,cwd=checkout,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
        try:output,_=process.communicate(timeout=90)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            try:output,_=process.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);output,_=process.communicate()
            (root/'pg-buffer-probe-fixed.log').write_text(redact_text(output))
            raise TimeoutError('probe failed to complete within its deadline')
        (root/'pg-buffer-probe-fixed.log').write_text(redact_text(output))
        report['exit_code']=process.returncode
        assert process.returncode==0,'repaired probe failed'
        report['status']='passed'
except Exception as error:
    report['error']=redact_text(str(error));report['error_type']=type(error).__name__
finally:
    for p,acl in acl_before.items():subprocess.run(['setfacl','--restore=-'],input=acl,text=True,check=True)
    acl_after={p:subprocess.check_output(['getfacl','-p',p],text=True) for p in acl_before}
    excluded={os.getpid(),*(p.pid for p in psutil.Process().parents())}
    remaining=[]
    for p in psutil.process_iter(['cmdline','status']):
        try:
            if p.pid not in excluded and p.info['status']!=psutil.STATUS_ZOMBIE and any(str(root) in a for a in (p.info['cmdline'] or [])):
                remaining.append(p.pid)
        except (psutil.NoSuchProcess,psutil.AccessDenied):pass
    report['cleanup']=dict(acl_restored=acl_before==acl_after,pg_pid_file_present=(root/'pg-probe/data/postmaster.pid').exists(),
        pg_socket_present=(root/'pg-probe/socket/.s.PGSQL.57661').exists(),remaining_task_processes=remaining,
        elapsed_s=time.monotonic()-started)
    if not report['cleanup']['acl_restored'] or report['cleanup']['pg_pid_file_present'] or report['cleanup']['pg_socket_present'] or remaining:
        report['status']='failed_cleanup'
    (root/'pg-probe-fixed-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
