"""Bounded length-prefixed UTF-8 JSON framing shared by versioned wire schemas."""

from __future__ import annotations

import json
import socket
import struct
import time
from typing import Any


MAX_FRAME_BYTES = 1024 * 1024


class ProtocolError(Exception):
    """A fail-closed protocol violation safe to report without payload data."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class _DuplicateFields(dict):
    """Marks duplicate JSON keys without changing legacy last-value decoding."""


def has_duplicate_fields(message: dict[str, Any]) -> bool:
    """Let strict schemas reject duplicate keys, including nested objects."""
    return isinstance(message, _DuplicateFields)


def encode_frame(message: dict[str, Any]) -> bytes:
    """Encode one canonical UTF-8 JSON frame with a four-byte big-endian length."""
    payload = json.dumps(
        message,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    if not payload or len(payload) > MAX_FRAME_BYTES:
        raise ProtocolError("invalid_frame_length")
    return struct.pack("!I", len(payload)) + payload


class RegisteredStream:
    """An authenticated stream may idle between frames; partial frames remain bounded."""

    def __init__(self, connection):
        self.connection = connection

    def __getattr__(self, name):
        return getattr(self.connection, name)


def read_frame(connection: socket.socket) -> dict[str, Any] | None:
    """Read one bounded frame; return None only for clean EOF between frames."""
    timeout = connection.gettimeout()
    deadline = None if timeout is None else time.monotonic() + timeout
    try:
        if isinstance(connection, RegisteredStream):
            connection.settimeout(None)
            first = connection.recv(1)
            if not first:
                return None
            deadline = None if timeout is None else time.monotonic() + timeout
            header = first + _read_exact(connection, 3, allow_initial_eof=False, deadline=deadline)
        else:
            header = _read_exact(connection, 4, allow_initial_eof=True, deadline=deadline)
        if header is None:
            return None
        length = struct.unpack("!I", header)[0]
        if length == 0 or length > MAX_FRAME_BYTES:
            raise ProtocolError("invalid_frame_length")
        raw = _read_exact(connection, length, allow_initial_eof=False, deadline=deadline)
        assert raw is not None
    finally:
        connection.settimeout(timeout)
    duplicate_fields = False

    def decode_object(pairs):
        nonlocal duplicate_fields
        result = {}
        for key, value in pairs:
            if key in result:
                duplicate_fields = True
            result[key] = value
        return result

    try:
        message = json.loads(raw.decode("utf-8"), object_pairs_hook=decode_object)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ProtocolError("invalid_json") from error
    if not isinstance(message, dict):
        raise ProtocolError("invalid_message")
    return _DuplicateFields(message) if duplicate_fields else message


def _read_exact(
    connection: socket.socket,
    length: int,
    *,
    allow_initial_eof: bool,
    deadline: float | None = None,
) -> bytes | None:
    buffer = bytearray()
    while len(buffer) < length:
        if deadline is not None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("frame deadline expired")
            connection.settimeout(remaining)
        chunk = connection.recv(length - len(buffer))
        if not chunk:
            if allow_initial_eof and not buffer:
                return None
            raise ProtocolError("unexpected_eof")
        buffer.extend(chunk)
    return bytes(buffer)
