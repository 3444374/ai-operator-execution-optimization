"""Command-line surface for the PostgreSQL AI-operator profiler."""

from __future__ import annotations

import argparse
import os

from src.data.workloads import WORKLOAD_NAMES


def _add_source_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--database-url", default=os.environ.get("DATABASE_URL"))
    parser.add_argument("--setup", action="store_true")
    parser.add_argument("--seed-rows", type=int, default=0)
    parser.add_argument(
        "--seed-workload",
        choices=WORKLOAD_NAMES,
        default="synthetic",
    )
    parser.add_argument("--reset-documents", action="store_true")
    parser.add_argument("--total-rows", type=int, default=10000)
    parser.add_argument("--db-fetch-rows", type=int, default=1024)
    parser.add_argument(
        "--data-source",
        choices=["arrow_postgres", "daft_postgres"],
        default="arrow_postgres",
    )
    parser.add_argument("--source-workload-name")
    parser.add_argument("--request-manifest")
    parser.add_argument("--source-max-prompt-tokens", type=int)
    parser.add_argument(
        "--source-order",
        choices=["doc_id", "arrival_time"],
        default="doc_id",
    )
    parser.add_argument("--source-row-offset", type=int, default=0)


def _add_operator_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--operator",
        choices=["ai_embed", "ai_complete"],
        default="ai_embed",
    )
    parser.add_argument("--ray-batch-rows", type=int, default=1024)
    parser.add_argument(
        "--batching-policy",
        choices=[
            "fixed_rows",
            "token_budget",
            "best_fit_token_budget",
            "row_cap_aware_token_budget",
            "length_align_fixed_rows",
            "length_align_token_budget",
            "prefix_aware_fixed_rows",
            "prefix_aware_token_budget",
            "prefix_aware_length_align_fixed_rows",
            "prefix_aware_length_align_token_budget",
        ],
        default="fixed_rows",
    )
    parser.add_argument("--token-budget", type=int, default=0)
    parser.add_argument(
        "--token-budget-policy",
        choices=["static", "service_quantum"],
        default="static",
    )
    parser.add_argument(
        "--token-budget-candidates",
        default="2048,4096,8192,16384",
        help="Comma-separated safe budgets calibrated by the static curve.",
    )
    parser.add_argument(
        "--token-budget-target-service-ms",
        type=float,
        default=2000.0,
    )
    parser.add_argument(
        "--token-budget-arrival-ewma-alpha",
        type=float,
        default=0.3,
    )
    parser.add_argument("--embedding-dim", type=int, default=128)


def _add_model_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--model-backend",
        choices=["fake", "compatible_http", "http_openai", "ollama"],
        default="fake",
    )
    parser.add_argument("--embedding-endpoint-url")
    parser.add_argument("--embedding-endpoint-urls")
    parser.add_argument(
        "--embedding-model",
        default=os.environ.get("EMBEDDING_MODEL", "local-embedding"),
    )
    parser.add_argument(
        "--embedding-api-key",
        default=os.environ.get("EMBEDDING_API_KEY"),
    )
    parser.add_argument(
        "--embedding-request-timeout-s",
        type=float,
        default=120.0,
    )
    parser.add_argument("--completion-endpoint-url")
    parser.add_argument("--completion-endpoint-urls")
    parser.add_argument(
        "--completion-model",
        default=os.environ.get("COMPLETION_MODEL", "local-completion"),
    )
    parser.add_argument(
        "--completion-api-key",
        default=os.environ.get("COMPLETION_API_KEY"),
    )
    parser.add_argument(
        "--completion-request-timeout-s",
        type=float,
        default=120.0,
    )
    parser.add_argument("--completion-max-tokens", type=int, default=128)
    parser.add_argument(
        "--completion-return-token-ids",
        action="store_true",
    )
    parser.add_argument(
        "--completion-ignore-eos",
        action="store_true",
        help=(
            "Ask a compatible vLLM endpoint to generate to max_tokens even "
            "after EOS. Use only for fixed-output synthetic contracts."
        ),
    )
    parser.add_argument(
        "--completion-prompt-format",
        choices=["raw", "chatml"],
        default="raw",
    )
    parser.add_argument(
        "--completion-protocol",
        choices=["completions", "chat_completions"],
        default="completions",
    )
    parser.add_argument(
        "--completion-prompt-token-overhead",
        type=int,
        default=0,
        help=(
            "Calibrated service-side prompt tokens added per request by the "
            "selected protocol/template. This is part of admission work, not "
            "a cross-model constant."
        ),
    )
    parser.add_argument(
        "--completion-http-transport",
        choices=["urllib", "httpx_async"],
        default="urllib",
        help=(
            "HTTP transport used by compatible completion Ray actors. "
            "httpx_async keeps one bounded connection pool per actor."
        ),
    )
    parser.add_argument(
        "--completion-http-keepalive-expiry-s",
        type=float,
        default=4.0,
        help=(
            "Idle lifetime for pooled HTTP/1.1 completion connections. "
            "Freeze it below the model server keep-alive timeout."
        ),
    )
    parser.add_argument("--completion-temperature", type=float)
    parser.add_argument(
        "--output-cost-mode",
        choices=[
            "prompt_only",
            "fixed_output_cap",
            "trace_target_output",
        ],
        default="fixed_output_cap",
    )
    parser.add_argument("--cost-model-id", default="")
    parser.add_argument("--cost-tokenizer-id", default="")
    parser.add_argument("--model-metrics-url")
    parser.add_argument("--model-metrics-urls")
    parser.add_argument(
        "--service-prefix-caching",
        choices=["enabled", "disabled", "unknown"],
        default="unknown",
        help=(
            "Declared vLLM prefix-cache state recorded in every CSV row. "
            "Formal scenario runners must match this to live service flags."
        ),
    )


def _add_ray_and_credit_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--model-workers", type=int, default=2)
    parser.add_argument(
        "--actor-workers-per-endpoint",
        type=int,
        default=0,
        help="Number of Ray HTTP client actors per service endpoint.",
    )
    parser.add_argument("--ray-actor-max-concurrency", type=int, default=1)
    parser.add_argument(
        "--actor-worker-routing",
        choices=["round_robin", "least_active_work"],
        default="round_robin",
    )
    parser.add_argument("--ray-worker-num-cpus", type=float, default=0.25)
    parser.add_argument("--max-inflight", type=int, default=8)
    parser.add_argument(
        "--admission-scope",
        choices=["global", "per_endpoint"],
        default="global",
        help=(
            "Interpret --max-inflight as one global limit or as an independent "
            "limit for each model endpoint."
        ),
    )
    parser.add_argument(
        "--endpoint-routing",
        choices=[
            "round_robin",
            "least_queued",
            "least_work",
            "manifest_pinned",
            "prefix_affinity",
        ],
        default="round_robin",
    )
    parser.add_argument(
        "--max-active-work-per-endpoint",
        type=int,
        default=0,
        help=(
            "Optional prompt+estimated-output work credit per endpoint; "
            "zero disables the work cap."
        ),
    )
    parser.add_argument(
        "--ray-address",
        default=None,
        help=(
            "Explicit Ray cluster address. Required for shared-credit "
            "coordination; RAY_ADDRESS may supply the same value."
        ),
    )
    parser.add_argument("--shared-credit-coordinator-name", default="")
    parser.add_argument(
        "--shared-credit-namespace",
        default="ai-operator-scheduling",
    )
    parser.add_argument(
        "--shared-credit-request-limit",
        type=int,
        default=0,
    )
    parser.add_argument(
        "--shared-credit-work-limit",
        type=int,
        default=0,
    )
    parser.add_argument(
        "--shared-credit-quantum",
        type=int,
        default=0,
    )
    parser.add_argument(
        "--shared-credit-policy",
        choices=[
            "drr",
            "fifo",
            "vtc",
            "saor",
            "saor_bounded_priority",
            "saor_bounded_ready",
            "strict_priority",
        ],
        default="drr",
    )
    parser.add_argument(
        "--shared-ready-observation-contract",
        choices=["single_head", "bounded_concrete_pre_registration"],
        default="single_head",
    )
    parser.add_argument(
        "--shared-ready-payload-bytes-limit",
        type=int,
        default=0,
        help=(
            "Per-Job logical Arrow payload-byte bound for a bounded concrete "
            "ready window; this is not a physical RSS limit."
        ),
    )
    parser.add_argument("--shared-credit-job-weight", type=int, default=1)
    parser.add_argument("--shared-credit-job-priority", type=int, default=0)
    parser.add_argument("--shared-credit-job-slo-ms", type=float, default=0.0)
    parser.add_argument(
        "--shared-credit-priority-window-ms",
        type=float,
        default=0.0,
    )
    parser.add_argument(
        "--shared-credit-job-debt-cap-work",
        type=float,
        default=0.0,
    )
    parser.add_argument(
        "--saor-entitlement-weight",
        type=float,
        default=1.0,
    )
    parser.add_argument("--saor-queue-weight", type=float, default=0.0)
    parser.add_argument("--saor-fairness-weight", type=float, default=1.0)
    parser.add_argument("--saor-slo-weight", type=float, default=0.0)


def _add_scheduling_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--pool-routing",
        choices=["none", "request_cost"],
        default="none",
    )
    parser.add_argument("--endpoint-pool-ids")
    parser.add_argument("--endpoint-gpu-ids")
    parser.add_argument(
        "--long-request-token-threshold",
        type=int,
        default=0,
    )
    parser.add_argument(
        "--scheduling-policy",
        choices=[
            "static",
            "queue_adaptive",
            "aimd",
            "ewma_aimd",
            "pid",
            "aimd_hol",
        ],
        default="static",
    )
    parser.add_argument("--adaptive-min-inflight", type=int, default=2)
    parser.add_argument("--adaptive-max-inflight", type=int, default=16)
    parser.add_argument("--adaptive-queue-threshold", type=int, default=0)
    parser.add_argument(
        "--adaptive-running-threshold",
        type=int,
        default=128,
    )
    parser.add_argument("--adaptive-kv-threshold", type=float, default=0.85)
    parser.add_argument(
        "--adaptive-poll-interval-s",
        type=float,
        default=0.05,
    )
    parser.add_argument("--controller-min-window", type=int)
    parser.add_argument("--controller-max-window", type=int, default=16)
    parser.add_argument("--controller-initial-window", type=int)
    parser.add_argument("--controller-additive-increase", type=int, default=2)
    parser.add_argument(
        "--controller-multiplicative-decrease",
        type=float,
        default=0.5,
    )
    parser.add_argument(
        "--controller-congestion-kv-usage",
        type=float,
        default=0.85,
    )
    parser.add_argument(
        "--controller-low-load-kv-usage",
        type=float,
        default=0.50,
    )
    parser.add_argument(
        "--controller-low-load-running",
        type=int,
        default=64,
    )
    parser.add_argument(
        "--adaptive-sample-interval-s",
        type=float,
        default=0.25,
    )
    parser.add_argument("--ewma-alpha", type=float, default=0.3)
    parser.add_argument(
        "--pid-proportional-gain",
        type=float,
        default=0.5,
    )
    parser.add_argument("--pid-integral-gain", type=float, default=0.1)
    parser.add_argument(
        "--pid-derivative-gain",
        type=float,
        default=0.05,
    )
    parser.add_argument("--hol-age-congestion-s", type=float, default=2.0)
    parser.add_argument("--hol-age-low-load-s", type=float, default=0.5)
    parser.add_argument("--control-trace-output")


def _add_replay_and_observability_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--arrival-replay", action="store_true")
    parser.add_argument("--arrival-time-scale", type=float, default=1.0)
    parser.add_argument(
        "--arrival-replay-start-epoch-s",
        type=float,
        default=0.0,
        help=(
            "Optional wall-clock epoch for synchronized replay submission; "
            "zero starts immediately after preload."
        ),
    )
    parser.add_argument(
        "--submission-granularity",
        choices=["batch", "request", "service_quantum"],
        default="batch",
    )
    parser.add_argument(
        "--service-quantum-tokens",
        type=int,
        default=0,
        help=(
            "Predicted prompt+output work per complete-row service quantum; "
            "only valid with --submission-granularity service_quantum."
        ),
    )
    parser.add_argument(
        "--flush-policy",
        choices=[
            "immediate",
            "fixed_timeout",
            "queue_adaptive",
            "slo_ewma",
        ],
        default="immediate",
    )
    parser.add_argument("--flush-timeout-ms", type=float, default=25.0)
    parser.add_argument("--flush-max-wait-ms", type=float, default=50.0)
    parser.add_argument("--flush-ewma-alpha", type=float, default=0.3)
    parser.add_argument("--flush-deadband-ratio", type=float, default=0.1)
    parser.add_argument(
        "--flush-service-capacity-tokens-s-per-endpoint",
        type=float,
        default=0.0,
    )
    parser.add_argument("--flush-trace-output")
    parser.add_argument("--submission-trace-output")
    parser.add_argument("--resource-trace-output")
    parser.add_argument(
        "--resource-sample-interval-s",
        type=float,
        default=0.25,
    )
    parser.add_argument("--model-flops-per-token", type=float, default=0.0)
    parser.add_argument("--gpu-peak-tflops", type=float, default=0.0)
    parser.add_argument("--mfu-precision", default="")
    parser.add_argument("--request-trace-output")
    parser.add_argument(
        "--source-scan-evidence-output",
        help=(
            "Opt-in CSV of privacy-preserving fingerprints for the exact source "
            "rows handed to the organizer (doc_id + text SHA256 + source metadata)."
        ),
    )
    parser.add_argument(
        "--completion-evidence-output",
        help=(
            "Opt-in per-doc completion evidence CSV (doc_id, prompt_tokens, "
            "output_tokens, output_text, status, error_type, finish_reason, "
            "timestamps). output_text is flattened from in-process "
            "operator_results for an independent no-writeback correctness seal. "
            "Only emitted when set; zero behavior change otherwise. Requires "
            "--request-trace-output (to populate the lifecycle events)."
        ),
    )
    parser.add_argument("--request-slo-ms", type=float, default=0.0)
    parser.add_argument(
        "--ttft-slo-ms",
        type=float,
        default=0.0,
        help="Optional TTFT objective used to report observed P99 SLO scale.",
    )
    parser.add_argument(
        "--itl-slo-ms",
        type=float,
        default=0.0,
        help="Optional inter-token-latency objective for observed P99 SLO scale.",
    )
    parser.add_argument(
        "--input-cost-per-million-tokens-usd",
        type=float,
        default=None,
        help="Optional explicit input-token price; omitted prices stay unavailable.",
    )
    parser.add_argument(
        "--output-cost-per-million-tokens-usd",
        type=float,
        default=None,
        help="Optional explicit output-token price; omitted prices stay unavailable.",
    )


def _add_execution_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--scenario-id", default="manual")
    parser.add_argument("--random-seed", type=int, default=0)
    parser.add_argument(
        "--strategy",
        choices=["fine", "coalesced"],
        default="coalesced",
    )
    parser.add_argument(
        "--organizer",
        choices=["arrow", "daft"],
        default="arrow",
    )
    parser.add_argument(
        "--organizer-partition-mode",
        choices=["none", "into_partitions", "repartition"],
        default="none",
    )
    parser.add_argument("--organizer-partitions", type=int, default=0)
    parser.add_argument(
        "--daft-runner",
        choices=["native", "ray"],
        default="native",
    )
    parser.add_argument(
        "--executor",
        choices=["ray_actor", "ray_task", "python"],
        default="ray_actor",
    )
    parser.add_argument(
        "--writeback-mode",
        choices=["none", "json_text", "pgvector"],
        default="json_text",
    )
    parser.add_argument(
        "--database-e2e-timing-boundary",
        action="store_true",
        help=(
            "Stop e2e_s immediately after the unified database sink write, "
            "before trace/evidence serialization and the after-service metrics "
            "scrape. Opt-in only; the historical profiler boundary is unchanged."
        ),
    )
    parser.add_argument("--write-batch-rows", type=int, default=0)
    parser.add_argument("--warmup-runs", type=int, default=0)
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument(
        "--run-phase",
        choices=["warmup", "formal"],
    )
    parser.add_argument("--run-repeat-index", type=int)
    parser.add_argument("--experiment-id", default="manual")
    parser.add_argument(
        "--output",
        default="experiments/results/diagnostics/postgres_ai_operator_profile.csv",
    )
    parser.add_argument("--dry-run", action="store_true")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Profile PostgreSQL-triggered AI operator execution through "
            "Daft, Ray, and an external model service."
        )
    )
    _add_source_arguments(parser)
    _add_operator_arguments(parser)
    _add_model_arguments(parser)
    _add_ray_and_credit_arguments(parser)
    _add_scheduling_arguments(parser)
    _add_replay_and_observability_arguments(parser)
    _add_execution_arguments(parser)
    return parser.parse_args(argv)
