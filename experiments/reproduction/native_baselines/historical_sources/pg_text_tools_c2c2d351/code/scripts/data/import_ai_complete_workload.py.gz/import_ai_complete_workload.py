#!/usr/bin/env python3
"""Import ShareGPT prompts with BurstGPT trace metadata into PostgreSQL."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from collections.abc import Callable, Iterable
from dataclasses import dataclass, fields, replace
from pathlib import Path
from urllib import request

import psycopg

CODE_ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "src").is_dir()
)
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


DOCUMENTS_SQL = """
CREATE TABLE IF NOT EXISTS documents (
  doc_id BIGINT PRIMARY KEY,
  tenant_id INTEGER NOT NULL,
  category TEXT NOT NULL,
  text TEXT NOT NULL,
  workload_name TEXT NOT NULL DEFAULT 'synthetic',
  prompt_tokens INTEGER,
  target_output_tokens INTEGER,
  arrival_time_s DOUBLE PRECISION,
  session_id TEXT,
  prefix_key TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

DOCUMENTS_ALTER_SQL = [
    "ALTER TABLE documents ADD COLUMN IF NOT EXISTS workload_name TEXT NOT NULL DEFAULT 'synthetic'",
    "ALTER TABLE documents ADD COLUMN IF NOT EXISTS prompt_tokens INTEGER",
    "ALTER TABLE documents ADD COLUMN IF NOT EXISTS target_output_tokens INTEGER",
    "ALTER TABLE documents ADD COLUMN IF NOT EXISTS arrival_time_s DOUBLE PRECISION",
    "ALTER TABLE documents ADD COLUMN IF NOT EXISTS session_id TEXT",
    "ALTER TABLE documents ADD COLUMN IF NOT EXISTS prefix_key TEXT",
]


@dataclass(frozen=True)
class BurstTraceRow:
    timestamp_s: float
    model: str
    request_tokens: int
    response_tokens: int
    total_tokens: int
    log_type: str


@dataclass(frozen=True)
class WorkloadRow:
    doc_id: int
    tenant_id: int
    category: str
    text: str
    workload_name: str
    prompt_tokens: int
    target_output_tokens: int
    arrival_time_s: float
    session_id: str
    prefix_key: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a ShareGPT+BurstGPT AI_COMPLETE workload.")
    parser.add_argument("--database-url", required=True)
    parser.add_argument(
        "--sharegpt-json",
        default="data/raw/sharegpt_vicuna/ShareGPT_V3_unfiltered_cleaned_split.json",
    )
    parser.add_argument("--burstgpt-csv", default="data/raw/burstgpt/BurstGPT_1.csv")
    parser.add_argument("--workload-name", default="sharegpt_burstgpt")
    parser.add_argument("--max-rows", type=int, default=1024)
    parser.add_argument("--start-doc-id", type=int, default=0)
    parser.add_argument(
        "--source-row-offset",
        type=int,
        default=0,
        help="Skip this many eligible rows after all prompt/token length filters.",
    )
    parser.add_argument(
        "--multi-turn",
        action="store_true",
        help=(
            "Import ShareGPT multi-turn conversations with running context. "
            "Each human turn becomes a row whose prompt is the accumulated "
            "conversation, so later turns share earlier turns' prefix "
            "(enables prefix-cache experiments). session_id and prefix_key "
            "group turns by conversation."
        ),
    )
    parser.add_argument(
        "--max-turns-per-session",
        type=int,
        default=8,
        help="Maximum human turns to emit per ShareGPT conversation in multi-turn mode.",
    )
    parser.add_argument(
        "--verify-existing-prefix-rows",
        type=int,
        default=0,
        help=(
            "Regenerate and exactly compare doc IDs 0..N-1 before an append. "
            "Requires --append-only and matching source/start offsets."
        ),
    )
    parser.add_argument(
        "--append-only",
        action="store_true",
        help="Insert new doc IDs and fail on any conflict instead of updating old rows.",
    )
    parser.add_argument("--batch-rows", type=int, default=1000)
    parser.add_argument("--max-prompt-chars", type=int, default=6000)
    parser.add_argument("--max-request-tokens", type=int, default=1800)
    parser.add_argument(
        "--max-prompt-tokens",
        type=int,
        help=(
            "Optional explicit prompt-token eligibility limit, independent "
            "of the model context limit."
        ),
    )
    parser.add_argument(
        "--tokenizer-path",
        help="Optional local tokenizer path used to store and filter model-specific prompt token counts.",
    )
    parser.add_argument(
        "--tokenizer-endpoint-url",
        help="Optional vLLM-compatible /tokenize endpoint used for model-specific prompt token counts.",
    )
    parser.add_argument(
        "--tokenizer-model",
        help="Model name sent to --tokenizer-endpoint-url.",
    )
    parser.add_argument("--tokenizer-timeout-s", type=float, default=10.0)
    parser.add_argument(
        "--max-model-len",
        type=int,
        help="Drop prompts whose tokenizer count plus completion tokens exceeds this limit.",
    )
    parser.add_argument("--completion-max-tokens", type=int, default=16)
    parser.add_argument(
        "--controlled-prefix-source-workload",
        help="Clone an existing database workload and add a deterministic shared prefix.",
    )
    parser.add_argument("--controlled-prefix-ratio", type=float)
    parser.add_argument(
        "--controlled-prefix-source-max-prompt-tokens",
        type=int,
        default=1400,
    )
    parser.add_argument(
        "--controlled-prefix-text",
        default=(
            "You are processing database AI operator requests. Follow the requested "
            "output format exactly, preserve identifiers, avoid unsupported claims, "
            "and return only the requested answer. Apply these instructions to the "
            "independent user request below."
        ),
    )
    parser.add_argument("--reset-documents", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def first_human_prompt(record: dict) -> str | None:
    conversations = record.get("conversations")
    if not isinstance(conversations, list):
        return None
    for turn in conversations:
        if not isinstance(turn, dict):
            continue
        if turn.get("from") != "human":
            continue
        value = turn.get("value")
        if isinstance(value, str) and value.strip():
            return normalize_text(value)
    return None


def normalize_text(text: str) -> str:
    return " ".join(text.replace("\x00", " ").split())


def prefix_key(text: str) -> str:
    prefix = normalize_text(text).lower()[:160]
    return hashlib.sha1(prefix.encode("utf-8")).hexdigest()[:16]


def length_bucket(tokens: int) -> str:
    if tokens < 512:
        return "short"
    if tokens < 1536:
        return "medium"
    return "long"


def category_for(trace: BurstTraceRow, prompt_tokens: int | None = None) -> str:
    model = trace.model.lower().replace(" ", "_").replace("-", "_")
    return f"{length_bucket(prompt_tokens or trace.request_tokens)}_{model}"


def load_prompt_token_counter(tokenizer_path: str) -> Callable[[str], int]:
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True)

    def count_tokens(text: str) -> int:
        return len(tokenizer.encode(text, add_special_tokens=False))

    return count_tokens


def load_http_prompt_token_counter(
    endpoint_url: str,
    model: str,
    *,
    timeout_s: float = 10.0,
    open_request: Callable = request.urlopen,
) -> Callable[[str], int]:
    """Build a prompt counter backed by a vLLM-compatible /tokenize endpoint."""
    if not endpoint_url:
        raise ValueError("tokenizer endpoint URL must be non-empty")
    if not model:
        raise ValueError("tokenizer model must be non-empty")
    if not math.isfinite(timeout_s) or timeout_s <= 0:
        raise ValueError("tokenizer timeout must be positive")

    def count_tokens(text: str) -> int:
        body = json.dumps({"model": model, "prompt": text}).encode("utf-8")
        http_request = request.Request(
            endpoint_url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with open_request(http_request, timeout=timeout_s) as response:
            decoded = json.loads(response.read().decode("utf-8"))
        count = decoded.get("count")
        if (
            not isinstance(count, int)
            or isinstance(count, bool)
            or count < 0
        ):
            raise ValueError("tokenizer response count must be a non-negative integer")
        return count

    return count_tokens


def load_sharegpt_prompts(path: Path, max_prompt_chars: int) -> list[tuple[str, str]]:
    records = json.load(path.open(encoding="utf-8"))
    prompts: list[tuple[str, str]] = []
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            continue
        prompt = first_human_prompt(record)
        if not prompt or len(prompt) > max_prompt_chars:
            continue
        session_id = str(record.get("id") or f"sharegpt-{index}")
        prompts.append((session_id, prompt))
    return prompts


def load_sharegpt_multi_turn_prompts(
    path: Path, max_prompt_chars: int, max_turns_per_session: int
) -> list[tuple[str, str, str | None]]:
    """Load multi-turn ShareGPT prompts with running context for prefix overlap.

    For each conversation, emits one ``(session_id, prompt, response)`` per
    human turn.  The prompt is the accumulated conversation text up to and
    including the current human turn, so turn N+1's prompt **starts with**
    turn N's prompt → vLLM prefix-cache material.  The response is the actual
    assistant reply (used for a more accurate target_output_tokens than the
    BurstGPT trace pairing).

    The conversation is formatted as ``"Human: ...\\nAssistant: ...\\nHuman: ..."``
    (model-agnostic raw text).  All turns from the same conversation share the
    same session_id, enabling session-level prefix-affinity routing.
    """
    if max_turns_per_session <= 0:
        raise ValueError("max_turns_per_session must be positive")
    records = json.load(path.open(encoding="utf-8"))
    prompts: list[tuple[str, str, str | None]] = []
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            continue
        session_id = str(record.get("id") or f"sharegpt-{index}")
        conversations = record.get("conversations")
        if not isinstance(conversations, list):
            continue
        context_parts: list[str] = []
        turns_emitted = 0
        pending_prompt: str | None = None
        for turn in conversations:
            if turns_emitted >= max_turns_per_session:
                break
            if not isinstance(turn, dict):
                continue
            role = turn.get("from")
            value = turn.get("value")
            if not isinstance(value, str) or not value.strip():
                continue
            value = normalize_text(value)
            label = "Human" if role in ("human", "user") else "Assistant"
            context_parts.append(f"{label}: {value}")
            if role in ("human", "user"):
                pending_prompt = "\n".join(context_parts)
            elif role in ("gpt", "assistant", "model") and pending_prompt is not None:
                if len(pending_prompt) <= max_prompt_chars:
                    prompts.append((session_id, pending_prompt, value))
                    turns_emitted += 1
                pending_prompt = None
    return prompts


def burstgpt_rows_from_dicts(rows: Iterable[dict[str, str]], max_request_tokens: int) -> list[BurstTraceRow]:
    traces: list[BurstTraceRow] = []
    for row in rows:
        request_tokens = int(row["Request tokens"])
        response_tokens = int(row["Response tokens"])
        if request_tokens <= 0 or response_tokens <= 0 or request_tokens > max_request_tokens:
            continue
        traces.append(
            BurstTraceRow(
                timestamp_s=float(row["Timestamp"]),
                model=row["Model"],
                request_tokens=request_tokens,
                response_tokens=response_tokens,
                total_tokens=int(row["Total tokens"]),
                log_type=row["Log Type"],
            )
        )
    return traces


def load_burstgpt_trace(path: Path, max_request_tokens: int) -> list[BurstTraceRow]:
    rows: list[BurstTraceRow] = []
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        rows = burstgpt_rows_from_dicts(reader, max_request_tokens)
    return rows


def build_workload_rows(
    prompts: list[tuple[str, str]],
    traces: list[BurstTraceRow],
    workload_name: str,
    start_doc_id: int,
    max_rows: int,
    prompt_token_counter: Callable[[str], int] | None = None,
    max_prompt_tokens: int | None = None,
    max_model_len: int | None = None,
    completion_max_tokens: int = 0,
    source_row_offset: int = 0,
) -> list[WorkloadRow]:
    if max_rows <= 0:
        raise ValueError("--max-rows must be positive")
    if source_row_offset < 0:
        raise ValueError("source_row_offset must be non-negative")
    if max_prompt_tokens is not None and max_prompt_tokens <= 0:
        raise ValueError("max_prompt_tokens must be positive")
    if not prompts:
        raise ValueError("ShareGPT prompt list is empty after filtering")
    if not traces:
        raise ValueError("BurstGPT trace list is empty after filtering")

    rows: list[WorkloadRow] = []
    eligible_rows_seen = 0
    for prompt_record, trace in zip(prompts, traces):
        if len(rows) >= max_rows:
            break
        session_id, prompt = prompt_record
        prompt_tokens = trace.request_tokens
        if prompt_token_counter is not None:
            prompt_tokens = prompt_token_counter(prompt)
        if prompt_tokens <= 0:
            continue
        if max_prompt_tokens is not None and prompt_tokens > max_prompt_tokens:
            continue
        if max_model_len is not None and prompt_tokens + completion_max_tokens > max_model_len:
            continue
        if eligible_rows_seen < source_row_offset:
            eligible_rows_seen += 1
            continue
        eligible_rows_seen += 1
        doc_id = start_doc_id + len(rows)
        rows.append(
            WorkloadRow(
                doc_id=doc_id,
                tenant_id=stable_tenant_id(session_id),
                category=category_for(trace, prompt_tokens),
                text=prompt,
                workload_name=workload_name,
                prompt_tokens=prompt_tokens,
                target_output_tokens=trace.response_tokens,
                arrival_time_s=trace.timestamp_s,
                session_id=session_id,
                prefix_key=prefix_key(prompt),
            )
        )
    if not rows:
        raise ValueError("No workload rows remain after tokenizer/model-length filtering")
    return rows


def build_multi_turn_workload_rows(
    prompts: list[tuple[str, str, str | None]],
    traces: list[BurstTraceRow],
    workload_name: str,
    start_doc_id: int,
    max_rows: int,
    prompt_token_counter: Callable[[str], int] | None = None,
    max_prompt_tokens: int | None = None,
    max_model_len: int | None = None,
    completion_max_tokens: int = 0,
    source_row_offset: int = 0,
) -> list[WorkloadRow]:
    """Build rows from multi-turn ShareGPT prompts with prefix overlap.

    Each turn's prompt is the running conversation context, so later turns
    share earlier turns' prefix (prefix-cache material).  ``session_id`` and
    ``prefix_key`` group turns by conversation so prefix-affinity routing can
    concentrate them on one endpoint.

    ``target_output_tokens`` uses the **actual** assistant response token count
    (when a tokenizer is available), which is more accurate than the BurstGPT
    trace pairing.  BurstGPT traces are cycled for ``arrival_time_s`` and as a
    fallback for token counts.
    """
    if max_rows <= 0:
        raise ValueError("--max-rows must be positive")
    if source_row_offset < 0:
        raise ValueError("source_row_offset must be non-negative")
    if not prompts:
        raise ValueError("multi-turn prompt list is empty after filtering")
    if not traces:
        raise ValueError("BurstGPT trace list is empty after filtering")

    rows: list[WorkloadRow] = []
    eligible_seen = 0
    trace_count = len(traces)
    for index, (session_id, prompt, response) in enumerate(prompts):
        if len(rows) >= max_rows:
            break
        trace = traces[index % trace_count]
        prompt_tokens = (
            prompt_token_counter(prompt) if prompt_token_counter else trace.request_tokens
        )
        if prompt_tokens <= 0:
            continue
        if max_prompt_tokens is not None and prompt_tokens > max_prompt_tokens:
            continue
        if max_model_len is not None and prompt_tokens + completion_max_tokens > max_model_len:
            continue
        if eligible_seen < source_row_offset:
            eligible_seen += 1
            continue
        eligible_seen += 1
        # Prefer the actual response token count; fall back to the trace.
        if response and prompt_token_counter:
            raw_response_tokens = prompt_token_counter(response)
            target_output_tokens = (
                min(raw_response_tokens, completion_max_tokens)
                if completion_max_tokens > 0
                else raw_response_tokens
            )
        else:
            target_output_tokens = trace.response_tokens
        doc_id = start_doc_id + len(rows)
        rows.append(
            WorkloadRow(
                doc_id=doc_id,
                tenant_id=stable_tenant_id(session_id),
                category=category_for(trace, prompt_tokens),
                text=prompt,
                workload_name=workload_name,
                prompt_tokens=prompt_tokens,
                target_output_tokens=target_output_tokens,
                arrival_time_s=trace.timestamp_s,
                session_id=session_id,
                prefix_key=hashlib.sha1(session_id.encode("utf-8")).hexdigest()[:16],
            )
        )
    if not rows:
        raise ValueError("No multi-turn rows remain after filtering")
    return rows


def apply_controlled_prefix(
    rows: list[WorkloadRow],
    *,
    ratio: float,
    common_prefix: str,
    workload_name: str,
    start_doc_id: int,
    prompt_token_counter: Callable[[str], int],
    max_prompt_tokens: int,
) -> list[WorkloadRow]:
    """Materialize an exact, deterministic subset with one shared prefix."""
    if not math.isfinite(ratio) or not 0.0 <= ratio <= 1.0:
        raise ValueError("controlled prefix ratio must be between 0 and 1")
    if not common_prefix.strip():
        raise ValueError("controlled prefix text must be non-empty")
    if max_prompt_tokens <= 0:
        raise ValueError("max_prompt_tokens must be positive")
    selected_count = math.floor(len(rows) * ratio + 0.5)
    ranked_indices = sorted(
        range(len(rows)),
        key=lambda index: (
            hashlib.sha1(
                f"{rows[index].session_id}:{rows[index].doc_id}".encode("utf-8")
            ).digest(),
            index,
        ),
    )
    selected = set(ranked_indices[:selected_count])
    shared_key = f"controlled:{prefix_key(common_prefix)}"
    materialized = []
    for index, row in enumerate(rows):
        text = row.text
        prompt_tokens = row.prompt_tokens
        row_prefix_key = row.prefix_key
        if prompt_tokens > max_prompt_tokens:
            raise ValueError(
                "source row exceeds max_prompt_tokens: "
                f"session_id={row.session_id}, tokens={prompt_tokens}, "
                f"max_prompt_tokens={max_prompt_tokens}"
            )
        if index in selected:
            text = f"{common_prefix.strip()}\n\n{text}"
            prompt_tokens = prompt_token_counter(text)
            if prompt_tokens > max_prompt_tokens:
                raise ValueError(
                    "controlled prefix row exceeds max_prompt_tokens: "
                    f"session_id={row.session_id}, tokens={prompt_tokens}, "
                    f"max_prompt_tokens={max_prompt_tokens}"
                )
            row_prefix_key = shared_key
        materialized.append(
            replace(
                row,
                doc_id=start_doc_id + index,
                text=text,
                workload_name=workload_name,
                prompt_tokens=prompt_tokens,
                prefix_key=row_prefix_key,
            )
        )
    return materialized


def stable_tenant_id(session_id: str) -> int:
    digest = hashlib.sha1(session_id.encode("utf-8")).digest()
    return int.from_bytes(digest[:2], "big") % 16


def setup_documents(conn) -> None:
    with conn.cursor() as cur:
        cur.execute(DOCUMENTS_SQL)
        for sql in DOCUMENTS_ALTER_SQL:
            cur.execute(sql)
    conn.commit()


def load_existing_workload_rows(
    conn,
    workload_name: str,
    max_rows: int,
    max_prompt_tokens: int,
) -> list[WorkloadRow]:
    if max_rows <= 0:
        raise ValueError("--max-rows must be positive")
    if max_prompt_tokens <= 0:
        raise ValueError(
            "--controlled-prefix-source-max-prompt-tokens must be positive"
        )
    sql = """
        SELECT doc_id, tenant_id, category, text, workload_name, prompt_tokens,
               target_output_tokens, arrival_time_s, session_id, prefix_key
        FROM documents
        WHERE workload_name = %s
          AND prompt_tokens <= %s
        ORDER BY arrival_time_s, doc_id
        LIMIT %s
    """
    with conn.cursor() as cur:
        cur.execute(sql, (workload_name, max_prompt_tokens, max_rows))
        records = cur.fetchall()
    if len(records) != max_rows:
        raise ValueError(
            f"source workload returned {len(records)} rows; expected {max_rows}"
        )
    return [WorkloadRow(*record) for record in records]


def load_existing_workload_prefix(
    conn,
    workload_name: str,
    row_count: int,
) -> list[WorkloadRow]:
    if row_count <= 0:
        raise ValueError("prefix row count must be positive")
    sql = """
        SELECT doc_id, tenant_id, category, text, workload_name, prompt_tokens,
               target_output_tokens, arrival_time_s, session_id, prefix_key
        FROM documents
        WHERE workload_name = %s
          AND doc_id >= 0
          AND doc_id < %s
        ORDER BY doc_id
    """
    with conn.cursor() as cur:
        cur.execute(sql, (workload_name, row_count))
        records = cur.fetchall()
    return [WorkloadRow(*record) for record in records]


def verify_workload_prefix(
    existing_rows: list[WorkloadRow],
    expected_rows: list[WorkloadRow],
) -> None:
    if len(existing_rows) != len(expected_rows):
        raise ValueError(
            "existing workload prefix returned "
            f"{len(existing_rows)} rows; expected {len(expected_rows)}"
        )
    for existing, expected in zip(existing_rows, expected_rows):
        for field in fields(WorkloadRow):
            existing_value = getattr(existing, field.name)
            expected_value = getattr(expected, field.name)
            if existing_value != expected_value:
                raise ValueError(
                    "existing workload prefix mismatch at "
                    f"doc_id={expected.doc_id}, field={field.name}: "
                    f"database={existing_value!r}, regenerated={expected_value!r}"
                )


def reset_documents(conn) -> None:
    with conn.cursor() as cur:
        cur.execute("TRUNCATE documents CASCADE")
    conn.commit()


def insert_rows(
    conn,
    rows: list[WorkloadRow],
    batch_rows: int,
    *,
    append_only: bool = False,
) -> None:
    if batch_rows <= 0:
        raise ValueError("--batch-rows must be positive")
    insert_sql = """
        INSERT INTO documents (
            doc_id, tenant_id, category, text, workload_name, prompt_tokens,
            target_output_tokens, arrival_time_s, session_id, prefix_key
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    update_sql = """
        ON CONFLICT (doc_id) DO UPDATE SET
            tenant_id = EXCLUDED.tenant_id,
            category = EXCLUDED.category,
            text = EXCLUDED.text,
            workload_name = EXCLUDED.workload_name,
            prompt_tokens = EXCLUDED.prompt_tokens,
            target_output_tokens = EXCLUDED.target_output_tokens,
            arrival_time_s = EXCLUDED.arrival_time_s,
            session_id = EXCLUDED.session_id,
            prefix_key = EXCLUDED.prefix_key,
            updated_at = CURRENT_TIMESTAMP
    """
    sql = insert_sql if append_only else f"{insert_sql}\n{update_sql}"
    values = [
        (
            row.doc_id,
            row.tenant_id,
            row.category,
            row.text,
            row.workload_name,
            row.prompt_tokens,
            row.target_output_tokens,
            row.arrival_time_s,
            row.session_id,
            row.prefix_key,
        )
        for row in rows
    ]
    with conn.cursor() as cur:
        for offset in range(0, len(values), batch_rows):
            cur.executemany(sql, values[offset : offset + batch_rows])
    conn.commit()


def summarize(rows: list[WorkloadRow]) -> dict[str, object]:
    prompt_tokens = [row.prompt_tokens for row in rows]
    output_tokens = [row.target_output_tokens for row in rows]
    categories = sorted({row.category for row in rows})
    return {
        "rows": len(rows),
        "categories": categories,
        "prompt_tokens_min": min(prompt_tokens) if prompt_tokens else 0,
        "prompt_tokens_max": max(prompt_tokens) if prompt_tokens else 0,
        "output_tokens_min": min(output_tokens) if output_tokens else 0,
        "output_tokens_max": max(output_tokens) if output_tokens else 0,
        "arrival_time_min_s": min((row.arrival_time_s for row in rows), default=0.0),
        "arrival_time_max_s": max((row.arrival_time_s for row in rows), default=0.0),
    }


def main() -> None:
    args = parse_args()
    if args.tokenizer_path and args.tokenizer_endpoint_url:
        raise ValueError(
            "--tokenizer-path and --tokenizer-endpoint-url are mutually exclusive"
        )
    if args.max_model_len is not None and not (
        args.tokenizer_path or args.tokenizer_endpoint_url
    ):
        raise ValueError(
            "--max-model-len requires --tokenizer-path or --tokenizer-endpoint-url"
        )
    if args.tokenizer_endpoint_url and not args.tokenizer_model:
        raise ValueError("--tokenizer-endpoint-url requires --tokenizer-model")
    if args.completion_max_tokens < 0:
        raise ValueError("--completion-max-tokens must be non-negative")
    if args.verify_existing_prefix_rows < 0:
        raise ValueError("--verify-existing-prefix-rows must be non-negative")
    if args.reset_documents and args.append_only:
        raise ValueError("--reset-documents and --append-only are mutually exclusive")
    if args.verify_existing_prefix_rows:
        if not args.append_only:
            raise ValueError(
                "--verify-existing-prefix-rows requires --append-only"
            )
        if args.source_row_offset != args.verify_existing_prefix_rows:
            raise ValueError(
                "--source-row-offset must equal --verify-existing-prefix-rows"
            )
        if args.start_doc_id != args.verify_existing_prefix_rows:
            raise ValueError(
                "--start-doc-id must equal --verify-existing-prefix-rows"
            )
    if args.tokenizer_path:
        token_counter = load_prompt_token_counter(args.tokenizer_path)
    elif args.tokenizer_endpoint_url:
        token_counter = load_http_prompt_token_counter(
            args.tokenizer_endpoint_url,
            args.tokenizer_model,
            timeout_s=args.tokenizer_timeout_s,
        )
    else:
        token_counter = None
    if args.controlled_prefix_source_workload:
        if args.verify_existing_prefix_rows:
            raise ValueError(
                "--verify-existing-prefix-rows is not supported with "
                "--controlled-prefix-source-workload"
            )
        if args.source_row_offset:
            raise ValueError(
                "--source-row-offset is not supported with "
                "--controlled-prefix-source-workload"
            )
        if args.max_prompt_tokens is not None:
            raise ValueError(
                "--max-prompt-tokens is not supported with "
                "--controlled-prefix-source-workload; use "
                "--controlled-prefix-source-max-prompt-tokens"
            )
        if args.controlled_prefix_ratio is None:
            raise ValueError(
                "--controlled-prefix-source-workload requires "
                "--controlled-prefix-ratio"
            )
        if token_counter is None or args.max_model_len is None:
            raise ValueError(
                "controlled prefix materialization requires a tokenizer and "
                "--max-model-len"
            )
        max_prompt_tokens = args.max_model_len - args.completion_max_tokens
        with psycopg.connect(args.database_url) as conn:
            if not args.dry_run:
                setup_documents(conn)
            base_rows = load_existing_workload_rows(
                conn,
                args.controlled_prefix_source_workload,
                args.max_rows,
                args.controlled_prefix_source_max_prompt_tokens,
            )
            rows = apply_controlled_prefix(
                base_rows,
                ratio=args.controlled_prefix_ratio,
                common_prefix=args.controlled_prefix_text,
                workload_name=args.workload_name,
                start_doc_id=args.start_doc_id,
                prompt_token_counter=token_counter,
                max_prompt_tokens=max_prompt_tokens,
            )
            summary = summarize(rows)
            if args.dry_run:
                print(
                    json.dumps(
                        {"status": "dry_run", **summary},
                        ensure_ascii=False,
                        indent=2,
                    )
                )
                return
            insert_rows(
                conn,
                rows,
                args.batch_rows,
                append_only=args.append_only,
            )
        print(json.dumps({"status": "ok", **summary}, ensure_ascii=False, indent=2))
        return
    if args.multi_turn:
        multi_prompts = load_sharegpt_multi_turn_prompts(
            Path(args.sharegpt_json), args.max_prompt_chars, args.max_turns_per_session
        )
        traces = load_burstgpt_trace(Path(args.burstgpt_csv), args.max_request_tokens)
        rows = build_multi_turn_workload_rows(
            multi_prompts,
            traces,
            args.workload_name,
            args.start_doc_id,
            args.max_rows,
            prompt_token_counter=token_counter,
            max_prompt_tokens=args.max_prompt_tokens,
            max_model_len=args.max_model_len,
            completion_max_tokens=args.completion_max_tokens,
            source_row_offset=args.source_row_offset,
        )
        summary = summarize(rows)
        sessions = sorted({row.session_id for row in rows})
        summary["distinct_sessions"] = len(sessions)
        summary["rows_per_session_mean"] = (
            round(len(rows) / len(sessions), 2) if sessions else 0.0
        )
        if args.dry_run:
            print(json.dumps({"status": "dry_run", **summary}, ensure_ascii=False, indent=2))
            return
        with psycopg.connect(args.database_url) as conn:
            setup_documents(conn)
            if args.reset_documents:
                reset_documents(conn)
            insert_rows(conn, rows, args.batch_rows, append_only=args.append_only)
        print(json.dumps({"status": "ok", **summary}, ensure_ascii=False, indent=2))
        return

    prompts = load_sharegpt_prompts(Path(args.sharegpt_json), args.max_prompt_chars)
    traces = load_burstgpt_trace(Path(args.burstgpt_csv), args.max_request_tokens)
    rows = build_workload_rows(
        prompts,
        traces,
        args.workload_name,
        args.start_doc_id,
        args.max_rows,
        prompt_token_counter=token_counter,
        max_prompt_tokens=args.max_prompt_tokens,
        max_model_len=args.max_model_len,
        completion_max_tokens=args.completion_max_tokens,
        source_row_offset=args.source_row_offset,
    )
    summary = summarize(rows)
    if args.dry_run and not args.verify_existing_prefix_rows:
        print(json.dumps({"status": "dry_run", **summary}, ensure_ascii=False, indent=2))
        return

    expected_prefix = None
    if args.verify_existing_prefix_rows:
        expected_prefix = build_workload_rows(
            prompts,
            traces,
            args.workload_name,
            start_doc_id=0,
            max_rows=args.verify_existing_prefix_rows,
            prompt_token_counter=token_counter,
            max_prompt_tokens=args.max_prompt_tokens,
            max_model_len=args.max_model_len,
            completion_max_tokens=args.completion_max_tokens,
        )

    with psycopg.connect(args.database_url) as conn:
        if not args.dry_run:
            setup_documents(conn)
        if expected_prefix is not None:
            existing_prefix = load_existing_workload_prefix(
                conn,
                args.workload_name,
                args.verify_existing_prefix_rows,
            )
            verify_workload_prefix(existing_prefix, expected_prefix)
        if args.dry_run:
            print(
                json.dumps(
                    {"status": "verified_dry_run", **summary},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return
        if args.reset_documents:
            reset_documents(conn)
        insert_rows(
            conn,
            rows,
            args.batch_rows,
            append_only=args.append_only,
        )
    print(json.dumps({"status": "ok", **summary}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
