from pathlib import Path
import os,subprocess,json,hashlib,time
from src.baselines.common.redact import redact_text
from src.baselines.common.private_artifacts import write_private_json
from src.experiments.postgresql.movie_partition import prepare_movie_partitions
from src.experiments.postgresql.query_workloads import read_prepared
from src.baselines.text.sembench_movie import MOVIE_MAP_INSTRUCTION
from src.execution_provider.semantic_map import canonical_messages
base=Path('<artifact-root>');source=base/'source';started=time.monotonic()
python='<driver-venv>/bin/python'
envfile=base/'runtime.env';envfile.write_text(Path('<artifact-root>/runtime.env').read_text().replace('<artifact-root>',str(base)));envfile.chmod(0o600)
env=dict(os.environ,AI_OPERATOR_ENV_FILE=str(envfile),PYTHONPATH=str(source/'code'))
for key in ('http_proxy','https_proxy','HTTP_PROXY','HTTPS_PROXY','RAY_ADDRESS'):env.pop(key,None)
r=subprocess.run([python,'code/scripts/environment/manage_environment.py','check','--groups','core,text,semantic-benchmarks,text-qwen7b','--json-out',str(base/'preflight.json')],cwd=source,env=env,capture_output=True,text=True)
(base/'preflight.log').write_text(redact_text(r.stdout+r.stderr));assert r.returncode==0
model=Path('<model-root>');reference=json.loads(Path('<data-root>/sq-ar2/service-reference.json').read_text())
for name,digest in reference['model']['files'].items():
 h=hashlib.sha256()
 with (model/name).open('rb') as f:
  for block in iter(lambda:f.read(8*1048576),b''):h.update(block)
 assert h.hexdigest()==digest,name
write_private_json(base/'model-reference.json',reference)
reuse=json.loads(Path('<artifact-root>/build-reuse.json').read_text())
for name,digest in reuse['c_source_hashes'].items():
 assert hashlib.sha256((source/'code/postgres/semloom_pg'/name).read_bytes()).hexdigest()==digest
lib=Path('/opt/semloom-pg18.3-m1-probe/lib/postgresql/semloom_pg.so')
assert hashlib.sha256(lib.read_bytes()).hexdigest()==reuse['prior_build']['library_sha256']
write_private_json(base/'build-reuse.json',reuse)
report=prepare_movie_partitions('<data-root>/data/sembench-movie-v4/extracted/rotten_tomatoes_movie_reviews.csv',
 '<data-root>/sq-b/movie-sf2000/Reviews.csv',base/'inputs')
from transformers import AutoTokenizer
tokenizer=AutoTokenizer.from_pretrained(model,local_files_only=True)
from src.execution_provider.adapters.map_organization import tokenizer_fingerprint
for key in report['splits']:
 rows=list(read_prepared(base/'inputs'/key/'manifest.json','raw.jsonl'))
 values=[len(tokenizer.apply_chat_template(json.loads(canonical_messages(MOVIE_MAP_INSTRUCTION,row[3])),tokenize=True,add_generation_prompt=True))+128 for row in rows]
 assert max(values)<=4096
 write_private_json(base/'inputs'/key/'work.json',dict(work=values,max_new_tokens=128,context_tokens=4096))
 report['splits'][key].update(min_work=min(values),max_work=max(values),mean_work=sum(values)/len(values),wide_work=sum(sorted(values,reverse=True)[:64]))
report.update(model_id='qwen2.5-7b',model_revision=reference['model'].get('revision'),tokenizer_fingerprint=tokenizer_fingerprint(model),
 actual_model_posts=0,elapsed_s=time.monotonic()-started)
write_private_json(base/'data-preparation.json',report)
print(json.dumps(report,indent=2))
