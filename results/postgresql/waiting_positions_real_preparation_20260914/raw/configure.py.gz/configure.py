from pathlib import Path
import json,hashlib,subprocess
from src.baselines.common.private_artifacts import write_private_json
base=Path('<artifact-root>');source=base/'source';root=base/'real-run'
data=json.loads((base/'data-preparation.json').read_text())
q=dict(output_root=str(root/'queries'),inputs_root=str(base/'inputs'),model_config=str(root/'model.json'),
 pg_log=str(root/'pg/postgres.log'),max_posts=44544,max_seconds=1800,budget_id='m1.real-movie.20260914',budget_path=str(root/'budget.sqlite'),
 manifest_sha256={k:v['manifest_sha256'] for k,v in data['splits'].items()},model_id=data['model_id'],model_revision=data['model_revision'],
 service_signature='qwen7b-vllm0251-fcfs-ctx4096-prefix-off-single4090-v1',tokenizer_path='<model-root>',
 tokenizer_fingerprint=data['tokenizer_fingerprint'],work_limits=dict(tight=4096,wide=data['splits']['evaluation']['wide_work']))
write_private_json(base/'query-config.json',q)
files=subprocess.check_output(['git','ls-files','code'],cwd=source,text=True).splitlines()
files={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in files if (source/name).suffix!='.md' and (source/name).is_file()}
write_private_json(base/'source-snapshot.json',dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),files=files))
c=dict(base=str(base),output_root=str(root),source=str(source),prefix='/opt/semloom-pg18.3-m1-probe',
 driver_python='<driver-venv>/bin/python',model_python='<model-venv>/bin/python',
 model_path=q['tokenizer_path'],model_reference=str(base/'model-reference.json'),runtime_env=str(base/'runtime.env'),
 model_id=q['model_id'],model_port=18770,pg_port=57698,gpu='0',max_posts=44544,max_seconds=1800,model_startup_s=300,
 worker_timeout_s=1200,cleanup_reserve_s=120,source_snapshot=str(base/'source-snapshot.json'),
 library_record='<artifact-root>/build.json',query_config=str(base/'query-config.json'),
 worker=str(source/'code/src/experiments/postgresql/m1_campaign.py'),authorization=dict(approved=False,
 reason='exact real request and time allocation prepared for user review; no prior campaign allowance reused'))
write_private_json(base/'campaign-config.json',c)
print(json.dumps(dict(status='prepared',max_posts=c['max_posts'],max_seconds=c['max_seconds'],actual_model_posts=0,
 source_files=len(files),source_commit=json.loads((base/'source-snapshot.json').read_text())['commit'])))
