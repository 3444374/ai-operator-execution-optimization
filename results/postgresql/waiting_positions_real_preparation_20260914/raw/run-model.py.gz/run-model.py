"""Own one bounded model campaign; all machine paths and budgets are declared inputs."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,os,pwd,signal,socket,sqlite3,subprocess,sys,time,urllib.request
import psutil
from src.infrastructure.environment import load_env_file
from src.baselines.common.private_artifacts import new_private_directory,write_private_json
from src.baselines.common.redact import redact_text
from src.experiments.attempt_ledger import AttemptBudget
from src.experiments.cell_budget import CellBudgetLedger
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster
from src.experiments.process_sampling import ProcessSampler
from src.observability.metrics.timing import PeriodicSampler
from src.observability.metrics.vllm import scrape_prometheus_metrics
c=json.loads(Path(sys.argv[1]).read_text());q=json.loads(Path(c['query_config']).read_text())
base=Path(c['base']);root=Path(c['output_root']);source=Path(c['source']);prefix=Path(c['prefix']);user=pwd.getpwnam('postgres')
assert c['max_posts']==q['max_posts']==44544 and c['max_seconds']==q['max_seconds']==1800
assert json.loads((base/'controlled.json').read_text())['status']=='passed'
assert json.loads((base/'preflight.json').read_text())['status']=='ok'
if sys.argv[2:]==['--inspect']:
 runtime=load_env_file(Path(c['runtime_env']))
 assert all(runtime[k] for k in ('CUDA_HOME','CUDA_NVCC_BIN'))
 assert Path(c['worker']).is_file() and Path(c['model_python']).is_file() and Path(c['driver_python']).is_file()
 assert Path(c['model_reference']).is_file() and Path(c['query_config']).is_file()
 print(json.dumps(dict(status='ready',max_posts=c['max_posts'],max_seconds=c['max_seconds'],actual_model_posts=0)));raise SystemExit(0)
if sys.argv[2:]!=['--execute'] or c['authorization'].get('approved') is not True:
 raise PermissionError('the declared real campaign requires approval before execution')
new_private_directory(root);os.chown(root,user.pw_uid,user.pw_gid)
started=time.time();deadline=started+c['max_seconds'];work_until=deadline-c['cleanup_reserve_s']
write_private_json(root/'authorization.json',c['authorization']);write_private_json(root/'campaign-config.json',c)
write_private_json(root/'campaign-time.json',dict(started_utc=started,deadline_utc=deadline,work_until=work_until))
budget=AttemptBudget(q['budget_id'],c['max_posts']);ledger=CellBudgetLedger.create(Path(q['budget_path']),budget,deadline_utc=work_until)
os.chown(ledger.path,user.pw_uid,user.pw_gid)
acl_before={str(p):subprocess.check_output(['getfacl','-p',str(p)],text=True) for p in (Path('/root'),base,base/'inputs',*(base/'inputs').rglob('*'),Path(c['query_config']))}
write_private_json(root/'acl-before.json',acl_before)
model_process=None;worker=None;forced=False;report=dict(status='failed',errors=[])

def verify(path,expected):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(16*1048576),b''):
   if time.time()>=work_until:raise TimeoutError('identity verification exceeded campaign time')
   h.update(chunk)
 assert h.hexdigest()==expected,'file identity changed: '+path.name

def stop_model():
 global forced
 if model_process is None or (root/'service-stop.json').exists():return
 if model_process.poll() is None:os.killpg(model_process.pid,signal.SIGTERM)
 try:model_process.wait(30)
 except subprocess.TimeoutExpired:
  forced=True;os.killpg(model_process.pid,signal.SIGKILL);model_process.wait(10)
 write_private_json(root/'service-stop.json',dict(returncode=model_process.returncode,forced=forced))

def stop_worker():
 if worker is None or worker.poll() is not None:return
 try:children=psutil.Process(worker.pid).children(recursive=True)
 except psutil.NoSuchProcess:children=[]
 for child in children:
  try:child.terminate()
  except psutil.NoSuchProcess:pass
 _,alive=psutil.wait_procs(children,timeout=10)
 for child in alive:
  try:child.kill()
  except psutil.NoSuchProcess:pass
 psutil.wait_procs(alive,timeout=10)
 if worker.poll() is None:worker.terminate()
 worker.wait(10)

try:
 snapshot=json.loads(Path(c['source_snapshot']).read_text())
 for name,digest in snapshot['files'].items():verify(source/name,digest)
 library=prefix/'lib/postgresql/semloom_pg.so';verify(library,json.loads(Path(c['library_record']).read_text())['library_sha256'])
 reference=json.loads(Path(c['model_reference']).read_text());model=Path(c['model_path'])
 for name,digest in reference['model']['files'].items():verify(model/name,digest)
 write_private_json(root/'identity.json',dict(source_commit=snapshot['commit'],source_files=len(snapshot['files']),model=reference['model'],
  worker_sha256=hashlib.sha256(Path(c['worker']).read_bytes()).hexdigest(),query_config_sha256=hashlib.sha256(Path(c['query_config']).read_bytes()).hexdigest()))
 assert not subprocess.check_output(['nvidia-smi','-i',c['gpu'],'--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
 for port in (c['model_port'],c['pg_port']):
  with socket.socket() as s:s.bind(('127.0.0.1',port))
 for path in (str(Path('/root')),str(base)):subprocess.run(['setfacl','-m','u:postgres:--x',path],check=True)
 for p in (base/'inputs',*(base/'inputs').rglob('*'),Path(c['query_config'])):
  subprocess.run(['setfacl','-m','u:postgres:r-x' if p.is_dir() else 'u:postgres:r--',str(p)],check=True)
 with ExitStack() as stack:
  pgroot=root/'pg';pgroot.mkdir(mode=0o700);os.chown(pgroot,user.pw_uid,user.pw_gid)
  conn=stack.enter_context(isolated_pg18_cluster(prefix,pgroot,user,port=c['pg_port']))
  assert conn.execute("SHOW semloom_pg.test_flow_trace").fetchone()[0]=='off'
  runtime=load_env_file(Path(c['runtime_env']));cache=root/'cache';cache.mkdir(mode=0o700)
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=c['gpu'],HF_HUB_OFFLINE='1',CUDA_HOME=runtime['CUDA_HOME'],
   PATH=str(Path(c['model_python']).parent)+':'+runtime['CUDA_NVCC_BIN']+':'+os.environ['PATH'],HF_HOME=str(cache/'hf'),
   XDG_CACHE_HOME=str(cache/'xdg'),VLLM_CACHE_ROOT=str(cache/'vllm'),TORCHINDUCTOR_CACHE_DIR=str(cache/'torch'),
   FLASHINFER_WORKSPACE_BASE=str(cache/'flashinfer'),TRITON_CACHE_DIR=str(cache/'triton'),TMPDIR=str(cache),TOKENIZERS_PARALLELISM='false')
  args=['--model',str(model),'--tokenizer',str(model),'--served-model-name',c['model_id'],'--dtype','bfloat16',
   '--max-model-len','4096','--gpu-memory-utilization','0.8','--scheduling-policy','fcfs','--max-num-seqs','128',
   '--max-num-batched-tokens','8192','--tensor-parallel-size','1','--host','127.0.0.1','--port',str(c['model_port']),
   '--generation-config','vllm','--no-enable-prefix-caching','--enable-chunked-prefill']
  command=[c['model_python'],str(source/'code/scripts/services/launch_vllm_with_identity.py'),
   '--identity-output',str(root/'vllm-identity.json'),'--port',str(c['model_port']),'--',*args]
  write_private_json(root/'service-command.json',command)
  write_private_json(Path(q['model_config']),dict(endpoint_url='http://127.0.0.1:'+str(c['model_port'])+'/v1/chat/completions',model_id=c['model_id'],timeout_ms=30000))
  os.chown(q['model_config'],user.pw_uid,user.pw_gid)
  log=stack.enter_context((root/'model.log').open('x'));model_process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  stack.callback(stop_model);until=min(work_until,time.time()+c['model_startup_s'])
  url='http://127.0.0.1:'+str(c['model_port'])
  while time.time()<until:
   if model_process.poll() is not None:raise RuntimeError('model startup failed')
   try:
    with urllib.request.urlopen(url+'/health',timeout=1) as response:
     if response.status==200:break
   except OSError:time.sleep(.5)
  else:raise TimeoutError('model startup deadline')
  identity=json.loads((root/'vllm-identity.json').read_text());assert identity['package_version']==reference['vllm_version']=='0.25.1'
  with urllib.request.urlopen(url+'/v1/models',timeout=2) as response:models=json.load(response)
  assert [m['id'] for m in models['data']]==[c['model_id']]
  actual=Path('/proc/'+str(model_process.pid)+'/cmdline').read_bytes().decode().split('\0')[:-1];assert actual[-len(args):]==args
  write_private_json(root/'service-ready.json',dict(model_id_verified=True,actual_argv_matches=True,ready_utc=time.time()))
  def service_sample():
   return dict(monotonic_ns=time.monotonic_ns(),metrics=scrape_prometheus_metrics(url+'/metrics',timeout_s=2),
    gpu=subprocess.check_output(['nvidia-smi','-i',c['gpu'],'--query-gpu=memory.used,utilization.gpu,power.draw',
                                 '--format=csv,noheader,nounits'],text=True,timeout=3).strip())
  stack.enter_context(ProcessSampler(root/'model-process-rss.jsonl',{'model_server':model_process.pid},interval=1,include_children=True))
  service_sampler=PeriodicSampler(service_sample,interval_s=1)
  def finish_samples():
   service_sampler.close()
   write_private_json(root/'service-samples.json',list(service_sampler.samples))
  stack.callback(finish_samples)
  write_private_json(root/'service-before.json',service_sample())
  print('Model identity verified; starting up to 44544 declared POSTs',flush=True)
  if time.time()+c['worker_timeout_s']>=work_until:raise TimeoutError('not enough time for worker and cleanup')
  child=['runuser','-u','postgres','--','env','PYTHONPATH='+str(source/'code'),'OMP_NUM_THREADS=1','OPENBLAS_NUM_THREADS=1',
   'SEMLOOM_TEST_PG_DSN=host='+str(pgroot/'socket')+' port='+str(c['pg_port'])+' user=postgres dbname=postgres',
   'SEMLOOM_PG_LOG='+str(pgroot/'postgres.log'),c['driver_python'],'-m','src.experiments.postgresql.m1_campaign',c['query_config']]
  worker=subprocess.Popen(child,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
  try:output,_=worker.communicate(timeout=c['worker_timeout_s'])
  except subprocess.TimeoutExpired:
   stop_worker();output=worker.stdout.read();(root/'worker.log').write_text(redact_text(output));raise
  (root/'worker.log').write_text(redact_text(output))
  if worker.returncode:raise RuntimeError('shared query worker failed; no retry')
  summary=json.loads((Path(q['output_root'])/'comparison.json').read_text());assert summary['status'] in ('completed','inconclusive')
  report['query_summary']=summary;report['status']='passed'
  final_service=service_sample();write_private_json(root/'service-after.json',final_service)
  if any(final_service['metrics'].get(key)!=0 for key in ('vllm:num_requests_running','vllm:num_requests_waiting')):
   raise RuntimeError('service did not expose an idle final state')
except BaseException as error:
 report['errors'].append(dict(type=type(error).__name__,message=redact_text(str(error))))
finally:
 try:stop_worker()
 except BaseException as error:report['errors'].append(dict(phase='worker_cleanup',message=redact_text(str(error))))
 try:stop_model()
 except BaseException as error:report['errors'].append(dict(phase='model_cleanup',message=redact_text(str(error))))
 for unit in ledger.snapshot()['units']:ledger.close_shared_unit(unit['unit_id'])
 for pid in root.rglob('postmaster.pid'):
  subprocess.run(['runuser','-u','postgres','--',str(prefix/'bin/pg_ctl'),'-D',str(pid.parent),'-m','fast','-w','stop'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=20)
 for path,acl in acl_before.items():subprocess.run(['setfacl','--restore=-'],input=acl,text=True,check=True)
 after={p:subprocess.check_output(['getfacl','-p',p],text=True) for p in acl_before}
 with sqlite3.connect(ledger.path) as db:
  tables={r[0] for r in db.execute('SELECT name FROM sqlite_master WHERE type="table"')}
  spent=db.execute('SELECT count(*) FROM shared_requests').fetchone()[0] if 'shared_requests' in tables else 0
 log=(root/'model.log').read_text() if (root/'model.log').exists() else ''
 server_posts=log.count('POST /v1/chat/completions ')
 gpu=subprocess.check_output(['nvidia-smi','-i',c['gpu'],'--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
 port_closed=[]
 for port in (c['model_port'],c['pg_port']):
  with socket.socket() as s:port_closed.append(s.connect_ex(('127.0.0.1',port))!=0)
 excluded={os.getpid(),*(p.pid for p in psutil.Process().parents())};remaining=[]
 for p in psutil.process_iter(['cmdline','status']):
  try:
   if p.pid not in excluded and p.info['status']!=psutil.STATUS_ZOMBIE and any(str(root) in a for a in p.info['cmdline'] or []):remaining.append(p.pid)
  except (psutil.NoSuchProcess,psutil.AccessDenied):pass
 report.update(actual_posts=spent,server_posts=server_posts,ledger=ledger.snapshot(),elapsed_s=time.time()-started,
  cleanup=dict(acl_restored=acl_before==after,pg_pid_files=[str(p.relative_to(root)) for p in root.rglob('postmaster.pid')],remaining_task_processes=remaining,
  gpu_processes=gpu,ports_closed=port_closed,model_forced=forced))
 if report['status']=='passed' and not(spent==server_posts==report['query_summary']['actual_posts']<=c['max_posts']):report['errors'].append(dict(message='POST accounting mismatch'))
 if remaining or report['cleanup']['pg_pid_files'] or gpu or not all(port_closed) or acl_before!=after or time.time()>deadline:report['errors'].append(dict(message='cleanup or time bound failed'))
 if report['errors']:report['status']='failed'
 write_private_json(root/'campaign-result.json',report)
 print(json.dumps(dict(status=report['status'],actual_posts=spent,server_posts=server_posts,elapsed_s=report['elapsed_s'],errors=report['errors'],cleanup=report['cleanup'])),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
