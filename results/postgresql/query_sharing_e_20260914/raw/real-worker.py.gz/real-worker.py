"""Run the declared shared-query cells against a caller-owned endpoint and PG."""
from pathlib import Path
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import json,os,subprocess,sys,threading,time
import psycopg
from psycopg import sql
from src.baselines.common.private_artifacts import write_private_json
from src.experiments.postgresql.map_query_recording import record_pg_query,record_execution,evaluate_recording
from src.experiments.postgresql.map_bindings import parse_pg_bindings,verify_bound_map_results
from src.experiments.postgresql.filter_bindings import verify_filter_decisions
from src.experiments.postgresql.window_memory import verify_window_memory
from src.execution_provider.semantic_map import SemanticMapPlan
from src.execution_provider.wire import v3

config=json.loads(Path(sys.argv[1]).read_text());root=Path(config['output_root']);root.mkdir(mode=0o700)
model=config['model_id'];values=[tuple(row) for row in config['inputs']]
gateway=None;connections=[];runs=[];unpause=threading.Event()
model_options=lambda tokens:sql.Literal(json.dumps(dict(model=model,temperature=0,max_tokens=tokens)))
statement=sql.SQL('SELECT id, ai_semantic.map(body,{},{}::jsonb) FROM ONLY {}').format(
 sql.Literal(config['map_instruction']),model_options(config['map_tokens']),sql.Identifier(config['table']))
filter_sql=sql.SQL(' WHERE ai_semantic.filter(body,{},{}::jsonb)').format(sql.Literal(config['filter_instruction']),model_options(config['filter_tokens']))

def wait_for(test,seconds=10):
 deadline=time.monotonic()+seconds
 while not test():
  if time.monotonic()>=deadline:raise TimeoutError('shared-query observation deadline')
  time.sleep(.01)

def events():
 path=root/'events.jsonl'
 return [json.loads(s) for s in path.read_text().splitlines() if s.endswith('}')] if path.exists() else []

def live_jobs():
 c=Counter(e['event'] for e in events());return c['core_job_opened']-c['core_job_drained']

def connect():
 conn=psycopg.connect(os.environ['SEMLOOM_QUERY_DSN'],autocommit=True);connections.append(conn)
 settings={'semloom_pg.gateway_socket':str(root/'gateway.sock'),
  'semloom_pg.provider_execution_profile':'query-job','semloom_pg.enable_query_job_window':'on',
  'semloom_pg.provider_window_tasks':str(config['window']),'semloom_pg.provider_window_bytes':str(config['pg_bytes']),
  'semloom_pg.provider_staging_bytes':str(config['staging_bytes']),
  'semloom_pg.enable_total_window_budget':'on','semloom_pg.test_window_memory':'on',
  'semloom_pg.test_map_binding_id_column':'id','semloom_pg.test_filter_binding_id_column':'id',
  'statement_timeout':str(config['query_timeout_s']*1000)}
 for key,value in settings.items():conn.execute('SELECT set_config(%s,%s,false)',(key,value))
 return conn

def run(label,dependent=False,limit=None,barrier=None,paused=None):
 conn=connect();query=statement+(filter_sql if dependent else sql.SQL(''))
 if limit is not None:query+=sql.SQL(' LIMIT {}').format(sql.Literal(limit))
 entry=dict(label=label,dependent=dependent,limit=limit,backend_pid=conn.info.backend_pid,status='failed');runs.append(entry)
 target=root/label
 try:
  if barrier:barrier.wait(10)
  entry['release_ns']=time.monotonic_ns()
  if paused is None:
   record_pg_query(conn,query,target,max_rows=len(values),max_result_bytes=config['result_bytes'],
    metadata=entry,query_timeout_s=config['query_timeout_s'])
  else:
   @contextmanager
   def open_rows():
    with conn.transaction():
     with conn.cursor(name=label) as cursor:
      cursor.execute(query)
      def rows():
       yield from cursor.fetchmany(1)
       paused.set()
       if not unpause.wait(config['query_timeout_s']):raise TimeoutError('consumer pause exceeded limit')
       yield from cursor
      yield rows()
   record_execution(target,open_rows,max_rows=len(values),max_result_bytes=config['result_bytes'],
    metadata=entry,query_timeout_s=config['query_timeout_s'],cancel_query=lambda:conn.cancel_safe(timeout=1))
  entry['status']='completed'
 finally:
  entry['end_ns']=time.monotonic_ns();conn.close()
 return entry

try:
 with connect() as conn:
  conn.execute(sql.SQL('CREATE TABLE {}(id text PRIMARY KEY,body text)').format(sql.Identifier(config['table'])))
  with conn.cursor() as cursor:cursor.executemany(sql.SQL('INSERT INTO {} VALUES (%s,%s)').format(sql.Identifier(config['table'])),values)
 command=[sys.executable,'-m','src.experiments.choice_gateway_observer','--cell-budget',config['budget_path'],
  '--shared-unit-budget','--unit-id',config['unit_id'],'--budget-id',config['budget_id'],'--max-attempts',str(config['max_posts']),
  '--events',str(root/'events.jsonl'),'--session-events',str(root/'sessions.jsonl'),'--',
  '--socket',str(root/'gateway.sock'),'--fixed-model-config',config['model_config'],'--incremental-map',
  '--job-compute-policy','shared','--max-active-jobs',str(config['max_jobs']),
  '--max-active-requests',str(config['requests']),'--max-held-tasks',str(config['held_tasks']),
  '--max-connections',str(config['connections']),'--frame-timeout-ms','500']
 write_private_json(root/'gateway-command.json',command)
 with (root/'gateway.log').open('x') as log:
  gateway=subprocess.Popen(command,stdout=log,stderr=log)
  wait_for(lambda:(root/'gateway.sock').exists() or gateway.poll() is not None)
  if gateway.poll() is not None:raise RuntimeError('gateway failed before ready')
  for group in config['parallel_groups']:
   barrier=threading.Barrier(group['queries'])
   with ThreadPoolExecutor(group['queries']) as pool:
    results=[pool.submit(run,group['label']+'-'+str(i),dependent=group['dependent'],barrier=barrier) for i in range(group['queries'])]
    for result in results:result.result(config['query_timeout_s']+5)
   wait_for(lambda:live_jobs()==0)
  with ThreadPoolExecutor(config['max_jobs']) as pool:
   ready=[threading.Event() for _ in range(config['paused_queries'])]
   paused=[pool.submit(run,'paused-'+str(i),paused=e) for i,e in enumerate(ready)]
   try:
    for e in ready:assert e.wait(config['query_timeout_s'])
    wait_for(lambda:live_jobs()==config['paused_queries'])
    time.sleep(config['pause_s'])
    pool.submit(run,'idle-neighbours').result(config['query_timeout_s']+5)
   finally:unpause.set()
   for result in paused:result.result(config['query_timeout_s']+5)
  wait_for(lambda:live_jobs()==0)
  for i in range(config['sequential_queries']):
   run('sequential-'+str(i),limit=1);wait_for(lambda:live_jobs()==0)
  gateway.terminate();gateway.wait(12)
  assert gateway.returncode==0
 all_events=events();sessions=[json.loads(s) for s in (root/'sessions.jsonl').read_text().splitlines()]
 lines=Path(os.environ['SEMLOOM_PG_LOG']).read_text().splitlines();bindings=parse_pg_bindings(lines)
 audits=[];expected_requests=Counter();quality=[]
 def expect(instruction,text,tokens,filter=False):
  messages=json.loads(v3.canonical_messages(instruction,text) if filter else __import__('src.execution_provider.semantic_map',fromlist=['canonical_messages']).canonical_messages(instruction,text))
  generation=v3.GENERATION_CONSTRAINTS if filter else SemanticMapPlan(instruction,model,tokens).generation_constraints()
  expected_requests[json.dumps(dict(model=model,messages=messages,**generation),sort_keys=True)]+=1
 for run_data in runs:
  target=root/run_data['label'];prediction=[]
  evaluate_recording(target,lambda rows:prediction.extend(tuple(r) for r in rows) or {'rows':len(prediction)})
  expected=values if run_data['limit'] is None else values[:run_data['limit']]
  if run_data['dependent']:
   trace=[s for s in lines if 'SEMLOOM_FILTER_BINDING ' in s and json.loads(s.split('SEMLOOM_FILTER_BINDING ',1)[1])['backend_pid']==run_data['backend_pid']]
   decisions=verify_filter_decisions(trace,dict(values),model,complete=True,instruction=config['filter_instruction'])
   expected=[v for v in values if decisions[v[0]]]
   run_data['filter_decisions']=decisions
   for _,text in values:expect(config['filter_instruction'],text,config['filter_tokens'],True)
  for _,text in expected:expect(config['map_instruction'],text,config['map_tokens'])
  peer_sessions={s['session_id'] for s in sessions if s.get('event')=='session_start' and s.get('peer_pid')==run_data['backend_pid']}
  selected=[e for e in all_events if e.get('session_id') in peer_sessions and e['event'] in ('core_map_task','core_map_completion')]
  producer=[b for b in bindings if b.backend_pid==run_data['backend_pid']]
  if expected:
   audits.append(verify_bound_map_results(expected,prediction,producer,selected,sessions,plan=SemanticMapPlan(config['map_instruction'],model,config['map_tokens'])))
  else:assert not prediction and not producer and not selected
  jobs={e['job_id'] for e in all_events if e.get('session_id') in peer_sessions and e['event'] in ('core_map_task','core_filter_completion')}
  assert len(jobs)==1
  run_data['memory']=verify_window_memory(lines,backend_pid=run_data['backend_pid'],retained_limit=config['pg_bytes'],staging_limit=config['staging_bytes'],window=config['window'])
  for key,text in prediction:quality.append(dict(query=run_data['label'],row_id=key,exact_echo=text==dict(values)[key]))
 actual=Counter(json.dumps(e['body'],sort_keys=True) for e in all_events if e['event']=='request')
 assert actual==expected_requests
 counts=Counter(e['event'] for e in all_events);total=sum(actual.values());assert total<=config['max_posts']
 assert counts['core_submitted']==counts['core_terminal']==total
 assert counts['core_job_opened']==counts['core_job_drained']==len(runs)
 running=set()
 for e in all_events:
  if e['event'] not in ('core_submitted','core_terminal'):continue
  key=(e['key']['session_id'],e['key']['sequence'])
  if e['event']=='core_submitted':assert key not in running;running.add(key)
  else:running.remove(key)
  assert len(running)==e['usage']['active_requests']<=config['requests']
 assert not running
 close=[e for e in all_events if e['event']=='core_transport_closed'];assert len(close)==1 and close[0]['closed'] and not any(close[0]['usage'].values())
 write_private_json(root/'summary.json',dict(status='passed',actual_posts=total,queries=len(runs),bindings=audits,
  map_quality=dict(exact=sum(r['exact_echo'] for r in quality),rows=len(quality)),quality=quality,
  filter_kept=sum(sum(r.get('filter_decisions',{}).values()) for r in runs),
  peak_usage={k:max(e['usage'][k] for e in all_events if 'usage' in e) for k in close[0]['usage']}))
finally:
 unpause.set()
 for conn in connections:conn.close()
 if gateway is not None and gateway.poll() is None:
  gateway.terminate()
  try:gateway.wait(12)
  except subprocess.TimeoutExpired:gateway.kill();gateway.wait(3)
 write_private_json(root/'queries.json',runs)
 write_private_json(root/'cleanup.json',dict(gateway_returncode=gateway.poll() if gateway else None))
