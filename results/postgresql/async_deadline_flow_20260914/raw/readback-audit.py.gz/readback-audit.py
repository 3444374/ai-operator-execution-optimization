from pathlib import Path
from collections import Counter
import hashlib,json,sqlite3,sys
from src.baselines.common.private_artifacts import write_private_json,content_digest
from src.baselines.text.sembench_movie import MOVIE_MAP_INSTRUCTION
from src.execution_provider.semantic_map import SemanticMapPlan
from src.experiments.postgresql.query_config import QueryConfig
from src.experiments.postgresql.query_inputs import QueryInputs
from src.experiments.postgresql.query_workloads import read_prepared
from src.experiments.postgresql.query_evaluation import _evaluate_rows,http_accounting
from src.experiments.postgresql.map_direct import request_body
from src.experiments.postgresql.native_map_bindings import verify_native_map_results
from src.experiments.postgresql.flow_timing import analyze_flow
base=Path('<artifact-root>')

def read_record(root,n,completed=True):
 e=json.loads((root/'q0/execution.json').read_text());b=(root/'q0/results.jsonl').read_bytes();rows=[json.loads(x) for x in b.splitlines()]
 assert e['status']==('completed' if completed else 'failed') and e['recorded_rows']==len(rows)==n
 assert e['recorded_bytes']==len(b) and e['results_sha256']==hashlib.sha256(b).hexdigest()
 assert e['t_release_ns']<=e['t_first_row_ns']<=e['t_last_row_ns']<=e['t_query_terminal_ns']<=e['t_stream_cleanup_ns']<=e['t_results_durable_ns']<=e['ended_ns']
 return e,rows

def extended_flow(root):
 flow=analyze_flow(root,expected_rows=8,window=4);events=[json.loads(x) for x in (root/'events.jsonl').read_text().splitlines()]
 submits=[e for e in events if e['event']=='core_submitted'];terminals=[e for e in events if e['event']=='core_terminal']
 key=lambda e:(e['key']['session_id'],e['key']['sequence'])
 assert Counter(map(key,submits))==Counter(map(key,terminals)) and len(terminals)==8
 terminal={e['key']['sequence']:e['monotonic_ns'] for e in terminals}
 for row in flow['rows']:
  t=row['times_ns'];t['core_terminal']=terminal[row['sequence']]
  assert t['core_submitted']<=t['core_terminal']<=t['result_ready']
  row['core_terminal_to_pg_ready_s']=(t['result_ready']-t['core_terminal'])/1e9
  row['core_terminal_to_client_s']=(t['client_received']-t['core_terminal'])/1e9
  # The preceding node return releases the input-order head-of-line dependency.
  eligible=max(t['result_ready'],flow['rows'][row['input_index']-1]['times_ns']['node_return'] if row['input_index'] else t['result_ready'])
  row['eligible_to_node_s']=(t['node_return']-eligible)/1e9
 return flow

if sys.argv[1:]==['controlled']:
 r=base/'controlled-v2/flow';reports=[]
 for saved in json.loads((r/'flow-comparison.json').read_text()):
  u=r/saved['unit'];e,rows=read_record(u,8);s=json.loads((u/'summary.json').read_text());c=QueryConfig(**s['config'])
  audit=_evaluate_rows(c,QueryInputs('movie',c.table,8),SemanticMapPlan(MOVIE_MAP_INSTRUCTION,'model',128),
   r/'flow-workload/manifest.json',u,None,[x['row'] for x in rows])
  assert audit==s['evaluation']
  reports.append(dict(unit=saved['unit'],repeat=saved['repeat'],evaluation_replayed=True,flow=extended_flow(u)))
 with sqlite3.connect(r/'budget.sqlite') as db:
  spent=db.execute('SELECT count(*) FROM shared_requests').fetchone()[0];closed=db.execute('SELECT count(*) FROM closed_shared_units').fetchone()[0]
 assert spent==96 and closed==12
 write_private_json(base/'controlled-readback.json',dict(status='passed',actual_posts=spent,closed_units=closed,units=reports))
 print('controlled readback passed: 12 units, 96 requests')
else:
 assert sys.argv[1:]==['real'];r=base/'real-run';p=base/'real-proposal';reports=[];predictions={}
 campaign=json.loads((r/'campaign-result.json').read_text());assert campaign['status']=='passed'
 for unit in json.loads((p/'schedule.json').read_text())['units']:
  name=unit['name'];u=r/name;c=QueryConfig(**json.loads((p/unit['config_file']).read_text()));manifest=p/unit['manifest']
  e,rows=read_record(u,c.max_posts,completed=name!='deadline');plan=SemanticMapPlan(MOVIE_MAP_INSTRUCTION,'Qwen2.5-7B-Instruct',128)
  if name!='deadline':
   audit=_evaluate_rows(c,QueryInputs('movie',c.table,8),plan,manifest,u,None,[x['row'] for x in rows]);assert audit==json.loads((u/'summary.json').read_text())['evaluation']
   predictions[name]=dict(x['row'] for x in rows)
   report=dict(unit=name,evaluation_replayed=True,evaluation=audit,execution=e)
   if unit['profile']=='probe':report['flow']=extended_flow(u)
  else:
   raw=list(read_prepared(manifest,'raw.jsonl'));texts={v[1]:v[3] for v in raw};events=[json.loads(x) for x in (u/'events.jsonl').read_text().splitlines()]
   pred=dict(x['row'] for x in rows)
   requests=[e['body'] for e in events if e['event']=='request'];assert Counter(map(content_digest,requests))==Counter(content_digest(request_body(plan,t)) for t in texts.values())
   binding=verify_native_map_results(c.arm,texts,pred,events,plan=plan,source_positions={v[1]:v[0] for v in raw})
   http=http_accounting(events,4);assert http['started_requests']==1 and http['final_http_active']==0
   report=dict(unit=name,expected_timeout=True,association=binding,http=http,execution=e,scoring_performed=False)
  reports.append(report)
 baseline=predictions['pg'];differences={name:[key for key in baseline if value[key]!=baseline[key]] for name,value in predictions.items()}
 write_private_json(base/'real-readback.json',dict(status='passed',actual_posts=57,completed_rows=56,provisional_rows=1,
   prediction_differences_from_pg=differences,units=reports))
 print(json.dumps(dict(status='passed',actual_posts=57,prediction_differences=differences)))
