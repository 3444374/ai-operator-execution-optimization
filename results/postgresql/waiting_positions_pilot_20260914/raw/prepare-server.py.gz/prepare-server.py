from pathlib import Path
import os,shutil,subprocess,json,hashlib
root=Path('<artifact-root>');source=root/'source'
python='<driver-venv>/bin/python'
from src.baselines.common.redact import redact_text
envfile=root/'runtime.env'
envfile.write_text(Path('<data-root>/sq-e/runtime.env').read_text().replace('<data-root>/sq-e',str(root)))
envfile.chmod(0o600)
env=dict(os.environ,AI_OPERATOR_ENV_FILE=str(envfile),PYTHONPATH=str(source/'code'))
for key in ('http_proxy','https_proxy','HTTP_PROXY','HTTPS_PROXY','RAY_ADDRESS'):env.pop(key,None)
r=subprocess.run([python,'code/scripts/environment/manage_environment.py','check','--groups','core,text,semantic-benchmarks','--json-out',str(root/'preflight.json')],cwd=source,env=env,capture_output=True,text=True)
(root/'preflight.log').write_text(redact_text(r.stdout+r.stderr))
assert r.returncode==0
assert json.loads((root/'preflight.json').read_text())['status']=='ok'
prefix=Path('/opt/semloom-pg18.3-m1-probe')
shutil.copytree('/opt/semloom-pg18.3-flow-normal',prefix,symlinks=True)
shutil.copytree(source/'code',root/'check/code',ignore=shutil.ignore_patterns('__pycache__'))
build=root/'check/code/postgres/semloom_pg'
flags=['PG_CONFIG='+str(prefix/'bin/pg_config'),'PG_CFLAGS=-O2 -Werror','SEMLOOM_FLOW_DIAGNOSTIC=1']
for name,command in [('build',['make','-j8',*flags]),('install',['make','install',*flags])]:
    r=subprocess.run(command,cwd=build,env=env,capture_output=True,text=True,timeout=180)
    (root/(name+'.log')).write_text(redact_text(r.stdout+r.stderr))
    assert r.returncode==0,name
    print(name,'passed',flush=True)
lib=prefix/'lib/semloom_pg.so'
if not lib.exists():lib=prefix/'lib/postgresql/semloom_pg.so'
(root/'build.json').write_text(json.dumps(dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),library_sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),flags=flags),indent=2))
