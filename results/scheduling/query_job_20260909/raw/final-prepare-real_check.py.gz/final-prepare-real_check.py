"""Bounded real PG query-Job qualification; exact counts, not a throughput comparison."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import pwd
import sys
import time

import psycopg
from psycopg import sql
from src.baselines.common.redact import redact_text
from src.experiments.attempt_ledger import AttemptBudget, AttemptLedger
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster, owned_child_process, wait_for_path


def save(path, value):
    path.write_text(redact_text(json.dumps(value, indent=2)) + '\n')


def until(predicate, label):
    deadline = time.monotonic() + 30
    while not predicate():
        assert time.monotonic() < deadline, label
        time.sleep(.01)


def run(settings):
    root, source = Path(settings['root']), Path(settings['source'])
    root.mkdir()
    for name, digest in settings['source_delta'].items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest() == digest, name
    assert hashlib.sha256((Path(settings['prefix'])/'lib/postgresql/semloom_pg.so').read_bytes()).hexdigest() == settings['extension_sha256']
    config = json.loads(Path(settings['config']).read_text())
    assert settings['budget_limit'] == 24
    ledger = AttemptLedger(Path(settings['ledger']), AttemptBudget(settings['budget_id'], 24))
    assert ledger.attempts == 0
    trace = root/'gateway-events.jsonl'
    summary = {'status':'incomplete', 'max_requests':24, 'checks':{}}
    def events():
        return [json.loads(line) for line in trace.read_text().splitlines()] if trace.exists() else []
    def selected(kind):
        return [e for e in events() if e['event'] == 'core_'+kind]
    def idle():
        until(lambda: len(selected('job_opened')) == len(selected('job_drained')), 'query_jobs_drained')
    user = pwd.getpwuid(os.getuid())
    try:
        with isolated_pg18_cluster(Path(settings['prefix']), root, user, port=settings['pg_port']) as conn:
            conn.execute("CREATE TABLE inputs(id integer, body text); INSERT INTO inputs VALUES (1,'TRUE'),(2,'TRUE'),(3,NULL)")
            conn.execute('CREATE TABLE rejected(id integer CHECK(id<0), body text)')
            conn.execute("CREATE FUNCTION slow_input(x text) RETURNS text LANGUAGE plpgsql VOLATILE STRICT AS $$ BEGIN PERFORM pg_sleep(30); RETURN x; END $$")
            params = dict(host=conn.info.host,port=conn.info.port,user=conn.info.user,dbname=conn.info.dbname,autocommit=True)
            def options(tokens):
                return sql.Literal(json.dumps({'model':config['model_id'],'temperature':0,'max_tokens':tokens}))
            filt = sql.SQL("ai_semantic.filter(body,'The input text equals TRUE.',{}::jsonb)").format(options(8))
            filt2 = sql.SQL("ai_semantic.filter(body,'The input text equals TRUE.',{}::jsonb)").format(options(8))
            def map_expression(input_expression):
                return sql.SQL("ai_semantic.map({},'Return only the input text exactly as received. Do not add or remove anything.',{}::jsonb)").format(input_expression,options(128))
            mapped = map_expression(sql.SQL('body'))
            composed = sql.SQL('SELECT id,{} FROM ONLY inputs WHERE {}').format(mapped,filt)
            double = sql.SQL('SELECT id FROM ONLY inputs WHERE {} AND {} LIMIT 1').format(filt,filt2)
            sock=root/'socket'/'query.sock'
            command=[sys.executable,'-m','src.experiments.choice_gateway_observer','--events',str(trace),
                     '--ledger',settings['ledger'],'--budget-id',settings['budget_id'],'--max-attempts','24',
                     '--','--socket',str(sock),'--fixed-model-config',settings['config'],'--incremental-map',
                     '--max-active-jobs','3','--max-connections','12','--max-held-tasks','6','--max-active-requests','2']
            def configure(c):
                c.execute("SELECT set_config('semloom_pg.gateway_socket',%s,false)",(str(sock),))
                c.execute("SET semloom_pg.provider_execution_profile='query-job'; SET statement_timeout='60s'")
            with owned_child_process(command,root,'gateway',dict(os.environ,PYTHONPATH=str(source/'code')),user) as proc:
                wait_for_path(sock,proc);configure(conn)
                assert conn.execute(composed+sql.SQL(' LIMIT 0')).fetchall() == []
                assert conn.execute(composed+sql.SQL(' AND id=3')).fetchall() == []
                plan=conn.execute(sql.SQL('EXPLAIN (FORMAT JSON) ')+composed).fetchone()[0]
                assert json.dumps(plan).count('Query Job Binding Version') == 2
                double_plan=conn.execute(sql.SQL('EXPLAIN (FORMAT JSON) ')+double).fetchone()[0]
                assert json.dumps(double_plan).count('Query Job Binding Version') == 2, 'duplicate_filter_occurrences_preserved'
                assert ledger.attempts == 0 and not selected('job_opened')
                summary['checks']['zero_work']=True
                def checked(query, expected, calls):
                    before, jobs=ledger.attempts,len(selected('job_opened'))
                    assert conn.execute(query).fetchall()==expected
                    idle()
                    assert ledger.attempts-before==calls
                    assert len(selected('job_opened'))-jobs==1
                checked(double,[(1,)],2)
                checked(composed+sql.SQL(' LIMIT 1'),[(1,'TRUE')],2)
                conn.execute(sql.SQL('PREPARE q AS ')+double)
                checked('EXECUTE q',[(1,)],2);checked('EXECUTE q',[(1,)],2)
                conn.execute('DEALLOCATE q')
                summary['checks']['composition_and_prepared']=True
                def independent():
                    with psycopg.connect(**params) as c:
                        configure(c)
                        return c.execute(composed+sql.SQL(' LIMIT 1')).fetchall()
                before=len(selected('job_opened'))
                with ThreadPoolExecutor(max_workers=2) as pool:
                    assert list(pool.map(lambda _:independent(),range(2)))==[[(1,'TRUE')],[(1,'TRUE')]]
                idle();assert len(selected('job_opened'))-before==2 and ledger.attempts==12
                summary['checks']['two_backends']=True
                conn.execute('BEGIN')
                conn.execute(sql.SQL('DECLARE a CURSOR FOR ')+composed)
                conn.execute(sql.SQL('DECLARE b CURSOR FOR ')+composed)
                assert conn.execute('FETCH 1 FROM a').fetchall()==[(1,'TRUE')]
                assert conn.execute('FETCH 1 FROM b').fetchall()==[(1,'TRUE')]
                assert len(selected('job_opened'))-len(selected('job_drained'))==2
                conn.execute('CLOSE a')
                until(lambda:len(selected('job_opened'))-len(selected('job_drained'))==1,'other_cursor_alive')
                conn.execute('CLOSE b; COMMIT');idle()
                assert ledger.attempts==16
                summary['checks']['same_backend_cursors']=True
                conn.execute('BEGIN; SAVEPOINT s')
                try:
                    conn.execute(sql.SQL('INSERT INTO rejected ')+composed+sql.SQL(' LIMIT 1'))
                    raise AssertionError('missing check violation')
                except psycopg.errors.CheckViolation:
                    conn.execute('ROLLBACK TO s; COMMIT')
                idle();assert ledger.attempts==18
                checked(sql.SQL('SELECT {} FROM ONLY inputs LIMIT 1').format(mapped),[('TRUE',)],1)
                summary['checks']['transaction_error']=True
                # Cancel the PG query after both streams have run, while PG owns a sleeping input.
                # Controlled tests separately cover an outstanding model response at cancellation.
                with psycopg.connect(**params) as slow:
                    configure(slow);pid=slow.info.backend_pid
                    delayed=map_expression(sql.SQL('CASE WHEN id=2 THEN slow_input(body) ELSE body END'))
                    query=sql.SQL('SELECT id,{} FROM ONLY inputs WHERE {}').format(delayed,filt)
                    with ThreadPoolExecutor(max_workers=1) as pool:
                        future=pool.submit(lambda:slow.execute(query).fetchall())
                        until(lambda:conn.execute('SELECT wait_event FROM pg_stat_activity WHERE pid=%s',(pid,)).fetchone()==('PgSleep',),'PG_input_wait')
                        assert ledger.attempts==22
                        slow.cancel()
                        try:
                            future.result(10)
                            raise AssertionError('cancel did not cancel')
                        except psycopg.errors.QueryCanceled:
                            pass
                        idle()
                checked(composed+sql.SQL(' LIMIT 1'),[(1,'TRUE')],2)
                summary['checks']['cancel_and_recovery']=True
                assert ledger.attempts==24
                joins=selected('query_flow_joined')
                by_job={}
                for e in joins:by_job.setdefault(e['job_id'],[]).append(e['flow'])
                assert sum(sorted(v)==[0,1] for v in by_job.values())==11
                assert sum(v==[0] for v in by_job.values())==1
                assert len(selected('filter_completion'))==15
                assert len(selected('map_completion'))==9
                assert all(e['usage']['held_tasks']==0 and e['usage']['active_requests']==0 for e in selected('job_drained'))
                summary.update(status='passed',requests=ledger.attempts,query_flows=by_job,plan=plan)
            assert proc.returncode==0
            assert not sock.exists()
    finally:
        summary['actual_requests']=ledger.attempts
        save(root/'summary.json',summary)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--settings',required=True)
    args=parser.parse_args();run(json.loads(Path(args.settings).read_text()))
