import gzip,hashlib,json,sys
from pathlib import Path
from dataclasses import fields
from src.execution_provider.adapters.map_organization import MapOrganizationConfig
from src.experiments.postgresql.organization_evaluation import verify_organization
root=Path('experiments/results/postgresql/cd_validation_20260911/raw')
manifest=json.loads((root/'manifest.json').read_text())
results=[]
def checked(path):
    data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()==manifest[path.name]['sha256']
    return data
def audit(path,expected,requests,expected_sha):
    data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==expected_sha
    events=[json.loads(l) for l in gzip.decompress(data).splitlines()]
    event=next(e for e in events if e['event']=='core_map_organization_config')
    config=MapOrganizationConfig(**{f.name:('fixture' if f.name=='tokenizer_path' else event[f.name])
                                   for f in fields(MapOrganizationConfig)})
    actual=verify_organization(config,events,max_active_requests=requests,expected_max_new_tokens=128)
    assert actual==expected,(path,'changed nonempty audit result')
    results.append(dict(source=str(path),sha256=expected_sha,rows=actual['rows'],unchanged_audit=True))
for path in sorted(root.glob('*-organization-events.jsonl.gz')):
    expected=json.loads(gzip.decompress(checked(path.with_name(path.name.replace('-organization-events.jsonl.gz','-q0-evaluation.json.gz')))))['result']['organization']
    audit(path,expected,32,manifest[path.name]['sha256'])
old=root/'local-historical-replay-final.json.gz'
for entry in json.loads(gzip.decompress(checked(old)))['traces']:
    audit(Path(entry['source']),entry['result'],entry['result']['compute_lifecycle']['request_capacity'],entry['sha256'])
Path(sys.argv[1]).write_text(json.dumps(dict(
    audit_source_sha256=hashlib.sha256(Path('code/src/experiments/postgresql/organization_evaluation.py').read_bytes()).hexdigest(),
    scope='offline replay only; no new model or PG queries',traces=results),indent=2)+'\n')
print(len(results),'unchanged nonempty audits;',sum(r['rows'] for r in results),'tasks')
