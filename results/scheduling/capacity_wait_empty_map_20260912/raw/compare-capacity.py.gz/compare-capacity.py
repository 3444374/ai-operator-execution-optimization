"""Compare the archived and revised Core with real capacity and deterministic time."""
import hashlib,json,subprocess,sys,types
from pathlib import Path
from src.scheduling.core.session import SessionEngine
from src.scheduling.core.session_contract import SessionSpec,TaskKey
from src.scheduling.core.session_jobs import JobBudget
from tests.scheduling.test_incremental_session import setup,task
source=subprocess.check_output(['git','show','3a097d36:code/src/scheduling/core/session.py'])
module=types.ModuleType('src.scheduling.core._comparison_baseline')
module.__package__='src.scheduling.core'
sys.modules[module.__name__]=module
exec(compile(source,'baseline-session.py','exec'),module.__dict__)
rows=[]
for version,cls in [('before',module.SessionEngine),('after',SessionEngine)]:
    for registered in (False,True):
        original,_,backend,clock=setup(held_tasks=4,input_bytes=16,result_bytes=16,
            active_requests=2,active_work=10,poll_interval_s=.01)
        engine=cls(original.capacity.limits,backend,original.policies,clock=clock)
        if registered:
            job=engine.register_job('job',JobBudget(4,16,16,2,10))
            session=engine.open(SessionSpec(job.job_id,'flow','fixture'),job=job)
        else:session=engine.open(SessionSpec('job','flow','fixture'))
        session.offer([task(i,estimated_work=w) for i,w in enumerate((6,5,4))])
        for now in (0,.001,.01):
            clock.now=now
            if now==.001:backend.complete(TaskKey(0,0))
            if registered:engine.advance()
            result=session.advance(4)
            session.release([d.lease_id for d in result.deliveries])
            rows.append(dict(version=version,registered=registered,now_s=now,
                pending=[k.sequence for k in backend.pending],active_work=engine.capacity.usage().active_work,
                retry_at_s=session._retry_at))
for registered in (False,True):
    before=next(r for r in rows if r['registered']==registered and r['version']=='before' and r['now_s']==.001)
    after=next(r for r in rows if r['registered']==registered and r['version']=='after' and r['now_s']==.001)
    assert before['active_work']==0 and before['pending']==[] and before['retry_at_s']==.01
    assert after['pending']==[1,2] and after['active_work']==9
Path(sys.argv[1]).write_text(json.dumps(dict(scope='deterministic fixture; not observed server latency',
    before_source_sha256=hashlib.sha256(source).hexdigest(),
    after_source_sha256=hashlib.sha256(Path('code/src/scheduling/core/session.py').read_bytes()).hexdigest(),
    timeline=rows),indent=2)+'\n')
print('baseline and revised actual Core timeline verified')
