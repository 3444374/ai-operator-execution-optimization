"""Bounded real-model validation of PG v6 intake, compared with synchronous Map."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pwd
import sys
import threading
import time

import psycopg
from psycopg import sql
from transformers import AutoTokenizer
from src.baselines.common.redact import redact_text
from src.experiments.attempt_ledger import AttemptBudget, AttemptLedger
from src.experiments.postgresql.runtime_helpers import isolated_pg18_cluster, owned_child_process, wait_for_path
from src.execution_provider.semantic_map import SemanticMapPlan
from src.execution_provider.wire import v6

INSTRUCTION = 'Return only the input text exactly as received. Do not add or remove anything.'


def save(path, value):
    path.write_text(redact_text(json.dumps(value, indent=2, ensure_ascii=False)) + '\n')


def events(path):
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []


def until(predicate, label, seconds=30):
    deadline = time.monotonic() + seconds
    while not predicate():
        assert time.monotonic() < deadline, label
        time.sleep(.01)


def run(settings):
    root = Path(settings['root'])
    root.mkdir()
    source = Path(settings['source'])
    for name, digest in settings['source_delta'].items():
        assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, 'source_identity'
    assert hashlib.sha256((Path(settings['prefix']) / 'lib/postgresql/semloom_pg.so').read_bytes()).hexdigest() == settings['extension_sha256']
    config = json.loads(Path(settings['config']).read_text())
    window = settings['window']
    request_limit = 8 + 2 * window
    assert settings['budget_limit'] == request_limit
    ledger = AttemptLedger(Path(settings['ledger']), AttemptBudget(settings['budget_id'], request_limit))
    assert ledger.attempts == 0
    tokenizer = AutoTokenizer.from_pretrained(settings['model_root'], local_files_only=True)
    summary = {'status': 'incomplete', 'request_limit': request_limit, 'multi_inflight_pg': window > 1, 'window': window, 'phases': {}}
    try:
        with isolated_pg18_cluster(Path(settings['prefix']), root, pwd.getpwuid(os.getuid()), port=settings['pg_port']) as conn:
            conn.execute('CREATE TABLE inputs(id integer, body text)')
            conn.execute('CREATE TABLE outputs(id integer, body text, generated text)')
            conn.execute('CREATE TABLE rejected(id integer CHECK(id<0), body text, generated text)')
            with conn.cursor() as cur:
                cur.executemany('INSERT INTO inputs VALUES (%s,%s)', [(1,'Hello, SemLoom.'),(2,'Blue sky.'),(3,None)])
            parameters = dict(host=conn.info.host,port=conn.info.port,user=conn.info.user,dbname=conn.info.dbname,autocommit=True)
            options = json.dumps({'model':config['model_id'],'temperature':0,'max_tokens':128})
            expression = sql.SQL('ai_semantic.map(body,{},{}::jsonb)').format(sql.Literal(INSTRUCTION),sql.Literal(options))
            query = sql.SQL('SELECT id,body,{} FROM ONLY inputs').format(expression)
            reference = None
            for mode in ('reference','incremental'):
                path = root / (mode+'-events.jsonl')
                sock = root / 'socket' / (mode+'.sock')
                command = [sys.executable,'-m','src.experiments.choice_gateway_observer','--events',str(path),
                    '--ledger',settings['ledger'],'--budget-id',settings['budget_id'],'--max-attempts',str(request_limit),
                    '--','--socket',str(sock),'--fixed-model-config',settings['config'],'--max-active-requests',str(window)]
                profile = settings.get('reference_profile', 'openai-compatible-fixed') if mode == 'reference' else 'incremental-map'
                if mode == 'incremental':
                    command += ['--incremental-map', '--max-held-tasks', str(window)]
                elif profile == 'incremental-map-window-one':
                    command += ['--incremental-map-window-one']
                with owned_child_process(command,root,mode,dict(os.environ,PYTHONPATH=str(source/'code')),pwd.getpwuid(os.getuid())) as process:
                    wait_for_path(sock,process)
                    def configure(c):
                        c.execute("SELECT set_config('semloom_pg.gateway_socket',%s,false)",(str(sock),))
                        c.execute("SELECT set_config('semloom_pg.provider_execution_profile',%s,false)",(profile,))
                        c.execute("SELECT set_config('semloom_pg.provider_window_tasks',%s,false)",(str(window),))
                        c.execute("SET statement_timeout='120s'")
                    configure(conn)
                    before = ledger.attempts
                    assert conn.execute(query+sql.SQL(' LIMIT 0')).fetchall() == []
                    assert conn.execute(query+sql.SQL(' WHERE id=3')).fetchall() == [(3,None,None)]
                    plan = conn.execute(sql.SQL('EXPLAIN (FORMAT JSON) ')+query).fetchone()[0]
                    assert ledger.attempts == before, 'zero_controls'
                    rows = conn.execute(query).fetchall()
                    completion_event = 'completion' if mode=='reference' else 'core_map_completion'
                    until(lambda:len([e for e in events(path) if e['event']==completion_event])==2, 'completion_observation')
                    completed = [e for e in events(path) if e['event'] == completion_event]
                    by_sequence = {e.get('sequence',i):e['raw_output'] for i,e in enumerate(completed)}
                    assert rows == [(1,'Hello, SemLoom.',by_sequence[0]),(2,'Blue sky.',by_sequence[1]),(3,None,None)], 'sql_result_binding'
                    assert ledger.attempts-before == 2
                    summary['phases'][mode] = {'rows':rows,'plan':plan,'zero_controls':True}
                    if mode == 'reference':
                        reference = rows
                    else:
                        assert rows == reference, 'reference_parity'
                        assert 'semloom_incremental_map' in json.dumps(plan) and f'"Semantic Input Window": {window}' in json.dumps(plan), 'actual_pg_window'
                        conn.execute(sql.SQL('INSERT INTO outputs ')+query)
                        with psycopg.connect(**parameters) as audit:
                            assert audit.execute('SELECT * FROM outputs ORDER BY id').fetchall() == rows, 'insert_audit'
                        try:
                            conn.execute(sql.SQL('INSERT INTO rejected ')+query)
                            raise AssertionError('expected_constraint_failure')
                        except psycopg.errors.CheckViolation:
                            pass
                        assert conn.execute('SELECT count(*) FROM rejected').fetchone()[0] == 0
                        until(lambda: ledger.attempts==6+window, 'constraint_request_bound')
                        cancellation = []
                        with psycopg.connect(**parameters) as cancelled:
                            configure(cancelled)
                            long_options = json.dumps({'model':config['model_id'],'temperature':0,'max_tokens':256})
                            long_query = sql.SQL('SELECT ai_semantic.map(body,{},{}::jsonb) FROM ONLY inputs').format(
                                sql.Literal('Write a detailed numbered list of one hundred facts about astronomy. Do not stop early.'),sql.Literal(long_options))
                            def execute_cancelled():
                                try:
                                    cancelled.execute(long_query).fetchall()
                                    cancellation.append('unexpected_success')
                                except psycopg.Error as exc:
                                    cancellation.append(exc.sqlstate)
                            worker = threading.Thread(target=execute_cancelled)
                            worker.start()
                            until(lambda: ledger.attempts==6+2*window, 'bounded_cancel_requests')
                            assert worker.is_alive(), 'cancel_before_completion'
                            cancelled.cancel()
                            worker.join(30)
                            assert not worker.is_alive() and cancellation==['57014']
                        assert conn.execute(query+sql.SQL(' WHERE id=1 LIMIT 1')).fetchall() == rows[:1], 'recovery'
                        assert conn.execute(query+sql.SQL(' LIMIT 1')).fetchall() == rows[:1], 'limit_one'
                        until(lambda:len([e for e in events(path) if e['event']=='core_drained'])==6, 'all_sessions_drained')
                        seen = events(path)
                        submitted = [e for e in seen if e['event']=='core_submitted']
                        terminal = [e for e in seen if e['event']=='core_terminal']
                        drained = [e for e in seen if e['event']=='core_drained']
                        assert len(submitted)==len(terminal)==6+2*window
                        assert all(not any(e['usage'].values()) for e in drained)
                        active = set()
                        peak = 0
                        for event in seen:
                            if event['event'] in ('core_http_started','core_http_finished'):
                                key = (event['key']['session_id'],event['key']['sequence'])
                                if event['event']=='core_http_started':
                                    assert key not in active
                                    active.add(key)
                                    peak = max(peak,len(active))
                                    assert len({item[0] for item in active})==1, 'same_query_concurrency'
                                else:
                                    active.remove(key)
                        assert peak==window and not active, 'actual_overlapping_http'
                        summary.update(http_peak=peak,incremental_tasks=6+2*window,drained_sessions=6,cancel_sqlstate='57014',resources_zero=True)
                        model_results = [e for e in seen if e['event']=='core_map_completion']
                        requests = [e for e in seen if e['event']=='request']
                        for result in model_results:
                            matches = []
                            for event in requests:
                                body = event['body']
                                plan_spec = SemanticMapPlan(body['messages'][0]['content'],body['model'],body['max_tokens'])
                                digest = v6.build_task_message(plan_spec,sequence=0,input_value=body['messages'][1]['content'])['semantic_payload_digest']
                                if digest==result['payload_digest']:
                                    matches.append(body)
                            assert matches, 'completion_request_identity'
                            body = matches[0]
                            assert result['response_model_id']==config['model_id']
                            assert result['prompt_tokens']==len(tokenizer.apply_chat_template(body['messages'],tokenize=True,add_generation_prompt=True,return_dict=False))
                            assert 0<result['output_tokens']<=body['max_tokens']
                if mode=='incremental':
                    closed=[e for e in events(path) if e['event']=='core_transport_closed']
                    assert len(closed)==1 and closed[0]['closed'] and not any(closed[0]['usage'].values())
                assert not sock.exists()
            assert ledger.attempts==request_limit
        assert not (root/'data/postmaster.pid').exists()
        summary['status']='passed'
    finally:
        summary['model_requests']=ledger.attempts
        save(root/'summary.json',summary)


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--settings',type=Path,required=True)
    args=parser.parse_args()
    run(json.loads(args.settings.read_text()))
